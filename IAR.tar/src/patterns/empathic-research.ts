/**
 * Empathic Research Interface Patterns
 * 
 * This file implements empathic research interface patterns based on the
 * quantum-coherent research semantics specification.
 */

import { 
  Result, 
  AsyncResult, 
  Option, 
  some, 
  none, 
  ok, 
  err,
  TypeGuard
} from '@/types/utils';
import { 
  ResearcherModel,
  CognitiveProfile,
  EmotionalState,
  ResearchStyle,
  DomainExpertiseSystem,
  CollaborativeInsight,
  ExpertiseProfile,
  ResearchDomain,
  ProcessingStyle,
  ResearchApproach,
  ResearchMethodology
} from '@/types/quantum-research';

// Empathic Research Interface Core
export class EmpathicResearchInterface {
  private researcherUnderstanding: ResearcherUnderstandingSystem;
  private domainEmpathy: DomainEmpathySystem;
  private collaborativeIntuition: CollaborativeIntuitionSystem;
  private adaptationEngine: AdaptationEngine;
  private coherenceMonitor: CoherenceMonitor;

  constructor() {
    this.researcherUnderstanding = new ResearcherUnderstandingSystem();
    this.domainEmpathy = new DomainEmpathySystem();
    this.collaborativeIntuition = new CollaborativeIntuitionSystem();
    this.adaptationEngine = new AdaptationEngine();
    this.coherenceMonitor = new CoherenceMonitor();
  }

  async understandResearcherNeeds(researcher: Researcher): Promise<Result<ResearchGuidance>> {
    try {
      const expertiseLevel = await this.researcherUnderstanding.analyzeExpertise(researcher);
      const domainContext = await this.domainEmpathy.understandContext(researcher);
      const collaborativePotential = await this.collaborativeIntuition.assessSynergy(researcher);
      
      const guidance = new ResearchGuidance(expertiseLevel, domainContext, collaborativePotential);
      return ok(guidance);
    } catch (error) {
      return err(error instanceof Error ? error : new Error('Failed to understand researcher needs'));
    }
  }

  async adaptToResearcher(researcher: Researcher): Promise<Result<AdaptationResult>> {
    try {
      const adaptation = await this.adaptationEngine.createAdaptation(researcher);
      const coherence = await this.coherenceMonitor.assessCoherence(adaptation);
      
      const result: AdaptationResult = {
        success: true,
        adaptation,
        coherence,
        timestamp: Date.now()
      };
      
      return ok(result);
    } catch (error) {
      return err(error instanceof Error ? error : new Error('Failed to adapt to researcher'));
    }
  }

  async provideEmpathicGuidance(researcher: Researcher, context: ResearchContext): Promise<Result<EmpathicGuidance>> {
    try {
      const emotionalState = await this.researcherUnderstanding.assessEmotionalState(researcher);
      const cognitiveLoad = await this.researcherUnderstanding.assessCognitiveLoad(researcher);
      const domainUnderstanding = await this.domainEmpathy.assessDomainUnderstanding(researcher, context);
      
      const guidance = new EmpathicGuidance(emotionalState, cognitiveLoad, domainUnderstanding, context);
      return ok(guidance);
    } catch (error) {
      return err(error instanceof Error ? error : new Error('Failed to provide empathic guidance'));
    }
  }

  async maintainEmpathicCoherence(researcher: Researcher): Promise<Result<CoherenceStatus>> {
    try {
      const coherence = await this.coherenceMonitor.monitorCoherence(researcher);
      const adaptations = await this.adaptationEngine.maintainCoherence(researcher, coherence);
      
      const status: CoherenceStatus = {
        overall: coherence.overall,
        dimensional: coherence.dimensional,
        stability: coherence.stability,
        adaptations,
        timestamp: Date.now()
      };
      
      return ok(status);
    } catch (error) {
      return err(error instanceof Error ? error : new Error('Failed to maintain empathic coherence'));
    }
  }
}

// Researcher Understanding System
class ResearcherUnderstandingSystem {
  private cognitiveModels: Map<string, CognitiveProfile> = new Map();
  private emotionalModels: Map<string, EmotionalState> = new Map();
  private styleModels: Map<string, ResearchStyle> = new Map();

  async analyzeExpertise(researcher: Researcher): Promise<ExpertiseLevel> {
    const cognitiveProfile = await this.assessCognitiveProfile(researcher);
    const domainKnowledge = await this.assessDomainKnowledge(researcher);
    const experienceLevel = await this.assessExperienceLevel(researcher);
    
    return new ExpertiseLevel(cognitiveProfile, domainKnowledge, experienceLevel);
  }

  async assessCognitiveProfile(researcher: Researcher): Promise<CognitiveProfile> {
    const processingStyle = this.determineProcessingStyle(researcher);
    const creativity = this.assessCreativity(researcher);
    const analytical = this.assessAnalytical(researcher);
    const intuition = this.assessIntuition(researcher);
    const coherence = this.calculateCognitiveCoherence(creativity, analytical, intuition);
    
    return {
      processingStyle,
      creativity,
      analytical,
      intuition,
      coherence
    };
  }

  async assessEmotionalState(researcher: Researcher): Promise<EmotionalState> {
    const engagement = this.assessEngagement(researcher);
    const curiosity = this.assessCuriosity(researcher);
    const frustration = this.assessFrustration(researcher);
    const inspiration = this.assessInspiration(researcher);
    const coherence = this.calculateEmotionalCoherence(engagement, curiosity, frustration, inspiration);
    
    return {
      engagement,
      curiosity,
      frustration,
      inspiration,
      coherence
    };
  }

  async assessCognitiveLoad(researcher: Researcher): Promise<CognitiveLoad> {
    const workingMemory = this.assessWorkingMemory(researcher);
    const attention = this.assessAttention(researcher);
    const processingSpeed = this.assessProcessingSpeed(researcher);
    const coherence = this.calculateLoadCoherence(workingMemory, attention, processingSpeed);
    
    return new CognitiveLoad(workingMemory, attention, processingSpeed, coherence);
  }

  private determineProcessingStyle(researcher: Researcher): ProcessingStyle {
    // Analyze researcher's approach to determine processing style
    const patterns = researcher.researchPatterns;
    const preferences = researcher.preferences;
    
    if (patterns.holistic > 0.7) return 'holistic';
    if (patterns.quantum > 0.6) return 'quantum';
    if (patterns.emergent > 0.5) return 'emergent';
    return 'linear';
  }

  private assessCreativity(researcher: Researcher): number {
    // Assess creativity based on past work and approaches
    return researcher.creativityMetrics.originality * 0.4 +
           researcher.creativityMetrics.fluency * 0.3 +
           researcher.creativityMetrics.flexibility * 0.3;
  }

  private assessAnalytical(researcher: Researcher): number {
    // Assess analytical thinking capabilities
    return researcher.analyticalMetrics.logicalReasoning * 0.4 +
           researcher.analyticalMetrics.problemSolving * 0.3 +
           researcher.analyticalMetrics.criticalThinking * 0.3;
  }

  private assessIntuition(researcher: Researcher): number {
    // Assess intuitive capabilities
    return researcher.intuitiveMetrics.patternRecognition * 0.4 +
           researcher.intuitiveMetrics.insightGeneration * 0.3 +
           researcher.intuitiveMetrics.decisionSpeed * 0.3;
  }

  private calculateCognitiveCoherence(creativity: number, analytical: number, intuition: number): number {
    const balance = 1 - Math.abs(creativity - analytical) - Math.abs(analytical - intuition) - Math.abs(intuition - creativity);
    return Math.max(0, balance / 3);
  }

  private assessEngagement(researcher: Researcher): number {
    return researcher.behavioralMetrics.focusTime / researcher.behavioralMetrics.totalTime;
  }

  private assessCuriosity(researcher: Researcher): number {
    return researcher.explorationMetrics.novelTopicsExplored / researcher.explorationMetrics.totalTopics;
  }

  private assessFrustration(researcher: Researcher): number {
    return researcher.emotionalMetrics.negativeEvents / researcher.emotionalMetrics.totalEvents;
  }

  private assessInspiration(researcher: Researcher): number {
    return researcher.creativeMetrics.breakthroughIdeas / researcher.creativeMetrics.totalIdeas;
  }

  private calculateEmotionalCoherence(engagement: number, curiosity: number, frustration: number, inspiration: number): number {
    const positive = (engagement + curiosity + inspiration) / 3;
    const negative = frustration;
    return Math.max(0, positive - negative);
  }

  private assessWorkingMemory(researcher: Researcher): number {
    return researcher.cognitiveMetrics.workingMemoryCapacity;
  }

  private assessAttention(researcher: Researcher): number {
    return researcher.cognitiveMetrics.attentionSpan;
  }

  private assessProcessingSpeed(researcher: Researcher): number {
    return researcher.cognitiveMetrics.processingSpeed;
  }

  private calculateLoadCoherence(workingMemory: number, attention: number, processingSpeed: number): number {
    const optimal = 0.7; // Optimal cognitive load
    const current = (workingMemory + attention + processingSpeed) / 3;
    return 1 - Math.abs(current - optimal);
  }

  private assessDomainKnowledge(researcher: Researcher): Promise<DomainKnowledge> {
    // Implementation for domain knowledge assessment
    return Promise.resolve(new DomainKnowledge(new Map(), 0.8));
  }

  private assessExperienceLevel(researcher: Researcher): Promise<ExperienceLevel> {
    // Implementation for experience level assessment
    return Promise.resolve(new ExperienceLevel('expert', 0.9));
  }
}

// Domain Empathy System
class DomainEmpathySystem {
  private domainModels: Map<ResearchDomain, DomainModel> = new Map();
  private crossDomainUnderstanding: number = 0.8;

  async understandContext(researcher: Researcher): Promise<DomainContext> {
    const primaryDomain = researcher.primaryDomain;
    const secondaryDomains = researcher.secondaryDomains;
    const domainUnderstanding = await this.assessDomainUnderstanding(researcher, primaryDomain);
    const crossDomainConnections = await this.assessCrossDomainConnections(researcher);
    
    return new DomainContext(primaryDomain, secondaryDomains, domainUnderstanding, crossDomainConnections);
  }

  async assessDomainUnderstanding(researcher: Researcher, domain: ResearchDomain): Promise<DomainUnderstanding> {
    const depth = await this.assessKnowledgeDepth(researcher, domain);
    const breadth = await this.assessKnowledgeBreadth(researcher, domain);
    const coherence = await this.assessKnowledgeCoherence(researcher, domain);
    
    return new DomainUnderstanding(depth, breadth, coherence);
  }

  async assessCrossDomainConnections(researcher: Researcher): Promise<CrossDomainConnection[]> {
    const connections: CrossDomainConnection[] = [];
    const domains = [researcher.primaryDomain, ...researcher.secondaryDomains];
    
    for (let i = 0; i < domains.length; i++) {
      for (let j = i + 1; j < domains.length; j++) {
        const connection = await this.assessDomainConnection(domains[i], domains[j], researcher);
        connections.push(connection);
      }
    }
    
    return connections;
  }

  private async assessKnowledgeDepth(researcher: Researcher, domain: ResearchDomain): Promise<number> {
    const model = this.domainModels.get(domain);
    if (!model) return 0.5;
    
    const researcherKnowledge = researcher.domainKnowledge.get(domain) || 0;
    return Math.min(1, researcherKnowledge / model.requiredDepth);
  }

  private async assessKnowledgeBreadth(researcher: Researcher, domain: ResearchDomain): Promise<number> {
    const model = this.domainModels.get(domain);
    if (!model) return 0.5;
    
    const knownSubdomains = researcher.knownSubdomains.get(domain) || new Set();
    return knownSubdomains.size / model.subdomains.size;
  }

  private async assessKnowledgeCoherence(researcher: Researcher, domain: ResearchDomain): Promise<number> {
    const knowledge = researcher.domainKnowledge.get(domain) || 0;
    const connections = researcher.domainConnections.get(domain) || [];
    
    const averageConnectionStrength = connections.reduce((sum, conn) => sum + conn.strength, 0) / Math.max(1, connections.length);
    return (knowledge + averageConnectionStrength) / 2;
  }

  private async assessDomainConnection(domain1: ResearchDomain, domain2: ResearchDomain, researcher: Researcher): Promise<CrossDomainConnection> {
    const connectionStrength = researcher.crossDomainConnections.get(`${domain1}-${domain2}`) || 0;
    const coherence = this.calculateConnectionCoherence(domain1, domain2, connectionStrength);
    
    return new CrossDomainConnection(domain1, domain2, connectionStrength, coherence);
  }

  private calculateConnectionCoherence(domain1: ResearchDomain, domain2: ResearchDomain, strength: number): number {
    const domainSimilarity = this.calculateDomainSimilarity(domain1, domain2);
    return (strength + domainSimilarity) / 2;
  }

  private calculateDomainSimilarity(domain1: ResearchDomain, domain2: ResearchDomain): number {
    // Simplified domain similarity calculation
    const similarityMatrix: Record<ResearchDomain, Record<ResearchDomain, number>> = {
      physics: { mathematics: 0.9, computer_science: 0.7, biology: 0.6, chemistry: 0.8, interdisciplinary: 0.5 },
      mathematics: { physics: 0.9, computer_science: 0.8, biology: 0.4, chemistry: 0.7, interdisciplinary: 0.6 },
      computer_science: { physics: 0.7, mathematics: 0.8, biology: 0.5, chemistry: 0.4, interdisciplinary: 0.7 },
      biology: { physics: 0.6, mathematics: 0.4, computer_science: 0.5, chemistry: 0.9, interdisciplinary: 0.6 },
      chemistry: { physics: 0.8, mathematics: 0.7, computer_science: 0.4, biology: 0.9, interdisciplinary: 0.5 },
      interdisciplinary: { physics: 0.5, mathematics: 0.6, computer_science: 0.7, biology: 0.6, chemistry: 0.5 }
    };
    
    return similarityMatrix[domain1]?.[domain2] || 0.3;
  }
}

// Collaborative Intuition System
class CollaborativeIntuitionSystem {
  private collaborationModels: Map<string, CollaborationModel> = new Map();

  async assessSynergy(researcher: Researcher): Promise<CollaborativeSynergy> {
    const communication = await this.assessCommunicationStyle(researcher);
    const cooperation = await this.assessCooperationWillingness(researcher);
    const creativity = await this.assessCollaborativeCreativity(researcher);
    const coherence = await this.assessCollaborativeCoherence(researcher);
    
    return new CollaborativeSynergy(communication, cooperation, creativity, coherence);
  }

  private async assessCommunicationStyle(researcher: Researcher): Promise<CommunicationStyle> {
    const clarity = researcher.communicationMetrics.clarity;
    const frequency = researcher.communicationMetrics.frequency;
    const responsiveness = researcher.communicationMetrics.responsiveness;
    
    return new CommunicationStyle(clarity, frequency, responsiveness);
  }

  private async assessCooperationWillingness(researcher: Researcher): Promise<number> {
    return researcher.collaborationMetrics.cooperationScore;
  }

  private async assessCollaborativeCreativity(researcher: Researcher): Promise<number> {
    return researcher.collaborationMetrics.creativityScore;
  }

  private async assessCollaborativeCoherence(researcher: Researcher): Promise<number> {
    const communication = await this.assessCommunicationStyle(researcher);
    const cooperation = await this.assessCooperationWillingness(researcher);
    const creativity = await this.assessCollaborativeCreativity(researcher);
    
    return (communication.clarity + cooperation + creativity) / 3;
  }
}

// Adaptation Engine
class AdaptationEngine {
  private adaptationStrategies: Map<string, AdaptationStrategy> = new Map();

  async createAdaptation(researcher: Researcher): Promise<Adaptation> {
    const needs = await this.identifyAdaptationNeeds(researcher);
    const strategy = await this.selectAdaptationStrategy(needs);
    const implementation = await this.implementAdaptation(strategy, researcher);
    
    return new Adaptation(needs, strategy, implementation);
  }

  async maintainCoherence(researcher: Researcher, coherence: CoherenceStatus): Promise<Adaptation[]> {
    const adaptations: Adaptation[] = [];
    
    if (coherence.overall < 0.8) {
      const adaptation = await this.createCoherenceAdaptation(researcher, coherence);
      adaptations.push(adaptation);
    }
    
    for (const [dimension, value] of Object.entries(coherence.dimensional)) {
      if (value < 0.7) {
        const adaptation = await this.createDimensionalAdaptation(researcher, dimension, value);
        adaptations.push(adaptation);
      }
    }
    
    return adaptations;
  }

  private async identifyAdaptationNeeds(researcher: Researcher): Promise<AdaptationNeed[]> {
    const needs: AdaptationNeed[] = [];
    
    if (researcher.cognitiveLoad.overall > 0.8) {
      needs.push(new AdaptationNeed('cognitive_load_reduction', 'high'));
    }
    
    if (researcher.emotionalState.frustration > 0.6) {
      needs.push(new AdaptationNeed('frustration_reduction', 'high'));
    }
    
    if (researcher.expertiseLevel.overall < 0.7) {
      needs.push(new AdaptationNeed('expertise_development', 'medium'));
    }
    
    return needs;
  }

  private async selectAdaptationStrategy(needs: AdaptationNeed[]): Promise<AdaptationStrategy> {
    // Select appropriate strategy based on needs
    const primaryNeed = needs.find(need => need.priority === 'high') || needs[0];
    return this.adaptationStrategies.get(primaryNeed.type) || new DefaultAdaptationStrategy();
  }

  private async implementAdaptation(strategy: AdaptationStrategy, researcher: Researcher): Promise<AdaptationImplementation> {
    return strategy.execute(researcher);
  }

  private async createCoherenceAdaptation(researcher: Researcher, coherence: CoherenceStatus): Promise<Adaptation> {
    const need = new AdaptationNeed('coherence_improvement', 'high');
    const strategy = new CoherenceImprovementStrategy();
    const implementation = await strategy.execute(researcher);
    
    return new Adaptation([need], strategy, implementation);
  }

  private async createDimensionalAdaptation(researcher: Researcher, dimension: string, value: number): Promise<Adaptation> {
    const need = new AdaptationNeed(`${dimension}_improvement`, 'medium');
    const strategy = new DimensionalImprovementStrategy(dimension);
    const implementation = await strategy.execute(researcher);
    
    return new Adaptation([need], strategy, implementation);
  }
}

// Coherence Monitor
class CoherenceMonitor {
  private coherenceThresholds: CoherenceThresholds = {
    overall: 0.8,
    dimensional: 0.7,
    stability: 0.75
  };

  async monitorCoherence(researcher: Researcher): Promise<CoherenceStatus> {
    const overall = await this.calculateOverallCoherence(researcher);
    const dimensional = await this.calculateDimensionalCoherence(researcher);
    const stability = await this.calculateStability(researcher);
    
    return {
      overall,
      dimensional,
      stability,
      timestamp: Date.now()
    };
  }

  async assessCoherence(adaptation: Adaptation): Promise<number> {
    // Assess coherence of the adaptation
    return adaptation.implementation.coherence;
  }

  private async calculateOverallCoherence(researcher: Researcher): Promise<number> {
    const cognitive = researcher.cognitiveProfile.coherence;
    const emotional = researcher.emotionalState.coherence;
    const expertise = researcher.expertiseProfile.coherenceIntegration;
    
    return (cognitive + emotional + expertise) / 3;
  }

  private async calculateDimensionalCoherence(researcher: Researcher): Promise<Record<string, number>> {
    return {
      cognitive: researcher.cognitiveProfile.coherence,
      emotional: researcher.emotionalState.coherence,
      expertise: researcher.expertiseProfile.coherenceIntegration,
      collaborative: researcher.collaborativeMetrics.coherence
    };
  }

  private async calculateStability(researcher: Researcher): Promise<number> {
    const variance = researcher.coherenceMetrics.variance;
    return Math.max(0, 1 - variance);
  }
}

// Helper Classes and Interfaces
class ResearchGuidance {
  constructor(
    public expertiseLevel: ExpertiseLevel,
    public domainContext: DomainContext,
    public collaborativePotential: CollaborativeSynergy
  ) {}
}

class ExpertiseLevel {
  constructor(
    public cognitiveProfile: CognitiveProfile,
    public domainKnowledge: DomainKnowledge,
    public experienceLevel: ExperienceLevel
  ) {}
}

class DomainKnowledge {
  constructor(
    public knowledge: Map<ResearchDomain, number>,
    public coherence: number
  ) {}
}

class ExperienceLevel {
  constructor(
    public level: 'beginner' | 'intermediate' | 'advanced' | 'expert',
    public confidence: number
  ) {}
}

class DomainContext {
  constructor(
    public primaryDomain: ResearchDomain,
    public secondaryDomains: ResearchDomain[],
    public understanding: DomainUnderstanding,
    public crossDomainConnections: CrossDomainConnection[]
  ) {}
}

class DomainUnderstanding {
  constructor(
    public depth: number,
    public breadth: number,
    public coherence: number
  ) {}
}

class CrossDomainConnection {
  constructor(
    public domain1: ResearchDomain,
    public domain2: ResearchDomain,
    public strength: number,
    public coherence: number
  ) {}
}

class CollaborativeSynergy {
  constructor(
    public communication: CommunicationStyle,
    public cooperation: number,
    public creativity: number,
    public coherence: number
  ) {}
}

class CommunicationStyle {
  constructor(
    public clarity: number,
    public frequency: number,
    public responsiveness: number
  ) {}
}

class CognitiveLoad {
  constructor(
    public workingMemory: number,
    public attention: number,
    public processingSpeed: number,
    public coherence: number
  ) {}
}

class AdaptationResult {
  constructor(
    public success: boolean,
    public adaptation: Adaptation,
    public coherence: number,
    public timestamp: number
  ) {}
}

class Adaptation {
  constructor(
    public needs: AdaptationNeed[],
    public strategy: AdaptationStrategy,
    public implementation: AdaptationImplementation
  ) {}
}

class AdaptationNeed {
  constructor(
    public type: string,
    public priority: 'low' | 'medium' | 'high'
  ) {}
}

class AdaptationImplementation {
  constructor(
    public actions: string[],
    public coherence: number,
    public effectiveness: number
  ) {}
}

class EmpathicGuidance {
  constructor(
    public emotionalState: EmotionalState,
    public cognitiveLoad: CognitiveLoad,
    public domainUnderstanding: DomainUnderstanding,
    public context: ResearchContext
  ) {}
}

class ResearchContext {
  constructor(
    public currentTask: string,
    public environment: string,
    public constraints: string[]
  ) {}
}

class CoherenceStatus {
  constructor(
    public overall: number,
    public dimensional: Record<string, number>,
    public stability: number,
    public adaptations?: Adaptation[],
    public timestamp: number
  ) {}
}

interface CoherenceThresholds {
  overall: number;
  dimensional: number;
  stability: number;
}

interface DomainModel {
  requiredDepth: number;
  subdomains: Set<string>;
}

interface CollaborationModel {
  synergy: number;
  communication: number;
  cooperation: number;
}

interface AdaptationStrategy {
  execute(researcher: Researcher): Promise<AdaptationImplementation>;
}

class DefaultAdaptationStrategy implements AdaptationStrategy {
  async execute(researcher: Researcher): Promise<AdaptationImplementation> {
    return new AdaptationImplementation(['default_adaptation'], 0.5, 0.5);
  }
}

class CoherenceImprovementStrategy implements AdaptationStrategy {
  async execute(researcher: Researcher): Promise<AdaptationImplementation> {
    return new AdaptationImplementation(['improve_coherence'], 0.9, 0.8);
  }
}

class DimensionalImprovementStrategy implements AdaptationStrategy {
  constructor(private dimension: string) {}
  
  async execute(researcher: Researcher): Promise<AdaptationImplementation> {
    return new AdaptationImplementation([`improve_${this.dimension}`], 0.8, 0.7);
  }
}

// Extended Researcher Interface for Pattern Usage
interface Researcher {
  id: string;
  primaryDomain: ResearchDomain;
  secondaryDomains: ResearchDomain[];
  cognitiveProfile: CognitiveProfile;
  emotionalState: EmotionalState;
  researchStyle: ResearchStyle;
  expertiseProfile: ExpertiseProfile;
  collaborativeMetrics: CollaborativeMetrics;
  cognitiveLoad: CognitiveLoad;
  domainKnowledge: Map<ResearchDomain, number>;
  knownSubdomains: Map<ResearchDomain, Set<string>>;
  domainConnections: Map<ResearchDomain, any[]>;
  crossDomainConnections: Map<string, number>;
  researchPatterns: any;
  preferences: any;
  creativityMetrics: any;
  analyticalMetrics: any;
  intuitiveMetrics: any;
  behavioralMetrics: any;
  explorationMetrics: any;
  emotionalMetrics: any;
  creativeMetrics: any;
  coherenceMetrics: any;
  communicationMetrics: any;
  collaborationMetrics: any;
  expertiseLevel: any;
}

interface CollaborativeMetrics {
  cooperationScore: number;
  creativityScore: number;
  coherence: number;
}

interface CoherenceMetrics {
  variance: number;
}