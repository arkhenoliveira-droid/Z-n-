/**
 * Coherent Database Type Definitions
 * 
 * This file provides type definitions that ensure consistency across
 * database models, relationships, and operations.
 */

import { 
  ID, 
  UUID, 
  Email, 
  URL, 
  Timestamp, 
  DatabaseEntity,
  CreatableEntity,
  UpdatableEntity
} from './utils';

// Base Database Entity
export interface BaseModel extends DatabaseEntity {
  id: ID;
  createdAt: Timestamp;
  updatedAt: Timestamp;
  version: number;
}

// User Model
export interface UserModel extends BaseModel {
  email: Email;
  username: string;
  firstName: string;
  lastName: string;
  avatar?: URL;
  bio?: string;
  role: UserRole;
  isActive: boolean;
  emailVerified: boolean;
  lastLoginAt?: Timestamp;
  preferences: UserPreferences;
  metadata: Record<string, any>;
}

export type UserRole = 'super_admin' | 'admin' | 'moderator' | 'user' | 'guest';

export interface UserPreferences {
  theme: 'light' | 'dark' | 'system';
  language: string;
  timezone: string;
  notifications: NotificationPreferences;
  privacy: PrivacyPreferences;
}

export interface NotificationPreferences {
  email: boolean;
  push: boolean;
  sms: boolean;
  frequency: 'immediate' | 'daily' | 'weekly';
}

export interface PrivacyPreferences {
  profileVisible: boolean;
  showEmail: boolean;
  showActivity: boolean;
  allowMessages: 'everyone' | 'friends' | 'none';
}

// Session Model
export interface SessionModel extends BaseModel {
  userId: ID;
  token: string;
  refreshToken: string;
  expiresAt: Timestamp;
  ipAddress: string;
  userAgent: string;
  isActive: boolean;
  lastAccessedAt: Timestamp;
}

// Permission Model
export interface PermissionModel extends BaseModel {
  name: string;
  description: string;
  resource: string;
  action: string;
  conditions?: Record<string, any>;
}

// Role Model
export interface RoleModel extends BaseModel {
  name: string;
  description: string;
  permissions: PermissionModel[];
  isSystem: boolean;
}

// UserRole Model (Junction Table)
export interface UserRoleModel extends BaseModel {
  userId: ID;
  roleId: ID;
  assignedBy: ID;
  assignedAt: Timestamp;
  expiresAt?: Timestamp;
}

// Activity Log Model
export interface ActivityLogModel extends BaseModel {
  userId?: ID;
  action: string;
  resource: string;
  resourceId: ID;
  description: string;
  metadata: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

// File Model
export interface FileModel extends BaseModel {
  originalName: string;
  fileName: string;
  filePath: string;
  fileSize: number;
  mimeType: string;
  checksum: string;
  uploadedBy: ID;
  isPublic: boolean;
  expiresAt?: Timestamp;
  metadata: Record<string, any>;
}

// Folder Model
export interface FolderModel extends BaseModel {
  name: string;
  path: string;
  parentId?: ID;
  createdBy: ID;
  isPublic: boolean;
  metadata: Record<string, any>;
}

// Tag Model
export interface TagModel extends BaseModel {
  name: string;
  description?: string;
  color?: string;
  slug: string;
  usageCount: number;
}

// Content Model
export interface ContentModel extends BaseModel {
  title: string;
  slug: string;
  content: string;
  excerpt?: string;
  type: ContentType;
  status: ContentStatus;
  authorId: ID;
  categoryId?: ID;
  featuredImageId?: ID;
  publishedAt?: Timestamp;
  seo: SEOData;
  tags: TagModel[];
  metadata: Record<string, any>;
}

export type ContentType = 'article' | 'page' | 'post' | 'product' | 'event';
export type ContentStatus = 'draft' | 'published' | 'archived' | 'deleted';

export interface SEOData {
  title?: string;
  description?: string;
  keywords?: string[];
  ogImage?: URL;
  canonicalUrl?: URL;
}

// Category Model
export interface CategoryModel extends BaseModel {
  name: string;
  slug: string;
  description?: string;
  parentId?: ID;
  order: number;
  metadata: Record<string, any>;
}

// Comment Model
export interface CommentModel extends BaseModel {
  content: string;
  authorId: ID;
  contentId: ID;
  parentId?: ID;
  status: 'pending' | 'approved' | 'rejected' | 'spam';
  ipAddress?: string;
  userAgent?: string;
  metadata: Record<string, any>;
}

// Like Model
export interface LikeModel extends BaseModel {
  userId: ID;
  contentId: ID;
  type: 'like' | 'dislike' | 'love' | 'laugh' | 'wow' | 'sad' | 'angry';
}

// Notification Model
export interface NotificationModel extends BaseModel {
  userId: ID;
  type: NotificationType;
  title: string;
  message: string;
  data: Record<string, any>;
  isRead: boolean;
  readAt?: Timestamp;
  expiresAt?: Timestamp;
  priority: 'low' | 'medium' | 'high' | 'urgent';
}

export type NotificationType = 
  | 'system'
  | 'security'
  | 'content'
  | 'social'
  | 'marketing'
  | 'transactional';

// Setting Model
export interface SettingModel extends BaseModel {
  key: string;
  value: any;
  type: 'string' | 'number' | 'boolean' | 'json';
  category: string;
  description?: string;
  isSystem: boolean;
  isEditable: boolean;
}

// Webhook Model
export interface WebhookModel extends BaseModel {
  userId: ID;
  name: string;
  url: URL;
  events: string[];
  secret: string;
  isActive: boolean;
  lastTriggeredAt?: Timestamp;
  lastStatus?: 'success' | 'failed';
  failureCount: number;
}

// Webhook Log Model
export interface WebhookLogModel extends BaseModel {
  webhookId: ID;
  event: string;
  payload: Record<string, any>;
  responseStatus: number;
  responseBody?: string;
  attempt: number;
  status: 'pending' | 'success' | 'failed' | 'retried';
  nextAttemptAt?: Timestamp;
}

// Cache Model
export interface CacheModel extends BaseModel {
  key: string;
  value: any;
  ttl: number;
  tags: string[];
  compressed: boolean;
}

// Search Index Model
export interface SearchIndexModel extends BaseModel {
  documentId: ID;
  documentType: string;
  content: string;
  metadata: Record<string, any>;
  language: string;
  boost: number;
}

// Analytics Event Model
export interface AnalyticsEventModel extends BaseModel {
  userId?: ID;
  sessionId: string;
  event: string;
  properties: Record<string, any>;
  timestamp: Timestamp;
  ipAddress?: string;
  userAgent?: string;
  referrer?: string;
}

// Report Model
export interface ReportModel extends BaseModel {
  name: string;
  description?: string;
  type: ReportType;
  config: ReportConfig;
  schedule?: ReportSchedule;
  lastRunAt?: Timestamp;
  nextRunAt?: Timestamp;
  status: 'active' | 'paused' | 'completed' | 'failed';
  createdBy: ID;
  data?: any;
}

export type ReportType = 'analytics' | 'usage' | 'performance' | 'security' | 'custom';

export interface ReportConfig {
  metrics: string[];
  dimensions: string[];
  filters: Record<string, any>;
  timeRange: {
    start: Timestamp;
    end: Timestamp;
  };
  format: 'json' | 'csv' | 'pdf' | 'xlsx';
}

export interface ReportSchedule {
  frequency: 'hourly' | 'daily' | 'weekly' | 'monthly';
  dayOfWeek?: number;
  dayOfMonth?: number;
  hour: number;
  timezone: string;
}

// Database Query Types
export interface QueryOptions {
  limit?: number;
  offset?: number;
  orderBy?: {
    field: string;
    direction: 'asc' | 'desc';
  };
  where?: Record<string, any>;
  include?: Record<string, boolean | QueryOptions>;
  select?: string[];
}

export interface PaginationResult<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

// Database Transaction Types
export interface TransactionOptions {
  isolationLevel?: 'read_uncommitted' | 'read_committed' | 'repeatable_read' | 'serializable';
  timeout?: number;
}

export type TransactionCallback<T> = (transaction: any) => Promise<T>;

// Database Migration Types
export interface Migration {
  id: string;
  name: string;
  up: (tx: any) => Promise<void>;
  down: (tx: any) => Promise<void>;
  timestamp: Timestamp;
}

// Database Backup Types
export interface Backup {
  id: ID;
  name: string;
  size: number;
  checksum: string;
  createdAt: Timestamp;
  expiresAt?: Timestamp;
  status: 'pending' | 'completed' | 'failed' | 'expired';
  metadata: Record<string, any>;
}

// Database Health Check Types
export interface DatabaseHealth {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: Timestamp;
  metrics: {
    connections: {
      current: number;
      max: number;
      available: number;
    };
    performance: {
      avgQueryTime: number;
      slowQueryCount: number;
    };
    storage: {
      total: number;
      used: number;
      available: number;
    };
  };
  checks: {
    connectivity: boolean;
    replication?: boolean;
    backup?: boolean;
    performance: boolean;
  };
}