/**
 * Comprehensive TypeScript Utility Types for Enhanced Coherence
 * 
 * This file contains utility types that promote type safety, consistency,
 * and conceptual clarity throughout the application.
 */

// Primitive Types with Semantic Meaning
export type ID = string & { readonly __brand: unique symbol };
export type UUID = string & { readonly __brand: unique symbol };
export type Email = string & { readonly __brand: unique symbol };
export type URL = string & { readonly __brand: unique symbol };
export type Timestamp = number & { readonly __brand: unique symbol };
export type NonEmptyString = string & { readonly __brand: unique symbol };

// Result Types for Coherent Error Handling
export type Result<T, E = Error> = 
  | { success: true; data: T }
  | { success: false; error: E };

export type AsyncResult<T, E = Error> = Promise<Result<T, E>>;

// Option Type for Better Null/Undefined Handling
export type Option<T> = 
  | { some: T }
  | { none: true };

// Enhanced Array Types
export type NonEmptyArray<T> = [T, ...T[]];
export type ArrayElement<T> = T extends readonly (infer U)[] ? U : never;

// Object Utilities
export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type DeepReadonly<T> = {
  readonly [P in keyof T]: T[P] extends object ? DeepReadonly<T[P]> : T[P];
};

export type DeepRequired<T> = {
  [P in keyof T]-?: T[P] extends object ? DeepRequired<T[P]> : T[P];
};

// Function Utilities
export type AsyncFunction = (...args: any[]) => Promise<any>;
export type SyncFunction = (...args: any[]) => any;

export type Parameters<T extends AsyncFunction | SyncFunction> = T extends (...args: infer P) => any ? P : never;
export type ReturnType<T extends AsyncFunction | SyncFunction> = T extends (...args: any[]) => infer R ? R : never;

// Event Handling Types
export type EventHandler<T = any> = (event: T) => void;
export type AsyncEventHandler<T = any> = (event: T) => Promise<void>;

// API Response Types
export type APIResponse<T> = {
  data: T;
  success: true;
  message?: string;
  timestamp: Timestamp;
};

export type APIErrorResponse = {
  success: false;
  error: {
    code: string;
    message: string;
    details?: Record<string, any>;
  };
  timestamp: Timestamp;
};

export type ApiResponse<T> = APIResponse<T> | APIErrorResponse;

// Pagination Types
export type PaginationParams = {
  page: number;
  limit: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
};

export type PaginatedResponse<T> = {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
};

// Form Types
export type FormField<T> = {
  value: T;
  error?: string;
  touched: boolean;
  dirty: boolean;
};

export type FormState<T extends Record<string, any>> = {
  [K in keyof T]: FormField<T[K]>;
};

// State Management Types
export type StateUpdater<T> = (updater: T | ((prev: T) => T)) => void;
export type StateSelector<T, R> = (state: T) => R;

// Database Types
export type DatabaseEntity = {
  id: ID;
  createdAt: Timestamp;
  updatedAt: Timestamp;
};

export type CreatableEntity<T> = Omit<T, 'id' | 'createdAt' | 'updatedAt'>;
export type UpdatableEntity<T> = Partial<Omit<T, 'id' | 'createdAt' | 'updatedAt'>>;

// Validation Types
export type ValidationRule<T> = {
  validate: (value: T) => boolean;
  message: string;
};

export type ValidationSchema<T> = {
  [K in keyof T]?: ValidationRule<T[K]>[];
};

// Coherent Type Guards
export type TypeGuard<T> = (value: unknown) => value is T;

export const isString: TypeGuard<string> = (value): value is string => 
  typeof value === 'string';

export const isNumber: TypeGuard<number> = (value): value is number => 
  typeof value === 'number' && !isNaN(value);

export const isBoolean: TypeGuard<boolean> = (value): value is boolean => 
  typeof value === 'boolean';

export const isArray = <T>(guard: TypeGuard<T>): TypeGuard<T[]> => 
  (value): value is T[] => Array.isArray(value) && value.every(guard);

export const isObject = <T extends Record<string, any>>(shape: {
  [K in keyof T]?: TypeGuard<T[K]>
}): TypeGuard<T> => 
  (value): value is T => {
    if (typeof value !== 'object' || value === null) return false;
    return Object.entries(shape).every(([key, guard]) => 
      guard ? guard((value as any)[key]) : true
    );
  };

// Utility Functions
export const createId = (): ID => Math.random().toString(36).substring(2) as ID;
export const createUUID = (): UUID => crypto.randomUUID() as UUID;
export const createTimestamp = (): Timestamp => Date.now() as Timestamp;

export const some = <T>(value: T): Option<T> => ({ some: value });
export const none = <T>(): Option<T> => ({ none: true });

export const ok = <T, E = Error>(data: T): Result<T, E> => ({ success: true, data });
export const err = <T, E = Error>(error: E): Result<T, E> => ({ success: false, error });

// Type-safe event emitter
export interface EventEmitter<TEvents extends Record<string, any>> {
  on<K extends keyof TEvents>(event: K, handler: EventHandler<TEvents[K]>): void;
  off<K extends keyof TEvents>(event: K, handler: EventHandler<TEvents[K]>): void;
  emit<K extends keyof TEvents>(event: K, data: TEvents[K]): void;
}

// Coherent async utilities
export const withTimeout = <T>(
  promise: Promise<T>,
  timeoutMs: number,
  errorMessage = 'Operation timed out'
): Promise<T> => {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) => 
      setTimeout(() => reject(new Error(errorMessage)), timeoutMs)
    )
  ]);
};

export const retry = async <T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  delayMs: number = 1000
): Promise<T> => {
  let lastError: Error;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error as Error;
      if (i < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, delayMs));
      }
    }
  }
  
  throw lastError!;
};

// Type-safe builder pattern
export class Builder<T> {
  private data: Partial<T> = {};

  constructor(private defaults: Partial<T> = {}) {
    this.data = { ...defaults };
  }

  set<K extends keyof T>(key: K, value: T[K]): this {
    this.data[key] = value;
    return this;
  }

  build(): T {
    return this.data as T;
  }
}

// Immutable record utilities
export const updateRecord = <T extends Record<string, any>, K extends keyof T>(
  record: T,
  key: K,
  updater: (value: T[K]) => T[K]
): T => ({
  ...record,
  [key]: updater(record[key])
});

export const mergeRecords = <T extends Record<string, any>>(
  ...records: Partial<T>[]
): T => Object.assign({}, ...records);

// Coherent logging types
export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export type LogEntry = {
  level: LogLevel;
  message: string;
  timestamp: Timestamp;
  context?: Record<string, any>;
};

export type Logger = {
  log: (level: LogLevel, message: string, context?: Record<string, any>) => void;
  debug: (message: string, context?: Record<string, any>) => void;
  info: (message: string, context?: Record<string, any>) => void;
  warn: (message: string, context?: Record<string, any>) => void;
  error: (message: string, context?: Record<string, any>) => void;
};