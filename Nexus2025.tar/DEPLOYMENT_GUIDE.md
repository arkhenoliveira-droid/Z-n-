# Guia de Instalação e Deploy - Sistema de Coerência de Arquivos

Este documento fornece instruções completas para instalar e deployar o sistema de coerência de arquivos em diferentes ambientes e sistemas operacionais.

## Pré-requisitos

- Node.js 18+ 
- npm ou yarn
- TypeScript 5+
- Banco de dados (SQLite, PostgreSQL, MySQL)

## 1. Instalação Local

### 1.1 Linux (Ubuntu/Debian)

```bash
# Atualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Node.js e npm
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Instalar dependências de build
sudo apt-get install -y build-essential

# Clonar repositório
git clone <repository-url>
cd <project-name>

# Instalar dependências
npm install

# Configurar banco de dados
npm run db:push

# Iniciar desenvolvimento
npm run dev
```

### 1.2 Linux (CentOS/RHEL/Fedora)

```bash
# Atualizar sistema
sudo dnf update -y

# Instalar Node.js e npm
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo dnf install -y nodejs

# Instalar dependências de build
sudo dnf groupinstall -y "Development Tools"

# Clonar repositório
git clone <repository-url>
cd <project-name>

# Instalar dependências
npm install

# Configurar banco de dados
npm run db:push

# Iniciar desenvolvimento
npm run dev
```

### 1.3 macOS

```bash
# Instalar Homebrew (se não tiver)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Instalar Node.js
brew install node

# Clonar repositório
git clone <repository-url>
cd <project-name>

# Instalar dependências
npm install

# Configurar banco de dados
npm run db:push

# Iniciar desenvolvimento
npm run dev
```

### 1.4 Windows

```powershell
# Instalar Node.js (baixar de https://nodejs.org)

# Clonar repositório
git clone <repository-url>
cd <project-name>

# Instalar dependências
npm install

# Configurar banco de dados
npm run db:push

# Iniciar desenvolvimento
npm run dev
```

## 2. Build para Produção

```bash
# Limpar cache anterior
rm -rf .next

# Build do projeto
npm run build

# Verificar build
ls -la .next/
```

## 3. Configurações de Deploy

### 3.1 Variáveis de Ambiente

Crie um arquivo `.env.production`:

```env
NODE_ENV=production
PORT=3000
HOSTNAME=0.0.0.0

# Banco de dados
DATABASE_URL="file:./dev.db"

# Configurações adicionais
NEXT_TELEMETRY_DISABLED=1
```

### 3.2 Configuração do Servidor

O projeto usa um servidor customizado com Socket.IO. Verifique `server.ts`:

```typescript
const dev = process.env.NODE_ENV !== 'production';
const currentPort = process.env.PORT || 3000;
const hostname = process.env.HOSTNAME || '0.0.0.0';
```

## 4. Métodos de Deploy

### 4.1 Servidor Dedicado (VPS/Dedicated)

#### 4.1.1 Usando PM2 (Process Manager)

```bash
# Instalar PM2 globalmente
npm install -g pm2

# Build do projeto
npm run build

# Iniciar com PM2
pm2 start server.ts --name "coherence-system" --interpreter tsx

# Salvar configuração PM2
pm2 save

# Configurar startup automático
pm2 startup
pm2 enable coherence-system

# Verificar status
pm2 status
pm2 logs coherence-system
```

#### 4.1.2 Usando Systemd

Crie um serviço systemd: `/etc/systemd/system/coherence-system.service`

```ini
[Unit]
Description=Coherence File System
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/path/to/project
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=10
Environment=NODE_ENV=production
Environment=PORT=3000
Environment=HOSTNAME=0.0.0.0

[Install]
WantedBy=multi-user.target
```

```bash
# Habilitar e iniciar serviço
sudo systemctl daemon-reload
sudo systemctl enable coherence-system
sudo systemctl start coherence-system

# Verificar status
sudo systemctl status coherence-system
sudo journalctl -u coherence-system -f
```

### 4.2 Docker

#### 4.2.1 Dockerfile

```dockerfile
# Build stage
FROM node:18-alpine AS builder

WORKDIR /app

# Copy package files
COPY package*.json ./
COPY prisma ./prisma/

# Install dependencies
RUN npm ci --only=production

# Copy source code
COPY . .

# Generate Prisma client
RUN npx prisma generate

# Build the application
RUN npm run build

# Production stage
FROM node:18-alpine AS runner

WORKDIR /app

# Create non-root user
RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

# Copy built application
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static
COPY --from=builder --chown=nextjs:nodejs /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/server.ts ./
COPY --from=builder --chown=nextjs:nodejs /app/prisma ./prisma
COPY --from=builder --chown=nextjs:nodejs /app/node_modules ./node_modules

# Expose port
EXPOSE 3000

# Start application
USER nextjs
CMD ["tsx", "server.ts"]
```

#### 4.2.2 docker-compose.yml

```yaml
version: '3.8'

services:
  coherence-system:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - PORT=3000
      - HOSTNAME=0.0.0.0
      - DATABASE_URL=file:./dev.db
    volumes:
      - ./data:/app/data
    restart: unless-stopped

  # Optional: Database service
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: coherence_db
      POSTGRES_USER: coherence_user
      POSTGRES_PASSWORD: coherence_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    restart: unless-stopped

volumes:
  postgres_data:
```

```bash
# Build e iniciar containers
docker-compose up -d --build

# Verificar logs
docker-compose logs -f coherence-system

# Parar containers
docker-compose down
```

### 4.3 Cloud Platforms

#### 4.3.1 Vercel

1. **Configurar vercel.json**:

```json
{
  "builds": [
    {
      "src": "server.ts",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "server.ts"
    }
  ],
  "env": {
    "NODE_ENV": "production"
  }
}
```

2. **Deploy**:
```bash
# Instalar Vercel CLI
npm i -g vercel

# Login e deploy
vercel login
vercel --prod
```

#### 4.3.2 AWS Elastic Beanstalk

1. **Criar arquivo `.ebextensions/nodecommand.config`**:

```yaml
option_settings:
  aws:elasticbeanstalk:container:nodejs:
    NodeCommand: "tsx server.ts"
  aws:elasticbeanstalk:application:environment:
    NODE_ENV: production
    PORT: 8080
```

2. **Deploy via CLI**:
```bash
# Instalar EB CLI
pip install awsebcli

# Inicializar projeto
eb init

# Criar ambiente e deploy
eb create production
eb deploy
```

#### 4.3.3 Google Cloud Platform

1. **Usando Cloud Run**:

```bash
# Build Docker image
gcloud builds submit --tag gcr.io/PROJECT-ID/coherence-system

# Deploy para Cloud Run
gcloud run deploy --image gcr.io/PROJECT-ID/coherence-system --platform managed
```

2. **Usando App Engine**:

```yaml
# app.yaml
runtime: nodejs18
env: standard

instance_class: F2

env_variables:
  NODE_ENV: 'production'
  PORT: '8080'

automatic_scaling:
  min_num_instances: 1
  max_num_instances: 10
  cpu_utilization:
    target_utilization: 0.65
```

```bash
# Deploy
gcloud app deploy
```

### 4.4 Kubernetes

#### 4.4.1 Deployment YAML

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: coherence-system
spec:
  replicas: 3
  selector:
    matchLabels:
      app: coherence-system
  template:
    metadata:
      labels:
        app: coherence-system
    spec:
      containers:
      - name: coherence-system
        image: coherence-system:latest
        ports:
        - containerPort: 3000
        env:
        - name: NODE_ENV
          value: "production"
        - name: PORT
          value: "3000"
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /api/health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /api/health
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5

---
apiVersion: v1
kind: Service
metadata:
  name: coherence-system-service
spec:
  selector:
    app: coherence-system
  ports:
  - protocol: TCP
    port: 80
    targetPort: 3000
  type: LoadBalancer
```

```bash
# Deploy para Kubernetes
kubectl apply -f k8s-deployment.yaml

# Verificar status
kubectl get pods
kubectl get services
```

## 5. Monitoramento e Manutenção

### 5.1 Health Checks

O sistema inclui endpoints de health check:

```bash
# Verificar saúde do sistema
curl http://localhost:3000/api/health

# Verificar saúde do Socket.IO
curl -I http://localhost:3000/api/socketio
```

### 5.2 Logs

```bash
# Usando PM2
pm2 logs coherence-system

# Usando Docker
docker logs coherence-system

# Usando systemd
journalctl -u coherence-system -f
```

### 5.3 Backup e Restore

```bash
# Backup do banco de dados
cp dev.db backup-$(date +%Y%m%d).db

# Restore
cp backup-20231201.db dev.db
```

## 6. Solução de Problemas

### 6.1 Erros Comuns

#### Erro: "Sorry, there was a problem deploying the code"

**Causas possíveis:**
1. Erros de build no projeto
2. Problemas de dependências
3. Configuração incorreta do servidor

**Soluções:**
```bash
# 1. Limpar cache e rebuild
rm -rf .next node_modules package-lock.json
npm install
npm run build

# 2. Verificar erros de lint
npm run lint

# 3. Verificar tipos TypeScript
npx tsc --noEmit

# 4. Testar em ambiente local
npm run dev
```

#### Erro: "EADDRINUSE: address already in use"

**Solução:**
```bash
# Matar processo na porta 3000
lsof -ti:3000 | xargs kill -9

# Ou usar porta diferente
PORT=3001 npm start
```

#### Erro: "Module parse failed"

**Solução:**
```bash
# Verificar importações duplicadas
grep -r "import.*FileText" src/

# Corrigir importações
# Remover duplicatas e verificar nomes corretos dos ícones
```

### 6.2 Performance Optimization

```bash
# Otimizar build
npm run build -- --optimize

# Analisar bundle
npm install -g @next/bundle-analyzer
ANALYZE=true npm run build
```

### 6.3 Security Considerations

```bash
# Atualizar dependências
npm audit
npm audit fix

# Configurar firewall
sudo ufw allow 3000/tcp
sudo ufw enable

# Usar HTTPS com reverse proxy (nginx)
```

## 7. Configuração de Reverse Proxy (Nginx)

```nginx
server {
    listen 80;
    server_name seu-dominio.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name seu-dominio.com;
    
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    location /socket.io/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## 8. Scripts Úteis

### 8.1 Script de Deploy Automático

```bash
#!/bin/bash
# deploy.sh

echo "Iniciando deploy..."

# Parar serviço atual
pm2 stop coherence-system || true

# Pull latest changes
git pull origin main

# Install dependencies
npm install

# Build application
npm run build

# Migrate database
npm run db:migrate

# Start service
pm2 start server.ts --name "coherence-system" --interpreter tsx

# Check status
pm2 status coherence-system

echo "Deploy concluído!"
```

### 8.2 Script de Backup

```bash
#!/bin/bash
# backup.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups"
APP_DIR="/path/to/project"

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup database
cp $APP_DIR/dev.db $BACKUP_DIR/database_$DATE.db

# Backup source code
tar -czf $BACKUP_DIR/source_$DATE.tar.gz -C $APP_DIR .

# Keep only last 7 days of backups
find $BACKUP_DIR -name "*.db" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "Backup concluído: $BACKUP_DIR"
```

Este guia cobre as principais formas de instalação e deploy do sistema. Escolha o método que melhor se adapta às suas necessidades e infraestrutura.