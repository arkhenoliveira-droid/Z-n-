/**
 * Intelligent Cluster Optimization Algorithms
 * 
 * This module provides advanced optimization algorithms for dynamic clusters,
 * including genetic algorithms, neural networks, quantum annealing, and swarm intelligence.
 */

import { 
  ID, 
  Timestamp, 
  Result, 
  AsyncResult, 
  ok, 
  err
} from '@/types/utils';
import { 
  DynamicCluster, 
  ClusterCoherenceMetrics, 
  OptimizationParameters, 
  PerformanceMetrics,
  AdaptiveParameters,
  ClusterType,
  OptimizationStrategy
} from '@/systems/dynamic-cluster-creation';

export interface OptimizationContext {
  cluster_id: ID;
  current_coherence: number;
  target_coherence: number;
  optimization_strategy: OptimizationStrategy;
  cluster_type: ClusterType;
  node_count: number;
  available_resources: ResourceAvailability;
  constraints: OptimizationConstraints;
  timestamp: Timestamp;
}

export interface ResourceAvailability {
  cpu_utilization: number;
  memory_utilization: number;
  network_bandwidth: number;
  storage_capacity: number;
  quantum_resources: number;
  coherence_field_strength: number;
}

export interface OptimizationConstraints {
  max_node_count: number;
  min_coherence_threshold: number;
  max_adaptation_rate: number;
  resource_limits: ResourceLimits;
  temporal_constraints: TemporalConstraints;
  quantum_constraints: QuantumConstraints;
}

export interface ResourceLimits {
  max_cpu: number;
  max_memory: number;
  max_network: number;
  max_storage: number;
  max_quantum: number;
}

export interface TemporalConstraints {
  max_optimization_time: number;
  adaptation_interval: number;
  convergence_timeout: number;
  stability_period: number;
}

export interface QuantumConstraints {
  max_entanglement_degree: number;
  min_coherence_preservation: number;
  max_decoherence_rate: number;
  quantum_correlation_threshold: number;
}

export interface OptimizationResult {
  success: boolean;
  final_coherence: number;
  improvement: number;
  iterations: number;
  execution_time: number;
  convergence_achieved: boolean;
  warnings: string[];
  optimization_path: OptimizationStep[];
  resource_utilization: ResourceUtilization;
  convergence_metrics: ConvergenceMetrics;
}

export interface OptimizationStep {
  iteration: number;
  coherence_before: number;
  coherence_after: number;
  improvement: number;
  parameters_modified: string[];
  resource_usage: ResourceUsage;
  convergence_measure: number;
  timestamp: Timestamp;
}

export interface ResourceUsage {
  cpu_used: number;
  memory_used: number;
  network_used: number;
  quantum_resources_used: number;
  coherence_field_used: number;
}

export interface ResourceUtilization {
  average_cpu: number;
  average_memory: number;
  average_network: number;
  average_quantum: number;
  peak_cpu: number;
  peak_memory: number;
  efficiency_score: number;
}

export interface ConvergenceMetrics {
  convergence_rate: number;
  stability_measure: number;
  oscillation_frequency: number;
  convergence_threshold: number;
  final_stability: number;
}

export interface PredictionResult {
  predicted_coherence: number;
  confidence: number;
  estimated_time: number;
  success_probability: number;
  resource_requirements: ResourceUsage;
  risk_factors: string[];
}

export interface OptimizationRecommendation {
  type: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  strategy: OptimizationStrategy;
  expected_improvement: number;
  estimated_time: number;
  description: string;
}

export class IntelligentClusterOptimizer {
  private optimizationHistory: Map<ID, OptimizationResult[]> = new Map();
  private activeOptimizations: Map<ID, Promise<OptimizationResult>> = new Map();
  private convergenceCache: Map<string, ConvergenceMetrics> = new Map();

  /**
   * Optimize a cluster using the specified strategy
   */
  async optimizeCluster(
    cluster: DynamicCluster, 
    context: OptimizationContext
  ): AsyncResult<OptimizationResult> {
    
    // Check if optimization is already in progress
    if (this.activeOptimizations.has(cluster.id)) {
      return err(new Error(`Optimization already in progress for cluster ${cluster.id}`));
    }

    const optimizationPromise = this.performOptimization(cluster, context);
    this.activeOptimizations.set(cluster.id, optimizationPromise);

    try {
      const result = await optimizationPromise;
      
      // Store optimization history
      if (!this.optimizationHistory.has(cluster.id)) {
        this.optimizationHistory.set(cluster.id, []);
      }
      this.optimizationHistory.get(cluster.id)!.push(result);
      
      return ok(result);
    } finally {
      this.activeOptimizations.delete(cluster.id);
    }
  }

  /**
   * Get optimization history for a cluster
   */
  getOptimizationHistory(clusterId: ID): OptimizationResult[] {
    return this.optimizationHistory.get(clusterId) || [];
  }

  /**
   * Get optimization recommendations
   */
  getOptimizationRecommendations(cluster: DynamicCluster): OptimizationRecommendation[] {
    const recommendations: OptimizationRecommendation[] = [];
    
    // Analyze current cluster state
    const currentCoherence = cluster.coherence_metrics.overall_coherence;
    const performance = cluster.performance_metrics;
    
    // Generate recommendations based on analysis
    if (currentCoherence < 0.7) {
      recommendations.push({
        type: 'coherence_improvement',
        priority: 'high',
        strategy: 'genetic_algorithm',
        expected_improvement: 0.15,
        estimated_time: 5000,
        description: 'Low coherence detected - genetic algorithm optimization recommended'
      });
    }
    
    if (performance.error_rate > 0.1) {
      recommendations.push({
        type: 'error_reduction',
        priority: 'high',
        strategy: 'neural_network',
        expected_improvement: 0.08,
        estimated_time: 8000,
        description: 'High error rate detected - neural network optimization recommended'
      });
    }
    
    if (cluster.nodes.length > 20) {
      recommendations.push({
        type: 'scalability',
        priority: 'medium',
        strategy: 'swarm_intelligence',
        expected_improvement: 0.12,
        estimated_time: 6000,
        description: 'Large cluster size - swarm intelligence optimization recommended'
      });
    }
    
    return recommendations;
  }

  // Private implementation methods

  private async performOptimization(
    cluster: DynamicCluster, 
    context: OptimizationContext
  ): Promise<OptimizationResult> {
    
    const startTime = Date.now();
    const optimizationPath: OptimizationStep[] = [];
    
    switch (context.optimization_strategy) {
      case 'genetic_algorithm':
        return await this.geneticAlgorithmOptimization(cluster, context);
      
      case 'neural_network':
        return await this.neuralNetworkOptimization(cluster, context);
      
      case 'quantum_annealing':
        return await this.quantumAnnealingOptimization(cluster, context);
      
      case 'swarm_intelligence':
        return await this.swarmIntelligenceOptimization(cluster, context);
      
      case 'evolutionary':
        return await this.evolutionaryOptimization(cluster, context);
      
      case 'adaptive_hybrid':
        return await this.adaptiveHybridOptimization(cluster, context);
      
      case 'emergent_optimization':
        return await this.emergentOptimization(cluster, context);
      
      default:
        return await this.gradientDescentOptimization(cluster, context);
    }
  }

  private async geneticAlgorithmOptimization(
    cluster: DynamicCluster, 
    context: OptimizationContext
  ): Promise<OptimizationResult> {
    
    const startTime = Date.now();
    const optimizationPath: OptimizationStep[] = [];
    let currentCoherence = context.current_coherence;
    let iterations = 0;
    const maxIterations = 50;
    const populationSize = 20;

    while (iterations < maxIterations && currentCoherence < context.target_coherence) {
      // Simulate genetic algorithm optimization
      const improvement = this.simulateGeneticStep(context, currentCoherence, iterations);
      currentCoherence = Math.min(1.0, currentCoherence + improvement);
      
      optimizationPath.push({
        iteration: iterations,
        coherence_before: currentCoherence - improvement,
        coherence_after: currentCoherence,
        improvement: improvement,
        parameters_modified: ['genetic_parameters', 'fitness_function'],
        resource_usage: {
          cpu_used: 0.8,
          memory_used: 0.6,
          network_used: 0.2,
          quantum_resources_used: 0.1,
          coherence_field_used: 0.3
        },
        convergence_measure: Math.abs(context.target_coherence - currentCoherence),
        timestamp: Date.now()
      });

      iterations++;
    }

    const executionTime = Date.now() - startTime;
    
    return {
      success: true,
      final_coherence: currentCoherence,
      improvement: currentCoherence - context.current_coherence,
      iterations: iterations,
      execution_time: executionTime,
      convergence_achieved: currentCoherence >= context.target_coherence,
      warnings: [],
      optimization_path: optimizationPath,
      resource_utilization: this.calculateResourceUtilization(optimizationPath),
      convergence_metrics: this.calculateConvergenceMetrics(optimizationPath)
    };
  }

  private async neuralNetworkOptimization(
    cluster: DynamicCluster, 
    context: OptimizationContext
  ): Promise<OptimizationResult> {
    
    const startTime = Date.now();
    const optimizationPath: OptimizationStep[] = [];
    let currentCoherence = context.current_coherence;
    let iterations = 0;
    const maxIterations = 40;

    while (iterations < maxIterations && currentCoherence < context.target_coherence) {
      // Simulate neural network optimization step
      const improvement = this.simulateNeuralNetworkStep(context, currentCoherence);
      currentCoherence = Math.min(1.0, currentCoherence + improvement);
      
      optimizationPath.push({
        iteration: iterations,
        coherence_before: currentCoherence - improvement,
        coherence_after: currentCoherence,
        improvement: improvement,
        parameters_modified: ['neural_weights', 'biases'],
        resource_usage: {
          cpu_used: 0.9,
          memory_used: 0.7,
          network_used: 0.2,
          quantum_resources_used: 0.1,
          coherence_field_used: 0.3
        },
        convergence_measure: Math.abs(context.target_coherence - currentCoherence),
        timestamp: Date.now()
      });

      iterations++;
    }

    const executionTime = Date.now() - startTime;

    return {
      success: true,
      final_coherence: currentCoherence,
      improvement: currentCoherence - context.current_coherence,
      iterations: iterations,
      execution_time: executionTime,
      convergence_achieved: currentCoherence >= context.target_coherence,
      warnings: [],
      optimization_path: optimizationPath,
      resource_utilization: this.calculateResourceUtilization(optimizationPath),
      convergence_metrics: this.calculateConvergenceMetrics(optimizationPath)
    };
  }

  private async quantumAnnealingOptimization(
    cluster: DynamicCluster, 
    context: OptimizationContext
  ): Promise<OptimizationResult> {
    
    const startTime = Date.now();
    const optimizationPath: OptimizationStep[] = [];
    let currentCoherence = context.current_coherence;
    let iterations = 0;
    const maxIterations = 60;
    let temperature = 100;

    while (iterations < maxIterations && currentCoherence < context.target_coherence && temperature > 0.01) {
      // Simulate quantum annealing optimization
      const improvement = this.simulateQuantumAnnealingStep(context, currentCoherence, temperature);
      currentCoherence = Math.min(1.0, currentCoherence + improvement);
      
      optimizationPath.push({
        iteration: iterations,
        coherence_before: currentCoherence - improvement,
        coherence_after: currentCoherence,
        improvement: improvement,
        parameters_modified: ['quantum_state', 'annealing_parameters'],
        resource_usage: {
          cpu_used: 0.7,
          memory_used: 0.5,
          network_used: 0.3,
          quantum_resources_used: 0.8,
          coherence_field_used: 0.6
        },
        convergence_measure: Math.abs(context.target_coherence - currentCoherence),
        timestamp: Date.now()
      });

      temperature *= 0.95; // Cool down
      iterations++;
    }

    const executionTime = Date.now() - startTime;

    return {
      success: true,
      final_coherence: currentCoherence,
      improvement: currentCoherence - context.current_coherence,
      iterations: iterations,
      execution_time: executionTime,
      convergence_achieved: currentCoherence >= context.target_coherence,
      warnings: [],
      optimization_path: optimizationPath,
      resource_utilization: this.calculateResourceUtilization(optimizationPath),
      convergence_metrics: this.calculateConvergenceMetrics(optimizationPath)
    };
  }

  private async swarmIntelligenceOptimization(
    cluster: DynamicCluster, 
    context: OptimizationContext
  ): Promise<OptimizationResult> {
    
    const startTime = Date.now();
    const optimizationPath: OptimizationStep[] = [];
    let currentCoherence = context.current_coherence;
    let iterations = 0;
    const maxIterations = 45;

    while (iterations < maxIterations && currentCoherence < context.target_coherence) {
      // Simulate swarm intelligence optimization
      const improvement = this.simulateSwarmIntelligenceStep(context, currentCoherence, iterations);
      currentCoherence = Math.min(1.0, currentCoherence + improvement);
      
      optimizationPath.push({
        iteration: iterations,
        coherence_before: currentCoherence - improvement,
        coherence_after: currentCoherence,
        improvement: improvement,
        parameters_modified: ['particle_positions', 'swarm_parameters'],
        resource_usage: {
          cpu_used: 0.6,
          memory_used: 0.4,
          network_used: 0.5,
          quantum_resources_used: 0.3,
          coherence_field_used: 0.4
        },
        convergence_measure: Math.abs(context.target_coherence - currentCoherence),
        timestamp: Date.now()
      });

      iterations++;
    }

    const executionTime = Date.now() - startTime;

    return {
      success: true,
      final_coherence: currentCoherence,
      improvement: currentCoherence - context.current_coherence,
      iterations: iterations,
      execution_time: executionTime,
      convergence_achieved: currentCoherence >= context.target_coherence,
      warnings: [],
      optimization_path: optimizationPath,
      resource_utilization: this.calculateResourceUtilization(optimizationPath),
      convergence_metrics: this.calculateConvergenceMetrics(optimizationPath)
    };
  }

  private async evolutionaryOptimization(
    cluster: DynamicCluster, 
    context: OptimizationContext
  ): Promise<OptimizationResult> {
    // Similar to genetic algorithm but with different evolutionary operators
    return this.geneticAlgorithmOptimization(cluster, context);
  }

  private async adaptiveHybridOptimization(
    cluster: DynamicCluster, 
    context: OptimizationContext
  ): Promise<OptimizationResult> {
    
    const startTime = Date.now();
    const optimizationPath: OptimizationStep[] = [];
    let currentCoherence = context.current_coherence;
    let iterations = 0;
    const maxIterations = 55;

    while (iterations < maxIterations && currentCoherence < context.target_coherence) {
      // Adaptively choose optimization strategy based on current state
      let strategy: OptimizationStrategy;
      
      if (currentCoherence < 0.5) {
        strategy = 'genetic_algorithm';
      } else if (currentCoherence < 0.8) {
        strategy = 'neural_network';
      } else {
        strategy = 'quantum_annealing';
      }

      const improvement = this.simulateAdaptiveStep(context, currentCoherence, strategy);
      currentCoherence = Math.min(1.0, currentCoherence + improvement);

      optimizationPath.push({
        iteration: iterations,
        coherence_before: currentCoherence - improvement,
        coherence_after: currentCoherence,
        improvement: improvement,
        parameters_modified: [strategy],
        resource_usage: {
          cpu_used: 0.7,
          memory_used: 0.5,
          network_used: 0.3,
          quantum_resources_used: 0.2,
          coherence_field_used: 0.4
        },
        convergence_measure: Math.abs(context.target_coherence - currentCoherence),
        timestamp: Date.now()
      });

      iterations++;
    }

    const executionTime = Date.now() - startTime;

    return {
      success: true,
      final_coherence: currentCoherence,
      improvement: currentCoherence - context.current_coherence,
      iterations: iterations,
      execution_time: executionTime,
      convergence_achieved: currentCoherence >= context.target_coherence,
      warnings: [],
      optimization_path: optimizationPath,
      resource_utilization: this.calculateResourceUtilization(optimizationPath),
      convergence_metrics: this.calculateConvergenceMetrics(optimizationPath)
    };
  }

  private async emergentOptimization(
    cluster: DynamicCluster, 
    context: OptimizationContext
  ): Promise<OptimizationResult> {
    
    const startTime = Date.now();
    const optimizationPath: OptimizationStep[] = [];
    let currentCoherence = context.current_coherence;
    let iterations = 0;
    const maxIterations = 50;

    while (iterations < maxIterations && currentCoherence < context.target_coherence) {
      // Simulate emergent behavior optimization
      const improvement = this.simulateEmergentStep(context, currentCoherence, iterations);
      currentCoherence = Math.min(1.0, currentCoherence + improvement);

      optimizationPath.push({
        iteration: iterations,
        coherence_before: currentCoherence - improvement,
        coherence_after: currentCoherence,
        improvement: improvement,
        parameters_modified: ['emergent_properties', 'self_organization'],
        resource_usage: {
          cpu_used: 0.6,
          memory_used: 0.4,
          network_used: 0.5,
          quantum_resources_used: 0.3,
          coherence_field_used: 0.6
        },
        convergence_measure: Math.abs(context.target_coherence - currentCoherence),
        timestamp: Date.now()
      });

      iterations++;
    }

    const executionTime = Date.now() - startTime;

    return {
      success: true,
      final_coherence: currentCoherence,
      improvement: currentCoherence - context.current_coherence,
      iterations: iterations,
      execution_time: executionTime,
      convergence_achieved: currentCoherence >= context.target_coherence,
      warnings: [],
      optimization_path: optimizationPath,
      resource_utilization: this.calculateResourceUtilization(optimizationPath),
      convergence_metrics: this.calculateConvergenceMetrics(optimizationPath)
    };
  }

  private async gradientDescentOptimization(
    cluster: DynamicCluster, 
    context: OptimizationContext
  ): Promise<OptimizationResult> {
    
    const startTime = Date.now();
    const optimizationPath: OptimizationStep[] = [];
    let currentCoherence = context.current_coherence;
    let iterations = 0;
    const maxIterations = 80;
    const learningRate = 0.01;

    while (iterations < maxIterations && currentCoherence < context.target_coherence) {
      // Calculate gradient (simplified)
      const gradient = this.calculateGradient(context, currentCoherence);
      
      // Update coherence using gradient descent
      const improvement = learningRate * gradient;
      currentCoherence = Math.min(1.0, currentCoherence + improvement);

      optimizationPath.push({
        iteration: iterations,
        coherence_before: currentCoherence - improvement,
        coherence_after: currentCoherence,
        improvement: improvement,
        parameters_modified: ['gradient_parameters'],
        resource_usage: {
          cpu_used: 0.3,
          memory_used: 0.2,
          network_used: 0.1,
          quantum_resources_used: 0.05,
          coherence_field_used: 0.2
        },
        convergence_measure: Math.abs(context.target_coherence - currentCoherence),
        timestamp: Date.now()
      });

      iterations++;
    }

    const executionTime = Date.now() - startTime;

    return {
      success: true,
      final_coherence: currentCoherence,
      improvement: currentCoherence - context.current_coherence,
      iterations: iterations,
      execution_time: executionTime,
      convergence_achieved: currentCoherence >= context.target_coherence,
      warnings: [],
      optimization_path: optimizationPath,
      resource_utilization: this.calculateResourceUtilization(optimizationPath),
      convergence_metrics: this.calculateConvergenceMetrics(optimizationPath)
    };
  }

  // Simulation methods for different optimization strategies

  private simulateGeneticStep(context: OptimizationContext, currentCoherence: number, iteration: number): number {
    const baseImprovement = 0.008;
    const selectionPressure = Math.min(1.0, iteration / 20);
    const diversityFactor = Math.max(0.5, 1.0 - iteration / 40);
    
    return baseImprovement * (1 + selectionPressure * 0.5) * diversityFactor * (1 + Math.random() * 0.2);
  }

  private simulateNeuralNetworkStep(context: OptimizationContext, currentCoherence: number): number {
    const targetDiff = context.target_coherence - currentCoherence;
    const learningRate = 0.01;
    const networkComplexity = 0.1;
    
    return learningRate * targetDiff * (1 + networkComplexity * Math.random());
  }

  private simulateQuantumAnnealingStep(context: OptimizationContext, currentCoherence: number, temperature: number): number {
    const baseImprovement = 0.006;
    const quantumFactor = Math.min(1.0, temperature / 50);
    const tunnelingEffect = Math.random() * 0.3;
    
    return baseImprovement * quantumFactor * (1 + tunnelingEffect);
  }

  private simulateSwarmIntelligenceStep(context: OptimizationContext, currentCoherence: number, iteration: number): number {
    const baseImprovement = 0.007;
    const swarmIntelligence = Math.min(1.0, iteration / 15);
    const collectiveBehavior = 0.8 + Math.random() * 0.4;
    
    return baseImprovement * swarmIntelligence * collectiveBehavior;
  }

  private simulateAdaptiveStep(context: OptimizationContext, currentCoherence: number, strategy: OptimizationStrategy): number {
    const baseImprovement = 0.005;
    const strategyMultiplier = {
      'genetic_algorithm': 1.2,
      'neural_network': 1.1,
      'quantum_annealing': 1.3,
      'swarm_intelligence': 1.15,
      'evolutionary': 1.25,
      'adaptive_hybrid': 1.4,
      'emergent_optimization': 1.35,
      'gradient_descent': 1.0
    }[strategy];
    
    return baseImprovement * strategyMultiplier * (1 + Math.random() * 0.2);
  }

  private simulateEmergentStep(context: OptimizationContext, currentCoherence: number, iteration: number): number {
    const baseImprovement = 0.008;
    const emergenceFactor = Math.min(1.0, iteration / 30);
    const randomness = Math.random() * 0.3;
    
    return baseImprovement * (1 + emergenceFactor) * (1 + randomness);
  }

  private calculateGradient(context: OptimizationContext, currentCoherence: number): number {
    const targetDiff = context.target_coherence - currentCoherence;
    const gradient = targetDiff * 0.1;
    
    return gradient;
  }

  private calculateResourceUtilization(optimizationPath: OptimizationStep[]): ResourceUtilization {
    if (optimizationPath.length === 0) {
      return {
        average_cpu: 0,
        average_memory: 0,
        average_network: 0,
        average_quantum: 0,
        peak_cpu: 0,
        peak_memory: 0,
        efficiency_score: 0
      };
    }
    
    const totalCpu = optimizationPath.reduce((sum, step) => sum + step.resource_usage.cpu_used, 0);
    const totalMemory = optimizationPath.reduce((sum, step) => sum + step.resource_usage.memory_used, 0);
    const totalNetwork = optimizationPath.reduce((sum, step) => sum + step.resource_usage.network_used, 0);
    const totalQuantum = optimizationPath.reduce((sum, step) => sum + step.resource_usage.quantum_resources_used, 0);
    
    const peakCpu = Math.max(...optimizationPath.map(step => step.resource_usage.cpu_used));
    const peakMemory = Math.max(...optimizationPath.map(step => step.resource_usage.memory_used));
    
    return {
      average_cpu: totalCpu / optimizationPath.length,
      average_memory: totalMemory / optimizationPath.length,
      average_network: totalNetwork / optimizationPath.length,
      average_quantum: totalQuantum / optimizationPath.length,
      peak_cpu: peakCpu,
      peak_memory: peakMemory,
      efficiency_score: this.calculateEfficiencyScore(optimizationPath)
    };
  }

  private calculateEfficiencyScore(optimizationPath: OptimizationStep[]): number {
    if (optimizationPath.length === 0) return 0;
    
    const totalImprovement = optimizationPath.reduce((sum, step) => sum + step.improvement, 0);
    const totalResourceUsage = optimizationPath.reduce((sum, step) => 
      sum + step.resource_usage.cpu_used + step.resource_usage.memory_used + 
      step.resource_usage.network_used + step.resource_usage.quantum_resources_used, 0);
    
    return totalImprovement / (totalResourceUsage / optimizationPath.length);
  }

  private calculateConvergenceMetrics(optimizationPath: OptimizationStep[]): ConvergenceMetrics {
    if (optimizationPath.length < 2) {
      return {
        convergence_rate: 0,
        stability_measure: 0,
        oscillation_frequency: 0,
        convergence_threshold: 0.001,
        final_stability: 0
      };
    }
    
    const improvements = optimizationPath.map(step => step.improvement);
    const convergenceMeasures = optimizationPath.map(step => step.convergence_measure);
    
    const convergenceRate = this.calculateConvergenceRate(improvements);
    const stabilityMeasure = this.calculateStabilityMeasure(convergenceMeasures);
    const oscillationFrequency = this.calculateOscillationFrequency(improvements);
    
    return {
      convergence_rate: convergenceRate,
      stability_measure: stabilityMeasure,
      oscillation_frequency: oscillationFrequency,
      convergence_threshold: 0.001,
      final_stability: convergenceMeasures[convergenceMeasures.length - 1]
    };
  }

  private calculateConvergenceRate(improvements: number[]): number {
    if (improvements.length < 2) return 0;
    
    const recentImprovements = improvements.slice(-10);
    const avgImprovement = recentImprovements.reduce((sum, imp) => sum + imp, 0) / recentImprovements.length;
    
    return avgImprovement;
  }

  private calculateStabilityMeasure(convergenceMeasures: number[]): number {
    if (convergenceMeasures.length < 2) return 0;
    
    const variance = convergenceMeasures.reduce((sum, measure) => 
      sum + Math.pow(measure - convergenceMeasures[convergenceMeasures.length - 1], 2), 0) / convergenceMeasures.length;
    
    return 1 / (1 + variance);
  }

  private calculateOscillationFrequency(improvements: number[]): number {
    if (improvements.length < 3) return 0;
    
    let oscillations = 0;
    for (let i = 1; i < improvements.length - 1; i++) {
      if ((improvements[i] - improvements[i-1]) * (improvements[i+1] - improvements[i]) < 0) {
        oscillations++;
      }
    }
    
    return oscillations / improvements.length;
  }
}