import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const claimant = searchParams.get('claimant');

    const where: any = { walletId: params.id };
    if (status) where.status = status;
    if (claimant) where.claimant = claimant;

    const claims = await db.walletOwnershipClaim.findMany({
      where,
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(claims);
  } catch (error) {
    console.error('Error fetching ownership claims:', error);
    return NextResponse.json(
      { error: 'Failed to fetch ownership claims' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const {
      claimant,
      proof,
      verificationMethod,
      confidence,
      metadata,
      expiresAt
    } = body;

    // Validate required fields
    if (!claimant || !verificationMethod) {
      return NextResponse.json(
        { error: 'Claimant and verification method are required' },
        { status: 400 }
      );
    }

    // Check if wallet exists
    const wallet = await db.wallet.findUnique({
      where: { id: params.id }
    });

    if (!wallet) {
      return NextResponse.json(
        { error: 'Wallet not found' },
        { status: 404 }
      );
    }

    const claim = await db.walletOwnershipClaim.create({
      data: {
        walletId: params.id,
        claimant,
        proof,
        verificationMethod,
        confidence: confidence || 0.5,
        metadata: metadata ? JSON.stringify(metadata) : null,
        expiresAt: expiresAt ? new Date(expiresAt) : null
      }
    });

    // Simulate verification process
    setTimeout(async () => {
      try {
        const verificationResult = {
          verified: Math.random() > 0.3,
          confidence: 0.6 + Math.random() * 0.4,
          details: {
            signatureValid: Math.random() > 0.2,
            knowledgeVerified: Math.random() > 0.3,
            possessionConfirmed: Math.random() > 0.1,
            riskFactors: []
          }
        };

        await db.walletOwnershipClaim.update({
          where: { id: claim.id },
          data: {
            status: verificationResult.verified ? 'verified' : 'rejected',
            confidence: verificationResult.confidence,
            verifiedAt: new Date()
          }
        });
      } catch (error) {
        console.error('Error verifying ownership claim:', error);
      }
    }, 2000);

    return NextResponse.json(claim, { status: 201 });
  } catch (error) {
    console.error('Error creating ownership claim:', error);
    return NextResponse.json(
      { error: 'Failed to create ownership claim' },
      { status: 500 }
    );
  }
}