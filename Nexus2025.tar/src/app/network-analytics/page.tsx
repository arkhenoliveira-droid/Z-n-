'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Button } from '@/components/ui/button'
import { 
  Users, 
  Network, 
  TrendingUp, 
  Clock, 
  Globe, 
  Zap,
  BarChart3,
  PieChart,
  Activity
} from 'lucide-react'
import CommunityInsights from '@/components/community-insights'
import NetworkComparison from '@/components/network-comparison'

const orkutStats = {
  nodes: 3072441,
  edges: 117185083,
  avgClustering: 0.1666,
  triangles: 627584181,
  diameter: 9,
  effectiveDiameter: 4.8,
  communities: 6288363,
  topCommunities: 5000
}

const formatNumber = (num: number) => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M'
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K'
  }
  return num.toString()
}

const formatLargeNumber = (num: number) => {
  return num.toLocaleString()
}

export default function NetworkAnalytics() {
  const [activeTab, setActiveTab] = useState('overview')
  const [isLoading, setIsLoading] = useState(false)

  const networkDensity = (orkutStats.edges / (orkutStats.nodes * (orkutStats.nodes - 1) / 2) * 100).toFixed(4)
  const avgDegree = (orkutStats.edges * 2 / orkutStats.nodes).toFixed(1)
  const closedTrianglesFraction = (0.01414 * 100).toFixed(2)

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
          Orkut Network Analytics
        </h1>
        <p className="text-lg text-muted-foreground">
          Explore the real structure and scale of the original Orkut social network
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="structure">Network Structure</TabsTrigger>
          <TabsTrigger value="communities">Communities</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="border-red-200 dark:border-red-800">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                <Users className="h-4 w-4 text-red-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(orkutStats.nodes)}</div>
                <p className="text-xs text-muted-foreground">
                  {formatLargeNumber(orkutStats.nodes)} users
                </p>
              </CardContent>
            </Card>

            <Card className="border-blue-200 dark:border-blue-800">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Friendships</CardTitle>
                <Network className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(orkutStats.edges)}</div>
                <p className="text-xs text-muted-foreground">
                  {formatLargeNumber(orkutStats.edges)} connections
                </p>
              </CardContent>
            </Card>

            <Card className="border-green-200 dark:border-green-800">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Communities</CardTitle>
                <PieChart className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(orkutStats.communities)}</div>
                <p className="text-xs text-muted-foreground">
                  User-defined groups
                </p>
              </CardContent>
            </Card>

            <Card className="border-purple-200 dark:border-purple-800">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg. Degree</CardTitle>
                <TrendingUp className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{avgDegree}</div>
                <p className="text-xs text-muted-foreground">
                  Friends per user
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Network Scale Comparison
              </CardTitle>
              <CardDescription>
                How Orkut compares to other social networks of its era
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Orkut (2004-2014)</span>
                    <span className="font-medium">3.07M users</span>
                  </div>
                  <Progress value={100} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Early Facebook (2004)</span>
                    <span className="font-medium">1M users</span>
                  </div>
                  <Progress value={32} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>MySpace (Peak)</span>
                    <span className="font-medium">100M users</span>
                  </div>
                  <Progress value={3257} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="structure" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Network Topology
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Network Density</span>
                    <Badge variant="outline">{networkDensity}%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Clustering Coefficient</span>
                    <Badge variant="outline">{orkutStats.avgClustering}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Network Diameter</span>
                    <Badge variant="outline">{orkutStats.diameter} hops</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">90% Effective Diameter</span>
                    <Badge variant="outline">{orkutStats.effectiveDiameter} hops</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  Connectivity Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Connected Component</span>
                    <Badge variant="outline">100%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Strongly Connected</span>
                    <Badge variant="outline">100%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Triangles</span>
                    <Badge variant="outline">{formatNumber(orkutStats.triangles)}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Closed Triangles</span>
                    <Badge variant="outline">{closedTrianglesFraction}%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Network Structure Insights</CardTitle>
              <CardDescription>
                Key characteristics of Orkut's social graph
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold text-sm">Highly Connected</h4>
                  <p className="text-sm text-muted-foreground">
                    The network forms a single giant component, meaning almost every user is connected through some path.
                  </p>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-sm">Small World</h4>
                  <p className="text-sm text-muted-foreground">
                    With a diameter of just 9 hops, Orkut exhibited classic small-world network properties.
                  </p>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-sm">Community Focused</h4>
                  <p className="text-sm text-muted-foreground">
                    Users formed over 6 million communities, showing strong group-forming behavior.
                  </p>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-sm">Moderate Clustering</h4>
                  <p className="text-sm text-muted-foreground">
                    The clustering coefficient of 0.17 indicates moderate friend-of-friend connectivity.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="communities" className="space-y-6">
          <CommunityInsights />
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Historical Context
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-sm mb-2">Era Significance</h4>
                    <p className="text-sm text-muted-foreground">
                      Orkut was one of the first large-scale social networks, predating Facebook's global expansion and providing insights into early social network formation patterns.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm mb-2">Global Reach</h4>
                    <p className="text-sm text-muted-foreground">
                      Particularly popular in Brazil and India, showing how social networks can have strong regional adoption patterns.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Network Evolution
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-sm mb-2">Growth Patterns</h4>
                    <p className="text-sm text-muted-foreground">
                      The network structure shows organic growth patterns typical of early social networks, with community formation driving user engagement.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm mb-2">Legacy Impact</h4>
                    <p className="text-sm text-muted-foreground">
                      Orkut's community-focused design influenced many modern social platforms' group and community features.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Key Takeaways</CardTitle>
              <CardDescription>
                What the Orkut network teaches us about social networks
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold text-sm">Technical Insights</h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Large-scale networks can maintain connectivity</li>
                    <li>• Community formation is a natural behavior</li>
                    <li>• Small-world properties emerge organically</li>
                    <li>• Network density decreases with scale</li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-sm">Social Insights</h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Users self-organize into interest groups</li>
                    <li>• Geographic clustering occurs naturally</li>
                    <li>• Community quality varies significantly</li>
                    <li>• Social connections span multiple communities</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <NetworkComparison />

          <Card>
            <CardHeader>
              <CardTitle>Data Source</CardTitle>
              <CardDescription>
                Stanford SNAP Network Dataset Collection
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  This analysis is based on the Orkut social network dataset from the Stanford Network Analysis Platform (SNAP). The dataset contains:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <Badge variant="outline" className="mb-2">Network File</Badge>
                    <p className="text-muted-foreground">
                      com-orkut.ungraph.txt.gz - Undirected friendship network
                    </p>
                  </div>
                  <div>
                    <Badge variant="outline" className="mb-2">Communities File</Badge>
                    <p className="text-muted-foreground">
                      com-orkut.all.cmty.txt.gz - All user-defined communities
                    </p>
                  </div>
                  <div>
                    <Badge variant="outline" className="mb-2">Top Communities</Badge>
                    <p className="text-muted-foreground">
                      com-orkut.top5000.cmty.txt.gz - Highest quality communities
                    </p>
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <p className="text-xs text-muted-foreground">
                    Data provided by Alan Mislove et al. and processed by Jure Leskovec at Stanford University.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}