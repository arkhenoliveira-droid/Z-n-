'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Sparkles, 
  Rocket, 
  Brain, 
  Target,
  TrendingUp,
  BarChart3,
  Bell,
  Search,
  Plus,
  Users,
  MessageCircle,
  Heart,
  Share2,
  Activity,
  Star,
  Award,
  Eye,
  Play,
  Pause,
  Bot,
  Zap
} from 'lucide-react';

import AIAssistant2025 from '@/components/ai-assistant-2025';
import PerformanceOptimizer2025 from '@/components/performance-optimizer-2025';

// Modern 2025 Interfaces
interface UserProfile {
  id: string;
  name: string;
  username: string;
  avatar: string;
  bio: string;
  joinDate: string;
  stats: {
    posts: number;
    followers: number;
    following: number;
    projects: number;
  };
  badges: string[];
  isOnline: boolean;
  lastActive: string;
}

interface Project {
  id: string;
  title: string;
  description: string;
  category: string;
  author: UserProfile;
  progress: number;
  status: 'active' | 'completed' | 'paused' | 'planning';
  tags: string[];
  likes: number;
  views: number;
  createdAt: string;
  updatedAt: string;
  collaborators: UserProfile[];
  techStack: string[];
}

interface ActivityItem {
  id: string;
  type: 'post' | 'project' | 'achievement' | 'collaboration';
  title: string;
  description: string;
  user: UserProfile;
  timestamp: string;
  metadata?: {
    projectId?: string;
    achievementType?: string;
  };
}

interface TrendingTopic {
  id: string;
  title: string;
  category: string;
  posts: number;
  engagement: number;
  isTrending: boolean;
  tags: string[];
}

export default function ModernDashboard2025() {
  // User State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  
  // Content States
  const [projects, setProjects] = useState<Project[]>([]);
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [trendingTopics, setTrendingTopics] = useState<TrendingTopic[]>([]);
  
  // UI States
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<number>(0);
  
  // Initialize with modern mock data
  useEffect(() => {
    initializeMockData();
  }, []);

  const initializeMockData = () => {
    // Mock User
    const mockUser: UserProfile = {
      id: '1',
      name: 'Alex Chen',
      username: 'alexchen2025',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alex2025',
      bio: 'Full-stack developer & AI enthusiast. Building the future one line of code at a time. 🚀',
      joinDate: '2023-01-15',
      stats: {
        posts: 127,
        followers: 2847,
        following: 342,
        projects: 15
      },
      badges: ['Innovator', 'Early Adopter', 'AI Pioneer', 'Open Source'],
      isOnline: true,
      lastActive: new Date().toISOString()
    };

    // Mock Projects
    const mockProjects: Project[] = [
      {
        id: '1',
        title: 'Quantum AI Assistant',
        description: 'Next-generation AI assistant powered by quantum computing principles',
        category: 'AI/ML',
        author: mockUser,
        progress: 78,
        status: 'active',
        tags: ['AI', 'Quantum', 'Assistant', '2025'],
        likes: 1247,
        views: 15420,
        createdAt: '2025-01-15',
        updatedAt: '2025-06-20',
        collaborators: [mockUser],
        techStack: ['Next.js 15', 'React 19', 'TypeScript', 'Quantum SDK']
      },
      {
        id: '2',
        title: 'Neural Interface Platform',
        description: 'Brain-computer interface for seamless human-AI collaboration',
        category: 'Neurotech',
        author: mockUser,
        progress: 45,
        status: 'active',
        tags: ['BCI', 'Neural', 'Interface', 'Future Tech'],
        likes: 892,
        views: 12340,
        createdAt: '2025-02-20',
        updatedAt: '2025-06-18',
        collaborators: [mockUser],
        techStack: ['Python', 'TensorFlow', 'NeuroSDK', 'WebRTC']
      },
      {
        id: '3',
        title: 'Sustainable Energy Grid',
        description: 'AI-optimized energy distribution system for smart cities',
        category: 'Clean Tech',
        author: mockUser,
        progress: 92,
        status: 'active',
        tags: ['Sustainability', 'Energy', 'AI', 'Smart City'],
        likes: 2156,
        views: 28900,
        createdAt: '2024-11-10',
        updatedAt: '2025-06-19',
        collaborators: [mockUser],
        techStack: ['React', 'Node.js', 'IoT', 'Machine Learning']
      }
    ];

    // Mock Activities
    const mockActivities: ActivityItem[] = [
      {
        id: '1',
        type: 'project',
        title: 'Started new project: Quantum AI Assistant',
        description: 'Exploring the intersection of quantum computing and artificial intelligence',
        user: mockUser,
        timestamp: '2 hours ago',
        metadata: { projectId: '1' }
      },
      {
        id: '2',
        type: 'achievement',
        title: 'Achievement Unlocked: AI Pioneer',
        description: 'Recognized for contributions to artificial intelligence research',
        user: mockUser,
        timestamp: '1 day ago',
        metadata: { achievementType: 'AI Pioneer' }
      },
      {
        id: '3',
        type: 'collaboration',
        title: 'Joined Neural Interface Research Team',
        description: 'Collaborating on cutting-edge brain-computer interface technology',
        user: mockUser,
        timestamp: '3 days ago'
      }
    ];

    // Mock Trending Topics
    const mockTrendingTopics: TrendingTopic[] = [
      {
        id: '1',
        title: 'Quantum Computing Breakthrough',
        category: 'Technology',
        posts: 15420,
        engagement: 89.5,
        isTrending: true,
        tags: ['quantum', 'computing', 'breakthrough', '2025']
      },
      {
        id: '2',
        title: 'AI Ethics & Governance',
        category: 'AI/ML',
        posts: 12340,
        engagement: 76.2,
        isTrending: true,
        tags: ['ai', 'ethics', 'governance', 'responsibility']
      },
      {
        id: '3',
        title: 'Sustainable Tech Solutions',
        category: 'Environment',
        posts: 9870,
        engagement: 82.1,
        isTrending: true,
        tags: ['sustainability', 'green-tech', 'environment', 'innovation']
      }
    ];

    setCurrentUser(mockUser);
    setIsLoggedIn(true);
    setProjects(mockProjects);
    setActivities(mockActivities);
    setTrendingTopics(mockTrendingTopics);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'completed': return 'bg-blue-500';
      case 'paused': return 'bg-yellow-500';
      case 'planning': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <Play className="h-4 w-4" />;
      case 'completed': return <Award className="h-4 w-4" />;
      case 'paused': return <Pause className="h-4 w-4" />;
      case 'planning': return <Target className="h-4 w-4" />;
      default: return <Activity className="h-4 w-4" />;
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'project': return <Rocket className="h-5 w-5 text-blue-500" />;
      case 'achievement': return <Star className="h-5 w-5 text-yellow-500" />;
      case 'collaboration': return <Users className="h-5 w-5 text-green-500" />;
      default: return <Activity className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-700">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Sparkles className="h-8 w-8 text-purple-600" />
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  Nexus 2025
                </h1>
              </div>
              <Badge variant="outline" className="text-xs">
                BETA
              </Badge>
            </div>

            <div className="flex items-center space-x-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Search projects, users, topics..."
                  className="pl-10 w-64"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {/* Notifications */}
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-5 w-5" />
                {notifications > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {notifications}
                  </span>
                )}
              </Button>

              {/* User Profile */}
              {currentUser && (
                <div className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={currentUser.avatar} alt={currentUser.name} />
                    <AvatarFallback>{currentUser.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="hidden md:block">
                    <p className="text-sm font-medium">{currentUser.name}</p>
                    <p className="text-xs text-slate-500">@{currentUser.username}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-6 lg:w-auto lg:grid-cols-6">
            <TabsTrigger value="dashboard" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="projects" className="flex items-center space-x-2">
              <Rocket className="h-4 w-4" />
              <span>Projects</span>
            </TabsTrigger>
            <TabsTrigger value="activity" className="flex items-center space-x-2">
              <Activity className="h-4 w-4" />
              <span>Activity</span>
            </TabsTrigger>
            <TabsTrigger value="ai-assistant" className="flex items-center space-x-2">
              <Bot className="h-4 w-4" />
              <span>AI Assistant</span>
            </TabsTrigger>
            <TabsTrigger value="performance" className="flex items-center space-x-2">
              <Zap className="h-4 w-4" />
              <span>Performance</span>
            </TabsTrigger>
            <TabsTrigger value="trending" className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4" />
              <span>Trending</span>
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-8">
            {/* Welcome Section */}
            <div className="text-center space-y-4">
              <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                Welcome to the Future
              </h2>
              <p className="text-xl text-slate-600 dark:text-slate-300">
                Building tomorrow's technology, today.
              </p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Projects</CardTitle>
                  <Rocket className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{projects.length}</div>
                  <p className="text-xs opacity-80">+12% from last month</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                  <Users className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">2,847</div>
                  <p className="text-xs opacity-80">+23% from last month</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">AI Models</CardTitle>
                  <Brain className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">147</div>
                  <p className="text-xs opacity-80">+8% from last month</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
                  <Target className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">94.2%</div>
                  <p className="text-xs opacity-80">+2.1% from last month</p>
                </CardContent>
              </Card>
            </div>

            {/* Featured Projects */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Rocket className="h-5 w-5" />
                    <span>Featured Projects</span>
                  </CardTitle>
                  <CardDescription>
                    Most innovative projects this month
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {projects.slice(0, 3).map((project) => (
                    <div key={project.id} className="flex items-center space-x-4 p-4 rounded-lg border border-slate-200 dark:border-slate-700">
                      <div className="flex-shrink-0">
                        <div className={`w-12 h-12 rounded-lg ${getStatusColor(project.status)} flex items-center justify-center text-white`}>
                          {getStatusIcon(project.status)}
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{project.title}</p>
                        <p className="text-xs text-slate-500 truncate">{project.category}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Progress value={project.progress} className="h-2 flex-1" />
                          <span className="text-xs text-slate-500">{project.progress}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Activity className="h-5 w-5" />
                    <span>Recent Activity</span>
                  </CardTitle>
                  <CardDescription>
                    Latest updates from your network
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {activities.slice(0, 4).map((activity) => (
                    <div key={activity.id} className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-1">
                        {getActivityIcon(activity.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{activity.title}</p>
                        <p className="text-xs text-slate-500">{activity.description}</p>
                        <p className="text-xs text-slate-400 mt-1">{activity.timestamp}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-3xl font-bold">Projects</h2>
                <p className="text-slate-600 dark:text-slate-300">
                  Explore innovative projects from the community
                </p>
              </div>
              <Button className="flex items-center space-x-2">
                <Plus className="h-4 w-4" />
                <span>New Project</span>
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project) => (
                <Card key={project.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className={`w-8 h-8 rounded-lg ${getStatusColor(project.status)} flex items-center justify-center text-white`}>
                        {getStatusIcon(project.status)}
                      </div>
                      <Badge variant="outline">{project.category}</Badge>
                    </div>
                    <CardTitle className="text-lg">{project.title}</CardTitle>
                    <CardDescription className="line-clamp-2">
                      {project.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Progress</span>
                        <span>{project.progress}%</span>
                      </div>
                      <Progress value={project.progress} className="h-2" />
                    </div>

                    <div className="flex items-center justify-between text-sm text-slate-500">
                      <div className="flex items-center space-x-1">
                        <Heart className="h-4 w-4" />
                        <span>{project.likes}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Eye className="h-4 w-4" />
                        <span>{project.views}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4" />
                        <span>{project.collaborators.length}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {project.tags.slice(0, 3).map((tag, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center space-x-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={project.author.avatar} alt={project.author.name} />
                        <AvatarFallback className="text-xs">{project.author.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm text-slate-500">{project.author.name}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity" className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold">Activity Feed</h2>
              <p className="text-slate-600 dark:text-slate-300">
                Stay updated with the latest from your network
              </p>
            </div>

            <div className="space-y-6">
              {activities.map((activity) => (
                <Card key={activity.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start space-x-4">
                      <div className="flex-shrink-0">
                        {getActivityIcon(activity.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={activity.user.avatar} alt={activity.user.name} />
                            <AvatarFallback>{activity.user.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium">{activity.user.name}</p>
                            <p className="text-xs text-slate-500">@{activity.user.username}</p>
                          </div>
                        </div>
                        <div className="mt-3">
                          <h3 className="text-lg font-semibold">{activity.title}</h3>
                          <p className="text-slate-600 dark:text-slate-300 mt-1">
                            {activity.description}
                          </p>
                        </div>
                        <div className="flex items-center space-x-4 mt-3 text-sm text-slate-500">
                          <span>{activity.timestamp}</span>
                          <div className="flex items-center space-x-2">
                            <Heart className="h-4 w-4" />
                            <span>24</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <MessageCircle className="h-4 w-4" />
                            <span>8</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Share2 className="h-4 w-4" />
                            <span>3</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* AI Assistant Tab */}
          <TabsContent value="ai-assistant" className="space-y-8">
            <AIAssistant2025 />
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance" className="space-y-8">
            <PerformanceOptimizer2025 />
          </TabsContent>

          {/* Trending Tab */}
          <TabsContent value="trending" className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold">Trending Topics</h2>
              <p className="text-slate-600 dark:text-slate-300">
                Discover what's hot in the community right now
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {trendingTopics.map((topic) => (
                <Card key={topic.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge variant="outline">{topic.category}</Badge>
                      {topic.isTrending && (
                        <Badge className="bg-red-500 hover:bg-red-600">
                          <TrendingUp className="h-3 w-3 mr-1" />
                          Trending
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-xl">{topic.title}</CardTitle>
                    <CardDescription>
                      High engagement topic with active community discussion
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-slate-500">Posts</p>
                        <p className="text-lg font-semibold">{topic.posts.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-500">Engagement</p>
                        <p className="text-lg font-semibold">{topic.engagement}%</p>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {topic.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex space-x-2">
                      <Button size="sm" className="flex-1">
                        <Eye className="h-4 w-4 mr-2" />
                        View Topic
                      </Button>
                      <Button size="sm" variant="outline">
                        <Share2 className="h-4 w-4 mr-2" />
                        Share
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Sparkles className="h-6 w-6 text-purple-600" />
                <span className="text-lg font-bold">Nexus 2025</span>
              </div>
              <p className="text-sm text-slate-600 dark:text-slate-300">
                Building the future of collaborative innovation and technology.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Platform</h3>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
                <li><a href="#" className="hover:text-purple-600">Features</a></li>
                <li><a href="#" className="hover:text-purple-600">Pricing</a></li>
                <li><a href="#" className="hover:text-purple-600">API</a></li>
                <li><a href="#" className="hover:text-purple-600">Documentation</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Community</h3>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
                <li><a href="#" className="hover:text-purple-600">Blog</a></li>
                <li><a href="#" className="hover:text-purple-600">Forum</a></li>
                <li><a href="#" className="hover:text-purple-600">Events</a></li>
                <li><a href="#" className="hover:text-purple-600">Meetups</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Connect</h3>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
                <li><a href="#" className="hover:text-purple-600">Twitter</a></li>
                <li><a href="#" className="hover:text-purple-600">LinkedIn</a></li>
                <li><a href="#" className="hover:text-purple-600">GitHub</a></li>
                <li><a href="#" className="hover:text-purple-600">Discord</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-200 dark:border-slate-700 mt-8 pt-8 text-center text-sm text-slate-600 dark:text-slate-300">
            <p>&copy; 2025 Nexus 2025. All rights reserved. Built with Next.js 15, React 19, and TypeScript.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}