'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, BookOpen, Search, MessageSquare } from 'lucide-react';

interface SearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date: string;
  favicon: string;
}

interface BookAnalysis {
  success: boolean;
  response?: string;
  question?: string;
  error?: string;
}

export default function AndreLuizBooks() {
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [analysis, setAnalysis] = useState<BookAnalysis | null>(null);
  const [question, setQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);

  useEffect(() => {
    // Load initial search results
    fetchSearchResults();
  }, []);

  const fetchSearchResults = async () => {
    setSearchLoading(true);
    try {
      const response = await fetch('/api/andre-luiz-books');
      const data = await response.json();
      
      if (data.success) {
        setSearchResults(data.data);
      } else {
        console.error('Failed to fetch search results:', data.error);
      }
    } catch (error) {
      console.error('Error fetching search results:', error);
    } finally {
      setSearchLoading(false);
    }
  };

  const analyzeBooks = async () => {
    if (!question.trim()) return;
    
    setLoading(true);
    try {
      const response = await fetch('/api/andre-luiz-books', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ question }),
      });
      
      const data: BookAnalysis = await response.json();
      setAnalysis(data);
    } catch (error) {
      console.error('Error analyzing books:', error);
      setAnalysis({
        success: false,
        error: 'Failed to get analysis. Please try again.'
      });
    } finally {
      setLoading(false);
    }
  };

  const formatSnippet = (snippet: string) => {
    return snippet.replace(/<[^>]*>/g, '').substring(0, 200) + '...';
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <BookOpen className="h-8 w-8" />
          Obras de André Luiz
        </h1>
        <p className="text-muted-foreground">
          Explorando "Nos Domínios da Mediunidade" e "Mecanismos da Mediunidade"
        </p>
      </div>

      <Tabs defaultValue="analysis" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="analysis">Análise dos Livros</TabsTrigger>
          <TabsTrigger value="search">Pesquisa Online</TabsTrigger>
        </TabsList>

        <TabsContent value="analysis" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Análise Inteligente
              </CardTitle>
              <CardDescription>
                Faça perguntas sobre os ensinamentos de André Luiz sobre mediunidade
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Sua Pergunta:</label>
                <Textarea
                  placeholder="Ex: Quais são os principais ensinamentos sobre mediunidade em 'Nos Domínios da Mediunidade'?"
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  className="min-h-[100px]"
                />
              </div>
              
              <Button 
                onClick={analyzeBooks} 
                disabled={!question.trim() || loading}
                className="w-full"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analisando...
                  </>
                ) : (
                  'Analisar Livros'
                )}
              </Button>

              {analysis && (
                <Card className="mt-4">
                  <CardHeader>
                    <CardTitle className="text-lg">
                      {analysis.success ? 'Resposta da Análise' : 'Erro na Análise'}
                    </CardTitle>
                    {analysis.question && (
                      <CardDescription>
                        Pergunta: {analysis.question}
                      </CardDescription>
                    )}
                  </CardHeader>
                  <CardContent>
                    {analysis.success ? (
                      <div className="prose prose-sm max-w-none">
                        <p className="whitespace-pre-wrap">{analysis.response}</p>
                      </div>
                    ) : (
                      <div className="text-red-500">
                        {analysis.error}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="search" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Pesquisa Online
              </CardTitle>
              <CardDescription>
                Resultados de pesquisa sobre as obras de André Luiz
              </CardDescription>
            </CardHeader>
            <CardContent>
              {searchLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin" />
                  <span className="ml-2">Pesquisando...</span>
                </div>
              ) : (
                <ScrollArea className="h-[600px] w-full">
                  <div className="space-y-4">
                    {searchResults.map((result, index) => (
                      <Card key={index} className="p-4">
                        <div className="space-y-2">
                          <div className="flex items-start justify-between">
                            <h3 className="font-semibold text-lg">{result.name}</h3>
                            <Badge variant="secondary">#{result.rank}</Badge>
                          </div>
                          
                          <p className="text-sm text-muted-foreground">
                            {formatSnippet(result.snippet)}
                          </p>
                          
                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <span>{result.host_name}</span>
                            <span>{result.date}</span>
                          </div>
                          
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => window.open(result.url, '_blank')}
                          >
                            Visitar Página
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}