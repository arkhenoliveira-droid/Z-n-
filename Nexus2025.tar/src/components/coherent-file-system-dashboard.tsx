/**
 * Coherent File System Dashboard
 * 
 * This dashboard provides a comprehensive interface for managing file types,
 * analyzing coherence, and working with TAR archives in a coherent operating system.
 */

'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { FileCoherenceAnalyzer } from '@/systems/file-coherence-analyzer';
import { TarCompatibilitySystem } from '@/systems/tar-compatibility-system';
import { RawDataTARCompressor } from '@/systems/raw-data-tar-compressor';
import {
  FileType,
  FileCategory,
  CoherenceRelationship,
  CompatibilityMatrix,
  CompressionFormat,
  RawData,
  RawDataCompressionConfig,
  TarCompatibilityResult,
  RawDataCompressionResult
} from '@/types/file-system';

export interface CoherentFileSystemDashboardProps {
  className?: string;
}

export function CoherentFileSystemDashboard({ className }: CoherentFileSystemDashboardProps) {
  const [fileCoherenceAnalyzer] = useState(new FileCoherenceAnalyzer());
  const [tarCompatibilitySystem] = useState(new TarCompatibilitySystem());
  const [rawDataCompressor] = useState(new RawDataTARCompressor());

  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [compatibilityResult, setCompatibilityResult] = useState<TarCompatibilityResult | null>(null);
  const [compressionResult, setCompressionResult] = useState<RawDataCompressionResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('analysis');

  // File analysis state
  const [filePath, setFilePath] = useState('');
  const [compressionAlgorithm, setCompressionAlgorithm] = useState<CompressionFormat>('gzip');
  const [compressionLevel, setCompressionLevel] = useState(6);

  // Raw data compression state
  const [rawDataType, setRawDataType] = useState('binary');
  const [rawDataSize, setRawDataSize] = useState(1024);
  const [compressionConfig, setCompressionConfig] = useState<RawDataCompressionConfig | null>(null);

  // Initialize compression config
  useEffect(() => {
    const configs = rawDataCompressor.getCompressionConfigs();
    if (configs.length > 0) {
      setCompressionConfig(configs[0]);
    }
  }, [rawDataCompressor]);

  // Analyze file coherence
  const analyzeFileCoherence = async () => {
    if (selectedFiles.length === 0) return;

    setIsLoading(true);
    try {
      const result = fileCoherenceAnalyzer.analyzeFileCoherence(selectedFiles);
      if (result.success) {
        setAnalysisResult(result.data);
      }
    } catch (error) {
      console.error('Analysis failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Check TAR compatibility
  const checkTarCompatibility = async () => {
    if (!filePath) return;

    setIsLoading(true);
    try {
      const result = tarCompatibilitySystem.checkCompatibility(filePath, {
        compression: compressionAlgorithm,
        strictMode: false,
        preservePermissions: true
      });
      if (result.success) {
        setCompatibilityResult(result.data);
      }
    } catch (error) {
      console.error('Compatibility check failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Compress raw data
  const compressRawData = async () => {
    if (!compressionConfig) return;

    setIsLoading(true);
    try {
      // Create sample raw data
      const rawData: RawData = {
        id: Math.random().toString(36).substring(2) as any,
        type: rawDataType as any,
        data: Buffer.alloc(rawDataSize),
        metadata: {
          source: 'generated',
          format: 'raw',
          encoding: 'binary',
          byteOrder: 'little',
          createdAt: Date.now() as any,
          modifiedAt: Date.now() as any,
          size: rawDataSize,
          checksum: '',
          tags: ['sample'],
          description: 'Sample raw data for compression'
        },
        checksum: ''
      };

      const result = rawDataCompressor.compressRawData(rawData, compressionConfig);
      if (result.success) {
        setCompressionResult(result.data);
      }
    } catch (error) {
      console.error('Compression failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Add sample files for demonstration
  const addSampleFiles = () => {
    const sampleFiles = [
      '/home/user/documents/report.pdf',
      '/home/user/images/photo.jpg',
      '/home/user/data/database.json',
      '/home/user/logs/system.log',
      '/home/user/archive/backup.tar.gz'
    ];
    setSelectedFiles(sampleFiles);
  };

  // Render file type card
  const renderFileTypeCard = (fileType: FileType) => (
    <Card key={fileType.id} className="mb-4">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          {fileType.name}
          <Badge variant="outline">{fileType.category}</Badge>
        </CardTitle>
        <CardDescription>
          {fileType.extension} • {fileType.mimeType}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <strong>Structure:</strong> {fileType.structure.type} • {fileType.structure.format}
          </div>
          <div>
            <strong>Encoding:</strong> {fileType.structure.encoding || 'binary'}
          </div>
        </div>
        {fileType.specifications.length > 0 && (
          <div className="mt-2">
            <strong>Specifications:</strong>
            <ul className="list-disc list-inside text-sm text-gray-600">
              {fileType.specifications.map((spec, index) => (
                <li key={index}>{spec.name} v{spec.version}</li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );

  // Render relationship card
  const renderRelationshipCard = (relationship: CoherenceRelationship) => {
    const sourceType = analysisResult?.fileTypes.find((ft: FileType) => ft.id === relationship.sourceType);
    const targetType = analysisResult?.fileTypes.find((ft: FileType) => ft.id === relationship.targetType);

    return (
      <Card key={relationship.id} className="mb-4">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            {sourceType?.name} → {targetType?.name}
            <Badge variant={relationship.strength > 0.7 ? "default" : "secondary"}>
              {Math.round(relationship.strength * 100)}%
            </Badge>
          </CardTitle>
          <CardDescription>
            {relationship.relationshipType} • {relationship.bidirectional ? 'Bidirectional' : 'Unidirectional'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600 mb-2">{relationship.description}</p>
          {relationship.transformations.length > 0 && (
            <div>
              <strong>Transformations:</strong>
              <ul className="list-disc list-inside text-sm">
                {relationship.transformations.map((transform, index) => (
                  <li key={index}>
                    {transform.name} ({transform.lossiness})
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  // Render compatibility result
  const renderCompatibilityResult = () => {
    if (!compatibilityResult) return null;

    return (
      <Card>
        <CardHeader>
          <CardTitle>TAR Compatibility Analysis</CardTitle>
          <CardDescription>
            {compatibilityResult.sourceFormat} → {compatibilityResult.targetFormat}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span>Compatibility:</span>
              <Badge variant={
                compatibilityResult.compatibility === 'full' ? 'default' :
                compatibilityResult.compatibility === 'partial' ? 'secondary' : 'destructive'
              }>
                {compatibilityResult.compatibility}
              </Badge>
            </div>
            
            <div className="space-y-2">
              <Label>Conversion Method:</Label>
              <p className="text-sm text-gray-600">{compatibilityResult.conversionMethod}</p>
            </div>

            {compatibilityResult.warnings.length > 0 && (
              <Alert>
                <AlertTitle>Warnings</AlertTitle>
                <AlertDescription>
                  <ul className="list-disc list-inside">
                    {compatibilityResult.warnings.map((warning, index) => (
                      <li key={index}>{warning}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            {compatibilityResult.errors.length > 0 && (
              <Alert variant="destructive">
                <AlertTitle>Errors</AlertTitle>
                <AlertDescription>
                  <ul className="list-disc list-inside">
                    {compatibilityResult.errors.map((error, index) => (
                      <li key={index}>{error}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label>Recommendations:</Label>
              <ul className="list-disc list-inside text-sm">
                {compatibilityResult.recommendations.map((rec, index) => (
                  <li key={index}>{rec}</li>
                ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  // Render compression result
  const renderCompressionResult = () => {
    if (!compressionResult) return null;

    return (
      <Card>
        <CardHeader>
          <CardTitle>Raw Data Compression Result</CardTitle>
          <CardDescription>
            {compressionResult.config.name}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Original Size:</Label>
                <p className="text-sm font-medium">
                  {(compressionResult.originalData.data.length / 1024).toFixed(2)} KB
                </p>
              </div>
              <div>
                <Label>Compressed Size:</Label>
                <p className="text-sm font-medium">
                  {(compressionResult.compressedArchive.files.reduce((sum, file) => sum + file.data.length, 0) / 1024).toFixed(2)} KB
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Compression Ratio:</Label>
              <Progress value={(1 - compressionResult.performance.compressionRatio) * 100} />
              <p className="text-sm text-gray-600">
                {(compressionResult.performance.compressionRatio * 100).toFixed(1)}% of original size
              </p>
            </div>

            <div className="space-y-2">
              <Label>Coherence Score:</Label>
              <Progress value={compressionResult.coherenceScore * 100} />
              <p className="text-sm text-gray-600">
                {(compressionResult.coherenceScore * 100).toFixed(1)}% coherence
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <strong>Compression Speed:</strong> {compressionResult.performance.compressionSpeed.toFixed(2)} MB/s
              </div>
              <div>
                <strong>Memory Usage:</strong> {compressionResult.performance.memoryUsage.toFixed(2)} MB
              </div>
            </div>

            {compressionResult.validation.errors.length > 0 && (
              <Alert variant="destructive">
                <AlertTitle>Validation Errors</AlertTitle>
                <AlertDescription>
                  <ul className="list-disc list-inside">
                    {compressionResult.validation.errors.map((error, index) => (
                      <li key={index}>{error}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            {compressionResult.optimization.applied && (
              <div className="space-y-2">
                <Label>Applied Optimizations:</Label>
                <div className="flex flex-wrap gap-2">
                  {compressionResult.optimization.techniques.map((technique, index) => (
                    <Badge key={index} variant="outline">
                      {technique.name} ({(technique.improvement * 100).toFixed(1)}%)
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className={`space-y-6 ${className}`}>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Coherent File System</h1>
          <p className="text-gray-600">
            Analyze file types, ensure coherence, and compress data with TAR format
          </p>
        </div>
        <Button onClick={addSampleFiles} variant="outline">
          Add Sample Files
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="analysis">File Analysis</TabsTrigger>
          <TabsTrigger value="compatibility">TAR Compatibility</TabsTrigger>
          <TabsTrigger value="compression">Raw Data Compression</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="analysis" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>File Coherence Analysis</CardTitle>
              <CardDescription>
                Analyze file types and their relationships for optimal compatibility
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Selected Files:</Label>
                <div className="space-y-1">
                  {selectedFiles.map((file, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                      <span className="text-sm">{file}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setSelectedFiles(selectedFiles.filter((_, i) => i !== index))}
                      >
                        Remove
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={analyzeFileCoherence} disabled={selectedFiles.length === 0 || isLoading}>
                  {isLoading ? 'Analyzing...' : 'Analyze Coherence'}
                </Button>
                <Button variant="outline" onClick={() => setSelectedFiles([])}>
                  Clear Files
                </Button>
              </div>
            </CardContent>
          </Card>

          {analysisResult && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Analysis Results</h3>
                <div className="space-y-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Coherence Score:</span>
                          <Badge variant={analysisResult.coherenceScore > 0.7 ? 'default' : 'secondary'}>
                            {(analysisResult.coherenceScore * 100).toFixed(1)}%
                          </Badge>
                        </div>
                        <Progress value={analysisResult.coherenceScore * 100} />
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">File Types ({analysisResult.fileTypes.length})</CardTitle>
                    </CardHeader>
                    <CardContent className="max-h-96 overflow-y-auto">
                      {analysisResult.fileTypes.map(renderFileTypeCard)}
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">Relationships ({analysisResult.relationships.length})</h3>
                <div className="max-h-96 overflow-y-auto">
                  {analysisResult.relationships.map(renderRelationshipCard)}
                </div>
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="compatibility" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>TAR Compatibility Check</CardTitle>
              <CardDescription>
                Check file compatibility with TAR format and compression options
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="filePath">File Path:</Label>
                  <Input
                    id="filePath"
                    value={filePath}
                    onChange={(e) => setFilePath(e.target.value)}
                    placeholder="/path/to/your/file.ext"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="compression">Compression Algorithm:</Label>
                  <Select value={compressionAlgorithm} onValueChange={(value: CompressionFormat) => setCompressionAlgorithm(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="gzip">GZIP</SelectItem>
                      <SelectItem value="bzip2">BZIP2</SelectItem>
                      <SelectItem value="xz">XZ</SelectItem>
                      <SelectItem value="lzma">LZMA</SelectItem>
                      <SelectItem value="zstd">ZSTD</SelectItem>
                      <SelectItem value="lz4">LZ4</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button onClick={checkTarCompatibility} disabled={!filePath || isLoading}>
                {isLoading ? 'Checking...' : 'Check Compatibility'}
              </Button>
            </CardContent>
          </Card>

          {compatibilityResult && renderCompatibilityResult()}
        </TabsContent>

        <TabsContent value="compression" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Raw Data Compression</CardTitle>
              <CardDescription>
                Compress raw data using TAR format with various algorithms
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="rawDataType">Data Type:</Label>
                  <Select value={rawDataType} onValueChange={setRawDataType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="binary">Binary</SelectItem>
                      <SelectItem value="text">Text</SelectItem>
                      <SelectItem value="hex">Hex</SelectItem>
                      <SelectItem value="base64">Base64</SelectItem>
                      <SelectItem value="numeric">Numeric</SelectItem>
                      <SelectItem value="structured">Structured</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="rawDataSize">Data Size (bytes):</Label>
                  <Input
                    id="rawDataSize"
                    type="number"
                    value={rawDataSize}
                    onChange={(e) => setRawDataSize(Number(e.target.value))}
                    min={1}
                    max={1000000}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="compressionConfig">Compression Config:</Label>
                  {compressionConfig && (
                    <Select 
                      value={compressionConfig.id} 
                      onValueChange={(value) => {
                        const config = rawDataCompressor.getCompressionConfigs().find(c => c.id === value);
                        if (config) setCompressionConfig(config);
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {rawDataCompressor.getCompressionConfigs().map((config) => (
                          <SelectItem key={config.id} value={config.id}>
                            {config.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </div>
              </div>

              {compressionConfig && (
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium mb-2">{compressionConfig.name}</h4>
                  <p className="text-sm text-gray-600 mb-2">{compressionConfig.description}</p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                    <div><strong>Algorithm:</strong> {compressionConfig.compressionAlgorithm}</div>
                    <div><strong>Level:</strong> {compressionConfig.compressionLevel}</div>
                    <div><strong>Strategy:</strong> {compressionConfig.strategy}</div>
                    <div><strong>Optimize:</strong> {compressionConfig.optimizeFor}</div>
                  </div>
                </div>
              )}

              <Button onClick={compressRawData} disabled={!compressionConfig || isLoading}>
                {isLoading ? 'Compressing...' : 'Compress Data'}
              </Button>
            </CardContent>
          </Card>

          {compressionResult && renderCompressionResult()}
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Processing History</CardTitle>
              <CardDescription>
                View history of file analysis, compatibility checks, and compression operations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Analysis Operations</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {fileCoherenceAnalyzer.getAnalysisHistory().length}
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Compatibility Checks</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {tarCompatibilitySystem.getProcessingHistory().length}
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Compression Operations</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {rawDataCompressor.getCompressionHistory().length}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="text-center text-gray-500 py-8">
                  <p>Detailed history view would be implemented here</p>
                  <p className="text-sm">Showing timestamps, operation types, and results</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}