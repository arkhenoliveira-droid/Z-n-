'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Users, PieChart, TrendingUp, Globe } from 'lucide-react'

interface CommunityInsightsProps {
  className?: string
}

const orkutStats = {
  nodes: 3072441,
  edges: 117185083,
  communities: 6288363,
  topCommunities: 5000,
  avgClustering: 0.1666,
  triangles: 627584181,
  diameter: 9,
  effectiveDiameter: 4.8
}

const formatNumber = (num: number) => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M'
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K'
  }
  return num.toString()
}

export default function CommunityInsights({ className }: CommunityInsightsProps) {
  const networkDensity = (orkutStats.edges / (orkutStats.nodes * (orkutStats.nodes - 1) / 2) * 100).toFixed(4)
  const avgDegree = (orkutStats.edges * 2 / orkutStats.nodes).toFixed(1)
  const closedTrianglesFraction = (0.01414 * 100).toFixed(2)
  const usersPerCommunity = (orkutStats.nodes / orkutStats.communities).toFixed(1)

  return (
    <div className={`space-y-6 ${className}`}>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Community Structure Analysis
          </CardTitle>
          <CardDescription>
            How users organized themselves in the original Orkut network
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{formatNumber(orkutStats.communities)}</div>
              <div className="text-sm text-muted-foreground">Total Communities</div>
              <div className="text-xs text-blue-600 mt-1">User-defined groups</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{usersPerCommunity}</div>
              <div className="text-sm text-muted-foreground">Users per Community</div>
              <div className="text-xs text-green-600 mt-1">Average size</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{orkutStats.topCommunities.toLocaleString()}</div>
              <div className="text-sm text-muted-foreground">Top Quality</div>
              <div className="text-xs text-purple-600 mt-1">High engagement</div>
            </div>
            <div className="text-center p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">3+</div>
              <div className="text-sm text-muted-foreground">Min. Members</div>
              <div className="text-xs text-orange-600 mt-1">Quality threshold</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5" />
              Community Quality Metrics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">Network Density</span>
                <Badge variant="outline">{networkDensity}%</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Clustering Coefficient</span>
                <Badge variant="outline">{orkutStats.avgClustering}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Average Degree</span>
                <Badge variant="outline">{avgDegree}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Closed Triangles</span>
                <Badge variant="outline">{closedTrianglesFraction}%</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Community Formation Patterns
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Interest-based Communities</span>
                  <span className="font-medium">45%</span>
                </div>
                <Progress value={45} className="h-2" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Geographic Communities</span>
                  <span className="font-medium">30%</span>
                </div>
                <Progress value={30} className="h-2" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Social/Friend Groups</span>
                  <span className="font-medium">20%</span>
                </div>
                <Progress value={20} className="h-2" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Professional Networks</span>
                  <span className="font-medium">5%</span>
                </div>
                <Progress value={5} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Key Community Insights
          </CardTitle>
          <CardDescription>
            What the Orkut community structure teaches us
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-semibold text-sm text-blue-600">Formation Patterns</h4>
              <ul className="text-sm space-y-2 text-muted-foreground">
                <li>• Users naturally form communities around shared interests</li>
                <li>• Geographic clustering creates strong local networks</li>
                <li>• Small communities (2-10 members) are most common</li>
                <li>• Community membership follows power law distribution</li>
              </ul>
            </div>
            <div className="space-y-4">
              <h4 className="font-semibold text-sm text-green-600">Network Effects</h4>
              <ul className="text-sm space-y-2 text-muted-foreground">
                <li>• Communities create network bridges between users</li>
                <li>• Multi-community membership increases connectivity</li>
                <li>• Community overlap strengthens network resilience</li>
                <li>• High-quality communities drive user retention</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}