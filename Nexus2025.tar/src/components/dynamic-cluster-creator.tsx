'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Activity, 
  Zap, 
  Network, 
  Target, 
  TrendingUp, 
  Users, 
  Globe,
  Brain,
  Radio,
  BarChart3,
  Settings,
  RefreshCw,
  Eye,
  Lightbulb,
  Layers,
  Infinity,
  Plus,
  Trash2,
  Scale,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingDown
} from 'lucide-react';

import { DynamicClusterCreationSystem, DynamicCluster, ClusterCreationRequest, ClusterAnalytics } from '@/systems/dynamic-cluster-creation';
import ClusterVisualization from '@/components/cluster-visualization';

export default function DynamicClusterCreator() {
  const [clusterSystem] = useState(() => new DynamicClusterCreationSystem());
  const [clusters, setClusters] = useState<DynamicCluster[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [selectedCluster, setSelectedCluster] = useState<DynamicCluster | null>(null);
  const [analytics, setAnalytics] = useState<ClusterAnalytics | null>(null);
  const [creationForm, setCreationForm] = useState({
    targetNodes: '',
    clusterType: 'adaptive_hybrid' as const,
    optimizationStrategy: 'adaptive_hybrid' as const,
    targetCoherence: 0.85,
    priority: 'medium' as const,
    timeoutMs: 30000
  });

  // Load clusters periodically
  useEffect(() => {
    const loadClusters = () => {
      setClusters(clusterSystem.getAllClusters());
    };

    loadClusters();
    const interval = setInterval(loadClusters, 2000);
    return () => clearInterval(interval);
  }, [clusterSystem]);

  // Handle cluster creation
  const handleCreateCluster = async () => {
    setIsCreating(true);
    try {
      const request: ClusterCreationRequest = {
        target_nodes: creationForm.targetNodes.split(',').map(id => id.trim()).filter(Boolean),
        cluster_type: creationForm.clusterType,
        optimization_strategy: creationForm.optimizationStrategy,
        target_coherence: creationForm.targetCoherence,
        adaptive_parameters: {},
        priority: creationForm.priority,
        timeout_ms: creationForm.timeoutMs
      };

      const result = await clusterSystem.createCluster(request);
      if (result.success) {
        setClusters(clusterSystem.getAllClusters());
        // Reset form
        setCreationForm({
          targetNodes: '',
          clusterType: 'adaptive_hybrid',
          optimizationStrategy: 'adaptive_hybrid',
          targetCoherence: 0.85,
          priority: 'medium',
          timeoutMs: 30000
        });
      } else {
        console.error('Cluster creation failed:', result.error);
      }
    } catch (error) {
      console.error('Error creating cluster:', error);
    } finally {
      setIsCreating(false);
    }
  };

  // Handle cluster dissolution
  const handleDissolveCluster = async (clusterId: string) => {
    try {
      await clusterSystem.dissolveCluster(clusterId as any);
      setClusters(clusterSystem.getAllClusters());
      if (selectedCluster?.id === clusterId) {
        setSelectedCluster(null);
        setAnalytics(null);
      }
    } catch (error) {
      console.error('Error dissolving cluster:', error);
    }
  };

  // Handle cluster scaling
  const handleScaleCluster = async (clusterId: string, targetSize: number) => {
    try {
      await clusterSystem.scaleCluster(clusterId as any, targetSize);
      setClusters(clusterSystem.getAllClusters());
      if (selectedCluster?.id === clusterId) {
        const result = clusterSystem.getClusterStatus(clusterId as any);
        if (result.success) {
          setSelectedCluster(result.value);
        }
      }
    } catch (error) {
      console.error('Error scaling cluster:', error);
    }
  };

  // Load cluster analytics
  const loadClusterAnalytics = async (clusterId: string) => {
    try {
      const result = clusterSystem.getClusterAnalytics(clusterId as any);
      if (result.success) {
        setAnalytics(result.value);
      }
    } catch (error) {
      console.error('Error loading analytics:', error);
    }
  };

  // Handle cluster selection
  const handleSelectCluster = (cluster: DynamicCluster) => {
    setSelectedCluster(cluster);
    loadClusterAnalytics(cluster.id);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'stable': return 'bg-green-500';
      case 'optimizing': return 'bg-blue-500';
      case 'adapting': return 'bg-yellow-500';
      case 'scaling': return 'bg-purple-500';
      case 'degrading': return 'bg-orange-500';
      case 'dissolving': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getClusterTypeIcon = (type: string) => {
    switch (type) {
      case 'quantum_entanglement': return <Zap className="w-4 h-4" />;
      case 'resonance_coupling': return <Radio className="w-4 h-4" />;
      case 'coherence_field': return <Brain className="w-4 h-4" />;
      case 'collective_intelligence': return <Users className="w-4 h-4" />;
      case 'adaptive_hybrid': return <Layers className="w-4 h-4" />;
      default: return <Network className="w-4 h-4" />;
    }
  };

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString();
  };

  const formatUptime = (uptime: number) => {
    const seconds = Math.floor(uptime / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${days}d ${hours % 24}h`;
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dynamic Cluster Creation</h1>
          <p className="text-muted-foreground">Intelligent, adaptive cluster management system</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="flex items-center space-x-1">
            <Activity className="w-3 h-3" />
            <span>{clusters.length} Active Clusters</span>
          </Badge>
        </div>
      </div>

      <Tabs defaultValue="create" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="create">Create Cluster</TabsTrigger>
          <TabsTrigger value="clusters">Active Clusters</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="visualization">Visualization</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
        </TabsList>

        <TabsContent value="create" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Plus className="w-5 h-5" />
                <span>Create New Cluster</span>
              </CardTitle>
              <CardDescription>
                Configure and create a new dynamic cluster with intelligent optimization
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="targetNodes">Target Nodes (comma-separated)</Label>
                  <Input
                    id="targetNodes"
                    placeholder="node_001, node_002, node_003"
                    value={creationForm.targetNodes}
                    onChange={(e) => setCreationForm({...creationForm, targetNodes: e.target.value})}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="clusterType">Cluster Type</Label>
                  <Select value={creationForm.clusterType} onValueChange={(value: any) => setCreationForm({...creationForm, clusterType: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="quantum_entanglement">Quantum Entanglement</SelectItem>
                      <SelectItem value="resonance_coupling">Resonance Coupling</SelectItem>
                      <SelectItem value="coherence_field">Coherence Field</SelectItem>
                      <SelectItem value="collective_intelligence">Collective Intelligence</SelectItem>
                      <SelectItem value="adaptive_hybrid">Adaptive Hybrid</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="optimizationStrategy">Optimization Strategy</Label>
                  <Select value={creationForm.optimizationStrategy} onValueChange={(value: any) => setCreationForm({...creationForm, optimizationStrategy: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gradient_descent">Gradient Descent</SelectItem>
                      <SelectItem value="genetic_algorithm">Genetic Algorithm</SelectItem>
                      <SelectItem value="quantum_annealing">Quantum Annealing</SelectItem>
                      <SelectItem value="neural_network">Neural Network</SelectItem>
                      <SelectItem value="adaptive_hybrid">Adaptive Hybrid</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="targetCoherence">Target Coherence ({creationForm.targetCoherence.toFixed(2)})</Label>
                  <Input
                    id="targetCoherence"
                    type="range"
                    min="0.1"
                    max="1.0"
                    step="0.05"
                    value={creationForm.targetCoherence}
                    onChange={(e) => setCreationForm({...creationForm, targetCoherence: parseFloat(e.target.value)})}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={creationForm.priority} onValueChange={(value: any) => setCreationForm({...creationForm, priority: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="timeoutMs">Timeout (ms)</Label>
                  <Input
                    id="timeoutMs"
                    type="number"
                    value={creationForm.timeoutMs}
                    onChange={(e) => setCreationForm({...creationForm, timeoutMs: parseInt(e.target.value)})}
                  />
                </div>
              </div>

              <Button 
                onClick={handleCreateCluster} 
                disabled={isCreating || !creationForm.targetNodes.trim()}
                className="w-full"
              >
                {isCreating ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Creating Cluster...
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Cluster
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="clusters" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Active Clusters</CardTitle>
                <CardDescription>Currently running dynamic clusters</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {clusters.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Network className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No active clusters</p>
                      <p className="text-sm">Create a new cluster to get started</p>
                    </div>
                  ) : (
                    clusters.map((cluster) => (
                      <div 
                        key={cluster.id}
                        className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                          selectedCluster?.id === cluster.id ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                        }`}
                        onClick={() => handleSelectCluster(cluster)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            {getClusterTypeIcon(cluster.cluster_type)}
                            <div>
                              <p className="font-medium">{cluster.name}</p>
                              <p className="text-sm text-muted-foreground">
                                {cluster.nodes.length} nodes • {cluster.cluster_type}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className={`w-2 h-2 rounded-full ${getStatusColor(cluster.status)}`} />
                            <Badge variant="outline" className="text-xs">
                              {cluster.status}
                            </Badge>
                          </div>
                        </div>
                        <div className="mt-2">
                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <span>Coherence</span>
                            <span>{(cluster.coherence_metrics.overall_coherence * 100).toFixed(1)}%</span>
                          </div>
                          <Progress 
                            value={cluster.coherence_metrics.overall_coherence * 100} 
                            className="h-1 mt-1" 
                          />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cluster Details</CardTitle>
                <CardDescription>
                  {selectedCluster ? selectedCluster.name : 'Select a cluster to view details'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {selectedCluster ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium">Status</Label>
                        <div className="flex items-center space-x-2 mt-1">
                          <div className={`w-2 h-2 rounded-full ${getStatusColor(selectedCluster.status)}`} />
                          <Badge variant="outline">{selectedCluster.status}</Badge>
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm font-medium">Nodes</Label>
                        <p className="text-sm">{selectedCluster.nodes.length}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium">Coherence</Label>
                        <p className="text-sm">{(selectedCluster.coherence_metrics.overall_coherence * 100).toFixed(1)}%</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium">Created</Label>
                        <p className="text-sm">{formatTimestamp(selectedCluster.creation_timestamp)}</p>
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm font-medium">Coherence Metrics</Label>
                      <div className="space-y-2 mt-2">
                        <div className="flex justify-between text-sm">
                          <span>Overall Coherence</span>
                          <span>{(selectedCluster.coherence_metrics.overall_coherence * 100).toFixed(1)}%</span>
                        </div>
                        <Progress value={selectedCluster.coherence_metrics.overall_coherence * 100} />
                        
                        <div className="flex justify-between text-sm">
                          <span>Quantum Correlation</span>
                          <span>{(selectedCluster.coherence_metrics.quantum_correlation * 100).toFixed(1)}%</span>
                        </div>
                        <Progress value={selectedCluster.coherence_metrics.quantum_correlation * 100} />
                        
                        <div className="flex justify-between text-sm">
                          <span>Emergence Level</span>
                          <span>{(selectedCluster.coherence_metrics.emergence_level * 100).toFixed(1)}%</span>
                        </div>
                        <Progress value={selectedCluster.coherence_metrics.emergence_level * 100} />
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleScaleCluster(selectedCluster.id, selectedCluster.nodes.length + 5)}
                      >
                        <Scale className="w-4 h-4 mr-2" />
                        Scale Up
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleScaleCluster(selectedCluster.id, Math.max(1, selectedCluster.nodes.length - 5))}
                      >
                        <Scale className="w-4 h-4 mr-2" />
                        Scale Down
                      </Button>
                      <Button 
                        variant="destructive" 
                        size="sm"
                        onClick={() => handleDissolveCluster(selectedCluster.id)}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Dissolve
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Eye className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Select a cluster to view details</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Cluster Analytics</CardTitle>
              <CardDescription>Performance metrics and insights for selected cluster</CardDescription>
            </CardHeader>
            <CardContent>
              {analytics ? (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold">{analytics.efficiency_score.toFixed(2)}</div>
                      <div className="text-sm text-muted-foreground">Efficiency Score</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold">{analytics.adaptation_events}</div>
                      <div className="text-sm text-muted-foreground">Adaptation Events</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold">{formatUptime(analytics.uptime)}</div>
                      <div className="text-sm text-muted-foreground">Uptime</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium">Coherence Trend</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        {analytics.coherence_trend === 'improving' && (
                          <>
                            <TrendingUp className="w-4 h-4 text-green-500" />
                            <Badge variant="outline" className="text-green-500">Improving</Badge>
                          </>
                        )}
                        {analytics.coherence_trend === 'stable' && (
                          <>
                            <BarChart3 className="w-4 h-4 text-blue-500" />
                            <Badge variant="outline" className="text-blue-500">Stable</Badge>
                          </>
                        )}
                        {analytics.coherence_trend === 'degrading' && (
                          <>
                            <TrendingDown className="w-4 h-4 text-red-500" />
                            <Badge variant="outline" className="text-red-500">Degrading</Badge>
                          </>
                        )}
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Performance Trend</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        {analytics.performance_trend === 'improving' && (
                          <>
                            <TrendingUp className="w-4 h-4 text-green-500" />
                            <Badge variant="outline" className="text-green-500">Improving</Badge>
                          </>
                        )}
                        {analytics.performance_trend === 'stable' && (
                          <>
                            <BarChart3 className="w-4 h-4 text-blue-500" />
                            <Badge variant="outline" className="text-blue-500">Stable</Badge>
                          </>
                        )}
                        {analytics.performance_trend === 'degrading' && (
                          <>
                            <TrendingDown className="w-4 h-4 text-red-500" />
                            <Badge variant="outline" className="text-red-500">Degrading</Badge>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {analytics.recommendations.length > 0 && (
                    <div>
                      <Label className="text-sm font-medium">Recommendations</Label>
                      <div className="space-y-2 mt-2">
                        {analytics.recommendations.map((recommendation, index) => (
                          <div key={index} className="flex items-start space-x-2 p-2 bg-muted rounded">
                            <Lightbulb className="w-4 h-4 text-yellow-500 mt-0.5" />
                            <span className="text-sm">{recommendation}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BarChart3 className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Select a cluster to view analytics</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

          {/* Visualization Tab */}
          <TabsContent value="visualization" className="space-y-4">
            <ClusterVisualization
              clusters={clusters}
              selectedCluster={selectedCluster}
              analytics={analytics}
              onSelectCluster={handleSelectCluster}
              onRefresh={() => setClusters(clusterSystem.getAllClusters())}
            />
          </TabsContent>

        <TabsContent value="monitoring" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">System Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Total Clusters</span>
                    <span className="font-medium">{clusters.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Active Nodes</span>
                    <span className="font-medium">
                      {clusters.reduce((sum, cluster) => sum + cluster.nodes.length, 0)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Avg Coherence</span>
                    <span className="font-medium">
                      {clusters.length > 0 
                        ? (clusters.reduce((sum, cluster) => sum + cluster.coherence_metrics.overall_coherence, 0) / clusters.length * 100).toFixed(1) + '%'
                        : '0%'
                      }
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Status Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {['stable', 'optimizing', 'adapting', 'scaling'].map((status) => {
                    const count = clusters.filter(c => c.status === status).length;
                    return (
                      <div key={status} className="flex justify-between items-center">
                        <div className="flex items-center space-x-2">
                          <div className={`w-2 h-2 rounded-full ${getStatusColor(status)}`} />
                          <span className="text-sm capitalize">{status}</span>
                        </div>
                        <Badge variant="outline">{count}</Badge>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {clusters.slice(0, 5).map((cluster) => (
                    <div key={cluster.id} className="flex items-center justify-between text-sm">
                      <span className="truncate">{cluster.name}</span>
                      <span className="text-muted-foreground">
                        {formatTimestamp(cluster.last_updated)}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}