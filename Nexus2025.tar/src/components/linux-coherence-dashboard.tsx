'use client'

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Terminal, 
  Layers, 
  Users, 
  Clock, 
  Atom, 
  Leaf,
  Target,
  TrendingUp,
  RefreshCw,
  Activity,
  Zap,
  Globe,
  Cpu,
  GitBranch,
  Shield,
  Database,
  Network
} from 'lucide-react'
import { LinuxCoherenceAnalyzer, LinuxCoherenceVector, LinuxCoherencePrinciple } from '@/systems/linux-coherence-analyzer'

const LinuxCoherenceDashboard: React.FC = () => {
  const [analyzer] = useState(() => new LinuxCoherenceAnalyzer())
  const [analysis, setAnalysis] = useState<any>(null)
  const [principles, setPrinciples] = useState<LinuxCoherencePrinciple[]>([])
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisDepth, setAnalysisDepth] = useState(0)

  useEffect(() => {
    performAnalysis()
  }, [])

  const performAnalysis = async () => {
    setIsAnalyzing(true)
    await new Promise(resolve => setTimeout(resolve, 2000)) // Simular análise
    
    const newAnalysis = analyzer.analyzeLinuxCoherence()
    const newPrinciples = analyzer.getPrinciples()
    const newDepth = analyzer.getAnalysisDepth()
    
    setAnalysis(newAnalysis)
    setPrinciples(newPrinciples)
    setAnalysisDepth(newDepth)
    setIsAnalyzing(false)
  }

  const getDimensionIcon = (dimension: string) => {
    switch (dimension) {
      case 'architectural':
        return <Layers className="h-5 w-5" />
      case 'philosophical':
        return <Users className="h-5 w-5" />
      case 'operational':
        return <Cpu className="h-5 w-5" />
      case 'ecological':
        return <Leaf className="h-5 w-5" />
      case 'temporal':
        return <Clock className="h-5 w-5" />
      case 'quantum':
        return <Atom className="h-5 w-5" />
      default:
        return <Target className="h-5 w-5" />
    }
  }

  const getDimensionColor = (dimension: string) => {
    switch (dimension) {
      case 'architectural':
        return 'bg-blue-500'
      case 'philosophical':
        return 'bg-purple-500'
      case 'operational':
        return 'bg-green-500'
      case 'ecological':
        return 'bg-emerald-500'
      case 'temporal':
        return 'bg-orange-500'
      case 'quantum':
        return 'bg-pink-500'
      default:
        return 'bg-gray-500'
    }
  }

  const getCoherenceColor = (coherence: number) => {
    if (coherence >= 0.9) return 'text-green-600'
    if (coherence >= 0.8) return 'text-yellow-600'
    if (coherence >= 0.7) return 'text-orange-600'
    return 'text-red-600'
  }

  const getCategoryBadge = (category: string) => {
    const variants = {
      core: 'default',
      design: 'secondary',
      implementation: 'outline',
      community: 'destructive'
    } as const

    const labels = {
      core: 'Núcleo',
      design: 'Design',
      implementation: 'Implementação',
      community: 'Comunidade'
    }

    return (
      <Badge variant={variants[category as keyof typeof variants] || 'default'}>
        {labels[category as keyof typeof labels] || category}
      </Badge>
    )
  }

  if (!analysis) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Análise de Coerência Linux</h2>
          <p className="text-muted-foreground">
            Explorando vetores de coerência em todas as dimensões do sistema Linux
          </p>
        </div>
        <Button 
          onClick={performAnalysis} 
          disabled={isAnalyzing}
          className="flex items-center gap-2"
        >
          {isAnalyzing ? (
            <RefreshCw className="h-4 w-4 animate-spin" />
          ) : (
            <Activity className="h-4 w-4" />
          )}
          {isAnalyzing ? 'Analisando...' : 'Reanalisar'}
        </Button>
      </div>

      {/* Cards Principais */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Coerência Global</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getCoherenceColor(analysis.globalCoherence)}`}>
              {(analysis.globalCoherence * 100).toFixed(1)}%
            </div>
            <Progress value={analysis.globalCoherence * 100} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vetores Analisados</CardTitle>
            <Network className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analysis.vectors.length}</div>
            <p className="text-xs text-muted-foreground">
              Dimensões de coerência
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Princípios</CardTitle>
            <GitBranch className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{principles.length}</div>
            <p className="text-xs text-muted-foreground">
              Princípios fundamentais
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Profundidade</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">#{analysisDepth}</div>
            <p className="text-xs text-muted-foreground">
              Nível de análise
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="vectors" className="space-y-4">
        <TabsList>
          <TabsTrigger value="vectors">Vetores de Coerência</TabsTrigger>
          <TabsTrigger value="dimensions">Análise Dimensional</TabsTrigger>
          <TabsTrigger value="principles">Princípios</TabsTrigger>
          <TabsTrigger value="patterns">Padrões</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
          <TabsTrigger value="report">Relatório</TabsTrigger>
        </TabsList>

        <TabsContent value="vectors" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {analysis.vectors.map((vector: LinuxCoherenceVector) => (
              <Card key={vector.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`p-2 rounded-full ${getDimensionColor(vector.dimension)} text-white`}>
                        {getDimensionIcon(vector.dimension)}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{vector.name}</CardTitle>
                        <CardDescription>{vector.description}</CardDescription>
                      </div>
                    </div>
                    <Badge variant="outline">{vector.dimension}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm">
                        <span>Coerência</span>
                        <span className={getCoherenceColor(vector.coherenceLevel)}>
                          {(vector.coherenceLevel * 100).toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={vector.coherenceLevel * 100} className="mt-1" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Impacto Técnico:</span>
                        <span className="ml-1 font-medium">
                          {(vector.impact.technical * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Impacto Social:</span>
                        <span className="ml-1 font-medium">
                          {(vector.impact.social * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Estabilidade:</span>
                        <span className="ml-1 font-medium">
                          {(vector.metrics.stability * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Adaptabilidade:</span>
                        <span className="ml-1 font-medium">
                          {(vector.metrics.adaptability * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>

                    <div>
                      <span className="text-sm text-muted-foreground">Princípios Chave:</span>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {vector.principles.slice(0, 3).map((principle, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {principle}
                          </Badge>
                        ))}
                        {vector.principles.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{vector.principles.length - 3}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="dimensions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Análise Dimensional</CardTitle>
              <CardDescription>
                Coerência do Linux em cada dimensão fundamental
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {Object.entries(analysis.dimensionalAnalysis).map(([dimension, coherence]) => (
                  <div key={dimension} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={`p-1 rounded ${getDimensionColor(dimension)} text-white`}>
                          {getDimensionIcon(dimension)}
                        </div>
                        <span className="font-medium capitalize">{dimension}</span>
                      </div>
                      <span className={`text-sm font-medium ${getCoherenceColor(coherence as number)}`}>
                        {(coherence as number * 100).toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={(coherence as number) * 100} />
                    <div className="grid grid-cols-4 gap-4 text-xs text-muted-foreground">
                      <div>Técnico: {((analysis.vectors.find((v: LinuxCoherenceVector) => v.dimension === dimension)?.impact.technical || 0) * 100).toFixed(0)}%</div>
                      <div>Social: {((analysis.vectors.find((v: LinuxCoherenceVector) => v.dimension === dimension)?.impact.social || 0) * 100).toFixed(0)}%</div>
                      <div>Econômico: {((analysis.vectors.find((v: LinuxCoherenceVector) => v.dimension === dimension)?.impact.economic || 0) * 100).toFixed(0)}%</div>
                      <div>Cultural: {((analysis.vectors.find((v: LinuxCoherenceVector) => v.dimension === dimension)?.impact.cultural || 0) * 100).toFixed(0)}%</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="principles" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Princípios Fundamentais</CardTitle>
              <CardDescription>
                Os princípios que governam a coerência do Linux
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {principles.map((principle) => (
                    <Card key={principle.id} className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold">{principle.name}</h4>
                            {getCategoryBadge(principle.category)}
                          </div>
                          <p className="text-sm text-muted-foreground">{principle.description}</p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>Força: {(principle.coherenceStrength * 100).toFixed(0)}%</span>
                            <Progress value={principle.coherenceStrength * 100} className="w-20 h-2" />
                          </div>
                          <div className="space-y-1">
                            <span className="text-xs text-muted-foreground">Exemplos:</span>
                            <ul className="text-xs text-muted-foreground list-disc list-inside">
                              {principle.examples.slice(0, 2).map((example, index) => (
                                <li key={index}>{example}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patterns" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Padrões de Coerência</CardTitle>
              <CardDescription>
                Padrões identificados na análise de coerência do Linux
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analysis.coherencePatterns.map((pattern: string, index: number) => (
                  <div key={index} className="flex items-start gap-3 p-4 rounded-lg border">
                    <Zap className="h-5 w-5 text-blue-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium">Padrão #{index + 1}</h4>
                      <p className="text-sm text-muted-foreground">{pattern}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Sugestões de Otimização</CardTitle>
              <CardDescription>
                Recomendações para melhorar a coerência do sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analysis.optimizationSuggestions.map((suggestion: string, index: number) => (
                  <div key={index} className="flex items-start gap-3 p-3 rounded-lg border">
                    <Target className="h-5 w-5 text-orange-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium">Sugestão #{index + 1}</h4>
                      <p className="text-sm text-muted-foreground">{suggestion}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Insights Evolutivos</CardTitle>
              <CardDescription>
                Descobertas e aprendizados da análise de coerência
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {analysis.evolutionaryInsights.map((insight: string, index: number) => (
                  <div key={index} className="space-y-3 p-4 rounded-lg border-l-4 border-l-blue-500 bg-blue-50 dark:bg-blue-950">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <h4 className="font-semibold">Insight #{index + 1}</h4>
                    </div>
                    <p className="text-sm leading-relaxed pl-10">{insight}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="report" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Relatório Completo</CardTitle>
              <CardDescription>
                Relatório detalhado da análise de coerência do Linux
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <pre className="text-sm whitespace-pre-wrap bg-muted p-4 rounded-lg">
                  {analyzer.generateLinuxCoherenceReport()}
                </pre>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default LinuxCoherenceDashboard