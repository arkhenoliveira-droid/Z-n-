'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Button } from '@/components/ui/button'
import { 
  TrendingUp, 
  Users, 
  Network, 
  Globe, 
  Clock,
  BarChart3,
  Zap,
  Target
} from 'lucide-react'

interface NetworkComparisonProps {
  className?: string
}

const networkData = [
  {
    name: 'Orkut',
    period: '2004-2014',
    users: 3072441,
    connections: 117185083,
    communities: 6288363,
    avgDegree: 76.2,
    clustering: 0.1666,
    diameter: 9,
    density: 0.0025,
    regions: ['Brazil', 'India', 'USA'],
    features: ['Communities', 'Testimonials', 'Scraps'],
    color: 'red'
  },
  {
    name: 'Facebook (Early)',
    period: '2004-2006',
    users: 1000000,
    connections: 10000000,
    communities: 50000,
    avgDegree: 20.0,
    clustering: 0.25,
    diameter: 6,
    density: 0.02,
    regions: ['USA', 'UK', 'Canada'],
    features: ['Wall', 'Groups', 'Photos'],
    color: 'blue'
  },
  {
    name: 'MySpace (Peak)',
    period: '2006-2008',
    users: 100000000,
    connections: 5000000000,
    communities: 1000000,
    avgDegree: 100.0,
    clustering: 0.15,
    diameter: 5,
    density: 0.001,
    regions: ['USA', 'UK', 'Australia'],
    features: ['Profiles', 'Music', 'Blogs'],
    color: 'purple'
  },
  {
    name: 'LinkedIn (Early)',
    period: '2003-2007',
    users: 20000000,
    connections: 100000000,
    communities: 100000,
    avgDegree: 10.0,
    clustering: 0.3,
    diameter: 8,
    density: 0.0005,
    regions: ['USA', 'Europe', 'India'],
    features: ['Connections', 'Recommendations', 'Jobs'],
    color: 'green'
  }
]

const formatNumber = (num: number) => {
  if (num >= 1000000000) {
    return (num / 1000000000).toFixed(1) + 'B'
  }
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M'
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K'
  }
  return num.toString()
}

const formatLargeNumber = (num: number) => {
  return num.toLocaleString()
}

export default function NetworkComparison({ className }: NetworkComparisonProps) {
  const maxUsers = Math.max(...networkData.map(n => n.users))
  const maxConnections = Math.max(...networkData.map(n => n.connections))
  const maxCommunities = Math.max(...networkData.map(n => n.communities))

  return (
    <div className={`space-y-6 ${className}`}>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Network Comparison Analysis
          </CardTitle>
          <CardDescription>
            Compare Orkut with other major social networks of its era
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-semibold text-sm mb-3">User Base Comparison</h4>
              {networkData.map((network, index) => (
                <div key={network.name} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">{network.name}</span>
                    <span>{formatNumber(network.users)} users</span>
                  </div>
                  <Progress 
                    value={(network.users / maxUsers) * 100} 
                    className="h-2"
                  />
                  <div className="text-xs text-muted-foreground">
                    {network.period} • {network.regions.join(', ')}
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold text-sm mb-3">Connection Density</h4>
              {networkData.map((network, index) => (
                <div key={network.name} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">{network.name}</span>
                    <span>{formatNumber(network.connections)} connections</span>
                  </div>
                  <Progress 
                    value={(network.connections / maxConnections) * 100} 
                    className="h-2"
                  />
                  <div className="text-xs text-muted-foreground">
                    Avg. Degree: {network.avgDegree.toFixed(1)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Network Structure Metrics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <div className="font-medium">Network</div>
                  {networkData.map(network => (
                    <div key={network.name} className="text-muted-foreground">{network.name}</div>
                  ))}
                </div>
                <div className="space-y-2">
                  <div className="font-medium">Clustering</div>
                  {networkData.map(network => (
                    <div key={network.name} className="text-muted-foreground">
                      {network.clustering.toFixed(3)}
                    </div>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <div className="font-medium">Diameter</div>
                  {networkData.map(network => (
                    <div key={network.name} className="text-muted-foreground">{network.diameter} hops</div>
                  ))}
                </div>
                <div className="space-y-2">
                  <div className="font-medium">Density</div>
                  {networkData.map(network => (
                    <div key={network.name} className="text-muted-foreground">
                      {network.density.toFixed(4)}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Community Engagement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {networkData.map((network, index) => (
                <div key={network.name} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-sm">{network.name}</span>
                    <Badge variant="outline">{formatNumber(network.communities)}</Badge>
                  </div>
                  <Progress 
                    value={(network.communities / maxCommunities) * 100} 
                    className="h-2"
                  />
                  <div className="text-xs text-muted-foreground">
                    Users per Community: {(network.users / network.communities).toFixed(1)}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Key Differentiators
          </CardTitle>
          <CardDescription>
            What made each network unique
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-semibold text-sm text-red-600">Orkut's Strengths</h4>
              <ul className="text-sm space-y-2 text-muted-foreground">
                <li>• Massive community formation (6.2M communities)</li>
                <li>• Strong regional focus (Brazil, India)</li>
                <li>• High user engagement per community</li>
                <li>• Simple, accessible interface</li>
                <li>• Unique features like testimonials and scraps</li>
              </ul>
            </div>
            <div className="space-y-4">
              <h4 className="font-semibold text-sm text-blue-600">Competitive Advantages</h4>
              <ul className="text-sm space-y-2 text-muted-foreground">
                <li>• Facebook: Real identity focus</li>
                <li>• MySpace: Music and customization</li>
                <li>• LinkedIn: Professional networking</li>
                <li>• Each had unique regional strengths</li>
                <li>• Different approaches to privacy</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Evolution Timeline
          </CardTitle>
          <CardDescription>
            How these networks evolved and influenced each other
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {networkData.map((network, index) => (
                <div key={network.name} className="text-center p-4 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg">
                  <div className="font-semibold text-sm mb-1">{network.name}</div>
                  <div className="text-xs text-muted-foreground mb-2">{network.period}</div>
                  <div className="space-y-1">
                    {network.features.slice(0, 2).map((feature, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="text-sm text-muted-foreground space-y-2">
              <p>
                <strong>Key Insights:</strong> Orkut pioneered community-focused social networking, 
                influencing later platforms. While Facebook eventually dominated globally, 
                Orkut's impact on regional markets (especially Brazil) was unprecedented.
              </p>
              <p>
                The network structures show different approaches: Orkut emphasized communities, 
                Facebook focused on real identity, MySpace on customization, and LinkedIn on 
                professional connections.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}