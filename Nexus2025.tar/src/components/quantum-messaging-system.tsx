'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  MessageCircle, 
  Send, 
  Heart, 
  Brain, 
  Zap, 
  Star,
  Shield,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Clock,
  Users,
  Globe,
  Wifi,
  WifiOff,
  Radio,
  RadioIcon,
  Satellite,
  SatelliteDish,
  Antenna,
  RadioTower,
  Waves,
  Activity,
  Triangle,
  Diamond,
  Hexagon,
  Circle,
  Square,
  Infinity,
  Atom,
  Layers,
  Network,
  Target,
  TargetIcon,
  Crosshair,
  Bullseye,
  Compass,
  Navigation,
  MapPin,
  Timer,
  Calendar,
  Bell,
  BellOff,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Phone,
  PhoneOff,
  MoreVertical,
  MoreHorizontal,
  Plus,
  Minus,
  RotateCcw,
  RotateCw,
  RefreshCw,
  Download,
  Upload,
  Share2,
  Link2,
  Unlink,
  AlignCenter,
  AlignHorizontalJustifyCenter,
  AlignVerticalJustifyCenter,
  GitBranch,
  GitMerge,
  GitFork,
  Sparkles,
  Crown,
  Flame,
  Sun,
  Moon,
  Cloud,
  Wind,
  Mountain,
  TreePine,
  Waves as WavesIcon,
  Heartbeat,
  Pulse,
  Activity as ActivityIcon,
  Search
} from 'lucide-react';

interface QuantumMessage {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  timestamp: number;
  message_type: 'text' | 'intention' | 'energy' | 'vision' | 'guidance' | 'healing' | 'activation' | 'telepathic';
  consciousness_level: number;
  vibration_frequency: number;
  quantum_state: 'superposition' | 'entangled' | 'collapsed' | 'transmitted';
  encryption_level: number;
  read: boolean;
  delivered: boolean;
  entanglement_strength: number;
  coherence_score: number;
  distance: number;
  transmission_time: number;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  attachments?: string[];
  metadata?: {
    emotion?: string;
    intention_strength?: number;
    visualization?: string;
    sound_frequency?: number;
    color_frequency?: string;
    geometric_pattern?: string;
  };
}

interface QuantumChannel {
  id: string;
  name: string;
  type: 'private' | 'group' | 'broadcast' | 'telepathic' | 'dimensional';
  participants: string[];
  frequency: number;
  encryption_key: string;
  coherence_level: number;
  entanglement_network: string[];
  created_at: number;
  last_activity: number;
  status: 'active' | 'dormant' | 'encrypted' | 'quantum_locked';
  bandwidth: number;
  latency: number;
  reliability: number;
}

interface QuantumContact {
  id: string;
  name: string;
  avatar: string;
  consciousness_level: number;
  vibration_frequency: number;
  online: boolean;
  last_seen: number;
  distance: number;
  entanglement_strength: number;
  communication_channels: string[];
  preferred_frequencies: number[];
  status: 'available' | 'busy' | 'meditating' | 'offline' | 'quantum_state';
  quantum_signature: {
    unique_id: string;
    resonance_pattern: string;
    coherence_matrix: number[][];
    dimensional_access: number[];
  };
}

interface QuantumMessagingSystemProps {
  className?: string;
}

export default function QuantumMessagingSystem({ 
  className 
}: QuantumMessagingSystemProps) {
  const [contacts, setContacts] = useState<QuantumContact[]>([]);
  const [channels, setChannels] = useState<QuantumChannel[]>([]);
  const [messages, setMessages] = useState<QuantumMessage[]>([]);
  const [activeChannel, setActiveChannel] = useState<string | null>(null);
  const [activeContact, setActiveContact] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [messageType, setMessageType] = useState<QuantumMessage['message_type']>('text');
  const [isTransmitting, setIsTransmitting] = useState(false);
  const [quantumState, setQuantumState] = useState<'superposition' | 'entangled' | 'collapsed' | 'transmitted'>('superposition');
  const [encryptionEnabled, setEncryptionEnabled] = useState(true);
  const [entanglementMode, setEntanglementMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFrequency, setSelectedFrequency] = useState(432);
  const [realtimeUpdates, setRealtimeUpdates] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    initializeQuantumContacts();
    initializeQuantumChannels();
    initializeMessages();
    startQuantumFieldUpdates();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, activeChannel]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const startQuantumFieldUpdates = () => {
    if (!realtimeUpdates) return;

    const interval = setInterval(() => {
      updateQuantumFields();
      simulateIncomingMessages();
    }, 3000);

    return () => clearInterval(interval);
  };

  const initializeQuantumContacts = () => {
    const mockContacts: QuantumContact[] = [
      {
        id: 'contact_1',
        name: 'Luzandra Estelar',
        avatar: '/avatars/luzandra.jpg',
        consciousness_level: 0.92,
        vibration_frequency: 963,
        online: true,
        last_seen: Date.now(),
        distance: 7615,
        entanglement_strength: 0.97,
        communication_channels: ['telepathic', 'private', 'dimensional'],
        preferred_frequencies: [432, 528, 963],
        status: 'available',
        quantum_signature: {
          unique_id: 'ls_2024_alpha',
          resonance_pattern: 'sacred_geometry',
          coherence_matrix: [[1, 0.9], [0.9, 1]],
          dimensional_access: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
        }
      },
      {
        id: 'contact_2',
        name: 'Marcus Dimensional',
        avatar: '/avatars/marcus.jpg',
        consciousness_level: 0.85,
        vibration_frequency: 741,
        online: true,
        last_seen: Date.now() - 300000,
        distance: 9434,
        entanglement_strength: 0.84,
        communication_channels: ['private', 'broadcast'],
        preferred_frequencies: [432, 741, 852],
        status: 'meditating',
        quantum_signature: {
          unique_id: 'md_2024_beta',
          resonance_pattern: 'fractal_harmonics',
          coherence_matrix: [[1, 0.8], [0.8, 1]],
          dimensional_access: [3, 4, 5, 6, 7, 8, 9]
        }
      },
      {
        id: 'contact_3',
        name: 'Sofia Cósmica',
        avatar: '/avatars/sofia.jpg',
        consciousness_level: 0.87,
        vibration_frequency: 639,
        online: false,
        last_seen: Date.now() - 1800000,
        distance: 18400,
        entanglement_strength: 0.79,
        communication_channels: ['private', 'group'],
        preferred_frequencies: [528, 639, 741],
        status: 'offline',
        quantum_signature: {
          unique_id: 'sc_2024_gamma',
          resonance_pattern: 'wave_function',
          coherence_matrix: [[1, 0.7], [0.7, 1]],
          dimensional_access: [3, 4, 5, 6, 7, 8]
        }
      },
      {
        id: 'contact_4',
        name: 'Rafael Quântico',
        avatar: '/avatars/rafael.jpg',
        consciousness_level: 0.91,
        vibration_frequency: 528,
        online: true,
        last_seen: Date.now() - 60000,
        distance: 11850,
        entanglement_strength: 0.88,
        communication_channels: ['telepathic', 'private', 'dimensional'],
        preferred_frequencies: [432, 528, 852],
        status: 'quantum_state',
        quantum_signature: {
          unique_id: 'rq_2024_delta',
          resonance_pattern: 'quantum_coherence',
          coherence_matrix: [[1, 0.9], [0.9, 1]],
          dimensional_access: [3, 4, 5, 6, 7, 8, 9, 10, 11]
        }
      }
    ];

    setContacts(mockContacts);
  };

  const initializeQuantumChannels = () => {
    const mockChannels: QuantumChannel[] = [
      {
        id: 'channel_1',
        name: 'Canal Telepático Privado',
        type: 'telepathic',
        participants: ['valeria_plaisant', 'contact_1'],
        frequency: 963,
        encryption_key: 'quantum_key_alpha',
        coherence_level: 0.94,
        entanglement_network: ['valeria_plaisant', 'contact_1'],
        created_at: Date.now() - 86400000,
        last_activity: Date.now() - 3600000,
        status: 'active',
        bandwidth: 1000,
        latency: 0.001,
        reliability: 0.99
      },
      {
        id: 'channel_2',
        name: 'Rede de Comunicação Dimensional',
        type: 'dimensional',
        participants: ['valeria_plaisant', 'contact_2', 'contact_4'],
        frequency: 852,
        encryption_key: 'quantum_key_beta',
        coherence_level: 0.87,
        entanglement_network: ['valeria_plaisant', 'contact_2', 'contact_4'],
        created_at: Date.now() - 172800000,
        last_activity: Date.now() - 7200000,
        status: 'active',
        bandwidth: 750,
        latency: 0.005,
        reliability: 0.92
      },
      {
        id: 'channel_3',
        name: 'Canal de Transmissão Quântica',
        type: 'broadcast',
        participants: ['valeria_plaisant', 'contact_1', 'contact_2', 'contact_3', 'contact_4'],
        frequency: 432,
        encryption_key: 'quantum_key_gamma',
        coherence_level: 0.82,
        entanglement_network: ['valeria_plaisant', 'contact_1', 'contact_2', 'contact_3', 'contact_4'],
        created_at: Date.now() - 259200000,
        last_activity: Date.now() - 10800000,
        status: 'active',
        bandwidth: 500,
        latency: 0.01,
        reliability: 0.85
      }
    ];

    setChannels(mockChannels);
    setActiveChannel(mockChannels[0].id);
  };

  const initializeMessages = () => {
    const mockMessages: QuantumMessage[] = [
      {
        id: 'msg_1',
        sender_id: 'contact_1',
        receiver_id: 'valeria_plaisant',
        content: 'Senti uma forte ressonância durante nossa meditação conjunta. Nossos campos quânticos estão perfeitamente alinhados!',
        timestamp: Date.now() - 3600000,
        message_type: 'energy',
        consciousness_level: 0.95,
        vibration_frequency: 963,
        quantum_state: 'entangled',
        encryption_level: 0.98,
        read: true,
        delivered: true,
        entanglement_strength: 0.97,
        coherence_score: 0.94,
        distance: 7615,
        transmission_time: 0.001,
        priority: 'high',
        metadata: {
          emotion: 'joy',
          intention_strength: 0.95,
          visualization: 'golden_light',
          sound_frequency: 963,
          color_frequency: 'golden',
          geometric_pattern: 'flower_of_life'
        }
      },
      {
        id: 'msg_2',
        sender_id: 'valeria_plaisant',
        receiver_id: 'contact_1',
        content: 'Sim! A conexão está incrivelmente forte. Estou recebendo visões de um novo portal energético se abrindo.',
        timestamp: Date.now() - 3500000,
        message_type: 'vision',
        consciousness_level: 0.93,
        vibration_frequency: 963,
        quantum_state: 'transmitted',
        encryption_level: 0.98,
        read: true,
        delivered: true,
        entanglement_strength: 0.97,
        coherence_score: 0.94,
        distance: 7615,
        transmission_time: 0.001,
        priority: 'high',
        metadata: {
          emotion: 'excitement',
          intention_strength: 0.92,
          visualization: 'portal_opening',
          sound_frequency: 963,
          color_frequency: 'violet',
          geometric_pattern: 'spiral'
        }
      },
      {
        id: 'msg_3',
        sender_id: 'contact_2',
        receiver_id: 'valeria_plaisant',
        content: 'Recebi uma transmissão dimensional sobre alinhamento planetário. Precisamos sincronizar nossos ritmos.',
        timestamp: Date.now() - 86400000,
        message_type: 'guidance',
        consciousness_level: 0.87,
        vibration_frequency: 741,
        quantum_state: 'entangled',
        encryption_level: 0.92,
        read: false,
        delivered: true,
        entanglement_strength: 0.84,
        coherence_score: 0.86,
        distance: 9434,
        transmission_time: 0.005,
        priority: 'normal',
        metadata: {
          emotion: 'serious',
          intention_strength: 0.88,
          visualization: 'planetary_grid',
          sound_frequency: 741,
          color_frequency: 'blue',
          geometric_pattern: 'grid'
        }
      }
    ];

    setMessages(mockMessages);
  };

  const updateQuantumFields = () => {
    // Simulate quantum field fluctuations
    setContacts(prev => prev.map(contact => ({
      ...contact,
      entanglement_strength: Math.max(0.5, Math.min(1, 
        contact.entanglement_strength + (Math.random() - 0.5) * 0.02
      )),
      consciousness_level: Math.max(0.7, Math.min(1, 
        contact.consciousness_level + (Math.random() - 0.5) * 0.01
      ))
    })));

    setChannels(prev => prev.map(channel => ({
      ...channel,
      coherence_level: Math.max(0.7, Math.min(1, 
        channel.coherence_level + (Math.random() - 0.5) * 0.02
      )),
      last_activity: Date.now()
    })));
  };

  const simulateIncomingMessages = () => {
    if (Math.random() < 0.1 && contacts.some(c => c.online)) { // 10% chance of incoming message
      const onlineContacts = contacts.filter(c => c.online);
      const randomContact = onlineContacts[Math.floor(Math.random() * onlineContacts.length)];
      
      const incomingMessage: QuantumMessage = {
        id: `msg_${Date.now()}`,
        sender_id: randomContact.id,
        receiver_id: 'valeria_plaisant',
        content: generateRandomMessageContent(),
        timestamp: Date.now(),
        message_type: ['text', 'energy', 'vision', 'guidance'][Math.floor(Math.random() * 4)] as QuantumMessage['message_type'],
        consciousness_level: randomContact.consciousness_level,
        vibration_frequency: randomContact.vibration_frequency,
        quantum_state: 'superposition',
        encryption_level: 0.9,
        read: false,
        delivered: true,
        entanglement_strength: randomContact.entanglement_strength,
        coherence_score: randomContact.consciousness_level,
        distance: randomContact.distance,
        transmission_time: 0.001 + Math.random() * 0.01,
        priority: ['low', 'normal', 'high'][Math.floor(Math.random() * 3)] as QuantumMessage['priority'],
        metadata: {
          emotion: ['love', 'joy', 'peace', 'excitement'][Math.floor(Math.random() * 4)],
          intention_strength: 0.8 + Math.random() * 0.2,
          visualization: ['light', 'energy', 'portal', 'grid'][Math.floor(Math.random() * 4)],
          sound_frequency: randomContact.vibration_frequency,
          color_frequency: ['golden', 'blue', 'violet', 'green'][Math.floor(Math.random() * 4)],
          geometric_pattern: ['spiral', 'grid', 'flower', 'mandala'][Math.floor(Math.random() * 4)]
        }
      };

      setMessages(prev => [...prev, incomingMessage]);
    }
  };

  const generateRandomMessageContent = (): string => {
    const messages = [
      'Os campos quânticos estão vibrando em harmonia perfeita!',
      'Recebi uma visão durante a meditação. Algo grande está prestes a acontecer.',
      'Nossa conexão está mais forte do que nunca. Sinto sua presença.',
      'As frequências estão se alinhando para uma grande ativação.',
      'O entrelaçamento quântico entre nós está aumentando.',
      'Senti uma onda de energia vindo de sua direção.',
      'Nossas assinaturas quânticas estão em perfeita ressonância.',
      'Agradeço pela conexão. Estamos fazendo um trabalho importante.'
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  };

  const sendQuantumMessage = async () => {
    if (!newMessage.trim() || !activeContact || isTransmitting) return;

    setIsTransmitting(true);
    setQuantumState('superposition');

    // Simulate quantum transmission process
    setTimeout(() => setQuantumState('entangled'), 500);
    setTimeout(() => setQuantumState('collapsed'), 1000);
    setTimeout(() => setQuantumState('transmitted'), 1500);

    try {
      const contact = contacts.find(c => c.id === activeContact);
      if (!contact) return;

      const newMsg: QuantumMessage = {
        id: `msg_${Date.now()}`,
        sender_id: 'valeria_plaisant',
        receiver_id: activeContact,
        content: newMessage,
        timestamp: Date.now(),
        message_type: messageType,
        consciousness_level: 0.85,
        vibration_frequency: selectedFrequency,
        quantum_state: 'transmitted',
        encryption_level: encryptionEnabled ? 0.95 : 0.1,
        read: false,
        delivered: true,
        entanglement_strength: contact.entanglement_strength,
        coherence_score: 0.85,
        distance: contact.distance,
        transmission_time: entanglementMode ? 0.001 : 0.01,
        priority: 'normal',
        metadata: {
          emotion: 'peace',
          intention_strength: 0.85,
          visualization: 'light_wave',
          sound_frequency: selectedFrequency,
          color_frequency: 'blue',
          geometric_pattern: 'wave'
        }
      };

      setMessages(prev => [...prev, newMsg]);
      setNewMessage('');
    } finally {
      setTimeout(() => setIsTransmitting(false), 2000);
    }
  };

  const getMessageTypeIcon = (type: QuantumMessage['message_type']) => {
    switch (type) {
      case 'text': return <MessageCircle className="h-4 w-4" />;
      case 'intention': return <Target className="h-4 w-4" />;
      case 'energy': return <Zap className="h-4 w-4" />;
      case 'vision': return <Eye className="h-4 w-4" />;
      case 'guidance': return <Brain className="h-4 w-4" />;
      case 'healing': return <Heart className="h-4 w-4" />;
      case 'activation': return <Star className="h-4 w-4" />;
      case 'telepathic': return <Brain className="h-4 w-4" />;
      default: return <MessageCircle className="h-4 w-4" />;
    }
  };

  const getChannelTypeIcon = (type: QuantumChannel['type']) => {
    switch (type) {
      case 'private': return <Lock className="h-4 w-4" />;
      case 'group': return <Users className="h-4 w-4" />;
      case 'broadcast': return <RadioTower className="h-4 w-4" />;
      case 'telepathic': return <Brain className="h-4 w-4" />;
      case 'dimensional': return <Layers className="h-4 w-4" />;
      default: return <MessageCircle className="h-4 w-4" />;
    }
  };

  const getContactStatusColor = (status: QuantumContact['status']) => {
    switch (status) {
      case 'available': return 'bg-green-500';
      case 'busy': return 'bg-yellow-500';
      case 'meditating': return 'bg-purple-500';
      case 'offline': return 'bg-gray-400';
      case 'quantum_state': return 'bg-blue-500';
      default: return 'bg-gray-400';
    }
  };

  const getQuantumStateColor = (state: QuantumMessage['quantum_state']) => {
    switch (state) {
      case 'superposition': return 'bg-purple-500';
      case 'entangled': return 'bg-blue-500';
      case 'collapsed': return 'bg-green-500';
      case 'transmitted': return 'bg-yellow-500';
      default: return 'bg-gray-400';
    }
  };

  const getPriorityColor = (priority: QuantumMessage['priority']) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'normal': return 'bg-blue-500';
      case 'low': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  const formatCoherenceValue = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  const formatFrequency = (value: number) => {
    return `${value} Hz`;
  };

  const formatTimeAgo = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (seconds < 60) return `${seconds}s atrás`;
    if (minutes < 60) return `${minutes}m atrás`;
    return `${hours}h atrás`;
  };

  const formatDistance = (distance: number) => {
    if (distance < 1000) return `${distance} km`;
    return `${(distance / 1000).toFixed(1)}k km`;
  };

  const filteredContacts = contacts.filter(contact =>
    contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getChannelMessages = () => {
    if (!activeChannel) return [];
    const channel = channels.find(c => c.id === activeChannel);
    if (!channel) return [];
    
    return messages.filter(msg =>
      channel.participants.includes(msg.sender_id) &&
      channel.participants.includes(msg.receiver_id)
    ).sort((a, b) => a.timestamp - b.timestamp);
  };

  return (
    <div className={`container mx-auto p-6 space-y-6 ${className}`}>
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Satellite className="h-10 w-10 text-purple-600 animate-pulse" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Sistema de Mensagem Quântica
          </h1>
          <RadioTower className="h-10 w-10 text-blue-600 animate-pulse" />
        </div>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Comunicação instantânea através de entrelaçamento quântico, 
          transmissão telepática e canais dimensionais
        </p>
        <div className="flex items-center justify-center gap-4">
          <Badge variant="outline" className="text-sm">
            <Wifi className="w-3 h-3 mr-1" />
            {contacts.filter(c => c.online).length} Contatos Online
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Radio className="w-3 h-3 mr-1" />
            {channels.filter(c => c.status === 'active').length} Canais Ativos
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Activity className="w-3 h-3 mr-1" />
            {messages.filter(m => !m.read).length} Mensagens Não Lidas
          </Badge>
        </div>
      </div>

      {/* Main Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Contacts & Channels Sidebar */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Contatos & Canais
            </CardTitle>
            <CardDescription>
              Conexões quânticas disponíveis
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Search */}
            <div className="relative">
              <Input
                placeholder="Buscar contatos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-8"
              />
              <Search className="absolute right-2 top-2.5 h-4 w-4 text-muted-foreground" />
            </div>

            {/* Quantum Channels */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium flex items-center gap-2">
                <Radio className="h-4 w-4" />
                Canais Quânticos
              </h3>
              <ScrollArea className="h-32">
                <div className="space-y-2">
                  {channels.map((channel) => (
                    <div
                      key={channel.id}
                      className={`p-2 rounded-lg cursor-pointer transition-colors ${
                        activeChannel === channel.id
                          ? 'bg-purple-100 border border-purple-300'
                          : 'hover:bg-muted'
                      }`}
                      onClick={() => setActiveChannel(channel.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {getChannelTypeIcon(channel.type)}
                          <div>
                            <div className="text-sm font-medium">{channel.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {channel.participants.length} participantes
                            </div>
                          </div>
                        </div>
                        <div className={`w-2 h-2 rounded-full ${
                          channel.status === 'active' ? 'bg-green-500' : 'bg-gray-400'
                        }`} />
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>

            {/* Contacts */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium flex items-center gap-2">
                <Users className="h-4 w-4" />
                Contatos
              </h3>
              <ScrollArea className="h-64">
                <div className="space-y-2">
                  {filteredContacts.map((contact) => (
                    <div
                      key={contact.id}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        activeContact === contact.id
                          ? 'bg-blue-100 border border-blue-300'
                          : 'hover:bg-muted'
                      }`}
                      onClick={() => setActiveContact(contact.id)}
                    >
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={contact.avatar} alt={contact.name} />
                          <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <div className="text-sm font-medium">{contact.name}</div>
                            <div className={`w-2 h-2 rounded-full ${getContactStatusColor(contact.status)}`} />
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {formatDistance(contact.distance)} • {formatFrequency(contact.vibration_frequency)}
                          </div>
                        </div>
                        {contact.entanglement_strength > 0.9 && (
                          <Zap className="h-4 w-4 text-purple-600" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </CardContent>
        </Card>

        {/* Chat Area */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {activeChannel ? (
                  <>
                    {getChannelTypeIcon(channels.find(c => c.id === activeChannel)?.type || 'private')}
                    {channels.find(c => c.id === activeChannel)?.name}
                  </>
                ) : activeContact ? (
                  <>
                    <MessageCircle className="h-5 w-5" />
                    Conversa com {contacts.find(c => c.id === activeContact)?.name}
                  </>
                ) : (
                  <>
                    <MessageCircle className="h-5 w-5" />
                    Selecione um contato ou canal
                  </>
                )}
              </div>
              <div className="flex items-center gap-2">
                {encryptionEnabled && <Lock className="h-4 w-4 text-green-600" />}
                {entanglementMode && <Sparkles className="h-4 w-4 text-purple-600" />}
                <Badge variant="outline" className="text-xs">
                  {formatFrequency(selectedFrequency)}
                </Badge>
              </div>
            </CardTitle>
            <CardDescription>
              {activeChannel 
                ? `Canal quântico com ${channels.find(c => c.id === activeChannel)?.participants.length} participantes`
                : activeContact
                ? `Conexão quântica com ${contacts.find(c => c.id === activeContact)?.name}`
                : 'Escolha uma conexão para começar a comunicar'
              }
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {(activeChannel || activeContact) ? (
              <>
                {/* Messages Display */}
                <ScrollArea className="h-96 border rounded-lg p-4">
                  <div className="space-y-4">
                    {getChannelMessages().map((message) => {
                      const isFromMe = message.sender_id === 'valeria_plaisant';
                      const contact = contacts.find(c => c.id === message.sender_id);
                      
                      return (
                        <div
                          key={message.id}
                          className={`flex ${isFromMe ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                              isFromMe
                                ? 'bg-blue-600 text-white'
                                : 'bg-muted'
                            }`}
                          >
                            <div className="flex items-center gap-2 mb-1">
                              {getMessageTypeIcon(message.message_type)}
                              <span className="text-xs opacity-75">
                                {formatTimeAgo(message.timestamp)}
                              </span>
                              <div className={`w-2 h-2 rounded-full ${getQuantumStateColor(message.quantum_state)}`} />
                              {message.encryption_level > 0.8 && <Lock className="h-3 w-3" />}
                              {message.priority === 'urgent' && <div className={`w-2 h-2 rounded-full ${getPriorityColor(message.priority)}`} />}
                            </div>
                            <div className="text-sm">{message.content}</div>
                            <div className="text-xs opacity-75 mt-1">
                              {formatFrequency(message.vibration_frequency)} • {formatCoherenceValue(message.coherence_score)}
                            </div>
                            {message.metadata && (
                              <div className="text-xs opacity-75 mt-1">
                                {message.metadata.emotion && `• ${message.metadata.emotion}`}
                                {message.metadata.visualization && `• ${message.metadata.visualization}`}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>

                {/* Message Input */}
                <div className="space-y-4">
                  {/* Message Type Selection */}
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">Tipo:</span>
                    <div className="flex gap-1">
                      {(['text', 'intention', 'energy', 'vision', 'guidance', 'healing', 'activation', 'telepathic'] as const).map((type) => (
                        <Button
                          key={type}
                          variant={messageType === type ? "default" : "outline"}
                          size="sm"
                          onClick={() => setMessageType(type)}
                          className="flex items-center gap-1"
                          title={type.charAt(0).toUpperCase() + type.slice(1)}
                        >
                          {getMessageTypeIcon(type)}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Frequency Selection */}
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">Frequência:</span>
                    <div className="flex gap-1">
                      {[432, 528, 639, 741, 852, 963].map((freq) => (
                        <Button
                          key={freq}
                          variant={selectedFrequency === freq ? "default" : "outline"}
                          size="sm"
                          onClick={() => setSelectedFrequency(freq)}
                        >
                          {freq}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Quantum Options */}
                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={encryptionEnabled}
                        onChange={(e) => setEncryptionEnabled(e.target.checked)}
                      />
                      <Lock className="h-4 w-4" />
                      Criptografia Quântica
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={entanglementMode}
                        onChange={(e) => setEntanglementMode(e.target.checked)}
                      />
                      <Sparkles className="h-4 w-4" />
                      Modo Entrelaçamento
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={realtimeUpdates}
                        onChange={(e) => setRealtimeUpdates(e.target.checked)}
                      />
                      <Activity className="h-4 w-4" />
                      Tempo Real
                    </label>
                  </div>

                  {/* Transmission Status */}
                  {isTransmitting && (
                    <div className="flex items-center gap-2 text-sm">
                      <div className={`w-3 h-3 rounded-full ${getQuantumStateColor(quantumState)} animate-pulse`} />
                      <span>Estado Quântico: {quantumState === 'superposition' ? 'Superposição' :
                           quantumState === 'entangled' ? 'Entrelaçado' :
                           quantumState === 'collapsed' ? 'Colapsado' : 'Transmitido'}</span>
                    </div>
                  )}

                  {/* Message Input */}
                  <div className="flex gap-2">
                    <Input
                      placeholder="Digite sua mensagem quântica..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && sendQuantumMessage()}
                      className="flex-1"
                      disabled={isTransmitting}
                    />
                    <Button 
                      onClick={sendQuantumMessage} 
                      disabled={isTransmitting || !newMessage.trim()}
                      className="flex items-center gap-2"
                    >
                      {isTransmitting ? (
                        <RefreshCw className="h-4 w-4 animate-spin" />
                      ) : (
                        <Send className="h-4 w-4" />
                      )}
                      Enviar
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center text-muted-foreground py-12">
                <MessageCircle className="h-12 w-12 mx-auto mb-4" />
                <p>Selecione um contato ou canal quântico para começar a comunicar</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quantum Field Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Status do Campo Quântico
          </CardTitle>
          <CardDescription>
            Monitoramento em tempo real das condições de transmissão
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Coerência Global</span>
                <span>{formatCoherenceValue(
                  channels.reduce((sum, channel) => sum + channel.coherence_level, 0) / channels.length
                )}</span>
              </div>
              <Progress 
                value={(channels.reduce((sum, channel) => sum + channel.coherence_level, 0) / channels.length) * 100} 
                className="h-2" 
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Entrelaçamento Médio</span>
                <span>{formatCoherenceValue(
                  contacts.reduce((sum, contact) => sum + contact.entanglement_strength, 0) / contacts.length
                )}</span>
              </div>
              <Progress 
                value={(contacts.reduce((sum, contact) => sum + contact.entanglement_strength, 0) / contacts.length) * 100} 
                className="h-2" 
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Consciência Média</span>
                <span>{formatCoherenceValue(
                  contacts.reduce((sum, contact) => sum + contact.consciousness_level, 0) / contacts.length
                )}</span>
              </div>
              <Progress 
                value={(contacts.reduce((sum, contact) => sum + contact.consciousness_level, 0) / contacts.length) * 100} 
                className="h-2" 
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Canais Ativos</span>
                <span>{channels.filter(c => c.status === 'active').length}/{channels.length}</span>
              </div>
              <Progress 
                value={(channels.filter(c => c.status === 'active').length / channels.length) * 100} 
                className="h-2" 
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}