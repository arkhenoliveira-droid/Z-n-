'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area,
  BarChart, 
  Bar,
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ScatterChart,
  Scatter
} from 'recharts';
import { 
  Activity, 
  Zap, 
  Heart, 
  Brain, 
  Users, 
  Target, 
  TrendingUp, 
  Star,
  BookOpen,
  User,
  Calendar,
  Award,
  Lightbulb,
  Shield,
  Eye,
  HelpCircle,
  Sparkles,
  Infinity,
  Atom,
  Layers,
  RefreshCw,
  Plus,
  GitBranch,
  Network,
  BarChart3
} from 'lucide-react';

import { 
  QuantumSeedSystem, 
  QuantumSeedState, 
  QuantumSeedMetrics,
  QuantumSeedConfig 
} from '@/systems/quantum-seed-system';
import { QuantumAIIntegration, QuantumAIConfig } from '@/systems/quantum-ai-integration';
import { QuantumFieldSystem, QuantumFieldConfig } from '@/systems/quantum-field-system';
import { MultiDimensionalCoherenceAnalyzer, DimensionalCoherenceConfig } from '@/systems/multi-dimensional-coherence-analyzer';
import { QuantumEntanglementNetwork, EntanglementNetworkConfig } from '@/systems/quantum-entanglement-network';
import { EmergencePatternRecognitionSystem, EmergencePatternConfig } from '@/systems/emergence-pattern-recognition';
import { QuantumConsciousnessAmplificationSystem, ConsciousnessAmplificationConfig } from '@/systems/quantum-consciousness-amplification';

interface QuantumSeedVisualizerProps {
  config?: Partial<QuantumSeedConfig>;
  onSeedEvolution?: (seedId: string, metrics: QuantumSeedMetrics) => void;
}

export default function QuantumSeedVisualizer({ 
  config,
  onSeedEvolution 
}: QuantumSeedVisualizerProps) {
  const [quantumSystem] = useState(() => new QuantumSeedSystem(config));
  const [aiSystem] = useState(() => new QuantumAIIntegration(quantumSystem));
  const [fieldSystem] = useState(() => new QuantumFieldSystem());
  const [dimensionalAnalyzer] = useState(() => new MultiDimensionalCoherenceAnalyzer());
  const [entanglementNetwork] = useState(() => new QuantumEntanglementNetwork());
  const [patternRecognition] = useState(() => new EmergencePatternRecognitionSystem());
  const [consciousnessAmplifier] = useState(() => new QuantumConsciousnessAmplificationSystem());
  
  const [selectedSeed, setSelectedSeed] = useState<QuantumSeedState | null>(null);
  const [seeds, setSeeds] = useState<QuantumSeedState[]>([]);
  const [systemOverview, setSystemOverview] = useState<any>(null);
  const [isEvolving, setIsEvolving] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const [activeSystemTab, setActiveSystemTab] = useState('quantum-seed');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // AI-specific states
  const [aiPrediction, setAiPrediction] = useState<any>(null);
  const [aiOptimization, setAiOptimization] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Field system states
  const [fieldVisualization, setFieldVisualization] = useState<any>(null);
  const [fieldMetrics, setFieldMetrics] = useState<any>(null);
  
  // Dimensional analysis states
  const [dimensionalAnalysis, setDimensionalAnalysis] = useState<any>(null);
  const [dimensionalMetrics, setDimensionalMetrics] = useState<any>(null);
  
  // Entanglement network states
  const [networkOverview, setNetworkOverview] = useState<any>(null);
  const [networkNodes, setNetworkNodes] = useState<any[]>([]);
  const [networkConnections, setNetworkConnections] = useState<any[]>([]);
  
  // Pattern recognition states
  const [patternRecognitionResult, setPatternRecognitionResult] = useState<any>(null);
  const [detectedPatterns, setDetectedPatterns] = useState<any[]>([]);
  
  // Consciousness amplification states
  const [amplificationSession, setAmplificationSession] = useState<any>(null);
  const [amplificationProgress, setAmplificationProgress] = useState(0);
  const [activeAmplifiers, setActiveAmplifiers] = useState<any[]>([]);
  const [amplificationStrategies, setAmplificationStrategies] = useState<any[]>([]);

  useEffect(() => {
    refreshData();
  }, [quantumSystem]);

  const refreshData = () => {
    const allSeeds = quantumSystem.getAllSeeds();
    setSeeds(allSeeds);
    setSystemOverview(quantumSystem.getSystemOverview());
    
    // Update AI system data
    const aiOverview = aiSystem.getSystemIntelligenceOverview();
    setSystemOverview(prev => ({ ...prev, ...aiOverview }));
    
    // Update field system data
    const fieldMetricsData = fieldSystem.getFieldMetrics();
    setFieldMetrics(fieldMetricsData);
    
    // Update dimensional analyzer data
    const dimensionalOverview = dimensionalAnalyzer.getSystemOverview();
    setSystemOverview(prev => ({ ...prev, ...dimensionalOverview }));
    
    // Update entanglement network data
    const networkOverviewData = entanglementNetwork.getSystemOverview();
    setNetworkOverview(networkOverviewData);
    
    // Update pattern recognition data
    const patternOverview = patternRecognition.getSystemOverview();
    setSystemOverview(prev => ({ ...prev, ...patternOverview }));
    
    // Update consciousness amplifier data
    const amplifierOverview = consciousnessAmplifier.getSystemOverview();
    setSystemOverview(prev => ({ ...prev, ...amplifierOverview }));
    
    // Update active amplifiers and strategies
    setActiveAmplifiers(consciousnessAmplifier.getAmplifiers());
    setAmplificationStrategies(consciousnessAmplifier.getStrategies());
    
    if (allSeeds.length > 0 && !selectedSeed) {
      setSelectedSeed(allSeeds[0]);
    }
  };

  const handleEvolveSeed = async (seedId: string) => {
    setIsEvolving(true);
    try {
      const evolvedSeed = quantumSystem.evolveSeed(seedId);
      if (evolvedSeed) {
        const metrics = quantumSystem.calculateSeedMetrics(evolvedSeed);
        onSeedEvolution?.(seedId, metrics);
        refreshData();
      }
    } finally {
      setIsEvolving(false);
    }
  };

  const handleCreateSeed = () => {
    const newSeed = quantumSystem.createQuantumSeed({
      consciousness_level: 0.7 + Math.random() * 0.3
    });
    refreshData();
    setSelectedSeed(newSeed);
  };

  const handleCreateSeedFamily = () => {
    if (selectedSeed) {
      quantumSystem.createSeedFamily(selectedSeed.id, 3);
      refreshData();
    }
  };

  // AI System Functions
  const handleAnalyzeWithAI = async (seedId: string) => {
    if (!selectedSeed) return;
    
    setIsAnalyzing(true);
    try {
      const prediction = await aiSystem.predictEvolution(seedId, 5);
      setAiPrediction(prediction);
      
      const optimization = await aiSystem.generateOptimizationStrategy(seedId);
      setAiOptimization(optimization);
    } catch (error) {
      console.error('AI analysis failed:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleRecognizePatterns = async (seedId: string) => {
    if (!selectedSeed) return;
    
    try {
      const result = patternRecognition.recognizeEmergencePatterns(selectedSeed);
      setPatternRecognitionResult(result);
      setDetectedPatterns(result.detected_patterns);
    } catch (error) {
      console.error('Pattern recognition failed:', error);
    }
  };

  // Field System Functions
  const handleCreateFieldVisualization = () => {
    if (!selectedSeed) return;
    
    try {
      const fieldId = fieldSystem.mapSeedToField(selectedSeed);
      const visualizationId = fieldSystem.createVisualization('coherence');
      const visualization = fieldSystem.getVisualization(visualizationId);
      setFieldVisualization(visualization);
    } catch (error) {
      console.error('Field visualization failed:', error);
    }
  };

  const handleOptimizeField = () => {
    try {
      const improvement = fieldSystem.optimizeFieldCoherence();
      setFieldMetrics(fieldSystem.getFieldMetrics());
    } catch (error) {
      console.error('Field optimization failed:', error);
    }
  };

  // Dimensional Analysis Functions
  const handleAnalyzeDimensions = () => {
    if (!selectedSeed) return;
    
    try {
      const analysis = dimensionalAnalyzer.analyzeSeedDimensions(selectedSeed);
      setDimensionalAnalysis(analysis);
      
      const metrics = dimensionalAnalyzer.calculateDimensionalCoherenceMetrics(analysis);
      setDimensionalMetrics(metrics);
    } catch (error) {
      console.error('Dimensional analysis failed:', error);
    }
  };

  // Entanglement Network Functions
  const handleAddToNetwork = () => {
    if (!selectedSeed) return;
    
    try {
      const nodeId = entanglementNetwork.addSeedToNetwork(selectedSeed);
      const network = entanglementNetwork.getAllNetworks()[0];
      if (network) {
        setNetworkNodes(Array.from(network.nodes.values()));
        setNetworkConnections(Array.from(network.connections.values()));
      }
    } catch (error) {
      console.error('Network addition failed:', error);
    }
  };

  const handleEvolveNetwork = () => {
    try {
      const networks = entanglementNetwork.getAllNetworks();
      networks.forEach(network => {
        entanglementNetwork.evolveNetwork(network.network_id, 1000);
      });
      
      const network = networks[0];
      if (network) {
        setNetworkNodes(Array.from(network.nodes.values()));
        setNetworkConnections(Array.from(network.connections.values()));
        setNetworkOverview(entanglementNetwork.getSystemOverview());
      }
    } catch (error) {
      console.error('Network evolution failed:', error);
    }
  };

  // Consciousness Amplification Functions
  const handleStartAmplification = async () => {
    if (!selectedSeed || activeAmplifiers.length === 0) return;
    
    try {
      const amplifier = activeAmplifiers[0];
      const strategy = amplificationStrategies[0];
      
      const sessionId = consciousnessAmplifier.startAmplificationSession(
        selectedSeed,
        amplifier.amplifier_id,
        strategy.strategy_id
      );
      
      // Monitor session progress
      const monitorSession = setInterval(() => {
        const session = consciousnessAmplifier.getSession(sessionId);
        if (session) {
          setAmplificationSession(session);
          setAmplificationProgress(session.progress);
          
          if (session.session_state === 'completed' || session.session_state === 'failed') {
            clearInterval(monitorSession);
            refreshData();
          }
        }
      }, 500);
      
      // Auto-clear after 30 seconds
      setTimeout(() => clearInterval(monitorSession), 30000);
    } catch (error) {
      console.error('Amplification failed:', error);
    }
  };

  const renderQuantumVisualization = () => {
    if (!selectedSeed) return null;

    const canvas = canvasRef.current;
    if (!canvas) return null;

    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    const width = canvas.width;
    const height = canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) * 0.3;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Draw quantum state visualization
    const { amplitude, phase, coherence } = selectedSeed.quantum_state;
    const dimensions = amplitude.length;

    // Draw coherence circle
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * coherence, 0, 2 * Math.PI);
    ctx.strokeStyle = `hsl(${coherence * 120}, 70%, 50%)`;
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw dimensional vectors
    for (let i = 0; i < dimensions; i++) {
      const angle = (i / dimensions) * 2 * Math.PI + phase[i];
      const vectorRadius = radius * amplitude[i];
      
      const x = centerX + Math.cos(angle) * vectorRadius;
      const y = centerY + Math.sin(angle) * vectorRadius;

      // Draw vector
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(x, y);
      ctx.strokeStyle = `hsl(${(i / dimensions) * 360}, 70%, 60%)`;
      ctx.lineWidth = 2;
      ctx.stroke();

      // Draw vector endpoint
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, 2 * Math.PI);
      ctx.fillStyle = `hsl(${(i / dimensions) * 360}, 70%, 60%)`;
      ctx.fill();
    }

    // Draw entanglement connections
    if (selectedSeed.quantum_state.entanglement_degree > 0.5) {
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius * 0.8, 0, 2 * Math.PI);
      ctx.strokeStyle = `rgba(138, 43, 226, ${selectedSeed.quantum_state.entanglement_degree})`;
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 5]);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    return null;
  };

  const getMetricsColor = (value: number) => {
    if (value >= 0.9) return 'text-green-600';
    if (value >= 0.8) return 'text-blue-600';
    if (value >= 0.7) return 'text-yellow-600';
    return 'text-red-600';
  };

  const formatMetricsValue = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  const selectedSeedMetrics = selectedSeed ? quantumSystem.calculateSeedMetrics(selectedSeed) : null;

  // Prepare data for charts
  const coherenceProgressionData = selectedSeed ? 
    selectedSeed.metadata.coherence_history.map((coherence, index) => ({
      step: index + 1,
      coherence: coherence
    })) : [];

  const metricsData = selectedSeedMetrics ? [
    { metric: 'Coerência Quântica', value: selectedSeedMetrics.quantum_coherence },
    { metric: 'Coerência Consciencial', value: selectedSeedMetrics.consciousness_coherence },
    { metric: 'Coerência Dimensional', value: selectedSeedMetrics.dimensional_coherence },
    { metric: 'Coerência Temporal', value: selectedSeedMetrics.temporal_coherence },
    { metric: 'Potencial de Emergência', value: selectedSeedMetrics.emergence_potential },
    { metric: 'Índice de Estabilidade', value: selectedSeedMetrics.stability_index },
    { metric: 'Prontidão Evolutiva', value: selectedSeedMetrics.evolution_readiness }
  ] : [];

  const dimensionData = selectedSeed ? 
    selectedSeed.dimensional_properties.dimensions.map((dim, index) => ({
      dimension: `D${dim}`,
      coherence: selectedSeed.dimensional_properties.emergence_field[index] || 0,
      fullMark: 1
    })) : [];

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1', '#d084d0', '#ffb347', '#87ceeb'];

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <Atom className="h-8 w-8 text-purple-600" />
          Sistema de Semente Quântica
        </h1>
        <p className="text-muted-foreground">
          Visualização e evolução de sementes quânticas para análise de coerência arquitetônica
        </p>
      </div>

      {/* System Overview */}
      {systemOverview && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Network className="h-5 w-5" />
              Visão Geral do Sistema
            </CardTitle>
            <CardDescription>
              Métricas globais do sistema de sementes quânticas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {systemOverview.total_seeds}
                </div>
                <div className="text-sm text-muted-foreground">Total de Sementes</div>
              </div>
              <div className="text-center">
                <div className={`text-2xl font-bold ${getMetricsColor(systemOverview.average_coherence)}`}>
                  {formatMetricsValue(systemOverview.average_coherence)}
                </div>
                <div className="text-sm text-muted-foreground">Coerência Média</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {formatMetricsValue(systemOverview.evolution_rate)}
                </div>
                <div className="text-sm text-muted-foreground">Taxa de Evolução</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {systemOverview.highest_coherence_seed ? 'Ativa' : 'N/A'}
                </div>
                <div className="text-sm text-muted-foreground">Semente Líder</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Advanced Systems Dashboard */}
      <Tabs value={activeSystemTab} onValueChange={setActiveSystemTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-7 gap-2">
          <TabsTrigger value="quantum-seed" className="flex items-center gap-2">
            <Atom className="w-4 h-4" />
            <span className="hidden sm:inline">Semente</span>
          </TabsTrigger>
          <TabsTrigger value="ai-system" className="flex items-center gap-2">
            <Brain className="w-4 h-4" />
            <span className="hidden sm:inline">IA</span>
          </TabsTrigger>
          <TabsTrigger value="field-system" className="flex items-center gap-2">
            <Zap className="w-4 h-4" />
            <span className="hidden sm:inline">Campo</span>
          </TabsTrigger>
          <TabsTrigger value="dimensional" className="flex items-center gap-2">
            <Network className="w-4 h-4" />
            <span className="hidden sm:inline">Dimensões</span>
          </TabsTrigger>
          <TabsTrigger value="entanglement" className="flex items-center gap-2">
            <GitBranch className="w-4 h-4" />
            <span className="hidden sm:inline">Entrelaçamento</span>
          </TabsTrigger>
          <TabsTrigger value="patterns" className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            <span className="hidden sm:inline">Padrões</span>
          </TabsTrigger>
          <TabsTrigger value="amplification" className="flex items-center gap-2">
            <Heart className="w-4 h-4" />
            <span className="hidden sm:inline">Amplificação</span>
          </TabsTrigger>
        </TabsList>

        {/* Quantum Seed System */}
        <TabsContent value="quantum-seed" className="space-y-6">
          {/* Main Dashboard */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Seed Selection Panel */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Layers className="h-5 w-5" />
              Sementes Quânticas
            </CardTitle>
            <CardDescription>
              Selecione uma semente para análise detalhada
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Button 
                onClick={handleCreateSeed}
                size="sm"
                className="flex-1"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Semente
              </Button>
              <Button 
                onClick={handleCreateSeedFamily}
                size="sm"
                variant="outline"
                disabled={!selectedSeed}
              >
                <GitBranch className="w-4 h-4 mr-2" />
                Familia
              </Button>
            </div>

            <ScrollArea className="h-96">
              <div className="space-y-2">
                {seeds.map((seed) => (
                  <div
                    key={seed.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      selectedSeed?.id === seed.id 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedSeed(seed)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-sm font-medium">
                        Semente {seed.metadata.generation > 0 ? `G${seed.metadata.generation}` : 'Primordial'}
                      </div>
                      <Badge variant={seed.quantum_state.coherence > 0.8 ? 'default' : 'secondary'}>
                        {formatMetricsValue(seed.quantum_state.coherence)}
                      </Badge>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Consciência: {formatMetricsValue(seed.consciousness_signature.awareness_level)}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Quantum Visualization */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              Visualização Quântica
            </CardTitle>
            <CardDescription>
              Representação visual do estado quântico da semente selecionada
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center">
              <canvas
                ref={canvasRef}
                width={400}
                height={400}
                className="border border-gray-200 rounded-lg"
              />
            </div>
            {selectedSeed && (
              <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Coerência Quântica:</span>
                  <span className={`ml-2 ${getMetricsColor(selectedSeed.quantum_state.coherence)}`}>
                    {formatMetricsValue(selectedSeed.quantum_state.coherence)}
                  </span>
                </div>
                <div>
                  <span className="font-medium">Entrelaçamento:</span>
                  <span className={`ml-2 ${getMetricsColor(selectedSeed.quantum_state.entanglement_degree)}`}>
                    {formatMetricsValue(selectedSeed.quantum_state.entanglement_degree)}
                  </span>
                </div>
                <div>
                  <span className="font-medium">Consciência:</span>
                  <span className={`ml-2 ${getMetricsColor(selectedSeed.consciousness_signature.awareness_level)}`}>
                    {formatMetricsValue(selectedSeed.consciousness_signature.awareness_level)}
                  </span>
                </div>
                <div>
                  <span className="font-medium">Evolução:</span>
                  <span className={`ml-2 ${getMetricsColor(selectedSeed.consciousness_signature.evolutionary_potential)}`}>
                    {formatMetricsValue(selectedSeed.consciousness_signature.evolutionary_potential)}
                  </span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      </TabsContent>
      </Tabs>

      {/* Detailed Analysis */}
      {selectedSeed && selectedSeedMetrics && (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="metrics">Métricas</TabsTrigger>
            <TabsTrigger value="evolution">Evolução</TabsTrigger>
            <TabsTrigger value="dimensions">Dimensões</TabsTrigger>
            <TabsTrigger value="actions">Ações</TabsTrigger>
          </TabsList>

          <TabsContent value="metrics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Metrics Overview */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    Métricas Detalhadas
                  </CardTitle>
                  <CardDescription>
                    Análise completa das métricas da semente
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Coerência Geral</span>
                        <span className={`text-sm font-bold ${getMetricsColor(selectedSeedMetrics.overall_coherence)}`}>
                          {formatMetricsValue(selectedSeedMetrics.overall_coherence)}
                        </span>
                      </div>
                      <Progress value={selectedSeedMetrics.overall_coherence * 100} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Coerência Quântica</span>
                        <span className={`text-sm font-bold ${getMetricsColor(selectedSeedMetrics.quantum_coherence)}`}>
                          {formatMetricsValue(selectedSeedMetrics.quantum_coherence)}
                        </span>
                      </div>
                      <Progress value={selectedSeedMetrics.quantum_coherence * 100} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Coerência Consciencial</span>
                        <span className={`text-sm font-bold ${getMetricsColor(selectedSeedMetrics.consciousness_coherence)}`}>
                          {formatMetricsValue(selectedSeedMetrics.consciousness_coherence)}
                        </span>
                      </div>
                      <Progress value={selectedSeedMetrics.consciousness_coherence * 100} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Potencial de Emergência</span>
                        <span className={`text-sm font-bold ${getMetricsColor(selectedSeedMetrics.emergence_potential)}`}>
                          {formatMetricsValue(selectedSeedMetrics.emergence_potential)}
                        </span>
                      </div>
                      <Progress value={selectedSeedMetrics.emergence_potential * 100} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Prontidão Evolutiva</span>
                        <span className={`text-sm font-bold ${getMetricsColor(selectedSeedMetrics.evolution_readiness)}`}>
                          {formatMetricsValue(selectedSeedMetrics.evolution_readiness)}
                        </span>
                      </div>
                      <Progress value={selectedSeedMetrics.evolution_readiness * 100} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Metrics Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Comparação de Métricas
                  </CardTitle>
                  <CardDescription>
                    Visualização comparativa de todas as métricas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={metricsData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="metric" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="value" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="evolution" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Progressão da Coerência
                </CardTitle>
                <CardDescription>
                  Evolução temporal da coerência da semente
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <AreaChart data={coherenceProgressionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="step" />
                    <YAxis />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey="coherence" 
                      stroke="#8884d8" 
                      fill="#8884d8" 
                      fillOpacity={0.6}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="dimensions" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5" />
                  Análise Dimensional
                </CardTitle>
                <CardDescription>
                  Coerência através das dimensões quânticas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <RadarChart data={dimensionData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="dimension" />
                    <PolarRadiusAxis angle={0} domain={[0, 1]} />
                    <Radar
                      name="Coerência Dimensional"
                      dataKey="coherence"
                      stroke="#8884d8"
                      fill="#8884d8"
                      fillOpacity={0.6}
                    />
                    <Tooltip />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="actions" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <RefreshCw className="h-5 w-5" />
                  Ações da Semente
                </CardTitle>
                <CardDescription>
                  Operações disponíveis para a semente selecionada
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button
                    onClick={() => handleEvolveSeed(selectedSeed.id)}
                    disabled={isEvolving}
                    className="w-full"
                  >
                    {isEvolving ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Zap className="w-4 h-4 mr-2" />
                    )}
                    Evoluir Semente
                  </Button>

                  <Button
                    onClick={handleCreateSeedFamily}
                    variant="outline"
                    className="w-full"
                  >
                    <GitBranch className="w-4 h-4 mr-2" />
                    Criar Família
                  </Button>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-2">Informações da Semente</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">ID:</span>
                      <span className="ml-2 text-muted-foreground">
                        {selectedSeed.id.slice(0, 8)}...
                      </span>
                    </div>
                    <div>
                      <span className="font-medium">Geração:</span>
                      <span className="ml-2 text-muted-foreground">
                        {selectedSeed.metadata.generation}
                      </span>
                    </div>
                    <div>
                      <span className="font-medium">Criada:</span>
                      <span className="ml-2 text-muted-foreground">
                        {new Date(selectedSeed.metadata.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <div>
                      <span className="font-medium">Modificada:</span>
                      <span className="ml-2 text-muted-foreground">
                        {new Date(selectedSeed.metadata.last_modified).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                {selectedSeed.metadata.parent_seed && (
                  <div className="border-t pt-4">
                    <h4 className="font-medium mb-2">Semente Parental</h4>
                    <div className="text-sm text-muted-foreground">
                      ID: {selectedSeed.metadata.parent_seed.slice(0, 8)}...
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}