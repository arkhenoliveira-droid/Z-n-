'use client';

import { useEffect, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';

interface UseInvestigationSocketProps {
  investigationId?: string;
  onInvestigationUpdate?: (update: any) => void;
  onInvestigationProgress?: (progress: number, message: string) => void;
  onInvestigationComplete?: (results: any) => void;
  onInvestigationError?: (error: string) => void;
}

export const useInvestigationSocket = ({
  investigationId,
  onInvestigationUpdate,
  onInvestigationProgress,
  onInvestigationComplete,
  onInvestigationError,
}: UseInvestigationSocketProps = {}) => {
  const socketRef = useRef<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<any>(null);

  useEffect(() => {
    // Initialize socket connection
    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:3000', {
      transports: ['websocket', 'polling'],
    });

    socketRef.current = socket;

    // Connection events
    socket.on('connect', () => {
      console.log('Connected to investigation server');
      setIsConnected(true);
    });

    socket.on('disconnect', () => {
      console.log('Disconnected from investigation server');
      setIsConnected(false);
    });

    // Investigation events
    socket.on('investigation-update', (update) => {
      setLastMessage(update);
      onInvestigationUpdate?.(update);
    });

    socket.on('investigation-progress', (data) => {
      setLastMessage(data);
      onInvestigationProgress?.(data.progress, data.message);
    });

    socket.on('investigation-complete', (data) => {
      setLastMessage(data);
      onInvestigationComplete?.(data.results);
    });

    socket.on('investigation-error', (data) => {
      setLastMessage(data);
      onInvestigationError?.(data.error);
    });

    // Join investigation room if ID is provided
    if (investigationId) {
      socket.emit('join-investigation', investigationId);
    }

    // Cleanup on unmount
    return () => {
      if (investigationId) {
        socket.emit('leave-investigation', investigationId);
      }
      socket.disconnect();
    };
  }, [investigationId, onInvestigationUpdate, onInvestigationProgress, onInvestigationComplete, onInvestigationError]);

  // Re-join room when investigationId changes
  useEffect(() => {
    if (socketRef.current && investigationId) {
      socketRef.current.emit('join-investigation', investigationId);
    }
  }, [investigationId]);

  const joinInvestigation = (id: string) => {
    if (socketRef.current) {
      socketRef.current.emit('join-investigation', id);
    }
  };

  const leaveInvestigation = (id: string) => {
    if (socketRef.current) {
      socketRef.current.emit('leave-investigation', id);
    }
  };

  const requestInvestigationStatus = (id: string) => {
    if (socketRef.current) {
      socketRef.current.emit('get-investigation-status', id);
    }
  };

  return {
    isConnected,
    lastMessage,
    joinInvestigation,
    leaveInvestigation,
    requestInvestigationStatus,
    socket: socketRef.current,
  };
};

export default useInvestigationSocket;