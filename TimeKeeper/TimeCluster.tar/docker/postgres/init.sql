-- TimeKeeper OS Database Initialization Script
-- This script sets up the database schema for TimeKeeper OS multi-node testing

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Create database user for application
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'timekeeper_app') THEN
        CREATE ROLE timekeeper_app WITH LOGIN PASSWORD 'timekeeper_app_password';
    END IF;
END $$;

-- Create schema for TimeKeeper OS
CREATE SCHEMA IF NOT EXISTS timekeeper;

-- Set search path
SET search_path TO timekeeper, public;

-- Create tables for temporal operations
CREATE TABLE IF NOT EXISTS chronons (
    id SERIAL PRIMARY KEY,
    chronon_number BIGINT NOT NULL UNIQUE,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    hash VARCHAR(66) NOT NULL,
    previous_hash VARCHAR(66),
    nonce BIGINT NOT NULL,
    difficulty INTEGER NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    node_id INTEGER NOT NULL
);

-- Create table for temporal processes
CREATE TABLE IF NOT EXISTS temporal_processes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    process_id VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    command TEXT NOT NULL,
    args JSONB DEFAULT '[]',
    state VARCHAR(50) NOT NULL DEFAULT 'created',
    priority INTEGER DEFAULT 0,
    creation_chronon BIGINT NOT NULL,
    execution_chronon BIGINT,
    termination_chronon BIGINT,
    node_id INTEGER NOT NULL,
    parent_id UUID REFERENCES temporal_processes(id),
    resource_usage JSONB DEFAULT '{}',
    stdout TEXT[] DEFAULT '{}',
    stderr TEXT[] DEFAULT '{}',
    exit_code INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create table for temporal files
CREATE TABLE IF NOT EXISTS temporal_files (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    path VARCHAR(1024) NOT NULL,
    content TEXT,
    current_version INTEGER NOT NULL DEFAULT 1,
    creation_chronon BIGINT NOT NULL,
    modification_chronon BIGINT NOT NULL,
    node_id INTEGER NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create table for file versions (time travel support)
CREATE TABLE IF NOT EXISTS file_versions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    file_id UUID REFERENCES temporal_files(id) ON DELETE CASCADE,
    version_number INTEGER NOT NULL,
    content TEXT NOT NULL,
    chronon BIGINT NOT NULL,
    hash VARCHAR(66) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create table for temporal memory blocks
CREATE TABLE IF NOT EXISTS temporal_memory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    block_id VARCHAR(255) NOT NULL,
    size BIGINT NOT NULL,
    allocated BOOLEAN NOT NULL DEFAULT FALSE,
    process_id UUID REFERENCES temporal_processes(id),
    chronon BIGINT NOT NULL,
    node_id INTEGER NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    released_at TIMESTAMP WITH TIME ZONE
);

-- Create table for temporal constraints
CREATE TABLE IF NOT EXISTS temporal_constraints (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    process_id UUID REFERENCES temporal_processes(id) ON DELETE CASCADE,
    execute_after BIGINT,
    execute_before BIGINT,
    timeout BIGINT,
    dependencies UUID[],
    recurring_interval BIGINT,
    recurring_end BIGINT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create table for network operations
CREATE TABLE IF NOT EXISTS network_operations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    operation_type VARCHAR(50) NOT NULL,
    source_node INTEGER NOT NULL,
    target_node INTEGER,
    packet_size INTEGER NOT NULL,
    chronon BIGINT NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

-- Create table for security events
CREATE TABLE IF NOT EXISTS security_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type VARCHAR(100) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    description TEXT,
    node_id INTEGER NOT NULL,
    chronon BIGINT NOT NULL,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create table for performance metrics
CREATE TABLE IF NOT EXISTS performance_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    node_id INTEGER NOT NULL,
    metric_name VARCHAR(100) NOT NULL,
    metric_value DOUBLE PRECISION NOT NULL,
    chronon BIGINT NOT NULL,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create table for system checkpoints
CREATE TABLE IF NOT EXISTS system_checkpoints (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chronon BIGINT NOT NULL,
    description TEXT,
    include_memory BOOLEAN DEFAULT FALSE,
    include_filesystem BOOLEAN DEFAULT FALSE,
    include_processes BOOLEAN DEFAULT FALSE,
    checkpoint_data JSONB,
    node_id INTEGER NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create table for cluster state
CREATE TABLE IF NOT EXISTS cluster_state (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    node_id INTEGER NOT NULL,
    status VARCHAR(50) NOT NULL,
    last_heartbeat TIMESTAMP WITH TIME ZONE NOT NULL,
    chronon_synchronization_offset DOUBLE PRECISION,
    connected_nodes INTEGER[],
    metadata JSONB,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_chronons_number ON chronons(chronon_number);
CREATE INDEX IF NOT EXISTS idx_chronons_timestamp ON chronons(timestamp);
CREATE INDEX IF NOT EXISTS idx_processes_state ON temporal_processes(state);
CREATE INDEX IF NOT EXISTS idx_processes_chronon ON temporal_processes(creation_chronon);
CREATE INDEX IF NOT EXISTS idx_files_path ON temporal_files(path);
CREATE INDEX IF NOT EXISTS idx_files_chronon ON temporal_files(modification_chronon);
CREATE INDEX IF NOT EXISTS idx_file_versions_file_id ON file_versions(file_id);
CREATE INDEX IF NOT EXISTS idx_file_versions_chronon ON file_versions(chronon);
CREATE INDEX IF NOT EXISTS idx_memory_allocated ON temporal_memory(allocated);
CREATE INDEX IF NOT EXISTS idx_memory_chronon ON temporal_memory(chronon);
CREATE INDEX IF NOT EXISTS idx_security_events_severity ON security_events(severity);
CREATE INDEX IF NOT EXISTS idx_security_events_chronon ON security_events(chronon);
CREATE INDEX IF NOT EXISTS idx_performance_metrics_name ON performance_metrics(metric_name);
CREATE INDEX IF NOT EXISTS idx_performance_metrics_chronon ON performance_metrics(chronon);
CREATE INDEX IF NOT EXISTS idx_cluster_state_status ON cluster_state(status);
CREATE INDEX IF NOT EXISTS idx_cluster_state_heartbeat ON cluster_state(last_heartbeat);

-- Create full-text search indexes
CREATE INDEX IF NOT EXISTS idx_processes_name_search ON temporal_processes USING gin(to_tsvector('english', name));
CREATE INDEX IF NOT EXISTS idx_security_events_description_search ON security_events USING gin(to_tsvector('english', description));

-- Create functions for temporal operations
CREATE OR REPLACE FUNCTION get_file_version_history(file_path VARCHAR(1024))
RETURNS TABLE(version_number INTEGER, content TEXT, chronon BIGINT, created_at TIMESTAMP WITH TIME ZONE) AS $$
BEGIN
    RETURN QUERY
    SELECT fv.version_number, fv.content, fv.chronon, fv.created_at
    FROM file_versions fv
    JOIN temporal_files tf ON fv.file_id = tf.id
    WHERE tf.path = file_path
    ORDER BY fv.version_number DESC;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION get_process_history(process_id VARCHAR(255))
RETURNS TABLE(state VARCHAR(50), chronon BIGINT, timestamp TIMESTAMP WITH TIME ZONE) AS $$
BEGIN
    RETURN QUERY
    SELECT tp.state, tp.creation_chronon, tp.created_at
    FROM temporal_processes tp
    WHERE tp.process_id = process_id
    ORDER BY tp.created_at DESC;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION get_system_state_at_chronon(target_chronon BIGINT)
RETURNS TABLE(component VARCHAR(50), state JSONB) AS $$
BEGIN
    RETURN QUERY
    SELECT 'processes' as component, jsonb_agg(
        jsonb_build_object(
            'id', tp.id,
            'name', tp.name,
            'state', tp.state,
            'chronon', tp.creation_chronon
        )
    ) as state
    FROM temporal_processes tp
    WHERE tp.creation_chronon <= target_chronon
    GROUP BY 'processes'
    
    UNION ALL
    
    SELECT 'files' as component, jsonb_agg(
        jsonb_build_object(
            'id', tf.id,
            'path', tf.path,
            'version', tf.current_version,
            'chronon', tf.modification_chronon
        )
    ) as state
    FROM temporal_files tf
    WHERE tf.modification_chronon <= target_chronon
    GROUP BY 'files';
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_temporal_processes_updated_at
    BEFORE UPDATE ON temporal_processes
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_temporal_files_updated_at
    BEFORE UPDATE ON temporal_files
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_cluster_state_updated_at
    BEFORE UPDATE ON cluster_state
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Create view for system overview
CREATE OR REPLACE VIEW system_overview AS
SELECT 
    (SELECT COUNT(*) FROM chronons) as total_chronons,
    (SELECT COUNT(*) FROM temporal_processes WHERE state = 'running') as running_processes,
    (SELECT COUNT(*) FROM temporal_processes WHERE state = 'ready') as ready_processes,
    (SELECT COUNT(*) FROM temporal_processes WHERE state = 'blocked') as blocked_processes,
    (SELECT COUNT(*) FROM temporal_files) as total_files,
    (SELECT COUNT(*) FROM file_versions) as total_file_versions,
    (SELECT COUNT(*) FROM temporal_memory WHERE allocated = true) as allocated_memory_blocks,
    (SELECT COUNT(*) FROM security_events WHERE created_at > NOW() - INTERVAL '1 hour') as recent_security_events,
    (SELECT COUNT(*) FROM cluster_state WHERE status = 'active') as active_nodes;

-- Grant permissions to application user
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA timekeeper TO timekeeper_app;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA timekeeper TO timekeeper_app;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA timekeeper TO timekeeper_app;
GRANT SELECT ON system_overview TO timekeeper_app;

-- Insert initial chronon
INSERT INTO chronons (chronon_number, timestamp, hash, previous_hash, nonce, difficulty, node_id)
VALUES (
    1000,
    NOW(),
    '0x0000000000000000000000000000000000000000000000000000000000000000000',
    NULL,
    123456,
    1000,
    1
) ON CONFLICT (chronon_number) DO NOTHING;

-- Insert initial cluster state
INSERT INTO cluster_state (node_id, status, last_heartbeat, chronon_synchronization_offset, connected_nodes, metadata)
VALUES (1, 'active', NOW(), 0.0, ARRAY[2, 3], '{"role": "primary"}')
ON CONFLICT DO NOTHING;

INSERT INTO cluster_state (node_id, status, last_heartbeat, chronon_synchronization_offset, connected_nodes, metadata)
VALUES (2, 'active', NOW(), 0.1, ARRAY[1, 3], '{"role": "secondary"}')
ON CONFLICT DO NOTHING;

INSERT INTO cluster_state (node_id, status, last_heartbeat, chronon_synchronization_offset, connected_nodes, metadata)
VALUES (3, 'active', NOW(), 0.05, ARRAY[1, 2], '{"role": "secondary"}')
ON CONFLICT DO NOTHING;

-- Print completion message
DO $$
BEGIN
    RAISE NOTICE 'TimeKeeper OS database initialization completed successfully';
    RAISE NOTICE 'Schema: timekeeper';
    RAISE NOTICE 'Tables: 15';
    RAISE NOTICE 'Indexes: 15';
    RAISE NOTICE 'Functions: 4';
    RAISE NOTICE 'Views: 1';
    RAISE NOTICE 'Triggers: 3';
END $$;