"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import DateUtils from "@/lib/date-utils";
import { useDateSync, useTimeDifference } from "@/hooks/useDateSync";

interface SyncDemo {
  id: string;
  name: string;
  type: "node" | "upload" | "system";
  lastSync: string;
  status: "synced" | "pending" | "error";
  coherence: number;
}

export default function TimeKeeperOSDemo() {
  const [activeTab, setActiveTab] = useState("overview");
  const [syncDemos, setSyncDemos] = useState<SyncDemo[]>([]);
  const [testDate, setTestDate] = useState("");
  const [formatResult, setFormatResult] = useState("");
  const [validationResult, setValidationResult] = useState("");
  const [timeDiffResult, setTimeDiffResult] = useState("");
  const [aurumGridTimestamp, setAurumGridTimestamp] = useState("");
  
  // Date synchronization hook
  const { 
    syncStatus, 
    nodesNeedingSync, 
    uploadsNeedingSync, 
    isSyncing,
    performManualSync,
    startSync,
    stopSync
  } = useDateSync({ 
    interval: 30000, // 30 seconds
    autoSync: true 
  });

  // Initialize demo data
  useEffect(() => {
    const now = DateUtils.now();
    const oneMinuteAgo = DateUtils.addTime(now, -1, 'minutes');
    const fiveMinutesAgo = DateUtils.addTime(now, -5, 'minutes');
    const tenMinutesAgo = DateUtils.addTime(now, -10, 'minutes');
    
    setSyncDemos([
      {
        id: "1",
        name: "Primary Harmonic Node",
        type: "node",
        lastSync: oneMinuteAgo,
        status: "synced",
        coherence: 0.96
      },
      {
        id: "2",
        name: "Quantum Processing Node",
        type: "node",
        lastSync: fiveMinutesAgo,
        status: "pending",
        coherence: 0.91
      },
      {
        id: "3",
        name: "Symbolic Sequence Upload",
        type: "upload",
        lastSync: tenMinutesAgo,
        status: "pending",
        coherence: 0.88
      },
      {
        id: "4",
        name: "System Clock",
        type: "system",
        lastSync: now,
        status: "synced",
        coherence: 1.0
      }
    ]);

    setTestDate(now);
    setAurumGridTimestamp(DateUtils.formatForAurumGrid(new Date()));
  }, []);

  const handleFormatDate = () => {
    if (!testDate) return;
    
    try {
      const parsed = DateUtils.parse(testDate);
      const formatted = DateUtils.formatDisplay(parsed);
      const dbFormat = DateUtils.formatForDB(parsed);
      const apiFormat = DateUtils.formatForAPI(parsed);
      
      setFormatResult(`
Display: ${formatted}
Database: ${dbFormat}
API: ${apiFormat}
Aurum Grid: ${DateUtils.formatForAurumGrid(parsed)}
      `.trim());
    } catch (error) {
      setFormatResult(`Error: ${error.message}`);
    }
  };

  const handleValidateDate = () => {
    if (!testDate) return;
    
    const isValid = DateUtils.isValid(testDate);
    const needsSync = DateUtils.needsSync(testDate, 5);
    const isRecent = DateUtils.isRecent(testDate, 24);
    
    setValidationResult(`
Valid: ${isValid}
Needs Sync (5min): ${needsSync}
Recent (24h): ${isRecent}
    `.trim());
  };

  const handleTimeDifference = () => {
    if (!testDate) return;
    
    try {
      const parsed = DateUtils.parse(testDate);
      const diff = DateUtils.timeDifference(parsed, new Date());
      
      setTimeDiffResult(`
Milliseconds: ${diff.milliseconds}
Seconds: ${diff.seconds}
Minutes: ${diff.minutes}
Hours: ${diff.hours}
Days: ${diff.days}
Human Readable: ${diff.humanReadable}
      `.trim());
    } catch (error) {
      setTimeDiffResult(`Error: ${error.message}`);
    }
  };

  const generateAurumGridTimestamp = () => {
    const timestamp = DateUtils.formatForAurumGrid(new Date());
    setAurumGridTimestamp(timestamp);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "synced": return "default";
      case "pending": return "secondary";
      case "error": return "destructive";
      default: return "default";
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "node": return "outline";
      case "upload": return "secondary";
      case "system": return "default";
      default: return "default";
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">TimeKeeper OS Date Synchronization System</h1>
        <p className="text-muted-foreground mb-4">
          Comprehensive date synchronization for harmonic nodes, quantum data processing, and multidimensional operations
        </p>
        
        {/* Sync Status Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Sync Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${syncStatus.success ? 'bg-green-500' : 'bg-red-500'}`}></div>
                <span className="text-2xl font-bold">{syncStatus.success ? 'Active' : 'Error'}</span>
              </div>
              <p className="text-xs text-muted-foreground">
                {isSyncing ? 'Syncing...' : 'System operational'}
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Nodes Needing Sync</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{nodesNeedingSync.length}</div>
              <p className="text-xs text-muted-foreground">
                {nodesNeedingSync.length === 0 ? 'All nodes synced' : 'Action required'}
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Uploads Needing Sync</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{uploadsNeedingSync.length}</div>
              <p className="text-xs text-muted-foreground">
                {uploadsNeedingSync.length === 0 ? 'All uploads synced' : 'Pending sync'}
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Last Sync</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-lg font-semibold">
                {DateUtils.formatDisplay(syncStatus.lastSync, { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </div>
              <p className="text-xs text-muted-foreground">
                Next: {DateUtils.formatDisplay(syncStatus.nextSync, { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Manual Sync Controls */}
        <div className="flex items-center gap-4 mb-6">
          <Button 
            onClick={performManualSync}
            disabled={isSyncing}
            variant="outline"
          >
            {isSyncing ? 'Syncing...' : 'Manual Sync'}
          </Button>
          <Button 
            onClick={startSync}
            variant="outline"
            size="sm"
          >
            Start Auto Sync
          </Button>
          <Button 
            onClick={stopSync}
            variant="outline"
            size="sm"
          >
            Stop Auto Sync
          </Button>
          {syncStatus.error && (
            <Alert className="flex-1">
              <AlertDescription>{syncStatus.error}</AlertDescription>
            </Alert>
          )}
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="demo">Live Demo</TabsTrigger>
          <TabsTrigger value="aurum-grid">Aurum Grid</TabsTrigger>
          <TabsTrigger value="api">API Examples</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>System Architecture</CardTitle>
                <CardDescription>
                  TimeKeeper OS date synchronization components
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                    <div>
                      <div className="font-medium">DateUtils</div>
                      <div className="text-sm text-muted-foreground">
                        Centralized date handling and formatting
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <div>
                      <div className="font-medium">DateSyncService</div>
                      <div className="text-sm text-muted-foreground">
                        Real-time synchronization service
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                    <div>
                      <div className="font-medium">useDateSync Hook</div>
                      <div className="text-sm text-muted-foreground">
                        React integration for components
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                    <div>
                      <div className="font-medium">Aurum Grid Integration</div>
                      <div className="text-sm text-muted-foreground">
                        High-precision timestamp support
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Key Features</CardTitle>
                <CardDescription>
                  Comprehensive date synchronization capabilities
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <div>
                      <div className="font-medium">Multiple Format Support</div>
                      <div className="text-sm text-muted-foreground">
                        ISO, Local, UTC, Timestamp formats
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                    <div>
                      <div className="font-medium">Real-time Synchronization</div>
                      <div className="text-sm text-muted-foreground">
                        Automatic sync with configurable intervals
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                    <div>
                      <div className="font-medium">High Precision</div>
                      <div className="text-sm text-muted-foreground">
                        Microsecond precision for Aurum Grid
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                    <div>
                      <div className="font-medium">Error Handling</div>
                      <div className="text-sm text-muted-foreground">
                        Comprehensive error recovery and retry logic
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Live Synchronization Status</CardTitle>
              <CardDescription>
                Real-time status of harmonic nodes and uploads
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {syncDemos.map((demo) => (
                  <div key={demo.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Badge variant={getTypeColor(demo.type)}>
                        {demo.type}
                      </Badge>
                      <div>
                        <div className="font-medium">{demo.name}</div>
                        <div className="text-sm text-muted-foreground">
                          Last sync: {DateUtils.formatDisplay(demo.lastSync)}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <div className="text-sm font-medium">Coherence</div>
                        <div className="text-lg font-bold">{(demo.coherence * 100).toFixed(1)}%</div>
                      </div>
                      <Badge variant={getStatusColor(demo.status)}>
                        {demo.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="demo" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Date Utilities Demo</CardTitle>
                <CardDescription>
                  Test DateUtils functionality
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="testDate">Test Date</Label>
                  <Input
                    id="testDate"
                    value={testDate}
                    onChange={(e) => setTestDate(e.target.value)}
                    placeholder="Enter date (ISO format or timestamp)"
                  />
                </div>
                
                <div className="flex gap-2">
                  <Button onClick={handleFormatDate} size="sm">
                    Format
                  </Button>
                  <Button onClick={handleValidateDate} size="sm">
                    Validate
                  </Button>
                  <Button onClick={handleTimeDifference} size="sm">
                    Time Diff
                  </Button>
                </div>
                
                {formatResult && (
                  <div className="p-3 bg-muted rounded-md">
                    <pre className="text-sm whitespace-pre-wrap">{formatResult}</pre>
                  </div>
                )}
                
                {validationResult && (
                  <div className="p-3 bg-muted rounded-md">
                    <pre className="text-sm whitespace-pre-wrap">{validationResult}</pre>
                  </div>
                )}
                
                {timeDiffResult && (
                  <div className="p-3 bg-muted rounded-md">
                    <pre className="text-sm whitespace-pre-wrap">{timeDiffResult}</pre>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Aurum Grid Timestamps</CardTitle>
                <CardDescription>
                  High-precision timestamps for quantum operations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Current Aurum Grid Timestamp</Label>
                  <div className="p-3 bg-muted rounded-md font-mono text-sm">
                    {aurumGridTimestamp}
                  </div>
                </div>
                
                <Button onClick={generateAurumGridTimestamp} className="w-full">
                  Generate New Timestamp
                </Button>
                
                <div className="space-y-2">
                  <Label>System Information</Label>
                  <div className="space-y-1 text-sm">
                    <div>Timezone: {Intl.DateTimeFormat().resolvedOptions().timeZone}</div>
                    <div>Locale: {navigator.language}</div>
                    <div>Sync Precision: Microseconds</div>
                    <div>Aurum Grid Format: High Precision</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Live Sync Status</CardTitle>
              <CardDescription>
                Real-time synchronization monitoring
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-3">Nodes Requiring Sync</h4>
                  {nodesNeedingSync.length > 0 ? (
                    <div className="space-y-2">
                      {nodesNeedingSync.slice(0, 3).map((node) => (
                        <div key={node.id} className="flex items-center justify-between p-2 bg-muted rounded">
                          <span className="text-sm">{node.id}</span>
                          <Badge variant="outline">Coherence: {(node.coherence * 100).toFixed(1)}%</Badge>
                        </div>
                      ))}
                      {nodesNeedingSync.length > 3 && (
                        <div className="text-sm text-muted-foreground">
                          +{nodesNeedingSync.length - 3} more nodes
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-sm text-muted-foreground">All nodes synchronized</div>
                  )}
                </div>
                
                <div>
                  <h4 className="font-medium mb-3">Uploads Requiring Sync</h4>
                  {uploadsNeedingSync.length > 0 ? (
                    <div className="space-y-2">
                      {uploadsNeedingSync.slice(0, 3).map((upload) => (
                        <div key={upload.id} className="flex items-center justify-between p-2 bg-muted rounded">
                          <span className="text-sm">{upload.id}</span>
                          <Badge variant="outline">Status: {upload.status}</Badge>
                        </div>
                      ))}
                      {uploadsNeedingSync.length > 3 && (
                        <div className="text-sm text-muted-foreground">
                          +{uploadsNeedingSync.length - 3} more uploads
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-sm text-muted-foreground">All uploads synchronized</div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="aurum-grid" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Aurum Grid Integration</CardTitle>
                <CardDescription>
                  Specialized date handling for quantum operations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <div className="font-medium">High Precision Timestamps</div>
                    <div className="text-sm text-muted-foreground">
                      Microsecond precision for quantum data synchronization
                    </div>
                  </div>
                  
                  <div>
                    <div className="font-medium">Harmonic Node Sync</div>
                    <div className="text-sm text-muted-foreground">
                      Coherence-based synchronization for harmonic nodes
                    </div>
                  </div>
                  
                  <div>
                    <div className="font-medium">Quantum Data Processing</div>
                    <div className="text-sm text-muted-foreground">
                      Timestamp coordination for quantum entanglement data
                    </div>
                  </div>
                  
                  <div>
                    <div className="font-medium">Multidimensional Operations</div>
                    <div className="text-sm text-muted-foreground">
                      Cross-dimensional timestamp synchronization
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Coherence Metrics</CardTitle>
                <CardDescription>
                  Synchronization quality measurements
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">System Coherence</span>
                      <span className="text-sm font-medium">98.5%</span>
                    </div>
                    <Progress value={98.5} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Node Sync Rate</span>
                      <span className="text-sm font-medium">96.2%</span>
                    </div>
                    <Progress value={96.2} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Upload Success</span>
                      <span className="text-sm font-medium">94.8%</span>
                    </div>
                    <Progress value={94.8} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Timestamp Accuracy</span>
                      <span className="text-sm font-medium">99.9%</span>
                    </div>
                    <Progress value={99.9} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Aurum Grid Operations</CardTitle>
              <CardDescription>
                Real-time quantum data processing synchronization
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg">
                  <div className="font-medium mb-2">Symbolic Sequences</div>
                  <div className="text-sm text-muted-foreground mb-2">
                    Glyphic pattern synchronization
                  </div>
                  <Badge variant="outline">Active</Badge>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <div className="font-medium mb-2">Quantum Entanglement</div>
                  <div className="text-sm text-muted-foreground mb-2">
                    Spacetime coordinate sync
                  </div>
                  <Badge variant="outline">Active</Badge>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <div className="font-medium mb-2">Biometric Integration</div>
                  <div className="text-sm text-muted-foreground mb-2">
                    EEG biosync coordination
                  </div>
                  <Badge variant="outline">Active</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api" className="mt-6">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>API Integration Examples</CardTitle>
                <CardDescription>
                  Using DateUtils in API endpoints
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="font-medium mb-2">Upload API</div>
                    <pre className="bg-muted p-3 rounded text-sm overflow-x-auto">
{`// Generate synchronized timestamp
const timestamp = DateUtils.generateSyncTimestamp();

// Store upload record
const upload = await db.aurumUpload.create({
  data: {
    id: uploadId,
    timestamp,
    // ... other fields
  }
});

// Format for Aurum Grid
const aurumTimestamp = DateUtils.formatForAurumGrid(new Date());`}
                    </pre>
                  </div>
                  
                  <div>
                    <div className="font-medium mb-2">Node Synchronization</div>
                    <pre className="bg-muted p-3 rounded text-sm overflow-x-auto">
{`// Check if node needs sync
const needsSync = DateUtils.needsSync(node.lastSync, 5);

// Update sync timestamp
await db.harmonicNode.update({
  where: { id: nodeId },
  data: {
    lastSync: DateUtils.generateSyncTimestamp(),
    status: 'ACTIVE'
  }
});`}
                    </pre>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Frontend Integration</CardTitle>
                <CardDescription>
                  Using useDateSync hook in React components
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="font-medium mb-2">Component Integration</div>
                    <pre className="bg-muted p-3 rounded text-sm overflow-x-auto">
{`const { 
  syncStatus, 
  nodesNeedingSync, 
  uploadsNeedingSync, 
  isSyncing,
  performManualSync 
} = useDateSync({ 
  interval: 30000,
  autoSync: true 
});

// Manual sync button
<Button onClick={performManualSync} disabled={isSyncing}>
  {isSyncing ? 'Syncing...' : 'Sync Now'}
</Button>

// Display sync status
<div className="flex items-center gap-2">
  <div className={\`w-2 h-2 rounded-full \${syncStatus.success ? 'bg-green-500' : 'bg-red-500'}\`}></div>
  <span>{syncStatus.success ? 'Active' : 'Error'}</span>
</div>`}
                    </pre>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Configuration Options</CardTitle>
                <CardDescription>
                  Customizing date synchronization behavior
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <div className="font-medium mb-2">DateUtils Configuration</div>
                    <pre className="bg-muted p-3 rounded text-sm overflow-x-auto">
{`DateUtils.initialize({
  timezone: 'UTC',
  format: 'ISO',
  locale: 'en-US'
}, {
  includeTime: true,
  includeTimezone: true,
  precision: 'milliseconds'
});`}
                    </pre>
                  </div>
                  
                  <div>
                    <div className="font-medium mb-2">Sync Service Configuration</div>
                    <pre className="bg-muted p-3 rounded text-sm overflow-x-auto">
{`const syncService = new DateSyncService({
  interval: 60000,    // 1 minute
  autoSync: true,
  maxRetries: 3,
  retryDelay: 5000   // 5 seconds
});`}
                    </pre>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}