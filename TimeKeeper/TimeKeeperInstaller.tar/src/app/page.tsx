"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CodeBlock } from "@/components/ui/code-block";

export default function InstallationFilesGuide() {
  const [activeTab, setActiveTab] = useState("msi");

  const msiContent = `# MSI (Microsoft Installer) Files Guide

## Overview
MSI (Microsoft Installer) is a file format used by Windows for the installation, storage, and removal of programs. It was introduced with Windows 2000 and has become the standard for Windows application installation.

## Key Features
- **Database Structure**: MSI files are actually databases that contain installation instructions
- **Transaction-based**: Supports rollback if installation fails
- **Self-healing**: Can repair corrupted installations
- **Advertisement**: Can install features on-demand
- **Patch Management**: Supports updates and patches
- **User Interface**: Customizable installation wizard

## MSI File Structure
\`\`\`
MSI Database Tables:
├── Component Table (defines installation components)
├── Feature Table (groups components into features)
├── File Table (lists all files to be installed)
├── Directory Table (defines directory structure)
├── Registry Table (registry entries)
├── CustomAction Table (custom installation actions)
├── Property Table (installation properties)
└── Summary Information (package metadata)
\`\`\`

## Common MSI Properties
- **ProductName**: Name of the application
- **ProductVersion**: Version number
- **Manufacturer**: Company name
- **INSTALLDIR**: Installation directory
- **ALLUSERS**: Per-machine or per-user installation
- **REBOOT**: Reboot behavior after installation

## Installation Commands
\`\`\`bash
# Basic installation
msiexec /i "package.msi"

# Silent installation
msiexec /i "package.msi" /quiet

# Passive installation (shows progress but no UI)
msiexec /i "package.msi" /passive

# Installation with log
msiexec /i "package.msi" /l*vx "install.log"

# Uninstallation
msiexec /x "package.msi"

# Repair installation
msiexec /f "package.msi"
\`\`\`

## MSI Command Line Switches
- **/i**: Install package
- **/x**: Uninstall package
- **/f**: Repair package
- **/a**: Administrative installation
- **/j**: Advertise package
- **/quiet**: Silent mode
- **/passive**: Unattended mode
- **/norestart**: Prevent restart
- **/promptrestart**: Prompt before restart
- **/forcerestart**: Always restart after installation

## Creating MSI Files
Tools for creating MSI installers:
1. **WiX Toolset**: Open-source toolset
2. **InstallShield**: Commercial solution
3. **Advanced Installer**: User-friendly GUI tool
4. **Visual Studio Installer Projects**: Built-in VS extension

## Best Practices
- Use digital signatures for security
- Test installations on clean systems
- Include uninstall functionality
- Support both per-user and per-machine installations
- Provide clear error messages
- Test rollback scenarios
- Include repair functionality`;

  const apkContent = `# APK (Android Package) Files Guide

## Overview
APK (Android Package Kit) is the file format used by the Android operating system for distribution and installation of mobile apps. It contains all the necessary components for an Android application.

## Key Features
- **Package Format**: ZIP-based archive format
- **Self-contained**: Contains all app resources and code
- **Signed**: Must be digitally signed for security
- **Compressed**: Optimized for mobile distribution
- **Multi-architecture**: Supports different device architectures
- **Resource Management**: Efficient resource handling for different devices

## APK File Structure
\`\`\`
APK Contents:
├── AndroidManifest.xml (app metadata and permissions)
├── classes.dex (compiled application code)
├── resources.arsc (compiled resources)
├── lib/ (native libraries)
│   ├── armeabi-v7a/
│   ├── arm64-v8a/
│   ├── x86/
│   └── x86_64/
├── res/ (app resources)
│   ├── drawable/
│   ├── layout/
│   ├── mipmap/
│   └── values/
├── META-INF/
│   ├── MANIFEST.MF
│   ├── CERT.SF
│   └── CERT.RSA
└── assets/ (raw assets)
\`\`\`

## AndroidManifest.xml Components
\`\`\`xml
<manifest package="com.example.app">
    <uses-permission android:name="android.permission.INTERNET" />
    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name">
        <activity android:name=".MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
\`\`\`

## APK Installation Methods
\`\`\`bash
# ADB installation (development)
adb install app.apk

# ADB installation with replacement
adb install -r app.apk

# ADB installation with grant permissions
adb install -g app.apk

# ADB uninstallation
adb uninstall com.example.app

# Check installed packages
adb shell pm list packages

# Install from device storage
adb shell pm install /sdcard/Download/app.apk
\`\`\`

## APK Signing
\`\`\`bash
# Generate keystore
keytool -genkey -v -keystore my-release-key.keystore \
  -alias my-alias -keyalg RSA -keysize 2048 -validity 10000

# Sign APK
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 \
  -keystore my-release-key.keystore app.apk my-alias

# Verify signature
jarsigner -verify -verbose -certs app.apk

# Optimize APK after signing
zipalign -v 4 app.apk app-aligned.apk
\`\`\`

## APK Build Process
1. **Compile Java/Kotlin code** → .class files
2. **Convert to DEX** → classes.dex
3. **Package resources** → resources.arsc
4. **Compile XML files** → binary XML
5. **Create unsigned APK** → app-unsigned.apk
6. **Sign APK** → app-signed.apk
7. **Align APK** → app-release.apk

## APK Analysis Tools
- **aapt**: Android Asset Packaging Tool
- **apktool**: Reverse engineering tool
- **jadx**: Dex to Java decompiler
- **dex2jar**: Convert DEX to JAR
- **jarsigner**: Sign and verify JAR files

## Security Considerations
- Always sign APKs with trusted certificates
- Use ProGuard/R8 for code obfuscation
- Implement proper permission requests
- Use Android App Bundle for reduced APK size
- Regular security updates
- Code signing best practices`;

  const comparisonContent = `# MSI vs APK Comparison

## Fundamental Differences

| Aspect | MSI (Windows) | APK (Android) |
|--------|---------------|---------------|
| **Platform** | Windows OS | Android OS |
| **File Format** | Database format | ZIP-based archive |
| **Signing** | Optional but recommended | Mandatory |
| **Structure** | Relational database tables | File system hierarchy |
| **Installation** | System-wide or user-specific | App-specific sandbox |
| **Permissions** | Windows UAC | Android permission system |

## Technical Comparison

### Installation Process
**MSI Installation:**
1. Read installation database
2. Check system requirements
3. Execute installation sequence
4. Write files and registry entries
5. Create shortcuts and services
6. Register components

**APK Installation:**
1. Verify digital signature
2. Extract package contents
3. Install to app sandbox
4. Grant requested permissions
5. Create app data directories
6. Register with system

### Security Models
**MSI Security:**
- Windows Installer service
- User Account Control (UAC)
- Digital signatures (optional)
- System integrity checks

**APK Security:**
- Mandatory code signing
- Application sandboxing
- Runtime permission model
- Google Play Protect

### Distribution Methods
**MSI Distribution:**
- Direct download
- Windows Store
- Enterprise deployment
- Group Policy
- SCCM/Intune

**APK Distribution:**
- Google Play Store
- Third-party app stores
- Direct sideloading
- Enterprise MDM
- ADB installation

## Use Case Scenarios

### When to Use MSI
- Desktop applications for Windows
- Enterprise software deployment
- System services and drivers
- Complex installation with dependencies
- Per-machine installations
- Software requiring Windows integration

### When to Use APK
- Mobile applications for Android
- Games and entertainment apps
- Utility applications
- Apps requiring device sensors
- Cross-platform mobile solutions
- Apps with frequent updates

## Development Tools

### MSI Development Tools
- **WiX Toolset**: Open-source, XML-based
- **InstallShield**: Commercial, feature-rich
- **Advanced Installer**: GUI-based, user-friendly
- **Visual Studio Installer**: Integrated with VS

### APK Development Tools
- **Android Studio**: Official IDE
- **Gradle**: Build automation
- **Android SDK**: Development kit
- **Firebase App Distribution**: Testing
- **Google Play Console**: Publishing

## Performance Considerations

### MSI Performance
- Installation time: Varies by complexity
- Disk space: Includes all components
- Memory usage: Moderate during installation
- Startup time: Depends on application

### APK Performance
- Installation time: Generally fast
- Disk space: Optimized for mobile
- Memory usage: Minimal overhead
- Startup time: Optimized for mobile devices

## Future Trends

### MSI Evolution
- MSIX format (modern replacement)
- Windows Package Manager
- Container-based deployments
- Cloud-based installations

### APK Evolution
- Android App Bundle (AAB)
- Instant Apps
- Play Feature Delivery
- Dynamic Feature Modules`;

  const examplesContent = `# Practical Examples

## MSI Example: Basic Installation Script

### WiX Source File Example
\`\`\`xml
<?xml version="1.0" encoding="UTF-8"?>
<Wix xmlns="http://schemas.microsoft.com/wix/2006/wi">
  <Product Id="*" 
           Name="My Application" 
           Language="1033" 
           Version="1.0.0.0" 
           Manufacturer="My Company" 
           UpgradeCode="12345678-1234-1234-1234-123456789012">
    
    <Package InstallerVersion="200" 
             Compressed="yes" 
             InstallScope="perMachine" />
    
    <MajorUpgrade DowngradeErrorMessage="A newer version is already installed." />
    
    <MediaTemplate EmbedCab="yes" />
    
    <Feature Id="ProductFeature" Title="My Application" Level="1">
      <ComponentGroupRef Id="ProductComponents" />
      <ComponentRef Id="ApplicationShortcut" />
    </Feature>
    
    <Directory Id="TARGETDIR" Name="SourceDir">
      <Directory Id="ProgramFilesFolder">
        <Directory Id="INSTALLFOLDER" Name="My Application" />
      </Directory>
      <Directory Id="ProgramMenuFolder">
        <Directory Id="ApplicationProgramsFolder" Name="My Application"/>
      </Directory>
    </Directory>
    
    <ComponentGroup Id="ProductComponents" Directory="INSTALLFOLDER">
      <Component Id="MainExecutable" Guid="*">
        <File Id="MainExecutableFile" 
              Source="$(var.MyApp.TargetPath)" 
              KeyPath="yes" />
      </Component>
    </ComponentGroup>
    
    <DirectoryRef Id="ApplicationProgramsFolder">
      <Component Id="ApplicationShortcut" Guid="*">
        <Shortcut Id="ApplicationStartMenuShortcut"
                  Name="My Application"
                  Description="My Application"
                  Target="[INSTALLFOLDER]MyApp.exe"
                  WorkingDirectory="INSTALLFOLDER"/>
        <RemoveFolder Id="ApplicationProgramsFolder" On="uninstall"/>
        <RegistryValue Root="HKCU" 
                      Key="Software\\Microsoft\\MyApp" 
                      Name="installed" 
                      Type="integer" 
                      Value="1" 
                      KeyPath="yes"/>
      </Component>
    </DirectoryRef>
  </Product>
</Wix>
\`\`\`

### MSI Installation Commands
\`\`\`batch
@echo off
REM Installation script for My Application

echo Installing My Application...

REM Check if running as administrator
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Please run this script as administrator
    pause
    exit /b 1
)

REM Install with logging
msiexec /i "MyApp.msi" /l*vx "install.log" /passive

if %errorLevel% equ 0 (
    echo Installation completed successfully
) else (
    echo Installation failed. Check install.log for details
    pause
    exit /b 1
)

REM Start the application
echo Starting My Application...
start "" "%ProgramFiles%\\My Application\\MyApp.exe"

pause
\`\`\`

## APK Example: Basic Android App

### AndroidManifest.xml
\`\`\`xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.myapp">
    
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    
    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:theme="@style/AppTheme">
        
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        
    </application>
</manifest>
\`\`\`

### build.gradle
\`\`\`groovy
plugins {
    id 'com.android.application'
}

android {
    compileSdk 34
    
    defaultConfig {
        applicationId "com.example.myapp"
        minSdk 21
        targetSdk 34
        versionCode 1
        versionName "1.0"
        
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }
    
    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.9.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.1.5'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'
}
\`\`\`

### APK Build and Sign Script
\`\`\`bash
#!/bin/bash

# APK Build and Sign Script

echo "Building APK..."

# Clean previous builds
./gradlew clean

# Build debug APK
./gradlew assembleDebug

if [ $? -eq 0 ]; then
    echo "Debug APK built successfully"
    echo "Location: app/build/outputs/apk/debug/app-debug.apk"
else
    echo "Build failed"
    exit 1
fi

# Build release APK (requires signing)
echo "Building release APK..."
./gradlew assembleRelease

if [ $? -eq 0 ]; then
    echo "Release APK built successfully"
    echo "Location: app/build/outputs/apk/release/app-release-unsigned.apk"
    
    # Sign the APK (if keystore exists)
    if [ -f "my-release-key.keystore" ]; then
        echo "Signing APK..."
        jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 \
            -keystore my-release-key.keystore \
            app/build/outputs/apk/release/app-release-unsigned.apk \
            my-alias
        
        # Align the APK
        zipalign -v 4 \
            app/build/outputs/apk/release/app-release-unsigned.apk \
            app-release-signed.apk
        
        echo "Signed APK: app-release-signed.apk"
    else
        echo "Warning: No keystore found. APK is unsigned."
    fi
else
    echo "Release build failed"
fi

echo "Build process completed"
\`\`\`

### ADB Installation Script
\`\`\`bash
#!/bin/bash

# ADB Installation Script

APK_FILE="app-release-signed.apk"
PACKAGE_NAME="com.example.myapp"

echo "Checking device connection..."
adb devices

if [ $? -ne 0 ]; then
    echo "No devices found. Please connect a device and enable USB debugging."
    exit 1
fi

echo "Installing $APK_FILE..."

# Uninstall previous version if exists
adb shell pm list packages | grep -q "$PACKAGE_NAME"
if [ $? -eq 0 ]; then
    echo "Uninstalling previous version..."
    adb uninstall "$PACKAGE_NAME"
fi

# Install the APK
adb install -r -g "$APK_FILE"

if [ $? -eq 0 ]; then
    echo "Installation successful!"
    
    # Start the app
    echo "Starting the application..."
    adb shell am start -n "$PACKAGE_NAME/.MainActivity"
else
    echo "Installation failed"
    exit 1
fi
\`\`\``;

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-4">Installation Files Study Guide</h1>
        <p className="text-lg text-muted-foreground">
          Comprehensive guide to MSI (Windows) and APK (Android) installation files
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="msi">MSI Files</TabsTrigger>
          <TabsTrigger value="apk">APK Files</TabsTrigger>
          <TabsTrigger value="comparison">Comparison</TabsTrigger>
          <TabsTrigger value="examples">Examples</TabsTrigger>
        </TabsList>

        <TabsContent value="msi" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Badge variant="secondary">Windows</Badge>
                MSI Installation Files
              </CardTitle>
              <CardDescription>
                Microsoft Installer format for Windows applications
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px] w-full">
                <pre className="whitespace-pre-wrap text-sm">{msiContent}</pre>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="apk" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Badge variant="secondary">Android</Badge>
                APK Installation Files
              </CardTitle>
              <CardDescription>
                Android Package Kit format for mobile applications
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px] w-full">
                <pre className="whitespace-pre-wrap text-sm">{apkContent}</pre>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="comparison" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Badge variant="secondary">Analysis</Badge>
                MSI vs APK Comparison
              </CardTitle>
              <CardDescription>
                Detailed comparison between Windows and Android installation formats
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px] w-full">
                <pre className="whitespace-pre-wrap text-sm">{comparisonContent}</pre>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="examples" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Badge variant="secondary">Code</Badge>
                Practical Examples
              </CardTitle>
              <CardDescription>
                Real-world examples and scripts for both formats
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px] w-full">
                <pre className="whitespace-pre-wrap text-sm">{examplesContent}</pre>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Quick Reference</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div><strong>MSI:</strong> Windows Installer database format</div>
              <div><strong>APK:</strong> Android Package ZIP archive</div>
              <div><strong>Signing:</strong> Optional for MSI, mandatory for APK</div>
              <div><strong>Security:</strong> UAC vs Android sandbox</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Key Tools</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div><strong>MSI:</strong> WiX, InstallShield, Advanced Installer</div>
              <div><strong>APK:</strong> Android Studio, ADB, Gradle</div>
              <div><strong>Analysis:</strong> Orca, apktool, jadx</div>
              <div><strong>Signing:</strong> signtool, jarsigner</div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}