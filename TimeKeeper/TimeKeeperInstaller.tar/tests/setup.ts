// Test setup for TimeKeeper OS tests
import { jest } from '@jest/globals';

// Mock console methods to reduce noise during tests
global.console = {
  ...console,
  log: jest.fn(),
  debug: jest.fn(),
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
};

// Set test environment variables
process.env.NODE_ENV = 'test';
process.env.TIMEKEEPER_TEST_MODE = 'true';

// Mock database connection for tests
jest.mock('@/lib/db', () => ({
  db: {
    // Mock database methods here
    select: jest.fn(),
    insert: jest.fn(),
    update: jest.fn(),
    delete: jest.fn(),
    query: jest.fn(),
  },
}));

// Mock TimeChain kernel for isolated testing
jest.mock('@/kernel/timechain_kernel', () => ({
  TimeChainKernel: jest.fn().mockImplementation(() => ({
    initialize: jest.fn().mockResolvedValue(true),
    getCurrentChronon: jest.fn().mockReturnValue(1000),
    validateVDF: jest.fn().mockResolvedValue(true),
    scheduleOperation: jest.fn().mockResolvedValue('op-123'),
  })),
}));

// Global test utilities
global.createMockChronon = (offset = 0) => ({
  id: `chronon-${1000 + offset}`,
  timestamp: Date.now() + offset * 1000,
  hash: `0x${Math.random().toString(16).substring(2)}`,
  previousHash: `0x${Math.random().toString(16).substring(2)}`,
  nonce: Math.floor(Math.random() * 1000000),
  operations: [],
});

global.createMockTemporalProcess = (id = 'test-process') => ({
  id,
  name: `Test Process ${id}`,
  state: 'running',
  chrononCreated: 1000,
  chrononModified: 1005,
  dependencies: [],
  resources: {
    memory: 1024 * 1024, // 1MB
    cpu: 0.1,
  },
});

global.createMockTemporalFile = (path = '/test/file.txt') => ({
  path,
  content: 'Test file content',
  chrononCreated: 1000,
  chrononModified: 1005,
  versions: [
    {
      chronon: 1000,
      content: 'Original content',
      hash: 'hash1',
    },
    {
      chronon: 1005,
      content: 'Test file content',
      hash: 'hash2',
    },
  ],
});

// Test timeout for async operations
jest.setTimeout(30000);