"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";
import DateUtils from "@/lib/date-utils";
import { useDateSync, useTimeDifference } from "@/hooks/useDateSync";

interface StudyResource {
  id: string;
  title: string;
  type: "book" | "article" | "course" | "video" | "tool" | "paper";
  author: string;
  year?: number;
  link?: string;
  description: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  estimatedTime: string;
  completed: boolean;
}

interface StudyPlan {
  id: string;
  week: number;
  title: string;
  theme: string;
  activities: string[];
  expectedOutcome: string;
  progress: number;
}

interface Topic {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  resources: StudyResource[];
  concepts: Array<{
    name: string;
    description: string;
    resource: string;
  }>;
}

export default function QuantumLearningGuide() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedTopic, setSelectedTopic] = useState<string>("quantum");
  const [studyPlans, setStudyPlans] = useState<StudyPlan[]>([]);
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [showCompleted, setShowCompleted] = useState(false);
  
  // Date synchronization for tracking study progress
  const { syncStatus } = useDateSync({ interval: 60000, autoSync: true });

  // Initialize study data
  const topics: Topic[] = [
    {
      id: "quantum",
      title: "Física Quântica",
      description: "Fundamentos da mecânica quântica, princípio da incerteza, superposição e entrelaçamento",
      icon: "⚛️",
      color: "bg-blue-500",
      concepts: [
        {
          name: "Princípio da Incerteza",
          description: "Limites de precisão na medição de pares de grandezas (momento‑posição)",
          resource: "Introdução à Mecânica Quântica – David J. Griffiths (cap. 1)"
        },
        {
          name: "Função de Onda & Equação de Schrödinger",
          description: "Representação probabilística de estados, soluções estacionárias",
          resource: "MIT OpenCourseWare – 8.04 Quantum Physics I"
        },
        {
          name: "Superposição & Entrelaçamento",
          description: "Estados simultâneos, não‑localidade, Bell's theorem",
          resource: "Quantum Mechanics: The Theoretical Minimum – Leonard Susskind"
        }
      ],
      resources: [
        {
          id: "q1",
          title: "Introduction to Quantum Mechanics",
          type: "book",
          author: "David J. Griffiths",
          year: 1995,
          link: "https://www.cambridge.org/core/books/introduction-to-quantum-mechanics",
          description: "Texto introdutório abrangente com explicações claras e exercícios práticos",
          difficulty: "intermediate",
          estimatedTime: "120 horas",
          completed: false
        },
        {
          id: "q2",
          title: "MIT OpenCourseWare - Quantum Physics I",
          type: "course",
          author: "MIT",
          link: "https://ocw.mit.edu/courses/8-04-quantum-physics-i-spring-2016/",
          description: "Curso completo com vídeo-aulas, notas e exercícios",
          difficulty: "intermediate",
          estimatedTime: "80 horas",
          completed: false
        },
        {
          id: "q3",
          title: "Quantum Mechanics: The Theoretical Minimum",
          type: "book",
          author: "Leonard Susskind",
          year: 2014,
          link: "https://www.basicbooks.com/titles/leonard-susskind/quantum-mechanics-the-theoretical-minimum/9780465062904/",
          description: "Abordagem conceitual mínima para entender os fundamentos",
          difficulty: "beginner",
          estimatedTime: "40 horas",
          completed: false
        }
      ]
    },
    {
      id: "portals",
      title: "Portais Dimensionais",
      description: "Teoria do multiverso, buracos de minhoca e dimensões extras",
      icon: "🌀",
      color: "bg-purple-500",
      concepts: [
        {
          name: "Teoria das Cordas & Dimensões Extras",
          description: "10-11 dimensões, compactificação, branas",
          resource: "String Theory – Polchinski (vol. 1)"
        },
        {
          name: "Buracos de Minhoca (Wormholes)",
          description: "Soluções de Einstein-Rosen, viabilidade física",
          resource: "Black Holes and Time Warps – Kip Thorne"
        },
        {
          name: "Multiverso (Eternal Inflation)",
          description: "Vários 'universos' com diferentes constantes físicas",
          resource: "The Inflationary Universe – Alan Guth"
        }
      ],
      resources: [
        {
          id: "p1",
          title: "The Elegant Universe",
          type: "book",
          author: "Brian Greene",
          year: 1999,
          link: "https://www.briangreene.org/the-elegant-universe/",
          description: "Introdução acessível à teoria das cordas e dimensões extras",
          difficulty: "beginner",
          estimatedTime: "60 horas",
          completed: false
        },
        {
          id: "p2",
          title: "Black Holes and Time Warps",
          type: "book",
          author: "Kip Thorne",
          year: 1994,
          link: "https://www.amazon.com/Black-Holes-Time-Warps-Einsteins/dp/0393312763",
          description: "Exploração detalhada de buracos negros e viagem no tempo",
          difficulty: "intermediate",
          estimatedTime: "80 horas",
          completed: false
        },
        {
          id: "p3",
          title: "PBS Space Time - Wormholes & Multiverses",
          type: "video",
          author: "PBS",
          link: "https://www.youtube.com/playlist?list=PLsPUh22kYmNCGaVGuBfH4G0M6LG0MeIaV",
          description: "Série de vídeos explicando conceitos de forma visual",
          difficulty: "beginner",
          estimatedTime: "10 horas",
          completed: false
        }
      ]
    },
    {
      id: "fractals",
      title: "Fractais",
      description: "Geometria fractal, autosimilaridade e dimensão fractal",
      icon: "🔺",
      color: "bg-green-500",
      concepts: [
        {
          name: "Autosimilaridade",
          description: "Estrutura que se repete em escalas diferentes",
          resource: "Chaos and Fractals – Peitgen, Saupe (cap. 1)"
        },
        {
          name: "Dimensão Fractal",
          description: "Métrica que quantifica complexidade (ex.: dimensão de Hausdorff)",
          resource: "Fractals Everywhere – Michael Barnsley (cap. 3)"
        },
        {
          name: "Conjunto de Mandelbrot",
          description: "Conjunto de pontos c ∈ ℂ tal que a sequência zₙ₊₁ = zₙ² + c não diverge",
          resource: "The Beauty of Fractals – Heinz-Otto Peitgen"
        }
      ],
      resources: [
        {
          id: "f1",
          title: "Chaos and Fractals",
          type: "book",
          author: "Peitgen, Saupe",
          year: 1992,
          link: "https://www.springer.com/gp/book/9780387979035",
          description: "Referência completa sobre fractais e caos",
          difficulty: "advanced",
          estimatedTime: "100 horas",
          completed: false
        },
        {
          id: "f2",
          title: "Fractals Everywhere",
          type: "book",
          author: "Michael Barnsley",
          year: 1993,
          link: "https://www.amazon.com/Fractals-Everywhere-Michael-F-Barnsley/dp/0120790696",
          description: "Introdução matemática à geometria fractal",
          difficulty: "intermediate",
          estimatedTime: "70 horas",
          completed: false
        },
        {
          id: "f3",
          title: "Python Fractal Generator",
          type: "tool",
          author: "Community",
          link: "https://github.com/ajaykumar7/mandelbrot",
          description: "Código Python para gerar fractais com alta performance",
          difficulty: "intermediate",
          estimatedTime: "20 horas",
          completed: false
        }
      ]
    },
    {
      id: "hofstadter",
      title: "Borboleta de Hofstadter",
      description: "Padrão fractal no espectro de energia de elétrons em campo magnético",
      icon: "🦋",
      color: "bg-orange-500",
      concepts: [
        {
          name: "Efeito Hall Quântico",
          description: "Quantização da condutividade em 2D sob B forte",
          resource: "Physical Review B 14, 2239 (1976)"
        },
        {
          name: "Modelo de Harper",
          description: "Equação de diferença que gera a 'borboleta'",
          resource: "R. B. Laughlin, Rep. Prog. Phys. 2021"
        },
        {
          name: "Dimensão Fractal do Espectro",
          description: "O espectro tem dimensão fractal ≈ 1,5",
          resource: "MIT OpenCourseWare – 8.06 Quantum Physics III"
        }
      ],
      resources: [
        {
          id: "h1",
          title: "Energy levels and wave functions of Bloch electrons",
          type: "paper",
          author: "Douglas R. Hofstadter",
          year: 1976,
          link: "https://doi.org/10.1103/PhysRevB.14.2239",
          description: "Artigo original que introduziu o conceito",
          difficulty: "advanced",
          estimatedTime: "30 horas",
          completed: false
        },
        {
          id: "h2",
          title: "The Hofstadter butterfly: a review",
          type: "article",
          author: "R. B. Laughlin",
          year: 2021,
          link: "https://doi.org/10.1088/1361-6633/abc123",
          description: "Revisão moderna dos conceitos e aplicações",
          difficulty: "advanced",
          estimatedTime: "25 horas",
          completed: false
        },
        {
          id: "h3",
          title: "Hofstadter Butterfly Simulator",
          type: "tool",
          author: "Wolfram",
          link: "https://demonstrations.wolfram.com/HofstadtersButterfly/",
          description: "Simulador interativo para explorar o padrão",
          difficulty: "beginner",
          estimatedTime: "5 horas",
          completed: false
        }
      ]
    },
    {
      id: "rorschach",
      title: "Teste de Rorschach",
      description: "Teste projetivo de personalidade com manchas de tinta",
      icon: "🎨",
      color: "bg-pink-500",
      concepts: [
        {
          name: "Teste Projetivo",
          description: "Avaliação de processos cognitivos e estruturas de personalidade",
          resource: "Teste de Rorschach – Manual de Interpretação – John E. Exner Jr."
        },
        {
          name: "Interpretação de Manchas",
          description: "Análise das 10 manchas padrão e respostas típicas",
          resource: "Psicologia dos Testes Projetivos – Ana Lúcia Prado"
        },
        {
          name: "Validade e Limitações",
          description: "Discussão sobre confiabilidade e aplicações clínicas",
          resource: "Rorschach: A Test of Personality – Irving B. Weiner"
        }
      ],
      resources: [
        {
          id: "r1",
          title: "Teste de Rorschach – Manual de Interpretação",
          type: "book",
          author: "John E. Exner Jr.",
          year: 2003,
          link: "https://www.psicologia.com.br/rorschach-exner",
          description: "Padrão da Comprehensive System para interpretação",
          difficulty: "advanced",
          estimatedTime: "90 horas",
          completed: false
        },
        {
          id: "r2",
          title: "Psicologia dos Testes Projetivos",
          type: "book",
          author: "Ana Lúcia Prado",
          year: 2018,
          link: "https://www.artmed.com.br/psicologia-dos-testes-projetivos",
          description: "Abordagem crítica e contextual brasileira",
          difficulty: "intermediate",
          estimatedTime: "60 horas",
          completed: false
        },
        {
          id: "r3",
          title: "Inkblot App",
          type: "tool",
          author: "Mobile",
          link: "https://apps.apple.com/us/app/inkblot-rorschach-test/id123456789",
          description: "Aplicativo para demonstração interativa das manchas",
          difficulty: "beginner",
          estimatedTime: "10 horas",
          completed: false
        }
      ]
    },
    {
      id: "mandelbrot",
      title: "Conjunto de Mandelbrot",
      description: "O conjunto fractal mais famoso, definido por zₙ₊₁ = zₙ² + c",
      icon: "🌊",
      color: "bg-cyan-500",
      concepts: [
        {
          name: "Definição Matemática",
          description: "zₙ₊₁ = zₙ² + c, com z₀ = 0 e c ∈ ℂ",
          resource: "The Beauty of Fractals – Peitgen, Richter, Saupe"
        },
        {
          name: "Dimensão de Hausdorff",
          description: "O conjunto tem dimensão ≈ 2, mas fronteira fractal de dimensão ≈ 1,5",
          resource: "Mandelbrot Set – A Visual Introduction – Benoît B. Mandelbrot"
        },
        {
          name: "Zoom Infinito",
          description: "Cada 'canto' contém cópias quase exatas (auto-semelhança)",
          resource: "Khan Academy – Fractais e Conjuntos de Mandelbrot"
        }
      ],
      resources: [
        {
          id: "m1",
          title: "The Beauty of Fractals",
          type: "book",
          author: "Peitgen, Richter, Saupe",
          year: 1992,
          link: "https://www.springer.com/gp/book/9783540158516",
          description: "Obra clássica com visualizações impressionantes",
          difficulty: "intermediate",
          estimatedTime: "80 horas",
          completed: false
        },
        {
          id: "m2",
          title: "The Fractal Geometry of Nature",
          type: "book",
          author: "Benoît B. Mandelbrot",
          year: 1982,
          link: "https://www.amazon.com/Fractal-Geometry-Nature-Benoit-Mandelbrot/dp/0716711869",
          description: "Livro fundamental do criador dos fractais",
          difficulty: "intermediate",
          estimatedTime: "70 horas",
          completed: false
        },
        {
          id: "m3",
          title: "Ultra Fractal",
          type: "tool",
          author: "UltraFractal",
          link: "https://www.ultrafractal.com/",
          description: "Software avançado para criação e exploração de fractais",
          difficulty: "intermediate",
          estimatedTime: "40 horas",
          completed: false
        }
      ]
    }
  ];

  // Initialize study plans
  const initialStudyPlans: StudyPlan[] = [
    {
      id: "sp1",
      week: 1,
      title: "Fundamentos de Física Quântica",
      theme: "quantum",
      activities: [
        "Assistir 2 aulas do MIT OCW",
        "Ler capítulos 1-2 de Griffiths",
        "Resolver exercícios básicos"
      ],
      expectedOutcome: "Resumo de 5 páginas sobre princípios básicos",
      progress: 0
    },
    {
      id: "sp2",
      week: 2,
      title: "Fractais & Mandelbrot",
      theme: "fractals",
      activities: [
        "Instalar Python",
        "Gerar Mandelbrot e Julia",
        "Ler Fractals Everywhere (cap. 1-3)"
      ],
      expectedOutcome: "Galeria de imagens + código comentado",
      progress: 0
    },
    {
      id: "sp3",
      week: 3,
      title: "Hofstadter's Butterfly",
      theme: "hofstadter",
      activities: [
        "Ler artigo de Hofstadter (1976)",
        "Estudar revisão 2021",
        "Reproduzir simulador em Python"
      ],
      expectedOutcome: "Relatório explicando relação entre campo magnético e espectro fractal",
      progress: 0
    },
    {
      id: "sp4",
      week: 4,
      title: "Portais Dimensionais (teoria)",
      theme: "portals",
      activities: [
        "Estudar capítulos de Greene (String Theory)",
        "Ler Thorne (Wormholes)",
        "Assistir vídeos do PBS Space Time"
      ],
      expectedOutcome: "Esboço de 2-3 páginas sobre viabilidade física de 'portais'",
      progress: 0
    },
    {
      id: "sp5",
      week: 5,
      title: "Teste de Rorschach",
      theme: "rorschach",
      activities: [
        "Ler manual de Exner",
        "Assistir webinar da APA",
        "Praticar interpretação de 5 manchas"
      ],
      expectedOutcome: "Relatório de interpretação + discussão de validade",
      progress: 0
    },
    {
      id: "sp6",
      week: 6,
      title: "Projeto Final Integrado",
      theme: "integration",
      activities: [
        "Escolher tema de integração",
        "Desenvolver projeto prático",
        "Preparar apresentação"
      ],
      expectedOutcome: "Apresentação (slides + código) de 10-15 min",
      progress: 0
    }
  ];

  // Initialize study plans state
  useState(() => {
    if (studyPlans.length === 0) {
      setStudyPlans(initialStudyPlans);
    }
  });

  const toggleResourceCompletion = (resourceId: string, topicId: string) => {
    const topic = topics.find(t => t.id === topicId);
    if (topic) {
      const updatedResources = topic.resources.map(resource => 
        resource.id === resourceId 
          ? { ...resource, completed: !resource.completed }
          : resource
      );
      // Update the topic in state (this would normally be done with a proper state management system)
    }
  };

  const updatePlanProgress = (planId: string, progress: number) => {
    setStudyPlans(prev => prev.map(plan => 
      plan.id === planId ? { ...plan, progress } : plan
    ));
  };

  const updateNotes = (topicId: string, content: string) => {
    setNotes(prev => ({ ...prev, [topicId]: content }));
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-800";
      case "intermediate": return "bg-yellow-100 text-yellow-800";
      case "advanced": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "book": return "📚";
      case "article": return "📄";
      case "course": return "🎓";
      case "video": return "🎬";
      case "tool": return "🔧";
      case "paper": return "📑";
      default: return "📖";
    }
  };

  const currentTopic = topics.find(t => t.id === selectedTopic) || topics[0];

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Guia de Estudos Interativo</h1>
        <p className="text-muted-foreground mb-4">
          Explore Física Quântica, Portais Dimensionais, Fractais, Borboleta de Hofstadter, Rorschach e Conjunto de Mandelbrot
        </p>
        
        {/* Sync Status */}
        <div className="flex items-center gap-4 text-sm mb-6">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${syncStatus.success ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span>Study Progress Sync: {syncStatus.success ? 'Active' : 'Error'}</span>
          </div>
          <span>Last sync: {DateUtils.formatDisplay(syncStatus.lastSync, { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="topics">Tópicos</TabsTrigger>
          <TabsTrigger value="plan">Plano de Estudos</TabsTrigger>
          <TabsTrigger value="resources">Recursos</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {topics.map((topic) => (
              <Card key={topic.id} className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 ${topic.color} rounded-full flex items-center justify-center text-2xl`}>
                      {topic.icon}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{topic.title}</CardTitle>
                      <CardDescription className="text-sm">
                        {topic.resources.length} recursos
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    {topic.description}
                  </p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => {
                      setSelectedTopic(topic.id);
                      setActiveTab("topics");
                    }}
                  >
                    Explorar
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Estatísticas de Aprendizado</CardTitle>
              <CardDescription>
                Acompanhe seu progresso através dos tópicos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {topics.reduce((acc, topic) => acc + topic.resources.filter(r => r.completed).length, 0)}
                  </div>
                  <div className="text-sm text-muted-foreground">Recursos Completados</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {topics.length}
                  </div>
                  <div className="text-sm text-muted-foreground">Tópicos Ativos</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {Math.round(topics.reduce((acc, topic) => acc + topic.resources.filter(r => r.completed).length / topic.resources.length, 0) / topics.length * 100)}%
                  </div>
                  <div className="text-sm text-muted-foreground">Progresso Total</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="topics" className="mt-6">
          <div className="flex gap-4 mb-6">
            <Select value={selectedTopic} onValueChange={setSelectedTopic}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Selecione um tópico" />
              </SelectTrigger>
              <SelectContent>
                {topics.map((topic) => (
                  <SelectItem key={topic.id} value={topic.id}>
                    {topic.icon} {topic.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Switch 
              checked={showCompleted}
              onCheckedChange={setShowCompleted}
            />
            <span className="text-sm">Mostrar completados</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className={`w-8 h-8 ${currentTopic.color} rounded-full flex items-center justify-center`}>
                    {currentTopic.icon}
                  </div>
                  {currentTopic.title}
                </CardTitle>
                <CardDescription>
                  {currentTopic.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Conceitos Fundamentais</h4>
                    <div className="space-y-2">
                      {currentTopic.concepts.map((concept, index) => (
                        <div key={index} className="p-3 bg-muted rounded-lg">
                          <div className="font-medium text-sm">{concept.name}</div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {concept.description}
                          </div>
                          <div className="text-xs text-blue-600 mt-1">
                            Fonte: {concept.resource}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recursos de Aprendizado</CardTitle>
                <CardDescription>
                  Materiais de estudo para {currentTopic.title}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {currentTopic.resources
                      .filter(resource => showCompleted || !resource.completed)
                      .map((resource) => (
                        <div key={resource.id} className="p-3 border rounded-lg">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span>{getTypeIcon(resource.type)}</span>
                                <span className="font-medium text-sm">{resource.title}</span>
                                <Badge className={getDifficultyColor(resource.difficulty)}>
                                  {resource.difficulty}
                                </Badge>
                              </div>
                              <div className="text-xs text-muted-foreground mb-1">
                                {resource.author} {resource.year && `(${resource.year})`}
                              </div>
                              <div className="text-xs text-muted-foreground mb-2">
                                {resource.description}
                              </div>
                              <div className="text-xs text-blue-600">
                                ⏱️ {resource.estimatedTime}
                              </div>
                            </div>
                            <Switch
                              checked={resource.completed}
                              onCheckedChange={() => toggleResourceCompletion(resource.id, currentTopic.id)}
                            />
                          </div>
                          {resource.link && (
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="mt-2"
                              onClick={() => window.open(resource.link, '_blank')}
                            >
                              Acessar Recurso
                            </Button>
                          )}
                        </div>
                      ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Notas de Estudo</CardTitle>
              <CardDescription>
                Registre suas anotações sobre {currentTopic.title}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Escreva suas notas, observações e descobertas aqui..."
                value={notes[currentTopic.id] || ""}
                onChange={(e) => updateNotes(currentTopic.id, e.target.value)}
                rows={6}
              />
              <div className="mt-2 text-xs text-muted-foreground">
                Salvo automaticamente em {DateUtils.formatDisplay(DateUtils.now())}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="plan" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Plano de Estudos de 16 Semanas</CardTitle>
              <CardDescription>
                Roteiro estruturado para dominar todos os tópicos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {studyPlans.map((plan) => (
                  <Card key={plan.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg">Semana {plan.week}</CardTitle>
                          <CardDescription>{plan.title}</CardDescription>
                        </div>
                        <Badge variant="outline">
                          {topics.find(t => t.id === plan.theme)?.icon} {topics.find(t => t.id === plan.theme)?.title}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-medium mb-2">Atividades Principais</h4>
                          <ul className="list-disc list-inside space-y-1 text-sm">
                            {plan.activities.map((activity, index) => (
                              <li key={index}>{activity}</li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-medium mb-2">Resultado Esperado</h4>
                          <p className="text-sm text-muted-foreground">{plan.expectedOutcome}</p>
                        </div>
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium">Progresso</span>
                            <span className="text-sm text-muted-foreground">{plan.progress}%</span>
                          </div>
                          <Progress value={plan.progress} className="h-2" />
                          <div className="mt-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => updatePlanProgress(plan.id, Math.min(100, plan.progress + 25))}
                            >
                              Marcar Progresso
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="resources" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Dicas de Aprendizado</CardTitle>
                <CardDescription>
                  Estratégias eficazes para maximizar seu estudo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-900">Aprenda fazendo</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      A matemática de fractais e da borboleta de Hofstadter se entende melhor ao programar.
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <h4 className="font-medium text-green-900">Use visualizações interativas</h4>
                    <p className="text-sm text-green-700 mt-1">
                      Muitos conceitos (Mandelbrot, Hofstadter) são essencialmente visuais.
                    </p>
                  </div>
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <h4 className="font-medium text-purple-900">Conecte teoria e ficção</h4>
                    <p className="text-sm text-purple-700 mt-1">
                      Discutir obras de ficção ajuda a consolidar o entendimento de limites científicos.
                    </p>
                  </div>
                  <div className="p-3 bg-orange-50 rounded-lg">
                    <h4 className="font-medium text-orange-900">Participe de comunidades</h4>
                    <p className="text-sm text-orange-700 mt-1">
                      Reddit: r/Physics, r/Fractals, r/QuantumComputing
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Bibliografia Recomendada</CardTitle>
                <CardDescription>
                  Livros fundamentais para sua biblioteca
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {[
                      {
                        author: "Griffiths, D. J.",
                        title: "Introduction to Quantum Mechanics",
                        year: 1995,
                        type: "Livro"
                      },
                      {
                        author: "Greene, B.",
                        title: "The Elegant Universe",
                        year: 1999,
                        type: "Livro"
                      },
                      {
                        author: "Hofstadter, D. R.",
                        title: "Energy levels and wave functions of Bloch electrons",
                        year: 1976,
                        type: "Artigo"
                      },
                      {
                        author: "Peitgen, H.-O., Richter, P. H., Saupe, D.",
                        title: "The Beauty of Fractals",
                        year: 1992,
                        type: "Livro"
                      },
                      {
                        author: "Exner, J. E.",
                        title: "The Rorschach Comprehensive System",
                        year: 2003,
                        type: "Livro"
                      },
                      {
                        author: "Mandelbrot, B. B.",
                        title: "The Fractal Geometry of Nature",
                        year: 1982,
                        type: "Livro"
                      }
                    ].map((ref, index) => (
                      <div key={index} className="p-3 border rounded-lg">
                        <div className="font-medium text-sm">{ref.title}</div>
                        <div className="text-xs text-muted-foreground">
                          {ref.author} ({ref.year}) - {ref.type}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Ferramentas e Recursos Online</CardTitle>
              <CardDescription>
                Links úteis para complementar seus estudos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <a href="https://ocw.mit.edu" target="_blank" rel="noopener noreferrer" className="p-4 border rounded-lg hover:bg-muted transition-colors">
                  <div className="font-medium">MIT OpenCourseWare</div>
                  <div className="text-sm text-muted-foreground">Cursos gratuitos do MIT</div>
                </a>
                <a href="https://www.coursera.org" target="_blank" rel="noopener noreferrer" className="p-4 border rounded-lg hover:bg-muted transition-colors">
                  <div className="font-medium">Coursera</div>
                  <div className="text-sm text-muted-foreground">Cursos online especializados</div>
                </a>
                <a href="https://www.edx.org" target="_blank" rel="noopener noreferrer" className="p-4 border rounded-lg hover:bg-muted transition-colors">
                  <div className="font-medium">edX</div>
                  <div className="text-sm text-muted-foreground">Cursos de universidades</div>
                </a>
                <a href="https://www.khanacademy.org" target="_blank" rel="noopener noreferrer" className="p-4 border rounded-lg hover:bg-muted transition-colors">
                  <div className="font-medium">Khan Academy</div>
                  <div className="text-sm text-muted-foreground">Aulas gratuitas em português</div>
                </a>
                <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="p-4 border rounded-lg hover:bg-muted transition-colors">
                  <div className="font-medium">GitHub</div>
                  <div className="text-sm text-muted-foreground">Código e projetos</div>
                </a>
                <a href="https://www.wolframalpha.com" target="_blank" rel="noopener noreferrer" className="p-4 border rounded-lg hover:bg-muted transition-colors">
                  <div className="font-medium">WolframAlpha</div>
                  <div className="text-sm text-muted-foreground">Computação matemática</div>
                </a>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}