/**
 * Centralized Date Utilities for TimeKeeper OS
 * Provides consistent date handling, formatting, and synchronization across the application
 */

export interface DateConfig {
  timezone: string;
  format: 'ISO' | 'LOCAL' | 'UTC' | 'TIMESTAMP';
  locale: string;
}

export interface SyncOptions {
  includeTime: boolean;
  includeTimezone: boolean;
  precision: 'seconds' | 'milliseconds' | 'microseconds';
}

export class DateUtils {
  private static config: DateConfig = {
    timezone: 'UTC',
    format: 'ISO',
    locale: 'en-US'
  };

  private static syncOptions: SyncOptions = {
    includeTime: true,
    includeTimezone: true,
    precision: 'milliseconds'
  };

  /**
   * Initialize date utilities with configuration
   */
  static initialize(config?: Partial<DateConfig>, syncOptions?: Partial<SyncOptions>): void {
    this.config = { ...this.config, ...config };
    this.syncOptions = { ...this.syncOptions, ...syncOptions };
  }

  /**
   * Get current timestamp in configured format
   */
  static now(): string {
    const now = new Date();
    
    switch (this.config.format) {
      case 'ISO':
        return now.toISOString();
      case 'LOCAL':
        return now.toLocaleString(this.config.locale);
      case 'UTC':
        return now.toUTCString();
      case 'TIMESTAMP':
        return now.getTime().toString();
      default:
        return now.toISOString();
    }
  }

  /**
   * Format date for display
   */
  static formatDisplay(date: string | Date, options?: Intl.DateTimeFormatOptions): string {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    const defaultOptions: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: this.syncOptions.includeTime ? '2-digit' : undefined,
      minute: this.syncOptions.includeTime ? '2-digit' : undefined,
      second: this.syncOptions.includeTime && this.syncOptions.precision === 'seconds' ? '2-digit' : undefined,
      timeZoneName: this.syncOptions.includeTimezone ? 'short' : undefined
    };

    return dateObj.toLocaleString(this.config.locale, { ...defaultOptions, ...options });
  }

  /**
   * Format date for database storage
   */
  static formatForDB(date: string | Date): string {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return dateObj.toISOString();
  }

  /**
   * Format date for API responses
   */
  static formatForAPI(date: string | Date): string {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    if (this.syncOptions.precision === 'microseconds') {
      return dateObj.toISOString();
    } else if (this.syncOptions.precision === 'milliseconds') {
      return dateObj.toISOString();
    } else {
      // Remove milliseconds for seconds precision
      return dateObj.toISOString().replace(/\.\d{3}Z$/, 'Z');
    }
  }

  /**
   * Parse date from various formats
   */
  static parse(date: string): Date {
    // Try ISO format first
    const isoDate = new Date(date);
    if (!isNaN(isoDate.getTime())) {
      return isoDate;
    }

    // Try timestamp
    const timestamp = parseInt(date, 10);
    if (!isNaN(timestamp)) {
      return new Date(timestamp);
    }

    // Try common formats
    const formats = [
      /(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})/,
      /(\d{2})\/(\d{2})\/(\d{4}) (\d{2}):(\d{2}):(\d{2})/,
      /(\d{4})\/(\d{2})\/(\d{2}) (\d{2}):(\d{2}):(\d{2})/
    ];

    for (const format of formats) {
      const match = date.match(format);
      if (match) {
        const [, year, month, day, hour, minute, second] = match;
        return new Date(
          parseInt(year),
          parseInt(month) - 1,
          parseInt(day),
          parseInt(hour),
          parseInt(minute),
          parseInt(second)
        );
      }
    }

    throw new Error(`Unable to parse date: ${date}`);
  }

  /**
   * Calculate time difference
   */
  static timeDifference(date1: string | Date, date2: string | Date): {
    milliseconds: number;
    seconds: number;
    minutes: number;
    hours: number;
    days: number;
    humanReadable: string;
  } {
    const d1 = typeof date1 === 'string' ? new Date(date1) : date1;
    const d2 = typeof date2 === 'string' ? new Date(date2) : date2;
    
    const diff = Math.abs(d1.getTime() - d2.getTime());
    
    const milliseconds = diff;
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    let humanReadable = '';
    if (days > 0) {
      humanReadable = `${days} day${days > 1 ? 's' : ''} ago`;
    } else if (hours > 0) {
      humanReadable = `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else if (minutes > 0) {
      humanReadable = `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    } else if (seconds > 0) {
      humanReadable = `${seconds} second${seconds > 1 ? 's' : ''} ago`;
    } else {
      humanReadable = 'just now';
    }

    return {
      milliseconds,
      seconds,
      minutes,
      hours,
      days,
      humanReadable
    };
  }

  /**
   * Check if date is recent (within last 24 hours)
   */
  static isRecent(date: string | Date, hours: number = 24): boolean {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    const now = new Date();
    const diffHours = Math.abs(now.getTime() - dateObj.getTime()) / (1000 * 60 * 60);
    return diffHours <= hours;
  }

  /**
   * Add time to date
   */
  static addTime(date: string | Date, amount: number, unit: 'seconds' | 'minutes' | 'hours' | 'days' | 'weeks' | 'months' | 'years'): string {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    const result = new Date(dateObj);

    switch (unit) {
      case 'seconds':
        result.setSeconds(result.getSeconds() + amount);
        break;
      case 'minutes':
        result.setMinutes(result.getMinutes() + amount);
        break;
      case 'hours':
        result.setHours(result.getHours() + amount);
        break;
      case 'days':
        result.setDate(result.getDate() + amount);
        break;
      case 'weeks':
        result.setDate(result.getDate() + (amount * 7));
        break;
      case 'months':
        result.setMonth(result.getMonth() + amount);
        break;
      case 'years':
        result.setFullYear(result.getFullYear() + amount);
        break;
    }

    return this.formatForDB(result);
  }

  /**
   * Validate date string
   */
  static isValid(date: string): boolean {
    try {
      const parsed = this.parse(date);
      return !isNaN(parsed.getTime());
    } catch {
      return false;
    }
  }

  /**
   * Get timezone offset
   */
  static getTimezoneOffset(date?: string | Date): number {
    const dateObj = date ? (typeof date === 'string' ? new Date(date) : date) : new Date();
    return dateObj.getTimezoneOffset();
  }

  /**
   * Convert timezone
   */
  static convertTimezone(date: string | Date, targetTimezone: string): string {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return dateObj.toLocaleString('en-US', { timeZone: targetTimezone });
  }

  /**
   * Sync date across multiple systems
   */
  static syncDate(sourceDate: string | Date, targetFormat: 'ISO' | 'LOCAL' | 'UTC' | 'TIMESTAMP' = 'ISO'): string {
    const dateObj = typeof sourceDate === 'string' ? new Date(sourceDate) : sourceDate;
    
    switch (targetFormat) {
      case 'ISO':
        return dateObj.toISOString();
      case 'LOCAL':
        return dateObj.toLocaleString(this.config.locale);
      case 'UTC':
        return dateObj.toUTCString();
      case 'TIMESTAMP':
        return dateObj.getTime().toString();
      default:
        return dateObj.toISOString();
    }
  }

  /**
   * Get date components
   */
  static getComponents(date: string | Date): {
    year: number;
    month: number;
    day: number;
    hours: number;
    minutes: number;
    seconds: number;
    milliseconds: number;
    dayOfWeek: number;
    dayOfYear: number;
    weekOfYear: number;
  } {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    const start = new Date(dateObj.getFullYear(), 0, 0);
    const diff = dateObj.getTime() - start.getTime();
    const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    const startOfYear = new Date(dateObj.getFullYear(), 0, 1);
    const pastDaysOfYear = (dateObj.getTime() - startOfYear.getTime()) / 86400000;
    const weekOfYear = Math.ceil((pastDaysOfYear + startOfYear.getDay() + 1) / 7);

    return {
      year: dateObj.getFullYear(),
      month: dateObj.getMonth() + 1,
      day: dateObj.getDate(),
      hours: dateObj.getHours(),
      minutes: dateObj.getMinutes(),
      seconds: dateObj.getSeconds(),
      milliseconds: dateObj.getMilliseconds(),
      dayOfWeek: dateObj.getDay(),
      dayOfYear,
      weekOfYear
    };
  }

  /**
   * Format date for Aurum Grid specific requirements
   */
  static formatForAurumGrid(date: string | Date): string {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    // Aurum Grid requires high precision timestamps
    const timestamp = dateObj.getTime();
    const microseconds = Math.floor((timestamp % 1000) * 1000);
    
    return `${dateObj.toISOString().replace('Z', '')}.${microseconds.toString().padStart(6, '0')}Z`;
  }

  /**
   * Parse Aurum Grid specific date format
   */
  static parseAurumGridDate(dateString: string): Date {
    // Handle high precision timestamps with microseconds
    if (dateString.includes('.')) {
      const [base, microseconds] = dateString.split('.');
      const [isoPart, timezone] = base.split(/([+-]\d{2}:\d{2}|Z)$/);
      const date = new Date(isoPart + 'Z');
      
      if (microseconds) {
        const micros = parseInt(microseconds.replace('Z', ''), 10);
        date.setTime(date.getTime() + Math.floor(micros / 1000));
      }
      
      return date;
    }
    
    return new Date(dateString);
  }

  /**
   * Generate sync timestamp for database operations
   */
  static generateSyncTimestamp(): string {
    return this.formatForDB(new Date());
  }

  /**
   * Check if synchronization is needed based on last sync time
   */
  static needsSync(lastSync: string | Date, intervalMinutes: number = 60): boolean {
    const lastSyncDate = typeof lastSync === 'string' ? new Date(lastSync) : lastSync;
    const now = new Date();
    const diffMinutes = (now.getTime() - lastSyncDate.getTime()) / (1000 * 60);
    return diffMinutes >= intervalMinutes;
  }

  /**
   * Get next sync time
   */
  static getNextSyncTime(lastSync: string | Date, intervalMinutes: number = 60): string {
    const lastSyncDate = typeof lastSync === 'string' ? new Date(lastSync) : lastSync;
    const nextSync = new Date(lastSyncDate.getTime() + (intervalMinutes * 60 * 1000));
    return this.formatForDB(nextSync);
  }
}

// Initialize with default configuration
DateUtils.initialize();

export default DateUtils;