/**
 * Real-time Date Synchronization Service
 * Provides automatic date synchronization for harmonic nodes and uploads
 */

import DateUtils from '@/lib/date-utils';

export interface SyncConfig {
  interval: number; // in milliseconds
  autoSync: boolean;
  maxRetries: number;
  retryDelay: number; // in milliseconds
}

export interface SyncStatus {
  lastSync: string;
  nextSync: string;
  isSyncing: boolean;
  success: boolean;
  error?: string;
  retryCount: number;
}

export interface NodeSyncData {
  id: string;
  lastSync: string;
  coherence: number;
  status: string;
  syncNeeded: boolean;
}

export interface UploadSyncData {
  id: string;
  timestamp: string;
  status: string;
  coherence: number;
  syncNeeded: boolean;
}

class DateSyncService {
  private config: SyncConfig = {
    interval: 60000, // 1 minute
    autoSync: true,
    maxRetries: 3,
    retryDelay: 5000 // 5 seconds
  };

  private syncStatus: SyncStatus = {
    lastSync: DateUtils.generateSyncTimestamp(),
    nextSync: DateUtils.getNextSyncTime(DateUtils.generateSyncTimestamp(), 1),
    isSyncing: false,
    success: true,
    retryCount: 0
  };

  private syncInterval: NodeJS.Timeout | null = null;
  private callbacks: Set<(status: SyncStatus) => void> = new Set();
  private nodeCallbacks: Set<(nodes: NodeSyncData[]) => void> = new Set();
  private uploadCallbacks: Set<(uploads: UploadSyncData[]) => void> = new Set();

  constructor(config?: Partial<SyncConfig>) {
    if (config) {
      this.config = { ...this.config, ...config };
    }
  }

  /**
   * Initialize the synchronization service
   */
  initialize(): void {
    if (this.config.autoSync) {
      this.startSync();
    }
  }

  /**
   * Start automatic synchronization
   */
  startSync(): void {
    if (this.syncInterval) {
      this.stopSync();
    }

    this.syncInterval = setInterval(() => {
      this.performSync();
    }, this.config.interval);

    console.log('Date synchronization service started');
  }

  /**
   * Stop automatic synchronization
   */
  stopSync(): void {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
      console.log('Date synchronization service stopped');
    }
  }

  /**
   * Perform manual synchronization
   */
  async performSync(): Promise<void> {
    if (this.syncStatus.isSyncing) {
      console.log('Sync already in progress, skipping...');
      return;
    }

    this.updateSyncStatus({
      isSyncing: true,
      retryCount: 0
    });

    try {
      // Sync harmonic nodes
      await this.syncHarmonicNodes();
      
      // Sync uploads
      await this.syncUploads();

      // Update sync status
      const now = DateUtils.generateSyncTimestamp();
      this.updateSyncStatus({
        lastSync: now,
        nextSync: DateUtils.getNextSyncTime(now, this.config.interval / 60000),
        isSyncing: false,
        success: true,
        error: undefined,
        retryCount: 0
      });

      console.log('Date synchronization completed successfully');

    } catch (error) {
      console.error('Date synchronization failed:', error);
      
      // Handle retry logic
      const retryCount = this.syncStatus.retryCount + 1;
      
      if (retryCount < this.config.maxRetries) {
        this.updateSyncStatus({
          isSyncing: false,
          success: false,
          error: error.message,
          retryCount
        });

        // Schedule retry
        setTimeout(() => {
          this.performSync();
        }, this.config.retryDelay);

        console.log(`Scheduling retry ${retryCount}/${this.config.maxRetries}`);
      } else {
        this.updateSyncStatus({
          isSyncing: false,
          success: false,
          error: `Max retries (${this.config.maxRetries}) exceeded: ${error.message}`,
          retryCount
        });

        console.error('Max retries exceeded for date synchronization');
      }
    }
  }

  /**
   * Synchronize harmonic nodes
   */
  private async syncHarmonicNodes(): Promise<void> {
    try {
      const response = await fetch('/api/aurum-grid/nodes');
      if (!response.ok) {
        throw new Error(`Failed to fetch nodes: ${response.statusText}`);
      }

      const data = await response.json();
      const nodes = data.nodes || [];

      // Check which nodes need synchronization
      const nodesNeedingSync: NodeSyncData[] = nodes
        .filter((node: any) => DateUtils.needsSync(node.lastSync, 5)) // 5 minutes
        .map((node: any) => ({
          id: node.id,
          lastSync: node.lastSync,
          coherence: node.coherence,
          status: node.status,
          syncNeeded: true
        }));

      if (nodesNeedingSync.length > 0) {
        console.log(`Found ${nodesNeedingSync.length} nodes needing synchronization`);
        
        // Notify callbacks about nodes needing sync
        this.notifyNodeCallbacks(nodesNeedingSync);

        // In a real implementation, you would update the nodes here
        // For now, we'll just log the action
        for (const node of nodesNeedingSync) {
          console.log(`Updating node ${node.id} sync time`);
        }
      }

      // Notify all nodes data
      const allNodesData: NodeSyncData[] = nodes.map((node: any) => ({
        id: node.id,
        lastSync: node.lastSync,
        coherence: node.coherence,
        status: node.status,
        syncNeeded: DateUtils.needsSync(node.lastSync, 5)
      }));

      this.notifyNodeCallbacks(allNodesData);

    } catch (error) {
      console.error('Failed to sync harmonic nodes:', error);
      throw error;
    }
  }

  /**
   * Synchronize uploads
   */
  private async syncUploads(): Promise<void> {
    try {
      const response = await fetch('/api/aurum-grid/uploads');
      if (!response.ok) {
        throw new Error(`Failed to fetch uploads: ${response.statusText}`);
      }

      const data = await response.json();
      const uploads = data.uploads || [];

      // Check which uploads need synchronization
      const uploadsNeedingSync: UploadSyncData[] = uploads
        .filter((upload: any) => 
          upload.status === 'uploading' || 
          upload.status === 'validating' || 
          upload.status === 'synchronizing' ||
          DateUtils.needsSync(upload.timestamp, 10) // 10 minutes
        )
        .map((upload: any) => ({
          id: upload.id,
          timestamp: upload.timestamp,
          status: upload.status,
          coherence: upload.coherence,
          syncNeeded: true
        }));

      if (uploadsNeedingSync.length > 0) {
        console.log(`Found ${uploadsNeedingSync.length} uploads needing synchronization`);
        
        // Notify callbacks about uploads needing sync
        this.notifyUploadCallbacks(uploadsNeedingSync);

        // In a real implementation, you would update the uploads here
        for (const upload of uploadsNeedingSync) {
          console.log(`Updating upload ${upload.id} sync time`);
        }
      }

      // Notify all uploads data
      const allUploadsData: UploadSyncData[] = uploads.map((upload: any) => ({
        id: upload.id,
        timestamp: upload.timestamp,
        status: upload.status,
        coherence: upload.coherence,
        syncNeeded: upload.status === 'uploading' || 
                    upload.status === 'validating' || 
                    upload.status === 'synchronizing' ||
                    DateUtils.needsSync(upload.timestamp, 10)
      }));

      this.notifyUploadCallbacks(allUploadsData);

    } catch (error) {
      console.error('Failed to sync uploads:', error);
      throw error;
    }
  }

  /**
   * Update sync status
   */
  private updateSyncStatus(updates: Partial<SyncStatus>): void {
    this.syncStatus = { ...this.syncStatus, ...updates };
    this.notifyCallbacks(this.syncStatus);
  }

  /**
   * Notify status callbacks
   */
  private notifyCallbacks(status: SyncStatus): void {
    this.callbacks.forEach(callback => {
      try {
        callback(status);
      } catch (error) {
        console.error('Error in sync status callback:', error);
      }
    });
  }

  /**
   * Notify node callbacks
   */
  private notifyNodeCallbacks(nodes: NodeSyncData[]): void {
    this.nodeCallbacks.forEach(callback => {
      try {
        callback(nodes);
      } catch (error) {
        console.error('Error in node sync callback:', error);
      }
    });
  }

  /**
   * Notify upload callbacks
   */
  private notifyUploadCallbacks(uploads: UploadSyncData[]): void {
    this.uploadCallbacks.forEach(callback => {
      try {
        callback(uploads);
      } catch (error) {
        console.error('Error in upload sync callback:', error);
      }
    });
  }

  /**
   * Subscribe to sync status updates
   */
  onStatusUpdate(callback: (status: SyncStatus) => void): () => void {
    this.callbacks.add(callback);
    
    // Immediately call with current status
    callback(this.syncStatus);

    // Return unsubscribe function
    return () => {
      this.callbacks.delete(callback);
    };
  }

  /**
   * Subscribe to node sync updates
   */
  onNodeSync(callback: (nodes: NodeSyncData[]) => void): () => void {
    this.nodeCallbacks.add(callback);
    
    // Return unsubscribe function
    return () => {
      this.nodeCallbacks.delete(callback);
    };
  }

  /**
   * Subscribe to upload sync updates
   */
  onUploadSync(callback: (uploads: UploadSyncData[]) => void): () => void {
    this.uploadCallbacks.add(callback);
    
    // Return unsubscribe function
    return () => {
      this.uploadCallbacks.delete(callback);
    };
  }

  /**
   * Get current sync status
   */
  getStatus(): SyncStatus {
    return { ...this.syncStatus };
  }

  /**
   * Update configuration
   */
  updateConfig(config: Partial<SyncConfig>): void {
    this.config = { ...this.config, ...config };
    
    // Restart sync if autoSync is enabled
    if (this.config.autoSync && this.syncInterval) {
      this.stopSync();
      this.startSync();
    }
  }

  /**
   * Check if specific node needs synchronization
   */
  needsNodeSync(nodeLastSync: string, intervalMinutes: number = 5): boolean {
    return DateUtils.needsSync(nodeLastSync, intervalMinutes);
  }

  /**
   * Check if specific upload needs synchronization
   */
  needsUploadSync(uploadTimestamp: string, intervalMinutes: number = 10): boolean {
    return DateUtils.needsSync(uploadTimestamp, intervalMinutes);
  }

  /**
   * Force synchronization of specific node
   */
  async syncNode(nodeId: string): Promise<void> {
    try {
      const response = await fetch(`/api/aurum-grid/nodes/${nodeId}/sync`, {
        method: 'POST'
      });
      
      if (!response.ok) {
        throw new Error(`Failed to sync node ${nodeId}: ${response.statusText}`);
      }

      console.log(`Node ${nodeId} synchronized successfully`);

    } catch (error) {
      console.error(`Failed to sync node ${nodeId}:`, error);
      throw error;
    }
  }

  /**
   * Force synchronization of specific upload
   */
  async syncUpload(uploadId: string): Promise<void> {
    try {
      const response = await fetch(`/api/aurum-grid/uploads/${uploadId}/sync`, {
        method: 'POST'
      });
      
      if (!response.ok) {
        throw new Error(`Failed to sync upload ${uploadId}: ${response.statusText}`);
      }

      console.log(`Upload ${uploadId} synchronized successfully`);

    } catch (error) {
      console.error(`Failed to sync upload ${uploadId}:`, error);
      throw error;
    }
  }

  /**
   * Cleanup resources
   */
  destroy(): void {
    this.stopSync();
    this.callbacks.clear();
    this.nodeCallbacks.clear();
    this.uploadCallbacks.clear();
  }
}

// Create singleton instance
const dateSyncService = new DateSyncService();

export default dateSyncService;
export { DateSyncService };