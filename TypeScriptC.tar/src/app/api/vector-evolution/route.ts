import { NextRequest, NextResponse } from 'next/server';
import { VectorEvolutionSystem, VectorEvolutionConfig, VectorState } from '@/lib/vector-evolution';

// Sistema global de evolução de vetores
let evolutionSystem: VectorEvolutionSystem | null = null;

// Inicializar sistema se não existir
function getEvolutionSystem(): VectorEvolutionSystem {
  if (!evolutionSystem) {
    const config: VectorEvolutionConfig = {
      dimensions: 12,
      coherenceThreshold: 0.8,
      quantumBits: 8,
      neuralLayers: 4,
      securityLayers: 3
    };
    
    evolutionSystem = new VectorEvolutionSystem(config);
    
    // Criar vetores iniciais
    const vectorTypes: VectorState['type'][] = [
      'coherence', 'quantum', 'neural', 'cryptographic', 'security', 'expansion'
    ];
    
    vectorTypes.forEach(type => {
      evolutionSystem!.createVector(type);
    });
  }
  
  return evolutionSystem;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');
    
    const system = getEvolutionSystem();
    
    switch (action) {
      case 'vectors':
        const vectors = system.getAllVectors();
        return NextResponse.json({ vectors });
        
      case 'metrics':
        const metrics = system.getMetrics();
        return NextResponse.json({ metrics });
        
      case 'history':
        const history = system.getEvolutionHistory();
        return NextResponse.json({ history });
        
      case 'correlations':
        const correlations = system.analyzeVectorCorrelations();
        return NextResponse.json({ correlations: Array.from(correlations.entries()) });
        
      case 'status':
        return NextResponse.json({
          status: 'active',
          vectorCount: system.getAllVectors().length,
          metrics: system.getMetrics(),
          lastEvolution: Date.now()
        });
        
      default:
        return NextResponse.json({ 
          error: 'Invalid action parameter' 
        }, { status: 400 });
    }
  } catch (error) {
    console.error('Vector evolution GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { action, data } = await request.json();
    
    const system = getEvolutionSystem();
    
    switch (action) {
      case 'evolve':
        const evolvedMetrics = await system.evolveAllVectors();
        return NextResponse.json({ 
          success: true, 
          metrics: evolvedMetrics,
          timestamp: Date.now()
        });
        
      case 'optimize':
        await system.optimizeSystem();
        return NextResponse.json({ 
          success: true, 
          message: 'System optimized',
          timestamp: Date.now()
        });
        
      case 'create-vector':
        if (!data?.type) {
          return NextResponse.json({ error: 'Vector type required' }, { status: 400 });
        }
        
        const newVector = system.createVector(data.type, data.coordinates);
        return NextResponse.json({ 
          success: true, 
          vector: newVector 
        });
        
      case 'analyze':
        if (!data?.vectorId) {
          return NextResponse.json({ error: 'Vector ID required' }, { status: 400 });
        }
        
        const vector = system.getVector(data.vectorId);
        if (!vector) {
          return NextResponse.json({ error: 'Vector not found' }, { status: 404 });
        }
        
        const analysis = {
          vector,
          recommendations: generateVectorRecommendations(vector),
          projections: projectVectorEvolution(vector)
        };
        
        return NextResponse.json({ analysis });
        
      case 'brainwallet-integration':
        if (!data?.passphrase) {
          return NextResponse.json({ error: 'Passphrase required' }, { status: 400 });
        }
        
        const brainwalletAnalysis = await analyzeBrainwalletIntegration(data.passphrase, system);
        return NextResponse.json({ brainwalletAnalysis });
        
      case 'quantum-enhancement':
        const quantumResults = await applyQuantumEnhancement(system);
        return NextResponse.json({ quantumResults });
        
      case 'neural-expansion':
        const neuralResults = await applyNeuralExpansion(system);
        return NextResponse.json({ neuralResults });
        
      default:
        return NextResponse.json({ 
          error: 'Invalid action parameter' 
        }, { status: 400 });
    }
  } catch (error) {
    console.error('Vector evolution POST error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// Funções auxiliares para análise avançada
function generateVectorRecommendations(vector: VectorState): string[] {
  const recommendations: string[] = [];
  
  if (vector.coherence < 0.6) {
    recommendations.push('Increase coherence through phase optimization');
  }
  
  if (vector.entropy > 6) {
    recommendations.push('Reduce entropy through coordinate normalization');
  }
  
  if (vector.magnitude < 0.5) {
    recommendations.push('Boost magnitude through coordinate scaling');
  }
  
  if (vector.magnitude > 2) {
    recommendations.push('Reduce magnitude through coordinate compression');
  }
  
  // Recomendações específicas por tipo
  switch (vector.type) {
    case 'coherence':
      recommendations.push('Apply harmonic resonance optimization');
      break;
    case 'quantum':
      recommendations.push('Enhance quantum entanglement patterns');
      break;
    case 'neural':
      recommendations.push('Increase neural layer complexity');
      break;
    case 'cryptographic':
      recommendations.push('Strengthen cryptographic hash functions');
      break;
    case 'security':
      recommendations.push('Add additional security layers');
      break;
    case 'expansion':
      recommendations.push('Explore dimensional expansion opportunities');
      break;
  }
  
  return recommendations;
}

function projectVectorEvolution(vector: VectorState): any[] {
  const projections: any[] = [];
  const steps = 5;
  
  for (let i = 1; i <= steps; i++) {
    const progress = i / steps;
    const projectedVector = {
      step: i,
      progress,
      projectedCoherence: Math.min(1, vector.coherence + progress * 0.2),
      projectedEntropy: Math.max(0, vector.entropy - progress * 0.5),
      projectedMagnitude: vector.magnitude * (1 + progress * 0.1),
      estimatedTime: Date.now() + (i * 60000) // 1 minuto por passo
    };
    
    projections.push(projectedVector as any);
  }
  
  return projections;
}

async function analyzeBrainwalletIntegration(passphrase: string, system: VectorEvolutionSystem): Promise<any> {
  // Integrar análise de brainwallet com o sistema de vetores
  const cryptoVector = system.getAllVectors().find(v => v.type === 'cryptographic');
  
  if (!cryptoVector) {
    throw new Error('Cryptographic vector not found');
  }
  
  // Gerar coordenadas baseadas na passphrase
  const passphraseCoordinates = passphraseToCoordinates(passphrase, cryptoVector.coordinates.length);
  
  // Calcular integração com vetor criptográfico existente
  const integrationScore = calculateIntegrationScore(cryptoVector.coordinates, passphraseCoordinates);
  
  // Gerar vetor de brainwallet
  const brainwalletVector = system.createVector('cryptographic', passphraseCoordinates);
  
  return {
    passphrase: passphrase.substring(0, 8) + '...',
    integrationScore,
    brainwalletVector: {
      id: brainwalletVector.id,
      type: brainwalletVector.type,
      coherence: brainwalletVector.coherence,
      entropy: brainwalletVector.entropy,
      magnitude: brainwalletVector.magnitude
    },
    connectivity: {
      toCryptographic: integrationScore,
      toSecurity: calculateSecurityConnectivity(brainwalletVector),
      toQuantum: calculateQuantumConnectivity(brainwalletVector)
    },
    recommendations: generateBrainwalletRecommendations(integrationScore, passphrase)
  };
}

function passphraseToCoordinates(passphrase: string, dimensions: number): number[] {
  const coordinates: number[] = [];
  
  for (let i = 0; i < dimensions; i++) {
    const charIndex = i % passphrase.length;
    const charCode = passphrase.charCodeAt(charIndex);
    const normalized = (charCode / 255) * 2 - 1; // Normalizar para [-1, 1]
    coordinates.push(normalized);
  }
  
  return coordinates;
}

function calculateIntegrationScore(coords1: number[], coords2: number[]): number {
  const minLength = Math.min(coords1.length, coords2.length);
  let dotProduct = 0;
  let mag1 = 0;
  let mag2 = 0;
  
  for (let i = 0; i < minLength; i++) {
    dotProduct += coords1[i] * coords2[i];
    mag1 += coords1[i] * coords1[i];
    mag2 += coords2[i] * coords2[i];
  }
  
  mag1 = Math.sqrt(mag1);
  mag2 = Math.sqrt(mag2);
  
  return mag1 === 0 || mag2 === 0 ? 0 : dotProduct / (mag1 * mag2);
}

function calculateSecurityConnectivity(vector: VectorState): number {
  // Simular análise de conectividade de segurança
  const entropyFactor = Math.max(0, 1 - vector.entropy / 10);
  const coherenceFactor = vector.coherence;
  const magnitudeFactor = Math.min(1, vector.magnitude / 2);
  
  return (entropyFactor + coherenceFactor + magnitudeFactor) / 3;
}

function calculateQuantumConnectivity(vector: VectorState): number {
  // Simular análise de conectividade quântica
  const phaseQuantization = Math.abs(Math.cos(vector.phase));
  const coordinateSuperposition = vector.coordinates.reduce((sum, coord) => 
    sum + Math.abs(coord), 0) / vector.coordinates.length;
  
  return (phaseQuantization + coordinateSuperposition) / 2;
}

function generateBrainwalletRecommendations(integrationScore: number, passphrase: string): string[] {
  const recommendations: string[] = [];
  
  if (integrationScore < 0.5) {
    recommendations.push('Increase passphrase complexity for better integration');
  }
  
  if (passphrase.length < 16) {
    recommendations.push('Use longer passphrases (minimum 16 characters)');
  }
  
  if (!/[A-Z]/.test(passphrase)) {
    recommendations.push('Include uppercase letters');
  }
  
  if (!/[a-z]/.test(passphrase)) {
    recommendations.push('Include lowercase letters');
  }
  
  if (!/\d/.test(passphrase)) {
    recommendations.push('Include numbers');
  }
  
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(passphrase)) {
    recommendations.push('Include special characters');
  }
  
  if (integrationScore > 0.8) {
    recommendations.push('Excellent integration with cryptographic vector');
  }
  
  return recommendations;
}

async function applyQuantumEnhancement(system: VectorEvolutionSystem): Promise<any> {
  const quantumVector = system.getAllVectors().find(v => v.type === 'quantum');
  
  if (!quantumVector) {
    throw new Error('Quantum vector not found');
  }
  
  // Aplicar melhorias quânticas
  await system.evolveAllVectors();
  const enhancedVector = system.getVector(quantumVector.id) || quantumVector;
  
  // Calcular métricas de melhoria
  const coherenceImprovement = enhancedVector.coherence - quantumVector.coherence;
  const entropyReduction = quantumVector.entropy - enhancedVector.entropy;
  const magnitudeOptimization = Math.abs(enhancedVector.magnitude - 1);
  
  return {
    enhancedVector: {
      id: enhancedVector.id,
      coherence: enhancedVector.coherence,
      entropy: enhancedVector.entropy,
      magnitude: enhancedVector.magnitude
    },
    improvements: {
      coherence: coherenceImprovement,
      entropy: entropyReduction,
      magnitude: magnitudeOptimization
    },
    quantumState: {
      phase: enhancedVector.phase,
      superposition: enhancedVector.coordinates.some(c => Math.abs(c) > 0.8),
      entanglement: enhancedVector.coordinates.reduce((sum, c) => sum + Math.abs(c), 0) / enhancedVector.coordinates.length
    }
  };
}

async function applyNeuralExpansion(system: VectorEvolutionSystem): Promise<any> {
  const neuralVector = system.getAllVectors().find(v => v.type === 'neural');
  
  if (!neuralVector) {
    throw new Error('Neural vector not found');
  }
  
  // Aplicar expansão neural
  await system.evolveAllVectors();
  const expandedVector = system.getVector(neuralVector.id) || neuralVector;
  
  // Analisar padrões neurais
  const patterns = analyzeNeuralPatterns(expandedVector.coordinates);
  const activationLevels = expandedVector.coordinates.map(Math.tanh);
  
  return {
    expandedVector: {
      id: expandedVector.id,
      coherence: expandedVector.coherence,
      entropy: expandedVector.entropy,
      magnitude: expandedVector.magnitude,
      dimensions: expandedVector.coordinates.length
    },
    neuralAnalysis: {
      patterns,
      activationLevels,
      averageActivation: activationLevels.reduce((sum, a) => sum + a, 0) / activationLevels.length,
      complexity: calculateNeuralComplexity(expandedVector.coordinates)
    },
    expansionMetrics: {
      dimensionalGrowth: expandedVector.coordinates.length - neuralVector.coordinates.length,
      coherenceChange: expandedVector.coherence - neuralVector.coherence,
      efficiency: calculateNeuralEfficiency(expandedVector.coordinates)
    }
  };
}

function analyzeNeuralPatterns(coordinates: number[]): string[] {
  const patterns: string[] = [];
  
  // Detectar padrões de ativação
  const activations = coordinates.map(Math.tanh);
  const highActivations = activations.filter(a => Math.abs(a) > 0.8).length;
  const lowActivations = activations.filter(a => Math.abs(a) < 0.2).length;
  
  if (highActivations > coordinates.length * 0.3) {
    patterns.push('High activation cluster detected');
  }
  
  if (lowActivations > coordinates.length * 0.5) {
    patterns.push('Sparse activation pattern');
  }
  
  // Detectar oscilações
  const oscillations = coordinates.filter((c, i) => i > 0 && Math.sign(c) !== Math.sign(coordinates[i - 1])).length;
  if (oscillations > coordinates.length * 0.4) {
    patterns.push('Oscillatory behavior detected');
  }
  
  // Detectar convergência
  const convergence = coordinates.reduce((sum, c) => sum + Math.abs(c), 0) / coordinates.length;
  if (convergence < 0.3) {
    patterns.push('Convergence pattern detected');
  }
  
  return patterns;
}

function calculateNeuralComplexity(coordinates: number[]): number {
  // Calcular complexidade baseada em entropia e correlações
  const entropy = calculateCoordinatesEntropy(coordinates);
  const correlations = calculateCoordinateCorrelations(coordinates);
  
  return (entropy + correlations) / 2;
}

function calculateCoordinatesEntropy(coordinates: number[]): number {
  const histogram = new Array(10).fill(0);
  coordinates.forEach(coord => {
    const bin = Math.floor((coord + 1) * 5);
    histogram[Math.max(0, Math.min(9, bin))]++;
  });
  
  return -histogram.reduce((entropy, count) => {
    const probability = count / coordinates.length;
    return entropy + (probability > 0 ? probability * Math.log2(probability) : 0);
  }, 0);
}

function calculateCoordinateCorrelations(coordinates: number[]): number {
  let totalCorrelation = 0;
  let correlationCount = 0;
  
  for (let i = 0; i < coordinates.length - 1; i++) {
    for (let j = i + 1; j < coordinates.length; j++) {
      const correlation = Math.abs(coordinates[i] * coordinates[j]);
      totalCorrelation += correlation;
      correlationCount++;
    }
  }
  
  return correlationCount > 0 ? totalCorrelation / correlationCount : 0;
}

function calculateNeuralEfficiency(coordinates: number[]): number {
  const activations = coordinates.map(Math.tanh);
  const usefulActivations = activations.filter(a => Math.abs(a) > 0.1).length;
  const totalActivations = activations.length;
  
  return usefulActivations / totalActivations;
}