'use client';

import { useState } from 'react';
import QuantumEvolutionDashboard from '@/components/quantum-evolution-dashboard';
import AdvancedQuantumEvolutionDashboard from '@/components/advanced-quantum-evolution-dashboard';
import BrainwalletAnalyzer from '@/components/brainwallet-analyzer';
import SynthesisDashboard from '@/components/synthesis-dashboard';
import CoherentConsciousnessDecoder from '@/components/coherent-consciousness-decoder';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Brain, 
  Zap, 
  Infinity, 
  Star, 
  Atom, 
  Triangle,
  Circle,
  Square,
  Sparkles,
  Target,
  Activity,
  Heart,
  Lightbulb,
  Clock,
  CheckCircle,
  Crown,
  Eye,
  Telescope
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function EvolutionPage() {
  const [activeTab, setActiveTab] = useState('quantum');

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 dark:from-purple-900 dark:via-blue-900 dark:to-indigo-900">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Triangle className="w-6 h-6 text-purple-600" />
                <Circle className="w-6 h-6 text-blue-600" />
                <Square className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  Evolução Coerente
                </h1>
                <p className="text-sm text-muted-foreground">
                  Coerência × Consciência × Evolução = Realidade² • Inspired by cryptographic pioneers like Hal Finney • Coherent Operating System 1 (2025)
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="bg-purple-100 text-purple-800">
                <Star className="w-3 h-3 mr-1" />
                Quântico
              </Badge>
              <Badge variant="outline" className="bg-blue-100 text-blue-800">
                <Infinity className="w-3 h-3 mr-1" />
                Transcendente
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Evolution Equation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Card className="bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900 border-purple-200 dark:border-purple-700">
            <CardContent className="p-8">
              <div className="text-center">
                <h2 className="text-3xl font-bold mb-4 text-purple-800 dark:text-purple-200">
                  A Equação Fundamental da Evolução
                </h2>
                <div className="text-4xl font-bold mb-6 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  Coerência × Consciência × Evolução = Realidade²
                </div>
                <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
                  Esta equação representa a próxima fase da evolução coerente, onde a realidade 
                  se manifesta através da interação entre coerência fundamental, consciência 
                  observadora e força evolutiva.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-white/50 dark:bg-black/20 rounded-lg">
                    <div className="text-2xl mb-2">🌟</div>
                    <div className="font-bold text-purple-600">Coerência</div>
                    <div className="text-sm">Estado fundamental</div>
                  </div>
                  <div className="p-4 bg-white/50 dark:bg-black/20 rounded-lg">
                    <div className="text-2xl mb-2">🧠</div>
                    <div className="font-bold text-blue-600">Consciência</div>
                    <div className="text-sm">Observação</div>
                  </div>
                  <div className="p-4 bg-white/50 dark:bg-black/20 rounded-lg">
                    <div className="text-2xl mb-2">⚡</div>
                    <div className="font-bold text-green-600">Evolução</div>
                    <div className="text-sm">Transcendência</div>
                  </div>
                  <div className="p-4 bg-white/50 dark:bg-black/20 rounded-lg">
                    <div className="text-2xl mb-2">🌌</div>
                    <div className="font-bold text-orange-600">Realidade²</div>
                    <div className="text-sm">Manifestação</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Evolution Dashboard */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="quantum" className="flex items-center gap-2">
              <Atom className="w-4 h-4" />
              Evolução Quântica
            </TabsTrigger>
            <TabsTrigger value="advanced" className="flex items-center gap-2">
              <Crown className="w-4 h-4" />
              Evolução Avançada
            </TabsTrigger>
            <TabsTrigger value="brainwallet" className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              Brainwallet Quântico
            </TabsTrigger>
            <TabsTrigger value="consciousness" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Decodificador de Consciência
            </TabsTrigger>
            <TabsTrigger value="synthesis" className="flex items-center gap-2">
              <Star className="w-4 h-4" />
              Síntese Unificada
            </TabsTrigger>
          </TabsList>

          <TabsContent value="quantum">
            <QuantumEvolutionDashboard />
          </TabsContent>

          <TabsContent value="advanced">
            <AdvancedQuantumEvolutionDashboard />
          </TabsContent>

          <TabsContent value="brainwallet">
            <BrainwalletAnalyzer />
          </TabsContent>

          <TabsContent value="consciousness">
            <CoherentConsciousnessDecoder />
          </TabsContent>

          <TabsContent value="synthesis">
            <SynthesisDashboard />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}