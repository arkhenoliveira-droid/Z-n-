'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronRight, Hash, Clock, Package } from 'lucide-react';
import { BlockData, Transaction } from '@/lib/blockchain';

interface BlockCardProps {
  block: BlockData;
  isGenesis?: boolean;
}

export function BlockCard({ block, isGenesis = false }: BlockCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const transactions = Array.isArray(block.transactions) ? block.transactions : [];
  const transactionCount = transactions.length;

  return (
    <Card className={`w-full ${isGenesis ? 'border-green-500 bg-green-50 dark:bg-green-950' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Package className="h-5 w-5 text-blue-600" />
            <CardTitle className="text-lg">Block #{block.index}</CardTitle>
            {isGenesis && (
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                Genesis
              </Badge>
            )}
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            {isExpanded ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
          </Button>
        </div>
        <CardDescription className="flex items-center space-x-4 text-sm">
          <div className="flex items-center space-x-1">
            <Hash className="h-3 w-3" />
            <span className="font-mono text-xs">
              {block.hash.substring(0, 16)}...
            </span>
          </div>
          <div className="flex items-center space-x-1">
            <Clock className="h-3 w-3" />
            <span>
              {new Date(typeof block.timestamp === 'string' ? Date.now() : block.timestamp).toLocaleString()}
            </span>
          </div>
          <Badge variant="outline">
            {transactionCount} {transactionCount === 1 ? 'transaction' : 'transactions'}
          </Badge>
        </CardDescription>
      </CardHeader>
      
      {isExpanded && (
        <CardContent className="pt-0">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Hash:</span>
                <div className="font-mono text-xs bg-muted p-2 rounded mt-1 break-all">
                  {block.hash}
                </div>
              </div>
              <div>
                <span className="font-medium">Previous Hash:</span>
                <div className="font-mono text-xs bg-muted p-2 rounded mt-1 break-all">
                  {block.previousHash}
                </div>
              </div>
              {block.nonce !== undefined && (
                <div>
                  <span className="font-medium">Nonce:</span>
                  <div className="font-mono text-sm">{block.nonce}</div>
                </div>
              )}
            </div>
            
            {transactions.length > 0 && (
              <div>
                <h4 className="font-medium mb-2">Transactions:</h4>
                <div className="space-y-2">
                  {transactions.map((tx, index) => (
                    <TransactionItem key={index} transaction={tx} />
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      )}
    </Card>
  );
}

interface TransactionItemProps {
  transaction: Transaction;
}

function TransactionItem({ transaction }: TransactionItemProps) {
  return (
    <div className="bg-muted/50 p-3 rounded-lg text-sm">
      <div className="flex items-center justify-between mb-2">
        <span className="font-medium">Amount: {transaction.amount} coins</span>
        {transaction.fromAddress === null ? (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
            Reward
          </Badge>
        ) : (
          <Badge variant="outline">Transfer</Badge>
        )}
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div>
          <span className="text-muted-foreground">From:</span>
          <div className="font-mono break-all">
            {transaction.fromAddress || 'System'}
          </div>
        </div>
        <div>
          <span className="text-muted-foreground">To:</span>
          <div className="font-mono break-all">
            {transaction.toAddress}
          </div>
        </div>
      </div>
      {transaction.timestamp && (
        <div className="mt-2 text-xs text-muted-foreground">
          {new Date(transaction.timestamp).toLocaleString()}
        </div>
      )}
    </div>
  );
}