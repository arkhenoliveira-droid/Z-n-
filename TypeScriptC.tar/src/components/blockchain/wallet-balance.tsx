'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Wallet, TrendingUp, TrendingDown } from 'lucide-react';

interface WalletBalanceProps {
  address: string;
  balance: number;
  transactions: number;
}

export function WalletBalance({ address, balance, transactions }: WalletBalanceProps) {
  const isPositive = balance > 0;
  const displayBalance = Math.abs(balance);

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center space-x-2">
          <Wallet className="h-5 w-5 text-blue-600" />
          <CardTitle className="text-lg">Wallet Balance</CardTitle>
        </div>
        <CardDescription>
          Address: {address.substring(0, 16)}...
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Balance:</span>
            <div className="flex items-center space-x-2">
              {isPositive ? (
                <TrendingUp className="h-4 w-4 text-green-600" />
              ) : (
                <TrendingDown className="h-4 w-4 text-red-600" />
              )}
              <span className={`text-2xl font-bold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
                {isPositive ? '+' : '-'}{displayBalance} coins
              </span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Transactions:</span>
            <Badge variant="outline">
              {transactions} {transactions === 1 ? 'transaction' : 'transactions'}
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}