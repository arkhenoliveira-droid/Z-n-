'use client';

import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Brain, 
  Zap, 
  Target, 
  Activity,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Minus
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface CoherenceMetrics {
  overall: number;
  quantum: number;
  system: number;
  interface: number;
  security: number;
  stability: number;
  efficiency: number;
}

interface CoherenceAlert {
  id: string;
  type: 'warning' | 'error' | 'info';
  message: string;
  timestamp: Date;
  resolved: boolean;
}

interface CoherenceDetectorProps {
  onCoherenceChange?: (metrics: CoherenceMetrics) => void;
  autoOptimize?: boolean;
}

export default function CoherenceDetector({ onCoherenceChange, autoOptimize = true }: CoherenceDetectorProps) {
  const [metrics, setMetrics] = useState<CoherenceMetrics>({
    overall: 87,
    quantum: 92,
    system: 85,
    interface: 88,
    security: 90,
    stability: 86,
    efficiency: 89
  });
  
  const [alerts, setAlerts] = useState<CoherenceAlert[]>([]);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [isRealTime, setIsRealTime] = useState(true);
  
  const optimizationInterval = useRef<NodeJS.Timeout | null>(null);
  const coherenceInterval = useRef<NodeJS.Timeout | null>(null);

  // Coherence calculation algorithms
  const calculateQuantumCoherence = (): number => {
    const time = Date.now() * 0.001;
    const baseCoherence = 92;
    const fluctuation = Math.sin(time * 0.1) * 3;
    const noise = (Math.random() - 0.5) * 2;
    
    return Math.max(0, Math.min(100, baseCoherence + fluctuation + noise));
  };

  const calculateSystemCoherence = (): number => {
    const time = Date.now() * 0.001;
    const baseCoherence = 85;
    const systemLoad = Math.sin(time * 0.05) * 5;
    const performance = Math.cos(time * 0.08) * 3;
    
    return Math.max(0, Math.min(100, baseCoherence + systemLoad + performance));
  };

  const calculateInterfaceCoherence = (): number => {
    const time = Date.now() * 0.001;
    const baseCoherence = 88;
    const userInteraction = Math.sin(time * 0.12) * 4;
    const responsiveness = Math.cos(time * 0.15) * 2;
    
    return Math.max(0, Math.min(100, baseCoherence + userInteraction + responsiveness));
  };

  const calculateSecurityCoherence = (): number => {
    const time = Date.now() * 0.001;
    const baseCoherence = 90;
    const threatLevel = Math.sin(time * 0.03) * 2;
    const encryptionStrength = Math.cos(time * 0.07) * 3;
    
    return Math.max(0, Math.min(100, baseCoherence + threatLevel + encryptionStrength));
  };

  const calculateStability = (): number => {
    const recentMetrics = [metrics.quantum, metrics.system, metrics.interface, metrics.security];
    const mean = recentMetrics.reduce((a, b) => a + b, 0) / recentMetrics.length;
    const variance = recentMetrics.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / recentMetrics.length;
    const standardDeviation = Math.sqrt(variance);
    
    // Higher stability = lower deviation
    return Math.max(0, 100 - (standardDeviation * 10));
  };

  const calculateEfficiency = (): number => {
    const coherenceFactors = [
      metrics.quantum * 0.3,
      metrics.system * 0.25,
      metrics.interface * 0.2,
      metrics.security * 0.15,
      metrics.stability * 0.1
    ];
    
    return coherenceFactors.reduce((a, b) => a + b, 0);
  };

  const updateMetrics = () => {
    const newMetrics: CoherenceMetrics = {
      quantum: calculateQuantumCoherence(),
      system: calculateSystemCoherence(),
      interface: calculateInterfaceCoherence(),
      security: calculateSecurityCoherence(),
      stability: calculateStability(),
      efficiency: calculateEfficiency(),
      overall: 0 // Will be calculated below
    };

    // Calculate overall coherence as weighted average
    newMetrics.overall = Math.round(
      (newMetrics.quantum * 0.35 +
       newMetrics.system * 0.25 +
       newMetrics.interface * 0.2 +
       newMetrics.security * 0.15 +
       newMetrics.stability * 0.05) * 100
    ) / 100;

    setMetrics(newMetrics);
    setLastUpdate(new Date());
    
    // Generate alerts based on coherence levels
    generateCoherenceAlerts(newMetrics);
    
    // Call parent callback if provided
    if (onCoherenceChange) {
      onCoherenceChange(newMetrics);
    }
  };

  const generateCoherenceAlerts = (currentMetrics: CoherenceMetrics) => {
    const newAlerts: CoherenceAlert[] = [];
    const timestamp = new Date();

    // Check for low coherence levels
    if (currentMetrics.overall < 80) {
      newAlerts.push({
        id: `low-overall-${timestamp.getTime()}`,
        type: 'warning',
        message: `Overall system coherence is low (${currentMetrics.overall}%)`,
        timestamp,
        resolved: false
      });
    }

    if (currentMetrics.quantum < 85) {
      newAlerts.push({
        id: `quantum-decoherence-${timestamp.getTime()}`,
        type: 'error',
        message: `Quantum decoherence detected (${currentMetrics.quantum}%)`,
        timestamp,
        resolved: false
      });
    }

    if (currentMetrics.stability < 75) {
      newAlerts.push({
        id: `instability-${timestamp.getTime()}`,
        type: 'warning',
        message: `System instability detected (${currentMetrics.stability}%)`,
        timestamp,
        resolved: false
      });
    }

    if (currentMetrics.efficiency < 80) {
      newAlerts.push({
        id: `low-efficiency-${timestamp.getTime()}`,
        type: 'info',
        message: `System efficiency below optimal (${currentMetrics.efficiency}%)`,
        timestamp,
        resolved: false
      });
    }

    // Check for rapid changes
    const previousMetrics = metrics;
    const overallChange = Math.abs(currentMetrics.overall - previousMetrics.overall);
    if (overallChange > 10) {
      newAlerts.push({
        id: `rapid-change-${timestamp.getTime()}`,
        type: 'warning',
        message: `Rapid coherence change detected (${overallChange > 0 ? '+' : ''}${overallChange.toFixed(1)}%)`,
        timestamp,
        resolved: false
      });
    }

    if (newAlerts.length > 0) {
      setAlerts(prev => [...prev, ...newAlerts]);
    }
  };

  const optimizeCoherence = async () => {
    setIsOptimizing(true);
    
    try {
      // Simulate quantum coherence optimization
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Apply optimization algorithms
      setMetrics(prev => ({
        ...prev,
        quantum: Math.min(100, prev.quantum + Math.random() * 8 + 2),
        system: Math.min(100, prev.system + Math.random() * 6 + 1),
        interface: Math.min(100, prev.interface + Math.random() * 5 + 1),
        security: Math.min(100, prev.security + Math.random() * 4 + 1),
        stability: Math.min(100, prev.stability + Math.random() * 7 + 2),
        efficiency: Math.min(100, prev.efficiency + Math.random() * 6 + 2)
      }));

      // Clear resolved alerts
      setAlerts(prev => prev.filter(alert => !alert.resolved));
      
      // Add optimization success alert
      setAlerts(prev => [...prev, {
        id: `optimization-success-${Date.now()}`,
        type: 'info',
        message: 'Quantum coherence optimization completed successfully',
        timestamp: new Date(),
        resolved: false
      }]);
      
    } catch (error) {
      console.error('Coherence optimization failed:', error);
      
      setAlerts(prev => [...prev, {
        id: `optimization-failed-${Date.now()}`,
        type: 'error',
        message: 'Coherence optimization failed',
        timestamp: new Date(),
        resolved: false
      }]);
    } finally {
      setIsOptimizing(false);
    }
  };

  const resolveAlert = (alertId: string) => {
    setAlerts(prev => 
      prev.map(alert => 
        alert.id === alertId ? { ...alert, resolved: true } : alert
      )
    );
  };

  const clearResolvedAlerts = () => {
    setAlerts(prev => prev.filter(alert => !alert.resolved));
  };

  const getCoherenceStatus = (score: number): { color: string; icon: React.ReactNode; text: string } => {
    if (score >= 90) {
      return { 
        color: 'text-green-600', 
        icon: <CheckCircle className="w-4 h-4" />, 
        text: 'Optimal' 
      };
    } else if (score >= 80) {
      return { 
        color: 'text-blue-600', 
        icon: <Target className="w-4 h-4" />, 
        text: 'Good' 
      };
    } else if (score >= 70) {
      return { 
        color: 'text-yellow-600', 
        icon: <Minus className="w-4 h-4" />, 
        text: 'Fair' 
      };
    } else {
      return { 
        color: 'text-red-600', 
        icon: <AlertTriangle className="w-4 h-4" />, 
        text: 'Critical' 
      };
    }
  };

  const getTrendIcon = (current: number, previous: number): React.ReactNode => {
    const difference = current - previous;
    if (Math.abs(difference) < 1) {
      return <Minus className="w-3 h-3 text-gray-500" />;
    } else if (difference > 0) {
      return <TrendingUp className="w-3 h-3 text-green-500" />;
    } else {
      return <TrendingDown className="w-3 h-3 text-red-500" />;
    }
  };

  // Initialize real-time monitoring
  useEffect(() => {
    if (isRealTime) {
      coherenceInterval.current = setInterval(updateMetrics, 3000);
      updateMetrics(); // Initial update
    }

    return () => {
      if (coherenceInterval.current) {
        clearInterval(coherenceInterval.current);
      }
    };
  }, [isRealTime]);

  // Auto-optimization when coherence drops below threshold
  useEffect(() => {
    if (autoOptimize && metrics.overall < 75 && !isOptimizing) {
      optimizationInterval.current = setTimeout(() => {
        optimizeCoherence();
      }, 5000);
    }

    return () => {
      if (optimizationInterval.current) {
        clearTimeout(optimizationInterval.current);
      }
    };
  }, [metrics.overall, autoOptimize, isOptimizing]);

  const overallStatus = getCoherenceStatus(metrics.overall);

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-600" />
            Quantum Coherence Detector
            <Badge variant={overallStatus.color === 'text-green-600' ? 'default' : 'secondary'}>
              {overallStatus.text}
            </Badge>
          </CardTitle>
          <CardDescription>
            Real-time quantum coherence monitoring and optimization • Coherent Operating System 1 (2025)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">
                  {metrics.overall}%
                </div>
                <div className="text-sm text-muted-foreground">Overall Coherence</div>
              </div>
              <div className="text-center">
                <div className="text-sm text-muted-foreground">
                  Last Update: {lastUpdate.toLocaleTimeString()}
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <Button
                    variant={isRealTime ? "default" : "outline"}
                    size="sm"
                    onClick={() => setIsRealTime(!isRealTime)}
                  >
                    {isRealTime ? 'Live' : 'Paused'}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={updateMetrics}
                  >
                    <RefreshCw className="w-3 h-3 mr-1" />
                    Refresh
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                onClick={optimizeCoherence}
                disabled={isOptimizing}
                size="sm"
              >
                {isOptimizing ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Zap className="w-4 h-4 mr-2" />
                )}
                Optimize Coherence
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={clearResolvedAlerts}
              >
                Clear Alerts
              </Button>
            </div>
          </div>
          
          <Progress value={metrics.overall} className="h-3" />
        </CardContent>
      </Card>

      {/* Detailed Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[
          { name: 'Quantum', value: metrics.quantum, icon: <Brain className="w-4 h-4" />, color: 'text-purple-600' },
          { name: 'System', value: metrics.system, icon: <Activity className="w-4 h-4" />, color: 'text-blue-600' },
          { name: 'Interface', value: metrics.interface, icon: <Target className="w-4 h-4" />, color: 'text-green-600' },
          { name: 'Security', value: metrics.security, icon: <Zap className="w-4 h-4" />, color: 'text-orange-600' },
          { name: 'Stability', value: metrics.stability, icon: <CheckCircle className="w-4 h-4" />, color: 'text-cyan-600' },
          { name: 'Efficiency', value: metrics.efficiency, icon: <TrendingUp className="w-4 h-4" />, color: 'text-indigo-600' }
        ].map((metric, index) => {
          const status = getCoherenceStatus(metric.value);
          const previousValue = metrics[metric.name.toLowerCase() as keyof CoherenceMetrics] as number;
          
          return (
            <Card key={index}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className={metric.color}>
                      {metric.icon}
                    </div>
                    <span className="font-medium">{metric.name}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {getTrendIcon(metric.value, previousValue)}
                    <span className={`text-sm ${status.color}`}>
                      {metric.value}%
                    </span>
                  </div>
                </div>
                <Progress value={metric.value} className="h-2" />
                <div className="flex items-center justify-between mt-2">
                  <div className={`flex items-center gap-1 text-xs ${status.color}`}>
                    {status.icon}
                    <span>{status.text}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {metric.value >= 90 ? 'Excellent' : metric.value >= 80 ? 'Good' : metric.value >= 70 ? 'Fair' : 'Needs Attention'}
                  </span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Alerts Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            Coherence Alerts
            <Badge variant="secondary">
              {alerts.filter(a => !a.resolved).length} Active
            </Badge>
          </CardTitle>
          <CardDescription>
            Real-time coherence monitoring alerts and notifications
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {alerts.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-500" />
                <p>No coherence alerts detected</p>
                <p className="text-sm">System coherence is optimal</p>
              </div>
            ) : (
              <AnimatePresence>
                {alerts.map((alert) => (
                  <motion.div
                    key={alert.id}
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Alert className={alert.resolved ? 'opacity-50' : ''}>
                      <AlertTriangle className={`w-4 h-4 ${
                        alert.type === 'error' ? 'text-red-500' : 
                        alert.type === 'warning' ? 'text-orange-500' : 
                        'text-blue-500'
                      }`} />
                      <AlertDescription className="flex items-center justify-between">
                        <div>
                          <span className="font-medium">{alert.message}</span>
                          <div className="text-xs text-muted-foreground mt-1">
                            {alert.timestamp.toLocaleTimeString()}
                          </div>
                        </div>
                        {!alert.resolved && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => resolveAlert(alert.id)}
                          >
                            Resolve
                          </Button>
                        )}
                      </AlertDescription>
                    </Alert>
                  </motion.div>
                ))}
              </AnimatePresence>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}