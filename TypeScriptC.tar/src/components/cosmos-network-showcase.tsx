'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { 
  Network, 
  Globe, 
  Shield, 
  Zap, 
  Database, 
  Layers, 
  Link, 
  Users,
  TrendingUp,
  BarChart3,
  Activity,
  Rocket,
  Star,
  CheckCircle,
  Clock,
  Coins,
  Cpu,
  HardDrive
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface CosmosMetrics {
  totalChains: number;
  activeValidators: number;
  totalTransactions: number;
  ibrStake: number;
  networkUptime: number;
  crossChainVolume: number;
}

interface ChainData {
  name: string;
  symbol: string;
  tvl: number;
  validators: number;
  transactions: number;
  status: 'active' | 'proposed' | 'deprecated';
}

interface ValidatorData {
  name: string;
  stake: number;
  commission: number;
  uptime: number;
  status: 'active' | 'jailed' | 'inactive';
}

export default function CosmosNetworkShowcase() {
  const [metrics, setMetrics] = useState<CosmosMetrics | null>(null);
  const [chains, setChains] = useState<ChainData[]>([]);
  const [validators, setValidators] = useState<ValidatorData[]>([]);
  const [selectedChain, setSelectedChain] = useState<string>('cosmos');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate API calls to get Cosmos Network data
    const loadCosmosData = async () => {
      setIsLoading(true);
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const mockMetrics: CosmosMetrics = {
        totalChains: 89,
        activeValidators: 12547,
        totalTransactions: 2847392847,
        ibrStake: 2.847,
        networkUptime: 99.95,
        crossChainVolume: 1547392847
      };
      
      const mockChains: ChainData[] = [
        {
          name: 'Cosmos Hub',
          symbol: 'ATOM',
          tvl: 2847392847,
          validators: 175,
          transactions: 2847392847,
          status: 'active'
        },
        {
          name: 'Osmosis',
          symbol: 'OSMO',
          tvl: 847392847,
          validators: 120,
          transactions: 847392847,
          status: 'active'
        },
        {
          name: 'Juno',
          symbol: 'JUNO',
          tvl: 284739284,
          validators: 85,
          transactions: 284739284,
          status: 'active'
        },
        {
          name: 'Secret Network',
          symbol: 'SCRT',
          tvl: 147392847,
          validators: 65,
          transactions: 147392847,
          status: 'active'
        },
        {
          name: 'Axelar',
          symbol: 'AXL',
          tvl: 84739284,
          validators: 45,
          transactions: 84739284,
          status: 'active'
        }
      ];
      
      const mockValidators: ValidatorData[] = [
        {
          name: 'Cosmostation',
          stake: 28473928,
          commission: 5,
          uptime: 99.99,
          status: 'active'
        },
        {
          name: 'Figment',
          stake: 21473928,
          commission: 7,
          uptime: 99.98,
          status: 'active'
        },
        {
          name: 'Stakefish',
          stake: 18473928,
          commission: 8,
          uptime: 99.97,
          status: 'active'
        },
        {
          name: 'Kraken',
          stake: 15473928,
          commission: 4,
          uptime: 99.99,
          status: 'active'
        },
        {
          name: 'Binance Staking',
          stake: 12473928,
          commission: 1,
          uptime: 99.95,
          status: 'active'
        }
      ];
      
      setMetrics(mockMetrics);
      setChains(mockChains);
      setValidators(mockValidators);
      setIsLoading(false);
    };
    
    loadCosmosData();
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'text-green-600 bg-green-100';
      case 'proposed':
        return 'text-yellow-600 bg-yellow-100';
      case 'deprecated':
        return 'text-red-600 bg-red-100';
      case 'jailed':
        return 'text-red-600 bg-red-100';
      case 'inactive':
        return 'text-gray-600 bg-gray-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000000) {
      return `$${(num / 1000000000).toFixed(2)}B`;
    } else if (num >= 1000000) {
      return `$${(num / 1000000).toFixed(2)}M`;
    } else if (num >= 1000) {
      return `$${(num / 1000).toFixed(2)}K`;
    }
    return `$${num}`;
  };

  const formatTransactions = (num: number) => {
    if (num >= 1000000000) {
      return `${(num / 1000000000).toFixed(1)}B`;
    } else if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Rocket className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-muted-foreground">Loading Cosmos Network data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="flex items-center justify-center gap-3 mb-4">
          <Network className="w-10 h-10 text-blue-600" />
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Cosmos Network Ecosystem
          </h1>
        </div>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          The Internet of Blockchains - Explore the revolutionary Cosmos ecosystem that enables 
          interoperable blockchains to scale and communicate with each other through IBC (Inter-Blockchain Communication).
        </p>
      </motion.div>

      {/* Key Metrics */}
      {metrics && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900 dark:to-purple-900">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Globe className="w-6 h-6 text-blue-600" />
                  <div>
                    <h3 className="font-semibold">Total Chains</h3>
                    <div className="text-2xl font-bold text-blue-600">{metrics.totalChains}</div>
                    <div className="text-sm text-muted-foreground">Active in ecosystem</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900 dark:to-emerald-900">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Users className="w-6 h-6 text-green-600" />
                  <div>
                    <h3 className="font-semibold">Active Validators</h3>
                    <div className="text-2xl font-bold text-green-600">{metrics.activeValidators.toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">Securing the network</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900 dark:to-pink-900">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Activity className="w-6 h-6 text-purple-600" />
                  <div>
                    <h3 className="font-semibold">Total Transactions</h3>
                    <div className="text-2xl font-bold text-purple-600">{formatTransactions(metrics.totalTransactions)}</div>
                    <div className="text-sm text-muted-foreground">Cross-chain transfers</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-900 dark:to-red-900">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <Coins className="w-6 h-6 text-orange-600" />
                  <div>
                    <h3 className="font-semibold">IBC Staked</h3>
                    <div className="text-2xl font-bold text-orange-600">{metrics.ibrStake}B ATOM</div>
                    <div className="text-sm text-muted-foreground">Total staked value</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      )}

      {/* Main Content Tabs */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="chains">Chains</TabsTrigger>
            <TabsTrigger value="validators">Validators</TabsTrigger>
            <TabsTrigger value="technology">Technology</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Network Health */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5" />
                    Network Health
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Network Uptime</span>
                      <span className="text-sm text-muted-foreground">{metrics?.networkUptime}%</span>
                    </div>
                    <Progress value={metrics?.networkUptime || 0} className="h-2" />
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">IBC Transactions</span>
                      <span className="text-sm text-muted-foreground">{formatTransactions(metrics?.crossChainVolume || 0)}</span>
                    </div>
                    <Progress value={85} className="h-2" />
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Validator Participation</span>
                      <span className="text-sm text-muted-foreground">92.3%</span>
                    </div>
                    <Progress value={92.3} className="h-2" />
                  </div>

                  <Separator />

                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div className="p-3 bg-blue-50 dark:bg-blue-900 rounded-lg">
                      <div className="text-lg font-bold text-blue-600">24/7</div>
                      <div className="text-xs text-muted-foreground">Network Operation</div>
                    </div>
                    <div className="p-3 bg-green-50 dark:bg-green-900 rounded-lg">
                      <div className="text-lg font-bold text-green-600">99.95%</div>
                      <div className="text-xs text-muted-foreground">SLA Uptime</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Key Features */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-5 h-5" />
                    Key Features
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Inter-Blockchain Communication (IBC)</h4>
                        <p className="text-sm text-muted-foreground">Secure cross-chain communication protocol</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Tendermint Consensus</h4>
                        <p className="text-sm text-muted-foreground">High-performance BFT consensus engine</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Cosmos SDK</h4>
                        <p className="text-sm text-muted-foreground">Modular framework for building blockchains</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Interoperability</h4>
                        <p className="text-sm text-muted-foreground">Seamless cross-chain asset transfers</p>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="text-center">
                    <Button className="w-full" asChild>
                      <a href="https://cosmos.network" target="_blank" rel="noopener noreferrer">
                        Explore Cosmos Network
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="chains" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Layers className="w-5 h-5" />
                  Active Chains in Ecosystem
                </CardTitle>
                <CardDescription>
                  Explore the diverse blockchains built on the Cosmos SDK
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {chains.map((chain, index) => (
                    <motion.div
                      key={chain.name}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Card className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                                <Coins className="w-5 h-5 text-white" />
                              </div>
                              <div>
                                <h3 className="font-semibold">{chain.name}</h3>
                                <p className="text-sm text-muted-foreground">{chain.symbol}</p>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-4">
                              <div className="text-right">
                                <div className="font-semibold">{formatNumber(chain.tvl)}</div>
                                <div className="text-xs text-muted-foreground">TVL</div>
                              </div>
                              
                              <div className="text-right">
                                <div className="font-semibold">{chain.validators}</div>
                                <div className="text-xs text-muted-foreground">Validators</div>
                              </div>
                              
                              <div className="text-right">
                                <div className="font-semibold">{formatTransactions(chain.transactions)}</div>
                                <div className="text-xs text-muted-foreground">Transactions</div>
                              </div>
                              
                              <Badge className={getStatusColor(chain.status)}>
                                {chain.status}
                              </Badge>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="validators" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Top Validators
                </CardTitle>
                <CardDescription>
                  Leading validators securing the Cosmos Network
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {validators.map((validator, index) => (
                    <motion.div
                      key={validator.name}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Card className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center">
                                <Shield className="w-5 h-5 text-white" />
                              </div>
                              <div>
                                <h3 className="font-semibold">{validator.name}</h3>
                                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                  <span>Commission: {validator.commission}%</span>
                                  <span>•</span>
                                  <span>Uptime: {validator.uptime}%</span>
                                </div>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-4">
                              <div className="text-right">
                                <div className="font-semibold">{formatNumber(validator.stake)}</div>
                                <div className="text-xs text-muted-foreground">Staked</div>
                              </div>
                              
                              <Badge className={getStatusColor(validator.status)}>
                                {validator.status}
                              </Badge>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="technology" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Technology Stack */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Cpu className="w-5 h-5" />
                    Technology Stack
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 dark:bg-blue-900 rounded-lg">
                      <h4 className="font-medium text-blue-600">Cosmos SDK</h4>
                      <p className="text-sm text-muted-foreground">Modular blockchain framework</p>
                    </div>
                    
                    <div className="p-3 bg-green-50 dark:bg-green-900 rounded-lg">
                      <h4 className="font-medium text-green-600">Tendermint Core</h4>
                      <p className="text-sm text-muted-foreground">BFT consensus engine</p>
                    </div>
                    
                    <div className="p-3 bg-purple-50 dark:bg-purple-900 rounded-lg">
                      <h4 className="font-medium text-purple-600">IBC Protocol</h4>
                      <p className="text-sm text-muted-foreground">Inter-blockchain communication</p>
                    </div>
                    
                    <div className="p-3 bg-orange-50 dark:bg-orange-900 rounded-lg">
                      <h4 className="font-medium text-orange-600">CosmWasm</h4>
                      <p className="text-sm text-muted-foreground">Smart contract platform</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Architecture */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <HardDrive className="w-5 h-5" />
                    Architecture
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                      <div>
                        <h4 className="font-medium">Hub-and-Spoke Model</h4>
                        <p className="text-sm text-muted-foreground">Central hub connecting specialized zones</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                      <div>
                        <h4 className="font-medium">Sovereign Blockchains</h4>
                        <p className="text-sm text-muted-foreground">Each chain maintains its own governance</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-purple-600 rounded-full mt-2"></div>
                      <div>
                        <h4 className="font-medium">Shared Security</h4>
                        <p className="text-sm text-muted-foreground">Optional security through validator sets</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-orange-600 rounded-full mt-2"></div>
                      <div>
                        <h4 className="font-medium">Cross-Chain Communication</h4>
                        <p className="text-sm text-muted-foreground">IBC enables seamless asset transfers</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}