'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Activity, 
  Brain,
  Zap,
  Target,
  Clock,
  RefreshCw,
  Download,
  Calendar,
  Filter,
  Shield
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAnalytics } from '@/hooks/use-analytics';

interface AnalyticsCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon: React.ReactNode;
  description: string;
}

const AnalyticsCard: React.FC<AnalyticsCardProps> = ({ 
  title, 
  value, 
  change, 
  changeType = 'neutral', 
  icon, 
  description 
}) => {
  const getChangeColor = () => {
    switch (changeType) {
      case 'positive': return 'text-green-600';
      case 'negative': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getChangeIcon = () => {
    switch (changeType) {
      case 'positive': return '📈';
      case 'negative': return '📉';
      default: return '➡️';
    }
  };

  return (
    <Card className="h-full">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
            {icon}
          </div>
          {change && (
            <div className={`flex items-center gap-1 text-sm ${getChangeColor()}`}>
              <span>{getChangeIcon()}</span>
              <span>{change}</span>
            </div>
          )}
        </div>
        
        <div className="space-y-2">
          <h3 className="text-2xl font-bold">{value}</h3>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
};

interface ChartData {
  name: string;
  value: number;
  color: string;
}

const MiniChart: React.FC<{ data: ChartData[]; title: string }> = ({ data, title }) => {
  const maxValue = Math.max(...data.map(d => d.value));
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {data.map((item, index) => (
            <div key={index} className="flex items-center gap-2">
              <div className="w-16 text-xs text-muted-foreground">{item.name}</div>
              <div className="flex-1">
                <div 
                  className="h-2 rounded-full transition-all duration-300"
                  style={{ 
                    width: `${(item.value / maxValue) * 100}%`,
                    backgroundColor: item.color 
                  }}
                />
              </div>
              <div className="w-8 text-xs text-right">{item.value}</div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default function SystemAnalyticsDashboard() {
  const {
    weeklyData,
    insights,
    summaryMetrics,
    isLoading,
    error,
    fetchAnalyticsData,
    getPersonalAnalytics,
    getTeamAnalytics,
    getTrendIcon,
    getTrendColor,
    formatFocusTime,
    getCoherenceStatus,
    getStressStatus,
    getProductivityStatus
  } = useAnalytics();

  const [selectedTimeRange, setSelectedTimeRange] = useState('week');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  const refreshData = async () => {
    setIsRefreshing(true);
    await fetchAnalyticsData();
    setIsRefreshing(false);
  };

  const handleTimeRangeChange = async (range: string) => {
    setSelectedTimeRange(range);
    // In a real implementation, this would fetch data for the selected time range
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">System Analytics</h2>
          <div className="flex items-center gap-2">
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span className="text-sm text-muted-foreground">Loading analytics...</span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-3">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                  <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                  <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-full"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Activity className="w-12 h-12 mx-auto mb-4 text-red-500" />
          <h3 className="text-lg font-semibold mb-2">Analytics Error</h3>
          <p className="text-muted-foreground mb-4">{error}</p>
          <Button onClick={refreshData} variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">System Analytics</h2>
          <p className="text-muted-foreground">
            Real-time system performance and usage analytics • Inspired by cryptographic pioneers like Hal Finney, Jameson Lopp, and Vitalik Buterin (vitalik.eth) • Coherent Operating System 1 (2025)
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Select value={selectedTimeRange} onValueChange={handleTimeRangeChange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="day">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="year">This Year</SelectItem>
            </SelectContent>
          </Select>
          
          <Button onClick={refreshData} variant="outline" size="sm" disabled={isRefreshing}>
            <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Summary Metrics */}
      {summaryMetrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <AnalyticsCard
            title="Coherence Score"
            value={`${summaryMetrics.dailyAverage.coherence}%`}
            change={getTrendIcon(summaryMetrics.weeklyTrends.coherence)}
            changeType={summaryMetrics.weeklyTrends.coherence === 'Improving' ? 'positive' : 'neutral'}
            icon={<Brain className="w-5 h-5 text-purple-600" />}
            description="System coherence level"
          />
          
          <AnalyticsCard
            title="Focus Time"
            value={formatFocusTime(summaryMetrics.dailyAverage.focusTime)}
            change={getTrendIcon(summaryMetrics.weeklyTrends.focusTime)}
            changeType={summaryMetrics.weeklyTrends.focusTime === 'Increasing' ? 'positive' : 'neutral'}
            icon={<Clock className="w-5 h-5 text-blue-600" />}
            description="Average daily focus duration"
          />
          
          <AnalyticsCard
            title="Stress Level"
            value={`${summaryMetrics.dailyAverage.stressLevel}%`}
            change={getTrendIcon(summaryMetrics.weeklyTrends.stressLevel)}
            changeType={summaryMetrics.weeklyTrends.stressLevel === 'Decreasing' ? 'positive' : 'negative'}
            icon={<Zap className="w-5 h-5 text-orange-600" />}
            description="System stress indicators"
          />
          
          <AnalyticsCard
            title="Productivity"
            value={`${summaryMetrics.dailyAverage.productivity}%`}
            change={getTrendIcon(summaryMetrics.weeklyTrends.productivity)}
            changeType={summaryMetrics.weeklyTrends.productivity === 'Excellent' ? 'positive' : 'neutral'}
            icon={<Target className="w-5 h-5 text-green-600" />}
            description="Overall productivity metrics"
          />
        </div>
      )}

      {/* Main Analytics Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="usage">Usage</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Weekly Performance Chart */}
            {weeklyData.length > 0 && (
              <MiniChart
                title="Weekly Coherence Performance"
                data={weeklyData.map(day => ({
                  name: day.day,
                  value: day.coherenceScore,
                  color: '#8b5cf6'
                }))}
              />
            )}
            
            {/* Focus Time Chart */}
            {weeklyData.length > 0 && (
              <MiniChart
                title="Daily Focus Time (hours)"
                data={weeklyData.map(day => ({
                  name: day.day,
                  value: day.focusTime,
                  color: '#3b82f6'
                }))}
              />
            )}
          </div>

          {/* Weekly Data Table */}
          {weeklyData.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Weekly Performance Summary</CardTitle>
                <CardDescription>Detailed breakdown of daily metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2">Day</th>
                        <th className="text-left p-2">Coherence</th>
                        <th className="text-left p-2">Focus Time</th>
                        <th className="text-left p-2">Stress Level</th>
                        <th className="text-left p-2">Productivity</th>
                      </tr>
                    </thead>
                    <tbody>
                      {weeklyData.map((day, index) => (
                        <tr key={index} className="border-b">
                          <td className="p-2 font-medium">{day.day}</td>
                          <td className="p-2">
                            <div className="flex items-center gap-2">
                              <span>{day.coherenceScore}%</span>
                              <Badge 
                                variant="outline" 
                                className={getCoherenceStatus(day.coherenceScore).color}
                              >
                                {getCoherenceStatus(day.coherenceScore).text}
                              </Badge>
                            </div>
                          </td>
                          <td className="p-2">{formatFocusTime(day.focusTime)}</td>
                          <td className="p-2">
                            <div className="flex items-center gap-2">
                              <span>{day.stressLevel}%</span>
                              <Badge 
                                variant="outline" 
                                className={getStressStatus(day.stressLevel).color}
                              >
                                {getStressStatus(day.stressLevel).text}
                              </Badge>
                            </div>
                          </td>
                          <td className="p-2">
                            <div className="flex items-center gap-2">
                              <span>{day.productivity}%</span>
                              <Badge 
                                variant="outline" 
                                className={getProductivityStatus(day.productivity).color}
                              >
                                {getProductivityStatus(day.productivity).text}
                              </Badge>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>System Performance Metrics</CardTitle>
                <CardDescription>Real-time performance indicators</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>API Response Time</span>
                    <span className="text-green-600">145ms</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Memory Usage</span>
                    <span className="text-blue-600">67%</span>
                  </div>
                  <Progress value={67} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>CPU Utilization</span>
                    <span className="text-yellow-600">42%</span>
                  </div>
                  <Progress value={42} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Network Latency</span>
                    <span className="text-green-600">23ms</span>
                  </div>
                  <Progress value={92} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Coherence Analysis</CardTitle>
                <CardDescription>Quantum coherence measurements</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Quantum Coherence</span>
                    <span className="text-purple-600">87%</span>
                  </div>
                  <Progress value={87} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Entanglement Strength</span>
                    <span className="text-blue-600">92%</span>
                  </div>
                  <Progress value={92} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Superposition Stability</span>
                    <span className="text-green-600">78%</span>
                  </div>
                  <Progress value={78} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Decoherence Rate</span>
                    <span className="text-orange-600">3.2%</span>
                  </div>
                  <Progress value={97} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-green-600" />
                  Jameson Lopp Security Metrics
                </CardTitle>
                <CardDescription>
                  Node operation and security health indicators
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Node Uptime</span>
                    <span className="text-green-600">99.9%</span>
                  </div>
                  <Progress value={99.9} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Security Score</span>
                    <span className="text-blue-600">94/100</span>
                  </div>
                  <Progress value={94} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Network Health</span>
                    <span className="text-green-600">Excellent</span>
                  </div>
                  <Progress value={96} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Threat Detection</span>
                    <span className="text-orange-600">Active</span>
                  </div>
                  <Progress value={88} className="h-2" />
                </div>
                
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <p className="text-xs text-blue-700 dark:text-blue-300">
                    💡 Security metrics inspired by Jameson Lopp's Bitcoin node monitoring best practices
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-purple-600" />
                  Vitalik Buterin Ethereum Metrics
                </CardTitle>
                <CardDescription>
                  Smart contract and Ethereum ecosystem performance indicators
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Smart Contract Deployments</span>
                    <span className="text-purple-600">1,247</span>
                  </div>
                  <Progress value={87} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Gas Optimization Score</span>
                    <span className="text-blue-600">92/100</span>
                  </div>
                  <Progress value={92} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>DeFi Protocol Health</span>
                    <span className="text-green-600">Excellent</span>
                  </div>
                  <Progress value={95} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Network Scalability</span>
                    <span className="text-orange-600">Improving</span>
                  </div>
                  <Progress value={78} className="h-2" />
                </div>
                
                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <p className="text-xs text-purple-700 dark:text-purple-300">
                    💡 Ethereum metrics inspired by Vitalik Buterin's (vitalik.eth) vision for scalable smart contracts
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="usage" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <AnalyticsCard
              title="Active Users"
              value="1,247"
              change="+12%"
              changeType="positive"
              icon={<Users className="w-5 h-5 text-green-600" />}
              description="Currently active users"
            />
            
            <AnalyticsCard
              title="API Calls"
              value="45.2K"
              change="+8%"
              changeType="positive"
              icon={<Activity className="w-5 h-5 text-blue-600" />}
              description="API calls this month"
            />
            
            <AnalyticsCard
              title="Sessions"
              value="3,891"
              change="+15%"
              changeType="positive"
              icon={<Calendar className="w-5 h-5 text-purple-600" />}
              description="Active sessions"
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Usage Patterns</CardTitle>
              <CardDescription>User behavior and system usage trends</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-medium">Peak Usage Hours</h4>
                  <div className="space-y-2">
                    {['9-11 AM', '2-4 PM', '7-9 PM'].map((time, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm">{time}</span>
                        <div className="flex items-center gap-2">
                          <Progress value={[85, 92, 78][index]} className="w-20 h-2" />
                          <span className="text-xs text-muted-foreground">{[85, 92, 78][index]}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-medium">Feature Usage</h4>
                  <div className="space-y-2">
                    {['Autocoder', 'Analytics', 'Settings', 'Language'].map((feature, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm">{feature}</span>
                        <div className="flex items-center gap-2">
                          <Progress value={[78, 65, 45, 88][index]} className="w-20 h-2" />
                          <span className="text-xs text-muted-foreground">{[78, 65, 45, 88][index]}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          {insights.map((category, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle>{category.category}</CardTitle>
                <CardDescription>AI-powered insights and recommendations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {category.insights.map((insight, insightIndex) => (
                    <div key={insightIndex} className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <Brain className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                      <p className="text-sm">{insight}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}