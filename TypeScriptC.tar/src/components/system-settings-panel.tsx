'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { 
  Settings, 
  Brain, 
  Globe, 
  Shield, 
  Zap,
  Target,
  Monitor,
  Bell,
  Database,
  Palette,
  Save,
  RotateCcw,
  Download,
  Upload,
  CheckCircle,
  AlertCircle,
  Info,
  Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import CoherenceDetector from '@/components/coherence-detector';

interface SystemSettings {
  general: {
    systemName: string;
    coherenceThreshold: number;
    autoUpdate: boolean;
    telemetryEnabled: boolean;
    debugMode: boolean;
  };
  performance: {
    maxMemoryUsage: number;
    cpuPriority: 'low' | 'normal' | 'high';
    cacheSize: number;
    compressionEnabled: boolean;
    parallelProcessing: boolean;
  };
  quantum: {
    quantumCoherence: number;
    entanglementStrength: number;
    superpositionStability: number;
    decoherenceRate: number;
    quantumAlgorithm: 'standard' | 'advanced' | 'experimental';
  };
  interface: {
    theme: 'light' | 'dark' | 'auto';
    language: string;
    animations: boolean;
    compactMode: boolean;
    highContrast: boolean;
  };
  security: {
    encryptionLevel: 'standard' | 'enhanced' | 'maximum';
    twoFactorAuth: boolean;
    sessionTimeout: number;
    auditLogging: boolean;
    ipWhitelist: string[];
  };
  notifications: {
    emailNotifications: boolean;
    pushNotifications: boolean;
    systemAlerts: boolean;
    coherenceWarnings: boolean;
    updateNotifications: boolean;
  };
}

const defaultSettings: SystemSettings = {
  general: {
    systemName: 'Coherent Operating System 1 (2025)',
    coherenceThreshold: 75,
    autoUpdate: true,
    telemetryEnabled: true,
    debugMode: false
  },
  performance: {
    maxMemoryUsage: 80,
    cpuPriority: 'normal',
    cacheSize: 1024,
    compressionEnabled: true,
    parallelProcessing: true
  },
  quantum: {
    quantumCoherence: 87,
    entanglementStrength: 92,
    superpositionStability: 78,
    decoherenceRate: 3.2,
    quantumAlgorithm: 'advanced'
  },
  interface: {
    theme: 'auto',
    language: 'en',
    animations: true,
    compactMode: false,
    highContrast: false
  },
  security: {
    encryptionLevel: 'enhanced',
    twoFactorAuth: true,
    sessionTimeout: 30,
    auditLogging: true,
    ipWhitelist: []
  },
  notifications: {
    emailNotifications: true,
    pushNotifications: true,
    systemAlerts: true,
    coherenceWarnings: true,
    updateNotifications: true
  }
};

interface SettingsSectionProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

const SettingsSection: React.FC<SettingsSectionProps> = ({ title, description, icon, children }) => (
  <div className="space-y-4">
    <div className="flex items-center gap-3">
      <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
        {icon}
      </div>
      <div>
        <h3 className="text-lg font-semibold">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
    <div className="pl-11">
      {children}
    </div>
  </div>
);

interface SettingItemProps {
  label: string;
  description?: string;
  children: React.ReactNode;
}

const SettingItem: React.FC<SettingItemProps> = ({ label, description, children }) => (
  <div className="flex items-center justify-between py-3 border-b border-border last:border-b-0">
    <div className="flex-1">
      <div className="font-medium">{label}</div>
      {description && (
        <div className="text-sm text-muted-foreground">{description}</div>
      )}
    </div>
    <div className="ml-4">
      {children}
    </div>
  </div>
);

export default function SystemSettingsPanel() {
  const [settings, setSettings] = useState<SystemSettings>(defaultSettings);
  const [hasChanges, setHasChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('general');
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success' | 'error'>('idle');

  // Load settings from API and localStorage on mount
  useEffect(() => {
    const loadSettings = async () => {
      try {
        // Try to load from API first
        const response = await fetch('/api/settings');
        const result = await response.json();

        if (result.success) {
          setSettings({ ...defaultSettings, ...result.data });
        } else {
          throw new Error(result.error || 'Failed to load settings from API');
        }
      } catch (error) {
        console.warn('Failed to load settings from API, falling back to localStorage:', error);
        
        // Fallback to localStorage
        const savedSettings = localStorage.getItem('systemSettings');
        if (savedSettings) {
          try {
            const parsed = JSON.parse(savedSettings);
            setSettings({ ...defaultSettings, ...parsed });
          } catch (parseError) {
            console.error('Failed to parse saved settings:', parseError);
          }
        }
      }
    };

    loadSettings();
  }, []);

  const updateSetting = (category: keyof SystemSettings, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value
      }
    }));
    setHasChanges(true);
  };

  const saveSettings = async () => {
    setIsSaving(true);
    setSaveStatus('saving');
    
    try {
      // Save to API
      const response = await fetch('/api/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ settings }),
      });

      const result = await response.json();

      if (result.success) {
        // Also save to localStorage as backup
        localStorage.setItem('systemSettings', JSON.stringify(settings));
        
        setSaveStatus('success');
        setHasChanges(false);
        
        // Reset status after 3 seconds
        setTimeout(() => setSaveStatus('idle'), 3000);
      } else {
        throw new Error(result.error || 'Failed to save settings');
      }
    } catch (error) {
      console.error('Failed to save settings:', error);
      setSaveStatus('error');
      
      // Fallback to localStorage
      localStorage.setItem('systemSettings', JSON.stringify(settings));
      setHasChanges(false);
      
      setTimeout(() => setSaveStatus('idle'), 3000);
    } finally {
      setIsSaving(false);
    }
  };

  const saveCategorySettings = async (category: keyof SystemSettings) => {
    try {
      const response = await fetch('/api/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          category, 
          settings: settings[category] 
        }),
      });

      const result = await response.json();

      if (!result.success) {
        console.error(`Failed to save ${category} settings:`, result.error);
        // Fallback to localStorage
        localStorage.setItem('systemSettings', JSON.stringify(settings));
      }
    } catch (error) {
      console.error(`Failed to save ${category} settings:`, error);
      // Fallback to localStorage
      localStorage.setItem('systemSettings', JSON.stringify(settings));
    }
  };

  const resetSettings = async () => {
    try {
      const response = await fetch('/api/settings', {
        method: 'DELETE',
      });

      const result = await response.json();

      if (result.success) {
        setSettings(defaultSettings);
        setHasChanges(true);
      } else {
        throw new Error(result.error || 'Failed to reset settings');
      }
    } catch (error) {
      console.error('Failed to reset settings:', error);
      // Fallback to local reset
      setSettings(defaultSettings);
      setHasChanges(true);
    }
  };

  const exportSettings = () => {
    const dataStr = JSON.stringify(settings, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'system-settings.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  const importSettings = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const imported = JSON.parse(e.target?.result as string);
          setSettings({ ...defaultSettings, ...imported });
          setHasChanges(true);
        } catch (error) {
          console.error('Failed to import settings:', error);
        }
      };
      reader.readAsText(file);
    }
  };

  const getStatusIcon = () => {
    switch (saveStatus) {
      case 'saving': return <RotateCcw className="w-4 h-4 animate-spin" />;
      case 'success': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'error': return <AlertCircle className="w-4 h-4 text-red-600" />;
      default: return <Save className="w-4 h-4" />;
    }
  };

  const getStatusText = () => {
    switch (saveStatus) {
      case 'saving': return 'Saving...';
      case 'success': return 'Saved!';
      case 'error': return 'Error!';
      default: return 'Save Changes';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">System Settings</h2>
          <p className="text-muted-foreground">
            Configure system preferences and behavior • Inspired by cryptographic pioneers like Hal Finney • Coherent Operating System 1 (2025)
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          {hasChanges && (
            <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
              Unsaved Changes
            </Badge>
          )}
          
          <Button onClick={resetSettings} variant="outline" size="sm">
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
          
          <Button onClick={exportSettings} variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          
          <label className="cursor-pointer">
            <Button variant="outline" size="sm" asChild>
              <span>
                <Upload className="w-4 h-4 mr-2" />
                Import
              </span>
            </Button>
            <input
              type="file"
              accept=".json"
              onChange={importSettings}
              className="hidden"
            />
          </label>
          
          <Button 
            onClick={saveSettings} 
            disabled={!hasChanges || isSaving}
            size="sm"
          >
            {getStatusIcon()}
            <span className="ml-2">{getStatusText()}</span>
          </Button>
        </div>
      </div>

      {/* Settings Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="quantum">Quantum</TabsTrigger>
          <TabsTrigger value="interface">Interface</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="coherence">Coherence</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <SettingsSection
            title="System Configuration"
            description="Basic system settings and preferences"
            icon={<Settings className="w-5 h-5 text-blue-600" />}
          >
            <div className="space-y-1 border rounded-lg">
              <SettingItem
                label="System Name"
                description="The name of your Coherent Operating System"
              >
                <Input
                  value={settings.general.systemName}
                  onChange={(e) => updateSetting('general', 'systemName', e.target.value)}
                  className="w-80"
                />
              </SettingItem>
              
              <SettingItem
                label="Coherence Threshold"
                description="Minimum coherence level for system operations"
              >
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.general.coherenceThreshold}
                    onChange={(e) => updateSetting('general', 'coherenceThreshold', parseInt(e.target.value))}
                    className="w-20"
                    min="0"
                    max="100"
                  />
                  <span className="text-sm text-muted-foreground">%</span>
                </div>
              </SettingItem>
              
              <SettingItem
                label="Auto Update"
                description="Automatically update system components"
              >
                <Switch
                  checked={settings.general.autoUpdate}
                  onCheckedChange={(checked) => updateSetting('general', 'autoUpdate', checked)}
                />
              </SettingItem>
              
              <SettingItem
                label="Telemetry"
                description="Share anonymous usage data to improve the system"
              >
                <Switch
                  checked={settings.general.telemetryEnabled}
                  onCheckedChange={(checked) => updateSetting('general', 'telemetryEnabled', checked)}
                />
              </SettingItem>
              
              <SettingItem
                label="Debug Mode"
                description="Enable debug logging and advanced diagnostics"
              >
                <Switch
                  checked={settings.general.debugMode}
                  onCheckedChange={(checked) => updateSetting('general', 'debugMode', checked)}
                />
              </SettingItem>
            </div>
          </SettingsSection>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <SettingsSection
            title="Performance Optimization"
            description="Configure system performance and resource allocation"
            icon={<Zap className="w-5 h-5 text-orange-600" />}
          >
            <div className="space-y-1 border rounded-lg">
              <SettingItem
                label="Max Memory Usage"
                description="Maximum memory allocation for system processes"
              >
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.performance.maxMemoryUsage}
                    onChange={(e) => updateSetting('performance', 'maxMemoryUsage', parseInt(e.target.value))}
                    className="w-20"
                    min="10"
                    max="100"
                  />
                  <span className="text-sm text-muted-foreground">%</span>
                </div>
              </SettingItem>
              
              <SettingItem
                label="CPU Priority"
                description="Process priority level for system operations"
              >
                <Select
                  value={settings.performance.cpuPriority}
                  onValueChange={(value) => updateSetting('performance', 'cpuPriority', value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </SettingItem>
              
              <SettingItem
                label="Cache Size"
                description="System cache size in megabytes"
              >
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.performance.cacheSize}
                    onChange={(e) => updateSetting('performance', 'cacheSize', parseInt(e.target.value))}
                    className="w-20"
                    min="128"
                    max="8192"
                  />
                  <span className="text-sm text-muted-foreground">MB</span>
                </div>
              </SettingItem>
              
              <SettingItem
                label="Compression"
                description="Enable data compression for storage optimization"
              >
                <Switch
                  checked={settings.performance.compressionEnabled}
                  onCheckedChange={(checked) => updateSetting('performance', 'compressionEnabled', checked)}
                />
              </SettingItem>
              
              <SettingItem
                label="Parallel Processing"
                description="Enable parallel processing for improved performance"
              >
                <Switch
                  checked={settings.performance.parallelProcessing}
                  onCheckedChange={(checked) => updateSetting('performance', 'parallelProcessing', checked)}
                />
              </SettingItem>
            </div>
          </SettingsSection>
        </TabsContent>

        <TabsContent value="quantum" className="space-y-6">
          <SettingsSection
            title="Quantum Configuration"
            description="Advanced quantum system parameters and algorithms"
            icon={<Brain className="w-5 h-5 text-purple-600" />}
          >
            <div className="space-y-1 border rounded-lg">
              <SettingItem
                label="Quantum Coherence"
                description="Base quantum coherence level"
              >
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.quantum.quantumCoherence}
                    onChange={(e) => updateSetting('quantum', 'quantumCoherence', parseFloat(e.target.value))}
                    className="w-20"
                    min="0"
                    max="100"
                    step="0.1"
                  />
                  <span className="text-sm text-muted-foreground">%</span>
                </div>
              </SettingItem>
              
              <SettingItem
                label="Entanglement Strength"
                description="Quantum entanglement measurement strength"
              >
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.quantum.entanglementStrength}
                    onChange={(e) => updateSetting('quantum', 'entanglementStrength', parseFloat(e.target.value))}
                    className="w-20"
                    min="0"
                    max="100"
                    step="0.1"
                  />
                  <span className="text-sm text-muted-foreground">%</span>
                </div>
              </SettingItem>
              
              <SettingItem
                label="Superposition Stability"
                description="Quantum superposition state stability"
              >
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.quantum.superpositionStability}
                    onChange={(e) => updateSetting('quantum', 'superpositionStability', parseFloat(e.target.value))}
                    className="w-20"
                    min="0"
                    max="100"
                    step="0.1"
                  />
                  <span className="text-sm text-muted-foreground">%</span>
                </div>
              </SettingItem>
              
              <SettingItem
                label="Decoherence Rate"
                description="Quantum decoherence rate percentage"
              >
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.quantum.decoherenceRate}
                    onChange={(e) => updateSetting('quantum', 'decoherenceRate', parseFloat(e.target.value))}
                    className="w-20"
                    min="0"
                    max="50"
                    step="0.1"
                  />
                  <span className="text-sm text-muted-foreground">%</span>
                </div>
              </SettingItem>
              
              <SettingItem
                label="Quantum Algorithm"
                description="Quantum processing algorithm type"
              >
                <Select
                  value={settings.quantum.quantumAlgorithm}
                  onValueChange={(value) => updateSetting('quantum', 'quantumAlgorithm', value)}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                    <SelectItem value="experimental">Experimental</SelectItem>
                  </SelectContent>
                </Select>
              </SettingItem>
            </div>
          </SettingsSection>
        </TabsContent>

        <TabsContent value="interface" className="space-y-6">
          <SettingsSection
            title="Interface Preferences"
            description="Customize the user interface and display settings"
            icon={<Monitor className="w-5 h-5 text-green-600" />}
          >
            <div className="space-y-1 border rounded-lg">
              <SettingItem
                label="Theme"
                description="Choose the interface theme"
              >
                <Select
                  value={settings.interface.theme}
                  onValueChange={(value) => updateSetting('interface', 'theme', value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="auto">Auto</SelectItem>
                  </SelectContent>
                </Select>
              </SettingItem>
              
              <SettingItem
                label="Language"
                description="Interface display language"
              >
                <Select
                  value={settings.interface.language}
                  onValueChange={(value) => updateSetting('interface', 'language', value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="pt">Português</SelectItem>
                    <SelectItem value="es">Español</SelectItem>
                  </SelectContent>
                </Select>
              </SettingItem>
              
              <SettingItem
                label="Animations"
                description="Enable interface animations and transitions"
              >
                <Switch
                  checked={settings.interface.animations}
                  onCheckedChange={(checked) => updateSetting('interface', 'animations', checked)}
                />
              </SettingItem>
              
              <SettingItem
                label="Compact Mode"
                description="Use compact interface layout"
              >
                <Switch
                  checked={settings.interface.compactMode}
                  onCheckedChange={(checked) => updateSetting('interface', 'compactMode', checked)}
                />
              </SettingItem>
              
              <SettingItem
                label="High Contrast"
                description="Enable high contrast mode for better visibility"
              >
                <Switch
                  checked={settings.interface.highContrast}
                  onCheckedChange={(checked) => updateSetting('interface', 'highContrast', checked)}
                />
              </SettingItem>
            </div>
          </SettingsSection>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <SettingsSection
            title="Security Settings"
            description="Configure system security and access controls"
            icon={<Shield className="w-5 h-5 text-red-600" />}
          >
            <div className="space-y-1 border rounded-lg">
              <SettingItem
                label="Encryption Level"
                description="Data encryption strength"
              >
                <Select
                  value={settings.security.encryptionLevel}
                  onValueChange={(value) => updateSetting('security', 'encryptionLevel', value)}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="enhanced">Enhanced</SelectItem>
                    <SelectItem value="maximum">Maximum</SelectItem>
                  </SelectContent>
                </Select>
              </SettingItem>
              
              <SettingItem
                label="Two-Factor Authentication"
                description="Enable 2FA for additional security"
              >
                <Switch
                  checked={settings.security.twoFactorAuth}
                  onCheckedChange={(checked) => updateSetting('security', 'twoFactorAuth', checked)}
                />
              </SettingItem>
              
              <SettingItem
                label="Session Timeout"
                description="Automatic session timeout in minutes"
              >
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={settings.security.sessionTimeout}
                    onChange={(e) => updateSetting('security', 'sessionTimeout', parseInt(e.target.value))}
                    className="w-20"
                    min="5"
                    max="480"
                  />
                  <span className="text-sm text-muted-foreground">minutes</span>
                </div>
              </SettingItem>
              
              <SettingItem
                label="Audit Logging"
                description="Enable detailed security audit logging"
              >
                <Switch
                  checked={settings.security.auditLogging}
                  onCheckedChange={(checked) => updateSetting('security', 'auditLogging', checked)}
                />
              </SettingItem>
            </div>
          </SettingsSection>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <SettingsSection
            title="Notification Preferences"
            description="Configure system notifications and alerts"
            icon={<Bell className="w-5 h-5 text-yellow-600" />}
          >
            <div className="space-y-1 border rounded-lg">
              <SettingItem
                label="Email Notifications"
                description="Receive notifications via email"
              >
                <Switch
                  checked={settings.notifications.emailNotifications}
                  onCheckedChange={(checked) => updateSetting('notifications', 'emailNotifications', checked)}
                />
              </SettingItem>
              
              <SettingItem
                label="Push Notifications"
                description="Enable browser push notifications"
              >
                <Switch
                  checked={settings.notifications.pushNotifications}
                  onCheckedChange={(checked) => updateSetting('notifications', 'pushNotifications', checked)}
                />
              </SettingItem>
              
              <SettingItem
                label="System Alerts"
                description="Receive critical system alerts"
              >
                <Switch
                  checked={settings.notifications.systemAlerts}
                  onCheckedChange={(checked) => updateSetting('notifications', 'systemAlerts', checked)}
                />
              </SettingItem>
              
              <SettingItem
                label="Coherence Warnings"
                description="Get notified when coherence levels drop"
              >
                <Switch
                  checked={settings.notifications.coherenceWarnings}
                  onCheckedChange={(checked) => updateSetting('notifications', 'coherenceWarnings', checked)}
                />
              </SettingItem>
              
              <SettingItem
                label="Update Notifications"
                description="Receive notifications about system updates"
              >
                <Switch
                  checked={settings.notifications.updateNotifications}
                  onCheckedChange={(checked) => updateSetting('notifications', 'updateNotifications', checked)}
                />
              </SettingItem>
            </div>
          </SettingsSection>
        </TabsContent>
        
        <TabsContent value="coherence" className="space-y-6">
          <SettingsSection
            title="Quantum Coherence Management"
            description="Real-time coherence monitoring and optimization"
            icon={<Activity className="w-5 h-5 text-purple-600" />}
          >
            <CoherenceDetector 
              onCoherenceChange={(metrics) => {
                // Auto-adjust settings based on coherence levels
                if (metrics.overall < 80) {
                  // Optimize quantum settings when coherence is low
                  updateSetting('quantum', 'quantumCoherence', Math.min(100, metrics.quantum + 5));
                  updateSetting('quantum', 'entanglementStrength', Math.min(100, metrics.overall + 3));
                }
              }}
              autoOptimize={settings.notifications.coherenceWarnings}
            />
          </SettingsSection>
        </TabsContent>
      </Tabs>
    </div>
  );
}