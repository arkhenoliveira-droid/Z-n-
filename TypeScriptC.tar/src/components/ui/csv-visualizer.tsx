'use client';

import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { 
  ScatterChart, 
  Scatter, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Area,
  AreaChart
} from 'recharts';
import { 
  Upload, 
  FileText, 
  BarChart3, 
  PieChart as PieIcon, 
  TrendingUp,
  Download,
  Eye,
  AlertCircle,
  CheckCircle,
  X,
  Table,
  Calendar
} from 'lucide-react';
import Papa from 'papaparse';

interface DataRow {
  [key: string]: any;
}

interface ColumnInfo {
  name: string;
  type: 'number' | 'string' | 'date';
  unique: number;
  nulls: number;
}

interface CSVVisualizerProps {
  className?: string;
}

const CSVVisualizer: React.FC<CSVVisualizerProps> = ({ className }) => {
  const [data, setData] = useState<DataRow[]>([]);
  const [columns, setColumns] = useState<ColumnInfo[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedColumns, setSelectedColumns] = useState<{ x: string; y: string }>({ x: '', y: '' });
  const [fileName, setFileName] = useState<string>('');

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    setError(null);
    setFileName(file.name);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        try {
          const parsedData = results.data as DataRow[];
          
          if (parsedData.length === 0) {
            setError('No data found in the CSV file.');
            setIsLoading(false);
            return;
          }

          // Analyze columns
          const columnInfo: ColumnInfo[] = Object.keys(parsedData[0]).map(colName => {
            const values = parsedData.map(row => row[colName]);
            const unique = new Set(values).size;
            const nulls = values.filter(v => v === null || v === undefined || v === '').length;
            
            // Determine column type
            let type: 'number' | 'string' | 'date' = 'string';
            const numberValues = values.filter(v => !isNaN(Number(v)) && v !== '').length;
            const dateValues = values.filter(v => !isNaN(Date.parse(v)) && v !== '').length;
            
            if (numberValues > values.length * 0.8) {
              type = 'number';
            } else if (dateValues > values.length * 0.8) {
              type = 'date';
            }

            return { name: colName, type, unique, nulls };
          });

          setData(parsedData);
          setColumns(columnInfo);
          
          // Auto-select first two numerical columns
          const numericalColumns = columnInfo.filter(col => col.type === 'number');
          if (numericalColumns.length >= 2) {
            setSelectedColumns({
              x: numericalColumns[0].name,
              y: numericalColumns[1].name
            });
          }

          setIsLoading(false);
        } catch (err) {
          setError(`Error parsing CSV: ${err instanceof Error ? err.message : 'Unknown error'}`);
          setIsLoading(false);
        }
      },
      error: (error) => {
        setError(`Error reading file: ${error.message}`);
        setIsLoading(false);
      }
    });
  }, []);

  const handleClearData = () => {
    setData([]);
    setColumns([]);
    setError(null);
    setSelectedColumns({ x: '', y: '' });
    setFileName('');
  };

  const exportToCSV = () => {
    if (data.length === 0) return;

    const csv = Papa.unparse(data);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `processed_${fileName || 'data.csv'}`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getNumericalColumns = () => columns.filter(col => col.type === 'number');
  const getCategoricalColumns = () => columns.filter(col => col.type === 'string');

  const prepareScatterData = () => {
    if (!selectedColumns.x || !selectedColumns.y) return [];
    return data.map(row => ({
      x: parseFloat(row[selectedColumns.x]) || 0,
      y: parseFloat(row[selectedColumns.y]) || 0
    })).filter(point => !isNaN(point.x) && !isNaN(point.y));
  };

  const prepareBarData = () => {
    const categoricalCols = getCategoricalColumns();
    if (categoricalCols.length === 0) return [];
    
    const col = categoricalCols[0].name;
    const counts = data.reduce((acc, row) => {
      const value = row[col] || 'Unknown';
      acc[value] = (acc[value] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(counts).map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10); // Top 10
  };

  const prepareLineData = () => {
    const numericalCols = getNumericalColumns();
    if (numericalCols.length === 0) return [];
    
    const col = numericalCols[0].name;
    return data.map((row, index) => ({
      index,
      value: parseFloat(row[col]) || 0
    })).filter(item => !isNaN(item.value));
  };

  const prepareHistogramData = (columnName: string, bins: number = 10) => {
    const values = data
      .map(row => parseFloat(row[columnName]))
      .filter(v => !isNaN(v));
    
    if (values.length === 0) return [];
    
    const min = Math.min(...values);
    const max = Math.max(...values);
    const binWidth = (max - min) / bins;
    
    const histogram = Array(bins).fill(0).map((_, i) => ({
      range: `${(min + i * binWidth).toFixed(1)}-${(min + (i + 1) * binWidth).toFixed(1)}`,
      count: 0,
      min: min + i * binWidth,
      max: min + (i + 1) * binWidth
    }));
    
    values.forEach(value => {
      const binIndex = Math.min(Math.floor((value - min) / binWidth), bins - 1);
      histogram[binIndex].count++;
    });
    
    return histogram;
  };

  if (isLoading) {
    return (
      <Card className={className}>
        <CardContent className="p-8">
          <div className="flex flex-col items-center space-y-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            <div className="text-center space-y-2">
              <p className="text-lg font-medium">Processing CSV file...</p>
              <p className="text-sm text-muted-foreground">This may take a moment for large files</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className={className}>
        <CardContent className="p-8">
          <div className="flex flex-col items-center space-y-4">
            <AlertCircle className="h-12 w-12 text-red-500" />
            <div className="text-center space-y-2">
              <p className="text-lg font-medium text-red-600">Error Processing File</p>
              <p className="text-sm text-muted-foreground">{error}</p>
            </div>
            <Button onClick={handleClearData} variant="outline">
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (data.length === 0) {
    return (
      <Card className={className}>
        <CardContent className="p-8">
          <div className="flex flex-col items-center space-y-6">
            <div className="p-4 bg-blue-50 rounded-full">
              <Upload className="h-8 w-8 text-blue-600" />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-lg font-medium">Upload CSV File</h3>
              <p className="text-sm text-muted-foreground">
                Upload a CSV file to visualize your data with interactive charts
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="csv-upload" className="sr-only">
                Upload CSV file
              </Label>
              <Input
                id="csv-upload"
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="cursor-pointer"
              />
            </div>
            <div className="text-xs text-muted-foreground">
              <p>Supported format: CSV files</p>
              <p>Maximum file size: 10MB</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const scatterData = prepareScatterData();
  const barData = prepareBarData();
  const lineData = prepareLineData();
  const numericalCols = getNumericalColumns();
  const categoricalCols = getCategoricalColumns();

  return (
    <div className={className}>
      {/* Header */}
      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5" />
                <span>Data Visualization</span>
                <Badge variant="outline">{fileName}</Badge>
              </CardTitle>
              <CardDescription>
                {data.length} rows • {columns.length} columns loaded
              </CardDescription>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" onClick={exportToCSV}>
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button variant="outline" size="sm" onClick={handleClearData}>
                <X className="w-4 h-4 mr-2" />
                Clear
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Column Information */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-lg">Data Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {columns.map((col, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">{col.name}</h4>
                  <Badge variant={
                    col.type === 'number' ? 'default' : 
                    col.type === 'date' ? 'secondary' : 'outline'
                  }>
                    {col.type}
                  </Badge>
                </div>
                <div className="space-y-1 text-sm text-muted-foreground">
                  <div>Unique values: {col.unique}</div>
                  <div>Null values: {col.nulls}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <Tabs defaultValue="scatter" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="scatter">Scatter Plot</TabsTrigger>
          <TabsTrigger value="histogram">Histogram</TabsTrigger>
          <TabsTrigger value="bar">Bar Chart</TabsTrigger>
          <TabsTrigger value="line">Line Chart</TabsTrigger>
        </TabsList>

        <TabsContent value="scatter" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Scatter Plot</CardTitle>
              <CardDescription>
                Relationship between two numerical variables
              </CardDescription>
            </CardHeader>
            <CardContent>
              {numericalCols.length >= 2 ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>X-Axis</Label>
                      <select
                        value={selectedColumns.x}
                        onChange={(e) => setSelectedColumns(prev => ({ ...prev, x: e.target.value }))}
                        className="w-full p-2 border rounded-md"
                      >
                        {numericalCols.map(col => (
                          <option key={col.name} value={col.name}>{col.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <Label>Y-Axis</Label>
                      <select
                        value={selectedColumns.y}
                        onChange={(e) => setSelectedColumns(prev => ({ ...prev, y: e.target.value }))}
                        className="w-full p-2 border rounded-md"
                      >
                        {numericalCols.map(col => (
                          <option key={col.name} value={col.name}>{col.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  
                  {scatterData.length > 0 && (
                    <div className="h-96">
                      <ResponsiveContainer width="100%" height="100%">
                        <ScatterChart data={scatterData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis 
                            type="number" 
                            dataKey="x" 
                            name={selectedColumns.x}
                          />
                          <YAxis 
                            type="number" 
                            dataKey="y" 
                            name={selectedColumns.y}
                          />
                          <Tooltip 
                            cursor={{ strokeDasharray: '3 3' }}
                            formatter={(value, name) => [value, name === 'x' ? selectedColumns.x : selectedColumns.y]}
                          />
                          <Scatter dataKey="y" fill="#8884d8" />
                        </ScatterChart>
                      </ResponsiveContainer>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BarChart3 className="h-12 w-12 mx-auto mb-4" />
                  <p>Need at least 2 numerical columns for scatter plot</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="histogram" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Histograms</CardTitle>
              <CardDescription>
                Distribution of numerical variables
              </CardDescription>
            </CardHeader>
            <CardContent>
              {numericalCols.length > 0 ? (
                <div className="space-y-8">
                  {numericalCols.map(col => {
                    const histData = prepareHistogramData(col.name);
                    return (
                      <div key={col.name} className="space-y-4">
                        <h4 className="font-medium">{col.name}</h4>
                        {histData.length > 0 && (
                          <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%">
                              <BarChart data={histData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="range" />
                                <YAxis />
                                <Tooltip />
                                <Bar dataKey="count" fill="#8884d8" />
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BarChart3 className="h-12 w-12 mx-auto mb-4" />
                  <p>No numerical columns found for histograms</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bar" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Bar Chart</CardTitle>
              <CardDescription>
                Distribution of categorical variables
              </CardDescription>
            </CardHeader>
            <CardContent>
              {categoricalCols.length > 0 ? (
                <div className="space-y-8">
                  {categoricalCols.slice(0, 3).map(col => {
                    const colData = data.reduce((acc, row) => {
                      const value = row[col.name] || 'Unknown';
                      acc[value] = (acc[value] || 0) + 1;
                      return acc;
                    }, {} as Record<string, number>);

                    const chartData = Object.entries(colData)
                      .map(([name, value]) => ({ name, value }))
                      .sort((a, b) => b.value - a.value)
                      .slice(0, 10);

                    return (
                      <div key={col.name} className="space-y-4">
                        <h4 className="font-medium">{col.name}</h4>
                        {chartData.length > 0 && (
                          <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%">
                              <BarChart data={chartData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="name" />
                                <YAxis />
                                <Tooltip />
                                <Bar dataKey="value" fill="#82ca9d" />
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <PieIcon className="h-12 w-12 mx-auto mb-4" />
                  <p>No categorical columns found for bar charts</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="line" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Line Chart</CardTitle>
              <CardDescription>
                Trends in numerical data over index
              </CardDescription>
            </CardHeader>
            <CardContent>
              {numericalCols.length > 0 ? (
                <div className="space-y-8">
                  {numericalCols.slice(0, 3).map(col => {
                    const chartData = prepareLineData();
                    return (
                      <div key={col.name} className="space-y-4">
                        <h4 className="font-medium">{col.name}</h4>
                        {chartData.length > 0 && (
                          <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%">
                              <LineChart data={chartData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="index" />
                                <YAxis />
                                <Tooltip />
                                <Line type="monotone" dataKey="value" stroke="#8884d8" strokeWidth={2} />
                              </LineChart>
                            </ResponsiveContainer>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <TrendingUp className="h-12 w-12 mx-auto mb-4" />
                  <p>No numerical columns found for line charts</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CSVVisualizer;