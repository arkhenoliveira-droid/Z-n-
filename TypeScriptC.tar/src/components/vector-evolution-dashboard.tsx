'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { 
  Brain, 
  Atom, 
  Network, 
  Shield, 
  Key, 
  Expand, 
  TrendingUp, 
  RefreshCw, 
  Play, 
  Pause,
  Zap,
  Activity,
  Target,
  Layers,
  Gauge,
  BarChart3,
  LineChart,
  PieChart
} from 'lucide-react';

interface VectorState {
  id: string;
  type: 'coherence' | 'quantum' | 'neural' | 'cryptographic' | 'security' | 'expansion';
  coordinates: number[];
  magnitude: number;
  phase: number;
  coherence: number;
  entropy: number;
  timestamp: number;
  metadata: Record<string, any>;
}

interface EvolutionMetrics {
  convergenceRate: number;
  stability: number;
  adaptability: number;
  efficiency: number;
  security: number;
  coherence: number;
}

interface BrainwalletAnalysis {
  passphrase: string;
  integrationScore: number;
  brainwalletVector: {
    id: string;
    type: string;
    coherence: number;
    entropy: number;
    magnitude: number;
  };
  connectivity: {
    toCryptographic: number;
    toSecurity: number;
    toQuantum: number;
  };
  recommendations: string[];
}

export default function VectorEvolutionDashboard() {
  const [vectors, setVectors] = useState<VectorState[]>([]);
  const [metrics, setMetrics] = useState<EvolutionMetrics | null>(null);
  const [isEvolving, setIsEvolving] = useState(false);
  const [evolutionHistory, setEvolutionHistory] = useState<VectorState[][]>([]);
  const [selectedVector, setSelectedVector] = useState<VectorState | null>(null);
  const [brainwalletPassphrase, setBrainwalletPassphrase] = useState('');
  const [brainwalletAnalysis, setBrainwalletAnalysis] = useState<BrainwalletAnalysis | null>(null);
  const [quantumResults, setQuantumResults] = useState<any>(null);
  const [neuralResults, setNeuralResults] = useState<any>(null);

  // Carregar dados iniciais
  useEffect(() => {
    loadSystemData();
  }, []);

  const loadSystemData = async () => {
    try {
      const [vectorsResponse, metricsResponse] = await Promise.all([
        fetch('/api/vector-evolution?action=vectors'),
        fetch('/api/vector-evolution?action=metrics')
      ]);

      if (vectorsResponse.ok) {
        const vectorsData = await vectorsResponse.json();
        setVectors(vectorsData.vectors);
      }

      if (metricsResponse.ok) {
        const metricsData = await metricsResponse.json();
        setMetrics(metricsData.metrics);
      }
    } catch (error) {
      console.error('Error loading system data:', error);
    }
  };

  const evolveSystem = async () => {
    setIsEvolving(true);
    try {
      const response = await fetch('/api/vector-evolution', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'evolve' }),
      });

      if (response.ok) {
        const data = await response.json();
        setMetrics(data.metrics);
        await loadSystemData();
      }
    } catch (error) {
      console.error('Error evolving system:', error);
    } finally {
      setIsEvolving(false);
    }
  };

  const optimizeSystem = async () => {
    try {
      const response = await fetch('/api/vector-evolution', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'optimize' }),
      });

      if (response.ok) {
        await loadSystemData();
      }
    } catch (error) {
      console.error('Error optimizing system:', error);
    }
  };

  const analyzeVector = async (vectorId: string) => {
    try {
      const response = await fetch('/api/vector-evolution', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          action: 'analyze', 
          data: { vectorId } 
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setSelectedVector(data.analysis.vector);
      }
    } catch (error) {
      console.error('Error analyzing vector:', error);
    }
  };

  const integrateBrainwallet = async () => {
    if (!brainwalletPassphrase.trim()) return;

    try {
      const response = await fetch('/api/vector-evolution', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          action: 'brainwallet-integration', 
          data: { passphrase: brainwalletPassphrase } 
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setBrainwalletAnalysis(data.brainwalletAnalysis);
        await loadSystemData();
      }
    } catch (error) {
      console.error('Error integrating brainwallet:', error);
    }
  };

  const applyQuantumEnhancement = async () => {
    try {
      const response = await fetch('/api/vector-evolution', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'quantum-enhancement' }),
      });

      if (response.ok) {
        const data = await response.json();
        setQuantumResults(data.quantumResults);
        await loadSystemData();
      }
    } catch (error) {
      console.error('Error applying quantum enhancement:', error);
    }
  };

  const applyNeuralExpansion = async () => {
    try {
      const response = await fetch('/api/vector-evolution', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'neural-expansion' }),
      });

      if (response.ok) {
        const data = await response.json();
        setNeuralResults(data.neuralResults);
        await loadSystemData();
      }
    } catch (error) {
      console.error('Error applying neural expansion:', error);
    }
  };

  const getVectorIcon = (type: string) => {
    switch (type) {
      case 'coherence': return <Brain className="w-5 h-5" />;
      case 'quantum': return <Atom className="w-5 h-5" />;
      case 'neural': return <Network className="w-5 h-5" />;
      case 'cryptographic': return <Key className="w-5 h-5" />;
      case 'security': return <Shield className="w-5 h-5" />;
      case 'expansion': return <Expand className="w-5 h-5" />;
      default: return <Activity className="w-5 h-5" />;
    }
  };

  const getVectorColor = (type: string) => {
    switch (type) {
      case 'coherence': return 'text-purple-600';
      case 'quantum': return 'text-blue-600';
      case 'neural': return 'text-green-600';
      case 'cryptographic': return 'text-yellow-600';
      case 'security': return 'text-red-600';
      case 'expansion': return 'text-indigo-600';
      default: return 'text-gray-600';
    }
  };

  const getVectorBgColor = (type: string) => {
    switch (type) {
      case 'coherence': return 'bg-purple-100 dark:bg-purple-900';
      case 'quantum': return 'bg-blue-100 dark:bg-blue-900';
      case 'neural': return 'bg-green-100 dark:bg-green-900';
      case 'cryptographic': return 'bg-yellow-100 dark:bg-yellow-900';
      case 'security': return 'bg-red-100 dark:bg-red-900';
      case 'expansion': return 'bg-indigo-100 dark:bg-indigo-900';
      default: return 'bg-gray-100 dark:bg-gray-900';
    }
  };

  const getStrengthColor = (value: number) => {
    if (value >= 0.8) return 'text-green-600';
    if (value >= 0.6) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <TrendingUp className="h-8 w-8" />
          Vector Evolution System
        </h1>
        <p className="text-gray-600">
          Advanced multi-dimensional vector evolution with quantum, neural, and cryptographic integration
        </p>
      </div>

      {/* System Controls */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            System Controls
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button 
              onClick={evolveSystem} 
              disabled={isEvolving}
              className="flex items-center gap-2"
            >
              {isEvolving ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              {isEvolving ? 'Evolving...' : 'Evolve Vectors'}
            </Button>
            <Button 
              onClick={optimizeSystem} 
              variant="outline"
              className="flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Optimize System
            </Button>
            <Button 
              onClick={applyQuantumEnhancement} 
              variant="outline"
              className="flex items-center gap-2"
            >
              <Zap className="w-4 h-4" />
              Quantum Enhancement
            </Button>
            <Button 
              onClick={applyNeuralExpansion} 
              variant="outline"
              className="flex items-center gap-2"
            >
              <Network className="w-4 h-4" />
              Neural Expansion
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Metrics Overview */}
      {metrics && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gauge className="h-5 w-5" />
              System Metrics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {Object.entries(metrics).map(([key, value]) => (
                <div key={key} className="text-center">
                  <div className={`text-2xl font-bold ${getStrengthColor(value as number)}`}>
                    {Math.round((value as number) * 100)}%
                  </div>
                  <div className="text-sm text-gray-600 capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </div>
                  <Progress value={(value as number) * 100} className="mt-1" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="vectors" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="vectors">Vectors</TabsTrigger>
          <TabsTrigger value="brainwallet">Brainwallet</TabsTrigger>
          <TabsTrigger value="quantum">Quantum</TabsTrigger>
          <TabsTrigger value="neural">Neural</TabsTrigger>
        </TabsList>

        <TabsContent value="vectors">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {vectors.map((vector) => (
              <Card key={vector.id} className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getVectorIcon(vector.type)}
                    <span className="capitalize">{vector.type}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <Label>Coherence</Label>
                      <div className="flex items-center gap-2">
                        <Progress value={vector.coherence * 100} className="flex-1" />
                        <span className={`text-sm font-medium ${getStrengthColor(vector.coherence)}`}>
                          {Math.round(vector.coherence * 100)}%
                        </span>
                      </div>
                    </div>
                    <div>
                      <Label>Entropy</Label>
                      <div className="flex items-center gap-2">
                        <Progress value={Math.min(100, vector.entropy * 10)} className="flex-1" />
                        <span className="text-sm font-medium">
                          {vector.entropy.toFixed(2)}
                        </span>
                      </div>
                    </div>
                    <div>
                      <Label>Magnitude</Label>
                      <p className="text-sm text-gray-600">
                        {vector.magnitude.toFixed(3)}
                      </p>
                    </div>
                    <div>
                      <Label>Dimensions</Label>
                      <p className="text-sm text-gray-600">
                        {vector.coordinates.length}
                      </p>
                    </div>
                    <Button 
                      onClick={() => analyzeVector(vector.id)}
                      variant="outline"
                      size="sm"
                      className="w-full"
                    >
                      Analyze
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="brainwallet">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5" />
                  Brainwallet Integration
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="passphrase">Passphrase</Label>
                    <Input
                      id="passphrase"
                      type="password"
                      value={brainwalletPassphrase}
                      onChange={(e) => setBrainwalletPassphrase(e.target.value)}
                      placeholder="Enter passphrase for integration..."
                      className="mt-1"
                    />
                  </div>
                  <Button 
                    onClick={integrateBrainwallet}
                    disabled={!brainwalletPassphrase.trim()}
                    className="w-full"
                  >
                    Integrate with Vector System
                  </Button>
                </div>
              </CardContent>
            </Card>

            {brainwalletAnalysis && (
              <Card>
                <CardHeader>
                  <CardTitle>Integration Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label>Integration Score</Label>
                      <div className="flex items-center gap-2">
                        <Progress value={brainwalletAnalysis.integrationScore * 100} className="flex-1" />
                        <span className={`text-sm font-medium ${getStrengthColor(brainwalletAnalysis.integrationScore)}`}>
                          {Math.round(brainwalletAnalysis.integrationScore * 100)}%
                        </span>
                      </div>
                    </div>
                    <div>
                      <Label>Connectivity</Label>
                      <div className="space-y-2">
                        {Object.entries(brainwalletAnalysis.connectivity).map(([key, value]) => (
                          <div key={key}>
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-sm capitalize">
                                {key.replace(/([A-Z])/g, ' $1').trim()}
                              </span>
                              <span className={`text-sm font-medium ${getStrengthColor(value)}`}>
                                {Math.round(value * 100)}%
                              </span>
                            </div>
                            <Progress value={value * 100} />
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <Label>Recommendations</Label>
                      <div className="space-y-1">
                        {brainwalletAnalysis.recommendations.map((rec, index) => (
                          <div key={index} className="text-sm text-gray-600">
                            • {rec}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="quantum">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Atom className="h-5 w-5" />
                  Quantum Enhancement
                </CardTitle>
                <CardDescription>
                  Apply quantum computing principles to enhance vector evolution
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button 
                    onClick={applyQuantumEnhancement}
                    className="w-full"
                  >
                    Apply Quantum Enhancement
                  </Button>
                  <div className="text-sm text-gray-600">
                    Quantum enhancement applies superposition, entanglement, and quantum
                    tunneling principles to optimize vector evolution patterns.
                  </div>
                </div>
              </CardContent>
            </Card>

            {quantumResults && (
              <Card>
                <CardHeader>
                  <CardTitle>Quantum Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label>Enhanced Vector</Label>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Coherence: {Math.round(quantumResults.enhancedVector.coherence * 100)}%</div>
                        <div>Entropy: {quantumResults.enhancedVector.entropy.toFixed(2)}</div>
                        <div>Magnitude: {quantumResults.enhancedVector.magnitude.toFixed(3)}</div>
                      </div>
                    </div>
                    <div>
                      <Label>Improvements</Label>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Coherence: {quantumResults.improvements.coherence > 0 ? '+' : ''}{quantumResults.improvements.coherence.toFixed(3)}</div>
                        <div>Entropy: {quantumResults.improvements.entropy > 0 ? '-' : ''}{Math.abs(quantumResults.improvements.entropy).toFixed(3)}</div>
                        <div>Magnitude: {quantumResults.improvements.magnitude.toFixed(3)}</div>
                      </div>
                    </div>
                    <div>
                      <Label>Quantum State</Label>
                      <div className="space-y-1 text-sm">
                        <div>Phase: {quantumResults.quantumState.phase.toFixed(3)}</div>
                        <div>Superposition: {quantumResults.quantumState.superposition ? 'Active' : 'Inactive'}</div>
                        <div>Entanglement: {quantumResults.quantumState.entanglement.toFixed(3)}</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="neural">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network className="h-5 w-5" />
                  Neural Expansion
                </CardTitle>
                <CardDescription>
                  Expand neural network capabilities for advanced vector processing
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button 
                    onClick={applyNeuralExpansion}
                    className="w-full"
                  >
                    Apply Neural Expansion
                  </Button>
                  <div className="text-sm text-gray-600">
                    Neural expansion increases the complexity and capabilities of neural
                    vectors through multi-layer processing and pattern recognition.
                  </div>
                </div>
              </CardContent>
            </Card>

            {neuralResults && (
              <Card>
                <CardHeader>
                  <CardTitle>Neural Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label>Expanded Vector</Label>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Coherence: {Math.round(neuralResults.expandedVector.coherence * 100)}%</div>
                        <div>Entropy: {neuralResults.expandedVector.entropy.toFixed(2)}</div>
                        <div>Magnitude: {neuralResults.expandedVector.magnitude.toFixed(3)}</div>
                        <div>Dimensions: {neuralResults.expandedVector.dimensions}</div>
                      </div>
                    </div>
                    <div>
                      <Label>Neural Analysis</Label>
                      <div className="space-y-1 text-sm">
                        <div>Patterns: {neuralResults.neuralAnalysis.patterns.join(', ')}</div>
                        <div>Avg Activation: {neuralResults.neuralAnalysis.averageActivation.toFixed(3)}</div>
                        <div>Complexity: {neuralResults.neuralAnalysis.complexity.toFixed(3)}</div>
                      </div>
                    </div>
                    <div>
                      <Label>Expansion Metrics</Label>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Dimensional Growth: +{neuralResults.expansionMetrics.dimensionalGrowth}</div>
                        <div>Coherence Change: {neuralResults.expansionMetrics.coherenceChange > 0 ? '+' : ''}{neuralResults.expansionMetrics.coherenceChange.toFixed(3)}</div>
                        <div>Efficiency: {Math.round(neuralResults.expansionMetrics.efficiency * 100)}%</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}