'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Zap, 
  Code, 
  Network, 
  BarChart3, 
  CheckCircle, 
  AlertTriangle,
  TrendingUp,
  Users,
  Database,
  Shield,
  Eye,
  Settings,
  Activity,
  BookOpen,
  Rocket,
  Brain,
  Globe
} from 'lucide-react';
import { motion } from 'framer-motion';

interface Contribution {
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  category: string;
  year: string;
}

interface EthereumMetric {
  name: string;
  value: string;
  change: string;
  status: 'excellent' | 'good' | 'warning';
}

const contributions: Contribution[] = [
  {
    title: "Ethereum Whitepaper",
    description: "Authored the foundational Ethereum whitepaper introducing smart contracts and decentralized applications",
    impact: "high",
    category: "Foundation",
    year: "2013"
  },
  {
    title: "Smart Contract Innovation",
    description: "Pioneered the concept of programmable money and self-executing contracts on blockchain",
    impact: "high",
    category: "Innovation",
    year: "2014"
  },
  {
    title: "Ethereum Network Launch",
    description: "Led the development and launch of the Ethereum mainnet, enabling the DeFi ecosystem",
    impact: "high",
    category: "Implementation",
    year: "2015"
  },
  {
    title: "Proof-of-Stake Transition",
    description: "Architected Ethereum's transition from Proof-of-Work to Proof-of-Stake (The Merge)",
    impact: "high",
    category: "Consensus",
    year: "2022"
  },
  {
    title: "Layer 2 Scaling Solutions",
    description: "Advocated for and contributed to the development of Layer 2 scaling solutions",
    impact: "medium",
    category: "Scaling",
    year: "2018-Present"
  },
  {
    title: "EIP Standards",
    description: "Created and contributed to Ethereum Improvement Proposals (EIPs) for network upgrades",
    impact: "medium",
    category: "Standards",
    year: "2015-Present"
  }
];

const ethereumMetrics: EthereumMetric[] = [
  {
    name: "Smart Contracts",
    value: "50M+",
    change: "+2.1M",
    status: "excellent"
  },
  {
    name: "DeFi TVL",
    value: "$45B+",
    change: "+$3.2B",
    status: "excellent"
  },
  {
    name: "Daily Transactions",
    value: "1.1M",
    change: "+15%",
    status: "excellent"
  },
  {
    name: "Active Addresses",
    value: "500K+",
    change: "+8%",
    status: "good"
  },
  {
    name: "Gas Efficiency",
    value: "87%",
    change: "+5%",
    status: "good"
  },
  {
    name: "Network Scalability",
    value: "15 TPS",
    change: "Improving",
    status: "warning"
  }
];

const innovations = [
  {
    icon: <Zap className="h-5 w-5" />,
    title: "Smart Contracts",
    description: "Self-executing contracts with predefined rules and conditions"
  },
  {
    icon: <Network className="h-5 w-5" />,
    title: "Decentralized Applications",
    description: "Applications that run on a peer-to-peer network without central control"
  },
  {
    icon: <Brain className="h-5 w-5" />,
    title: "Virtual Machine (EVM)",
    description: "Turing-complete virtual machine for executing smart contracts"
  },
  {
    icon: <Shield className="h-5 w-5" />,
    title: "Proof-of-Stake",
    description: "Energy-efficient consensus mechanism replacing Proof-of-Work"
  },
  {
    icon: <Rocket className="h-5 w-5" />,
    title: "Layer 2 Scaling",
    description: "Solutions for scaling Ethereum while maintaining security"
  },
  {
    icon: <Globe className="h-5 w-5" />,
    title: "Interoperability",
    description: "Cross-chain communication and asset transfer protocols"
  }
];

const ecosystemImpact = [
  {
    title: "DeFi Revolution",
    description: "Enabled the creation of decentralized financial protocols",
    metrics: ["$45B+ TVL", "1000+ Protocols", "5M+ Users"]
  },
  {
    title: "NFT Ecosystem",
    description: "Pioneered non-fungible tokens and digital ownership",
    metrics: ["$20B+ Market Cap", "100M+ NFTs", "10M+ Collectors"]
  },
  {
    title: "DAO Innovation",
    description: "Enabled decentralized autonomous organizations",
    metrics: ["5000+ DAOs", "$10B+ Treasury", "1M+ Members"]
  },
  {
    title: "Web3 Development",
    description: "Created the foundation for the decentralized web",
    metrics: ["200K+ Developers", "4000+ dApps", "100+ Blockchains"]
  }
];

export default function VitalikButerinShowcase() {
  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'text-green-600';
      case 'good': return 'text-blue-600';
      case 'warning': return 'text-yellow-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-2xl">
            <Zap className="h-8 w-8 text-purple-600" />
            Vitalik Buterin's (vitalik.eth) Blockchain Revolution
          </CardTitle>
          <CardDescription className="text-base">
            A comprehensive overview of Vitalik Buterin's revolutionary contributions to blockchain technology, 
            Ethereum, and the decentralized ecosystem. His vision has transformed how we think about 
            digital ownership, programmable money, and decentralized applications.
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="contributions" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="contributions">Key Contributions</TabsTrigger>
          <TabsTrigger value="metrics">Ethereum Metrics</TabsTrigger>
          <TabsTrigger value="innovations">Innovations</TabsTrigger>
          <TabsTrigger value="ecosystem">Ecosystem Impact</TabsTrigger>
          <TabsTrigger value="vision">Future Vision</TabsTrigger>
        </TabsList>

        <TabsContent value="contributions" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {contributions.map((contribution, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <CardTitle className="text-lg">{contribution.title}</CardTitle>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{contribution.category}</Badge>
                          <Badge className={getImpactColor(contribution.impact)}>
                            {contribution.impact} impact
                          </Badge>
                        </div>
                      </div>
                      <span className="text-sm text-muted-foreground">{contribution.year}</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      {contribution.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="metrics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {ethereumMetrics.map((metric, index) => (
              <Card key={index}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">{metric.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className={`text-2xl font-bold ${getStatusColor(metric.status)}`}>
                        {metric.value}
                      </span>
                      <TrendingUp className={`h-4 w-4 ${getStatusColor(metric.status)}`} />
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Change: {metric.change}
                    </div>
                    <Badge 
                      variant="outline" 
                      className={getStatusColor(metric.status)}
                    >
                      {metric.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="innovations" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {innovations.map((innovation, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg">
                      {innovation.icon}
                    </div>
                    {innovation.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    {innovation.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="ecosystem" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ecosystemImpact.map((impact, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    {impact.title}
                  </CardTitle>
                  <CardDescription>{impact.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {impact.metrics.map((metric, metricIndex) => (
                      <div key={metricIndex} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm">{metric}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="vision" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-purple-600" />
                  Current Research Areas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-purple-600" />
                  <span className="text-sm">Scalability solutions (Layer 2, sharding)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-purple-600" />
                  <span className="text-sm">Privacy enhancements (zero-knowledge proofs)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-purple-600" />
                  <span className="text-sm">Decentralized governance (DAOs)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-purple-600" />
                  <span className="text-sm">Cross-chain interoperability</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-purple-600" />
                  <span className="text-sm">Sustainable blockchain development</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Rocket className="h-5 w-5 text-blue-600" />
                  Future Vision
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none">
                  <p className="text-sm text-muted-foreground mb-3">
                    Vitalik's vision for the future includes:
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li><strong>Mass Adoption:</strong> Billions of users interacting with decentralized applications</li>
                    <li><strong>Advanced Scalability:</strong> 100,000+ TPS with full security guarantees</li>
                    <li><strong>Privacy by Default:</strong> Zero-knowledge proofs for all transactions</li>
                    <li><strong>Interoperability:</strong> Seamless communication between all blockchains</li>
                    <li><strong>Sustainability:</strong> Environmentally friendly and energy efficient</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-yellow-600" />
                Philosophy & Principles
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm max-w-none">
                <p className="text-sm text-muted-foreground mb-3">
                  Vitalik Buterin's approach to blockchain development emphasizes:
                </p>
                <ul className="space-y-2 text-sm">
                  <li><strong>Decentralization:</strong> Power distributed among many participants</li>
                  <li><strong>Security:</strong> Robust cryptographic guarantees and economic incentives</li>
                  <li><strong>Scalability:</strong> Ability to handle global adoption</li>
                  <li><strong>Sustainability:</strong> Long-term viability and environmental responsibility</li>
                  <li><strong>Innovation:</strong> Continuous research and development</li>
                  <li><strong>Accessibility:</strong> Open and inclusive for everyone</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}