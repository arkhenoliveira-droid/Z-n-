import { getRequestConfig } from 'next-intl/server';
import { supportedLanguages, defaultLanguage } from './lib/language-server';

export default getRequestConfig(async ({ locale }) => {
  // Validate that the incoming `locale` parameter is valid
  if (!supportedLanguages.includes(locale as any)) {
    // If invalid locale, use default
    return {
      locale: defaultLanguage as string,
      messages: (await import(`./messages/${defaultLanguage}.json`)).default
    };
  }

  return {
    locale: locale as string,
    messages: (await import(`./messages/${locale}.json`)).default
  };
});