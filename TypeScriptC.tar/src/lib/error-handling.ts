/**
 * Comprehensive Error Handling System for Holistic User Experience
 * Provides centralized error management, user feedback, and recovery strategies
 */

import { toast } from 'sonner'

// Error Types
export interface AppError extends Error {
  code: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  category: 'network' | 'validation' | 'authentication' | 'authorization' | 'server' | 'client' | 'unknown'
  retryable: boolean
  context?: Record<string, any>
  timestamp: number
  id: string
}

export interface ErrorHandler {
  canHandle: (error: AppError) => boolean
  handle: (error: AppError) => Promise<void> | void
}

export interface ErrorStrategy {
  shouldRetry: (error: AppError, attempt: number) => boolean
  getDelay: (attempt: number) => number
  maxAttempts: number
}

// Error Categories with predefined strategies
export const errorCategories = {
  network: {
    retryable: true,
    maxAttempts: 3,
    baseDelay: 1000,
    messages: {
      title: 'Network Error',
      description: 'Unable to connect to the server. Please check your internet connection.',
      action: 'Retry'
    }
  },
  validation: {
    retryable: false,
    maxAttempts: 1,
    baseDelay: 0,
    messages: {
      title: 'Validation Error',
      description: 'Please check your input and try again.',
      action: 'Fix Input'
    }
  },
  authentication: {
    retryable: false,
    maxAttempts: 1,
    baseDelay: 0,
    messages: {
      title: 'Authentication Error',
      description: 'Please log in to continue.',
      action: 'Login'
    }
  },
  authorization: {
    retryable: false,
    maxAttempts: 1,
    baseDelay: 0,
    messages: {
      title: 'Authorization Error',
      description: 'You don\'t have permission to perform this action.',
      action: 'Contact Admin'
    }
  },
  server: {
    retryable: true,
    maxAttempts: 2,
    baseDelay: 2000,
    messages: {
      title: 'Server Error',
      description: 'Something went wrong on our end. Please try again.',
      action: 'Retry'
    }
  },
  client: {
    retryable: false,
    maxAttempts: 1,
    baseDelay: 0,
    messages: {
      title: 'Application Error',
      description: 'An unexpected error occurred. Please refresh the page.',
      action: 'Refresh'
    }
  },
  unknown: {
    retryable: false,
    maxAttempts: 1,
    baseDelay: 0,
    messages: {
      title: 'Unknown Error',
      description: 'An unexpected error occurred. Please try again.',
      action: 'Retry'
    }
  }
}

// Error Factory
export class ErrorFactory {
  private static generateId(): string {
    return `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  }

  static create(
    message: string,
    code: string,
    category: AppError['category'],
    severity: AppError['severity'] = 'medium',
    retryable: boolean = false,
    context?: Record<string, any>,
    originalError?: Error
  ): AppError {
    const error = new Error(message) as AppError
    
    error.code = code
    error.category = category
    error.severity = severity
    error.retryable = retryable
    error.context = context
    error.timestamp = Date.now()
    error.id = this.generateId()
    
    if (originalError) {
      error.stack = originalError.stack
      error.name = originalError.name
    }
    
    return error
  }

  static fromError(
    error: Error,
    code: string,
    category: AppError['category'],
    severity: AppError['severity'] = 'medium',
    retryable: boolean = false,
    context?: Record<string, any>
  ): AppError {
    return this.create(
      error.message,
      code,
      category,
      severity,
      retryable,
      context,
      error
    )
  }

  static network(message: string, context?: Record<string, any>): AppError {
    return this.create(
      message,
      'NETWORK_ERROR',
      'network',
      'medium',
      true,
      context
    )
  }

  static validation(message: string, context?: Record<string, any>): AppError {
    return this.create(
      message,
      'VALIDATION_ERROR',
      'validation',
      'low',
      false,
      context
    )
  }

  static authentication(message: string, context?: Record<string, any>): AppError {
    return this.create(
      message,
      'AUTH_ERROR',
      'authentication',
      'high',
      false,
      context
    )
  }

  static authorization(message: string, context?: Record<string, any>): AppError {
    return this.create(
      message,
      'AUTHZ_ERROR',
      'authorization',
      'high',
      false,
      context
    )
  }

  static server(message: string, context?: Record<string, any>): AppError {
    return this.create(
      message,
      'SERVER_ERROR',
      'server',
      'high',
      true,
      context
    )
  }

  static client(message: string, context?: Record<string, any>): AppError {
    return this.create(
      message,
      'CLIENT_ERROR',
      'client',
      'medium',
      false,
      context
    )
  }
}

// Error Handler Registry
export class ErrorHandlerRegistry {
  private handlers: ErrorHandler[] = []

  register(handler: ErrorHandler): void {
    this.handlers.push(handler)
  }

  unregister(handler: ErrorHandler): void {
    const index = this.handlers.indexOf(handler)
    if (index > -1) {
      this.handlers.splice(index, 1)
    }
  }

  async handle(error: AppError): Promise<void> {
    for (const handler of this.handlers) {
      if (handler.canHandle(error)) {
        try {
          await handler.handle(error)
          return
        } catch (handlerError) {
          console.error('Error in error handler:', handlerError)
        }
      }
    }
    
    // Fallback to default handling
    await this.defaultHandle(error)
  }

  private async defaultHandle(error: AppError): Promise<void> {
    const category = errorCategories[error.category]
    const severity = error.severity
    
    // Log error for debugging
    console.error('Unhandled error:', {
      id: error.id,
      code: error.code,
      message: error.message,
      category: error.category,
      severity: error.severity,
      context: error.context,
      timestamp: error.timestamp
    })
    
    // Show user-friendly toast notification
    const toastOptions = {
      duration: severity === 'critical' ? 10000 : severity === 'high' ? 7000 : 5000,
      action: error.retryable ? {
        label: category.messages.action,
        onClick: () => this.retry(error)
      } : undefined
    }
    
    if (severity === 'critical' || severity === 'high') {
      toast.error(category.messages.title, {
        description: category.messages.description,
        ...toastOptions
      })
    } else {
      toast.warning(category.messages.title, {
        description: category.messages.description,
        ...toastOptions
      })
    }
  }

  private async retry(error: AppError): Promise<void> {
    // This would be implemented based on the specific retry logic needed
    // For now, just show a retry message
    toast.info('Retrying...', {
      description: `Attempting to recover from ${error.code}`
    })
  }
}

// Retry Strategy Implementation
export class RetryStrategy {
  constructor(private strategy: ErrorStrategy) {}

  async execute<T>(
    operation: () => Promise<T>,
    onError?: (error: AppError, attempt: number) => void
  ): Promise<T> {
    let lastError: AppError
    
    for (let attempt = 1; attempt <= this.strategy.maxAttempts; attempt++) {
      try {
        return await operation()
      } catch (error) {
        const appError = error instanceof Error && 'code' in error 
          ? error as AppError 
          : ErrorFactory.fromError(
              error,
              'RETRY_ERROR',
              'unknown',
              'medium',
              true
            )
        
        lastError = appError
        
        if (onError) {
          onError(appError, attempt)
        }
        
        if (!this.strategy.shouldRetry(appError, attempt)) {
          throw appError
        }
        
        if (attempt < this.strategy.maxAttempts) {
          const delay = this.strategy.getDelay(attempt)
          await new Promise(resolve => setTimeout(resolve, delay))
        }
      }
    }
    
    throw lastError!
  }
}

// Predefined retry strategies
export const retryStrategies = {
  exponential: {
    shouldRetry: (error: AppError, attempt: number) => {
      const category = errorCategories[error.category]
      return error.retryable && attempt <= category.maxAttempts
    },
    getDelay: (attempt: number) => {
      return Math.min(1000 * Math.pow(2, attempt - 1), 30000)
    },
    maxAttempts: 3
  },
  
  linear: {
    shouldRetry: (error: AppError, attempt: number) => {
      const category = errorCategories[error.category]
      return error.retryable && attempt <= category.maxAttempts
    },
    getDelay: (attempt: number) => {
      return 1000 * attempt
    },
    maxAttempts: 3
  },
  
  immediate: {
    shouldRetry: (error: AppError, attempt: number) => {
      const category = errorCategories[error.category]
      return error.retryable && attempt <= category.maxAttempts
    },
    getDelay: () => 0,
    maxAttempts: 3
  }
}

// Error Boundary Component Support
export interface ErrorBoundaryState {
  hasError: boolean
  error: AppError | null
  errorInfo: any
}

export class ErrorBoundaryManager {
  private static instance: ErrorBoundaryManager
  private errorHandler: ErrorHandlerRegistry

  private constructor() {
    this.errorHandler = new ErrorHandlerRegistry()
  }

  static getInstance(): ErrorBoundaryManager {
    if (!ErrorBoundaryManager.instance) {
      ErrorBoundaryManager.instance = new ErrorBoundaryManager()
    }
    return ErrorBoundaryManager.instance
  }

  async handleError(error: Error, errorInfo?: any): Promise<void> {
    const appError = error instanceof Error && 'code' in error 
      ? error as AppError 
      : ErrorFactory.fromError(
          error,
          'REACT_ERROR_BOUNDARY',
          'client',
          'medium',
          false,
          { errorInfo }
        )
    
    await this.errorHandler.handle(appError)
  }

  getErrorHandler(): ErrorHandlerRegistry {
    return this.errorHandler
  }
}

// Network Error Handler
export class NetworkErrorHandler implements ErrorHandler {
  canHandle(error: AppError): boolean {
    return error.category === 'network'
  }

  async handle(error: AppError): Promise<void> {
    const category = errorCategories.network
    
    // Check if we're offline
    if (!navigator.onLine) {
      toast.error('Offline', {
        description: 'You appear to be offline. Please check your internet connection.',
        action: {
          label: 'Check Connection',
          onClick: () => window.location.reload()
        }
      })
      return
    }
    
    // Handle specific network errors
    if (error.code === 'TIMEOUT_ERROR') {
      toast.warning('Request Timeout', {
        description: 'The request took too long to complete. Please try again.',
        action: {
          label: 'Retry',
          onClick: () => this.retry(error)
        }
      })
    } else {
      toast.error('Network Error', {
        description: category.messages.description,
        action: {
          label: category.messages.action,
          onClick: () => this.retry(error)
        }
      })
    }
  }

  private async retry(error: AppError): Promise<void> {
    // Implement retry logic based on the specific error context
    console.log('Retrying network operation:', error.id)
  }
}

// Validation Error Handler
export class ValidationErrorHandler implements ErrorHandler {
  canHandle(error: AppError): boolean {
    return error.category === 'validation'
  }

  handle(error: AppError): void {
    const category = errorCategories.validation
    
    toast.error('Validation Error', {
      description: error.message || category.messages.description,
      duration: 6000
    })
    
    // Focus on the first invalid field if context is available
    if (error.context?.fieldId) {
      const field = document.getElementById(error.context.fieldId)
      if (field) {
        field.focus()
        field.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }
    }
  }
}

// Authentication Error Handler
export class AuthenticationErrorHandler implements ErrorHandler {
  canHandle(error: AppError): boolean {
    return error.category === 'authentication'
  }

  handle(error: AppError): void {
    const category = errorCategories.authentication
    
    toast.error('Authentication Required', {
      description: category.messages.description,
      action: {
        label: 'Login',
        onClick: () => {
          // Redirect to login page
          window.location.href = '/login'
        }
      },
      duration: 8000
    })
  }
}

// Global Error Handler Setup
export function setupGlobalErrorHandling(): void {
  const errorBoundary = ErrorBoundaryManager.getInstance()
  const errorHandler = errorBoundary.getErrorHandler()
  
  // Register default handlers
  errorHandler.register(new NetworkErrorHandler())
  errorHandler.register(new ValidationErrorHandler())
  errorHandler.register(new AuthenticationErrorHandler())
  
  // Handle unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    event.preventDefault()
    const error = event.reason instanceof Error 
      ? ErrorFactory.fromError(event.reason, 'UNHANDLED_REJECTION', 'unknown', 'high')
      : ErrorFactory.create(
          String(event.reason),
          'UNHANDLED_REJECTION',
          'unknown',
          'high'
        )
    
    errorHandler.handle(error)
  })
  
  // Handle uncaught errors
  window.addEventListener('error', (event) => {
    event.preventDefault()
    const error = ErrorFactory.fromError(
      event.error,
      'UNCAUGHT_ERROR',
      'client',
      'critical',
      false,
      { filename: event.filename, lineno: event.lineno, colno: event.colno }
    )
    
    errorHandler.handle(error)
  })
}

// Export utilities
export const errorHandling = {
  factory: ErrorFactory,
  registry: ErrorHandlerRegistry,
  boundary: ErrorBoundaryManager,
  retry: RetryStrategy,
  strategies: retryStrategies,
  setup: setupGlobalErrorHandling,
  categories: errorCategories
}

// Export singleton instance for easy import
export const ErrorHandler = ErrorFactory

export default errorHandling