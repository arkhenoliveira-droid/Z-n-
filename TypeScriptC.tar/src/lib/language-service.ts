import { 
  Language, 
  languageUtils,
  supportedLanguages,
  defaultLanguage,
  languageNames
} from './language-server';

// Simple language detection that works in both client and server contexts
const detectLanguage = async (): Promise<Language> => {
  if (typeof window !== 'undefined') {
    // Client-side detection
    const { detectClientLanguage } = await import('./language-detector-client');
    return detectClientLanguage();
  } else {
    // Server-side simplified detection (no headers dependency)
    return defaultLanguage;
  }
};

// Simple confidence detection without server-side complexity
const detectLanguageWithConfidence = async () => {
  if (typeof window !== 'undefined') {
    // Client-side detection
    const { detectClientLanguage } = await import('./language-detector-client');
    const language = detectClientLanguage();
    return {
      language,
      confidence: 'medium' as const,
      method: 'header' as const
    };
  } else {
    // Server-side fallback
    return {
      language: defaultLanguage,
      confidence: 'low' as const,
      method: 'fallback' as const
    };
  }
};

export interface LanguageServiceConfig {
  cacheEnabled?: boolean;
  cacheDuration?: number;
  enableIPDetection?: boolean;
  fallbackLanguage?: Language;
}

export interface LanguageDetectionOptions {
  skipCache?: boolean;
  forceIPDetection?: boolean;
  preferredMethod?: 'header' | 'ip' | 'url' | 'preference';
}

export interface LocalizationResult {
  language: Language;
  isRTL: boolean;
  dateFormat: string;
  numberFormat: string;
  currency: string;
}

export class LanguageService {
  private config: LanguageServiceConfig;
  
  constructor(config: LanguageServiceConfig = {}) {
    this.config = {
      cacheEnabled: true,
      cacheDuration: 30 * 60 * 1000, // 30 minutes
      enableIPDetection: true,
      fallbackLanguage: defaultLanguage,
      ...config
    };
  }
  
  /**
   * Detect language with advanced options
   */
  async detectLanguage(options: LanguageDetectionOptions = {}): Promise<Language> {
    try {
      // Check user preference first if not skipped
      if (!options.skipCache && typeof window !== 'undefined') {
        const { languagePreferences } = await import('./language-detector-client');
        const preferred = languagePreferences.get();
        if (preferred && options.preferredMethod !== 'preference') {
          return preferred;
        }
      }
      
      // Use specified detection method
      switch (options.preferredMethod) {
        case 'header':
          return this.detectFromHeader();
        case 'ip':
          if (this.config.enableIPDetection && options.forceIPDetection) {
            return this.detectFromIP();
          }
          break;
        case 'url':
          return this.detectFromURL();
        default:
          // Use default detection logic
          return detectLanguage();
      }
      
      return detectLanguage();
    } catch (error) {
      console.warn('Language detection failed:', error);
      return this.config.fallbackLanguage || defaultLanguage;
    }
  }
  
  /**
   * Detect language with confidence scoring
   */
  async detectWithConfidence(): Promise<any> {
    try {
      return await detectLanguageWithConfidence();
    } catch (error) {
      console.warn('Confidence detection failed:', error);
      return {
        language: this.config.fallbackLanguage || defaultLanguage,
        confidence: 'low',
        method: 'fallback'
      };
    }
  }
  
  /**
   * Set user language preference
   */
  async setLanguagePreference(language: Language): Promise<void> {
    if (!languageUtils.isValid(language)) {
      throw new Error(`Invalid language: ${language}`);
    }
    
    if (typeof window !== 'undefined') {
      const { languagePreferences } = await import('./language-detector-client');
      languagePreferences.set(language);
    }
  }
  
  /**
   * Get user language preference
   */
  async getLanguagePreference(): Promise<Language | null> {
    if (typeof window !== 'undefined') {
      const { languagePreferences } = await import('./language-detector-client');
      return languagePreferences.get();
    }
    return null;
  }
  
  /**
   * Remove user language preference
   */
  async removeLanguagePreference(): Promise<void> {
    if (typeof window !== 'undefined') {
      const { languagePreferences } = await import('./language-detector-client');
      languagePreferences.remove();
    }
  }
  
  /**
   * Get localization settings for a language
   */
  getLocalization(language: Language): LocalizationResult {
    const localizationMap: Record<Language, LocalizationResult> = {
      pt: {
        language: 'pt',
        isRTL: false,
        dateFormat: 'DD/MM/YYYY',
        numberFormat: 'pt-BR',
        currency: 'BRL'
      },
      en: {
        language: 'en',
        isRTL: false,
        dateFormat: 'MM/DD/YYYY',
        numberFormat: 'en-US',
        currency: 'USD'
      },
      es: {
        language: 'es',
        isRTL: false,
        dateFormat: 'DD/MM/YYYY',
        numberFormat: 'es-ES',
        currency: 'EUR'
      }
    };
    
    return localizationMap[language] || localizationMap[defaultLanguage];
  }
  
  /**
   * Create localized URL
   */
  createLocalizedUrl(pathname: string, language: Language): string {
    if (!languageUtils.isValid(language)) {
      language = this.config.fallbackLanguage || defaultLanguage;
    }
    
    const segments = pathname.split('/').filter(Boolean);
    
    // Remove existing language prefix
    if (segments.length > 0 && supportedLanguages.includes(segments[0] as Language)) {
      segments.shift();
    }
    
    return `/${language}/${segments.join('/')}`;
  }
  
  /**
   * Extract language from URL
   */
  extractLanguageFromURL(pathname: string): Language | null {
    const segments = pathname.split('/').filter(Boolean);
    if (segments.length > 0 && supportedLanguages.includes(segments[0] as Language)) {
      return segments[0] as Language;
    }
    return null;
  }
  
  /**
   * Get all supported languages with metadata
   */
  getSupportedLanguages(): Array<{
    code: Language;
    name: string;
    nativeName: string;
    flag: string;
    localization: LocalizationResult;
  }> {
    return supportedLanguages.map(code => ({
      code,
      name: languageNames[code],
      nativeName: this.getNativeName(code),
      flag: this.getFlag(code),
      localization: this.getLocalization(code)
    }));
  }
  
  /**
   * Get language-specific formatting utilities
   */
  getFormatters(language: Language) {
    const localization = this.getLocalization(language);
    
    return {
      formatDate: (date: Date | string) => {
        const d = typeof date === 'string' ? new Date(date) : date;
        return d.toLocaleDateString(language, {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit'
        });
      },
      
      formatNumber: (number: number) => {
        return number.toLocaleString(language);
      },
      
      formatCurrency: (amount: number) => {
        return new Intl.NumberFormat(language, {
          style: 'currency',
          currency: localization.currency
        }).format(amount);
      },
      
      formatTime: (date: Date | string) => {
        const d = typeof date === 'string' ? new Date(date) : date;
        return d.toLocaleTimeString(language, {
          hour: '2-digit',
          minute: '2-digit'
        });
      }
    };
  }
  
  /**
   * Validate language code
   */
  validateLanguage(code: string): { valid: boolean; normalized?: Language; fallback?: Language } {
    if (languageUtils.isValid(code)) {
      return { valid: true, normalized: code };
    }
    
    const normalized = languageUtils.normalize(code);
    const fallback = languageUtils.getFallback(code);
    
    return {
      valid: false,
      normalized: normalized !== defaultLanguage ? normalized : undefined,
      fallback: fallback !== defaultLanguage ? fallback : undefined
    };
  }
  
  /**
   * Detect language from Accept-Language header
   */
  private async detectFromHeader(): Promise<Language> {
    if (typeof window === 'undefined') {
      // Server-side simplified - return default
      return this.config.fallbackLanguage || defaultLanguage;
    } else {
      // Client-side detection
      const browserLanguage = navigator.language || navigator.languages?.[0];
      if (browserLanguage) {
        const primary = browserLanguage.split('-')[0];
        if (supportedLanguages.includes(primary as Language)) {
          return primary as Language;
        }
      }
    }
    
    return this.config.fallbackLanguage || defaultLanguage;
  }
  
  /**
   * Detect language from IP address
   */
  private async detectFromIP(): Promise<Language> {
    if (typeof window !== 'undefined') {
      // Client-side IP detection is limited, use a service
      try {
        const response = await fetch('https://ipapi.co/json/');
        if (response.ok) {
          const data = await response.json();
          const countryCode = data.country_code;
          
          if (countryCode && countryToLanguage[countryCode]) {
            return countryToLanguage[countryCode];
          }
        }
      } catch (error) {
        console.warn('IP detection failed:', error);
      }
    } else {
      // Server-side simplified - return default
      return this.config.fallbackLanguage || defaultLanguage;
    }
    
    return this.config.fallbackLanguage || defaultLanguage;
  }
  
  /**
   * Detect language from URL
   */
  private detectFromURL(): Language {
    let pathname: string;
    
    if (typeof window !== 'undefined') {
      pathname = window.location.pathname;
    } else {
      // Server-side - we can't get the current URL easily, return fallback
      return this.config.fallbackLanguage || defaultLanguage;
    }
    
    const segments = pathname.split('/').filter(Boolean);
    if (segments.length > 0 && supportedLanguages.includes(segments[0] as Language)) {
      return segments[0] as Language;
    }
    
    return this.config.fallbackLanguage || defaultLanguage;
  }
  
  /**
   * Get native language name
   */
  private getNativeName(language: Language): string {
    const nativeNames: Record<Language, string> = {
      pt: 'Português',
      en: 'English',
      es: 'Español'
    };
    
    return nativeNames[language] || languageNames[language];
  }
  
  /**
   * Get flag emoji for language
   */
  private getFlag(language: Language): string {
    const flags: Record<Language, string> = {
      pt: '🇧🇷',
      en: '🇺🇸',
      es: '🇪🇸'
    };
    
    return flags[language] || '🌐';
  }
}

// Import countryToLanguage for IP detection
const countryToLanguage: Record<string, Language> = {
  'BR': 'pt', 'PT': 'pt', 'AO': 'pt', 'MZ': 'pt',
  'ES': 'es', 'MX': 'es', 'AR': 'es', 'CO': 'es',
  'US': 'en', 'GB': 'en', 'CA': 'en', 'AU': 'en'
};

// Export singleton instance
export const languageService = new LanguageService();

// Export convenience functions
export const detectLanguageWithOptions = (options?: LanguageDetectionOptions) => 
  languageService.detectLanguage(options);

export const getLocalizationSettings = (language: Language) => 
  languageService.getLocalization(language);

export const getFormatters = (language: Language) => 
  languageService.getFormatters(language);