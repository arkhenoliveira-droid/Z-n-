/**
 * Comprehensive Performance Optimization System
 * Provides monitoring, optimization strategies, and performance utilities
 */

// Performance Monitoring Types
export interface PerformanceMetric {
  name: string
  value: number
  unit: string
  timestamp: number
  category: 'navigation' | 'resource' | 'paint' | 'interaction' | 'custom'
  metadata?: Record<string, any>
}

export interface PerformanceThreshold {
  name: string
  min: number
  max: number
  unit: string
  severity: 'low' | 'medium' | 'high' | 'critical'
}

export interface PerformanceReport {
  metrics: PerformanceMetric[]
  thresholds: PerformanceThreshold[]
  violations: PerformanceViolation[]
  score: number
  recommendations: string[]
  timestamp: number
}

export interface PerformanceViolation {
  metric: string
  actual: number
  expected: number
  severity: 'low' | 'medium' | 'high' | 'critical'
  recommendation: string
}

// Performance Monitoring Class
export class PerformanceMonitor {
  private static instance: PerformanceMonitor
  private metrics: PerformanceMetric[] = []
  private thresholds: PerformanceThreshold[] = []
  private observers: PerformanceObserver[] = []
  private isMonitoring = false

  private constructor() {
    this.setupDefaultThresholds()
  }

  static getInstance(): PerformanceMonitor {
    if (!PerformanceMonitor.instance) {
      PerformanceMonitor.instance = new PerformanceMonitor()
    }
    return PerformanceMonitor.instance
  }

  private setupDefaultThresholds(): void {
    this.thresholds = [
      // Core Web Vitals
      { name: 'FCP', min: 0, max: 1800, unit: 'ms', severity: 'medium' },
      { name: 'LCP', min: 0, max: 2500, unit: 'ms', severity: 'high' },
      { name: 'FID', min: 0, max: 100, unit: 'ms', severity: 'high' },
      { name: 'CLS', min: 0, max: 0.1, unit: '', severity: 'medium' },
      { name: 'TTFB', min: 0, max: 800, unit: 'ms', severity: 'medium' },
      
      // Custom thresholds
      { name: 'page_load', min: 0, max: 3000, unit: 'ms', severity: 'medium' },
      { name: 'api_response', min: 0, max: 1000, unit: 'ms', severity: 'medium' },
      { name: 'component_render', min: 0, max: 100, unit: 'ms', severity: 'low' },
      { name: 'interaction_response', min: 0, max: 50, unit: 'ms', severity: 'medium' }
    ]
  }

  startMonitoring(): void {
    if (this.isMonitoring) return
    
    this.isMonitoring = true
    this.setupObservers()
    this.startPeriodicCollection()
  }

  stopMonitoring(): void {
    this.isMonitoring = false
    this.cleanupObservers()
  }

  private setupObservers(): void {
    if (typeof PerformanceObserver === 'undefined') return

    // Navigation Timing
    const navigationObserver = new PerformanceObserver((list) => {
      const entries = list.getEntriesByType('navigation')
      entries.forEach(entry => {
        this.recordMetric({
          name: 'page_load',
          value: entry.loadEventEnd - entry.fetchStart,
          unit: 'ms',
          timestamp: Date.now(),
          category: 'navigation',
          metadata: {
            domContentLoaded: entry.domContentLoadedEventEnd - entry.fetchStart,
            firstPaint: entry.responseEnd - entry.fetchStart
          }
        })
      })
    })
    navigationObserver.observe({ type: 'navigation', buffered: true })
    this.observers.push(navigationObserver)

    // Resource Timing
    const resourceObserver = new PerformanceObserver((list) => {
      const entries = list.getEntriesByType('resource')
      entries.forEach(entry => {
        if (entry.initiatorType === 'fetch' || entry.initiatorType === 'xmlhttprequest') {
          this.recordMetric({
            name: 'api_response',
            value: entry.responseEnd - entry.startTime,
            unit: 'ms',
            timestamp: Date.now(),
            category: 'resource',
            metadata: {
              url: entry.name,
              size: entry.transferSize
            }
          })
        }
      })
    })
    resourceObserver.observe({ type: 'resource', buffered: true })
    this.observers.push(resourceObserver)

    // Paint Timing
    const paintObserver = new PerformanceObserver((list) => {
      const entries = list.getEntriesByType('paint')
      entries.forEach(entry => {
        this.recordMetric({
          name: entry.name === 'first-contentful-paint' ? 'FCP' : entry.name,
          value: entry.startTime,
          unit: 'ms',
          timestamp: Date.now(),
          category: 'paint'
        })
      })
    })
    paintObserver.observe({ type: 'paint', buffered: true })
    this.observers.push(paintObserver)

    // Largest Contentful Paint
    const lcpObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries()
      const lastEntry = entries[entries.length - 1]
      if (lastEntry) {
        this.recordMetric({
          name: 'LCP',
          value: lastEntry.startTime,
          unit: 'ms',
          timestamp: Date.now(),
          category: 'paint',
          metadata: {
            element: lastEntry.element,
            size: lastEntry.size
          }
        })
      }
    })
    lcpObserver.observe({ type: 'largest-contentful-paint', buffered: true })
    this.observers.push(lcpObserver)

    // First Input Delay
    const fidObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries()
      entries.forEach(entry => {
        this.recordMetric({
          name: 'FID',
          value: entry.processingStart - entry.startTime,
          unit: 'ms',
          timestamp: Date.now(),
          category: 'interaction',
          metadata: {
            eventName: entry.name,
            target: entry.target
          }
        })
      })
    })
    fidObserver.observe({ type: 'first-input', buffered: true })
    this.observers.push(fidObserver)

    // Layout Shift
    const clsObserver = new PerformanceObserver((list) => {
      let clsValue = 0
      const entries = list.getEntries()
      entries.forEach(entry => {
        if (!entry.hadRecentInput) {
          clsValue += entry.value
        }
      })
      this.recordMetric({
        name: 'CLS',
        value: clsValue,
        unit: '',
        timestamp: Date.now(),
        category: 'paint'
      })
    })
    clsObserver.observe({ type: 'layout-shift', buffered: true })
    this.observers.push(clsObserver)
  }

  private cleanupObservers(): void {
    this.observers.forEach(observer => observer.disconnect())
    this.observers = []
  }

  private startPeriodicCollection(): void {
    const collectMetrics = () => {
      if (!this.isMonitoring) return

      // Collect memory metrics if available
      if (performance.memory) {
        this.recordMetric({
          name: 'memory_used',
          value: performance.memory.usedJSHeapSize,
          unit: 'bytes',
          timestamp: Date.now(),
          category: 'custom'
        })
        
        this.recordMetric({
          name: 'memory_total',
          value: performance.memory.totalJSHeapSize,
          unit: 'bytes',
          timestamp: Date.now(),
          category: 'custom'
        })
      }

      // Collect navigation timing if available
      if (performance.timing) {
        const timing = performance.timing
        this.recordMetric({
          name: 'TTFB',
          value: timing.responseStart - timing.requestStart,
          unit: 'ms',
          timestamp: Date.now(),
          category: 'navigation'
        })
      }
    }

    setInterval(collectMetrics, 5000)
  }

  recordMetric(metric: PerformanceMetric): void {
    this.metrics.push(metric)
    
    // Keep only last 1000 metrics to prevent memory issues
    if (this.metrics.length > 1000) {
      this.metrics = this.metrics.slice(-1000)
    }
    
    // Check for threshold violations
    this.checkThresholdViolations(metric)
  }

  private checkThresholdViolations(metric: PerformanceMetric): void {
    const threshold = this.thresholds.find(t => t.name === metric.name)
    if (!threshold) return

    if (metric.value > threshold.max) {
      const violation: PerformanceViolation = {
        metric: metric.name,
        actual: metric.value,
        expected: threshold.max,
        severity: threshold.severity,
        recommendation: this.getRecommendation(metric.name, metric.value)
      }
      
      this.handleViolation(violation)
    }
  }

  private getRecommendation(metricName: string, value: number): string {
    const recommendations = {
      FCP: 'Optimize critical rendering path, reduce render-blocking resources',
      LCP: 'Optimize images, improve server response time, reduce JavaScript execution time',
      FID: 'Reduce JavaScript execution time, break up long tasks, use web workers',
      CLS: 'Avoid dynamic content injection, specify image dimensions, use CSS transforms',
      TTFB: 'Improve server response time, use CDN, optimize database queries',
      page_load: 'Optimize bundle size, enable compression, use code splitting',
      api_response: 'Optimize API endpoints, implement caching, use pagination',
      component_render: 'Optimize component logic, use React.memo, implement virtualization',
      interaction_response: 'Debounce event handlers, use requestAnimationFrame, optimize JavaScript'
    }
    
    return recommendations[metricName as keyof typeof recommendations] || 'Review and optimize performance'
  }

  private handleViolation(violation: PerformanceViolation): void {
    // Log violation for debugging
    console.warn('Performance violation:', violation)
    
    // Send to analytics if available
    if (typeof navigator.sendBeacon === 'function') {
      const data = new Blob([JSON.stringify({
        type: 'performance_violation',
        violation,
        timestamp: Date.now(),
        url: window.location.href
      })], { type: 'application/json' })
      
      navigator.sendBeacon('/api/analytics/performance', data)
    }
    
    // Show user notification for critical violations
    if (violation.severity === 'critical') {
      this.showPerformanceNotification(violation)
    }
  }

  private showPerformanceNotification(violation: PerformanceViolation): void {
    // This would integrate with your toast/notification system
    console.warn(`Performance Alert: ${violation.metric} is ${violation.actual}${this.getUnit(violation.metric)} (expected: ${violation.expected}${this.getUnit(violation.metric)})`)
  }

  private getUnit(metricName: string): string {
    const threshold = this.thresholds.find(t => t.name === metricName)
    return threshold?.unit || ''
  }

  generateReport(): PerformanceReport {
    const violations: PerformanceViolation[] = []
    
    this.thresholds.forEach(threshold => {
      const recentMetrics = this.metrics.filter(m => 
        m.name === threshold.name && 
        Date.now() - m.timestamp < 30000 // Last 30 seconds
      )
      
      if (recentMetrics.length > 0) {
        const avgValue = recentMetrics.reduce((sum, m) => sum + m.value, 0) / recentMetrics.length
        
        if (avgValue > threshold.max) {
          violations.push({
            metric: threshold.name,
            actual: avgValue,
            expected: threshold.max,
            severity: threshold.severity,
            recommendation: this.getRecommendation(threshold.name, avgValue)
          })
        }
      }
    })
    
    const score = this.calculatePerformanceScore(violations)
    const recommendations = this.generateRecommendations(violations)
    
    return {
      metrics: this.metrics.slice(-100), // Last 100 metrics
      thresholds: this.thresholds,
      violations,
      score,
      recommendations,
      timestamp: Date.now()
    }
  }

  private calculatePerformanceScore(violations: PerformanceViolation[]): number {
    if (violations.length === 0) return 100
    
    let totalPenalty = 0
    violations.forEach(violation => {
      const severityWeight = {
        low: 1,
        medium: 2,
        high: 3,
        critical: 5
      }
      totalPenalty += severityWeight[violation.severity]
    })
    
    return Math.max(0, 100 - totalPenalty * 5)
  }

  private generateRecommendations(violations: PerformanceViolation[]): string[] {
    const recommendations = new Set<string>()
    
    violations.forEach(violation => {
      recommendations.add(violation.recommendation)
    })
    
    return Array.from(recommendations)
  }

  getMetrics(category?: PerformanceMetric['category']): PerformanceMetric[] {
    if (category) {
      return this.metrics.filter(m => m.category === category)
    }
    return [...this.metrics]
  }

  getThresholds(): PerformanceThreshold[] {
    return [...this.thresholds]
  }

  clearMetrics(): void {
    this.metrics = []
  }
}

// Performance Optimization Utilities
export class PerformanceOptimizer {
  private static instance: PerformanceOptimizer
  private observer: IntersectionObserver | null = null
  private loadedImages = new Set<string>()
  private loadedScripts = new Set<string>()

  private constructor() {}

  static getInstance(): PerformanceOptimizer {
    if (!PerformanceOptimizer.instance) {
      PerformanceOptimizer.instance = new PerformanceOptimizer()
    }
    return PerformanceOptimizer.instance
  }

  // Lazy Loading Images
  setupLazyLoading(): void {
    if ('IntersectionObserver' in window) {
      this.observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const img = entry.target as HTMLImageElement
            this.loadImage(img)
            this.observer?.unobserve(img)
          }
        })
      }, {
        rootMargin: '50px 0px',
        threshold: 0.1
      })

      // Observe all images with data-src
      document.querySelectorAll('img[data-src]').forEach(img => {
        this.observer?.observe(img)
      })
    }
  }

  private loadImage(img: HTMLImageElement): void {
    const src = img.dataset.src
    if (!src || this.loadedImages.has(src)) return

    this.loadedImages.add(src)
    
    // Create a new image to preload
    const tempImg = new Image()
    tempImg.onload = () => {
      img.src = src
      img.removeAttribute('data-src')
      img.classList.add('loaded')
    }
    tempImg.onerror = () => {
      img.classList.add('error')
    }
    tempImg.src = src
  }

  // Code Splitting and Lazy Loading
  async loadComponent<T>(importFn: () => Promise<T>, componentName: string): Promise<T> {
    const startTime = performance.now()
    
    try {
      const component = await importFn()
      const loadTime = performance.now() - startTime
      
      PerformanceMonitor.getInstance().recordMetric({
        name: 'component_load',
        value: loadTime,
        unit: 'ms',
        timestamp: Date.now(),
        category: 'custom',
        metadata: { componentName }
      })
      
      return component
    } catch (error) {
      PerformanceMonitor.getInstance().recordMetric({
        name: 'component_load_error',
        value: 1,
        unit: '',
        timestamp: Date.now(),
        category: 'custom',
        metadata: { componentName, error: String(error) }
      })
      
      throw error
    }
  }

  // Debounce and Throttle for Performance
  debounce<T extends (...args: any[]) => any>(
    func: T,
    wait: number
  ): (...args: Parameters<T>) => void {
    let timeout: NodeJS.Timeout
    
    return (...args: Parameters<T>) => {
      clearTimeout(timeout)
      timeout = setTimeout(() => func(...args), wait)
    }
  }

  throttle<T extends (...args: any[]) => any>(
    func: T,
    limit: number
  ): (...args: Parameters<T>) => void {
    let inThrottle: boolean
    
    return (...args: Parameters<T>) => {
      if (!inThrottle) {
        func(...args)
        inThrottle = true
        setTimeout(() => inThrottle = false, limit)
      }
    }
  }

  // Request Animation Frame for Smooth Animations
  raf(callback: FrameRequestCallback): number {
    return requestAnimationFrame(callback)
  }

  cancelRaf(id: number): void {
    cancelAnimationFrame(id)
  }

  // Virtual Scrolling for Large Lists
  setupVirtualScrolling(container: HTMLElement, itemHeight: number): void {
    let scrollTop = 0
    let viewportHeight = 0
    let totalItems = 0

    const updateVisibleItems = () => {
      const startIndex = Math.floor(scrollTop / itemHeight)
      const endIndex = Math.min(
        startIndex + Math.ceil(viewportHeight / itemHeight) + 1,
        totalItems
      )

      // Update visible items
      const items = container.children
      for (let i = 0; i < items.length; i++) {
        const item = items[i] as HTMLElement
        const itemIndex = parseInt(item.dataset.index || '0')
        
        if (itemIndex >= startIndex && itemIndex <= endIndex) {
          item.style.display = 'block'
          item.style.transform = `translateY(${itemIndex * itemHeight}px)`
        } else {
          item.style.display = 'none'
        }
      }
    }

    const handleScroll = () => {
      scrollTop = container.scrollTop
      updateVisibleItems()
    }

    const resizeObserver = new ResizeObserver(entries => {
      viewportHeight = container.clientHeight
      updateVisibleItems()
    })

    resizeObserver.observe(container)
    container.addEventListener('scroll', this.throttle(handleScroll, 16))
  }

  // Memory Management
  cleanup(): void {
    if (this.observer) {
      this.observer.disconnect()
      this.observer = null
    }
    
    this.loadedImages.clear()
    this.loadedScripts.clear()
  }
}

// Performance Analytics
export class PerformanceAnalytics {
  private static instance: PerformanceAnalytics
  private events: PerformanceEvent[] = []

  private constructor() {}

  static getInstance(): PerformanceAnalytics {
    if (!PerformanceAnalytics.instance) {
      PerformanceAnalytics.instance = new PerformanceAnalytics()
    }
    return PerformanceAnalytics.instance
  }

  trackEvent(event: PerformanceEvent): void {
    this.events.push(event)
    
    // Keep only last 1000 events
    if (this.events.length > 1000) {
      this.events = this.events.slice(-1000)
    }
    
    // Send to analytics if available
    this.sendToAnalytics(event)
  }

  private sendToAnalytics(event: PerformanceEvent): void {
    if (typeof navigator.sendBeacon === 'function') {
      const data = new Blob([JSON.stringify({
        type: 'performance_event',
        event,
        timestamp: Date.now(),
        url: window.location.href
      })], { type: 'application/json' })
      
      navigator.sendBeacon('/api/analytics/performance', data)
    }
  }

  getEvents(type?: PerformanceEvent['type']): PerformanceEvent[] {
    if (type) {
      return this.events.filter(e => e.type === type)
    }
    return [...this.events]
  }

  clearEvents(): void {
    this.events = []
  }
}

export interface PerformanceEvent {
  type: 'navigation' | 'interaction' | 'custom'
  name: string
  value: number
  unit: string
  timestamp: number
  metadata?: Record<string, any>
}

// Export utilities
export const performance = {
  monitor: PerformanceMonitor,
  optimizer: PerformanceOptimizer,
  analytics: PerformanceAnalytics,
  startMonitoring: () => PerformanceMonitor.getInstance().startMonitoring(),
  stopMonitoring: () => PerformanceMonitor.getInstance().stopMonitoring(),
  recordMetric: (metric: PerformanceMetric) => PerformanceMonitor.getInstance().recordMetric(metric),
  generateReport: () => PerformanceMonitor.getInstance().generateReport(),
  setupLazyLoading: () => PerformanceOptimizer.getInstance().setupLazyLoading(),
  loadComponent: <T>(importFn: () => Promise<T>, componentName: string) => 
    PerformanceOptimizer.getInstance().loadComponent(importFn, componentName),
  debounce: <T extends (...args: any[]) => any>(func: T, wait: number) => 
    PerformanceOptimizer.getInstance().debounce(func, wait),
  throttle: <T extends (...args: any[]) => any>(func: T, limit: number) => 
    PerformanceOptimizer.getInstance().throttle(func, limit),
  trackMetric: (name: string, value: number) => PerformanceMonitor.getInstance().recordMetric({
    name,
    value,
    unit: '',
    timestamp: Date.now(),
    category: 'custom'
  }),
  trackEvent: (event: PerformanceEvent) => PerformanceAnalytics.getInstance().trackEvent(event)
}

// Export singleton instance for easy import
export const performanceMonitor = PerformanceMonitor.getInstance()

export default performance