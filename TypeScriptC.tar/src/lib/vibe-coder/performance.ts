/**
 * Otimizador de Performance para Vibe-Coder
 * 
 * Implementa debounce, throttle e memoização para otimizar
 * o desempenho do sistema evolutivo
 */

export class PerformanceOptimizer {
  private debounceTimers = new Map<string, number>();
  private throttleFlags = new Map<string, boolean>();
  private memoCache = new Map<string, { data: any; timestamp: number }>();
  
  /**
   * Implementa debounce para evitar chamadas excessivas
   */
  debounce<T extends (...args: any[]) => any>(
    key: string,
    func: T,
    delay: number = 300
  ): (...args: Parameters<T>) => void {
    return (...args: Parameters<T>) => {
      const existingTimer = this.debounceTimers.get(key);
      if (existingTimer) {
        clearTimeout(existingTimer);
      }
      
      const timer = setTimeout(() => {
        func(...args);
        this.debounceTimers.delete(key);
      }, delay) as unknown as number;
      
      this.debounceTimers.set(key, timer);
    };
  }
  
  /**
   * Implementa throttle para limitar frequência de execução
   */
  throttle<T extends (...args: any[]) => any>(
    key: string,
    func: T,
    limit: number = 1000
  ): (...args: Parameters<T>) => void {
    return (...args: Parameters<T>) => {
      if (this.throttleFlags.get(key)) return;
      
      this.throttleFlags.set(key, true);
      func(...args);
      
      setTimeout(() => {
        this.throttleFlags.delete(key);
      }, limit);
    };
  }
  
  /**
   * Memoização de funções com cache baseado em argumentos
   */
  memoize<T extends (...args: any[]) => any>(
    key: string,
    func: T,
    ttl: number = 5000
  ): (...args: Parameters<T>) => ReturnType<T> {
    return (...args: Parameters<T>): ReturnType<T> => {
      const cacheKey = `${key}_${JSON.stringify(args)}`;
      const cached = this.memoCache.get(cacheKey);
      
      if (cached && Date.now() - cached.timestamp < ttl) {
        return cached.data;
      }
      
      const result = func(...args);
      this.memoCache.set(cacheKey, {
        data: result,
        timestamp: Date.now()
      });
      
      return result;
    };
  }
  
  /**
   * Limpa todos os timers e caches
   */
  cleanup(): void {
    // Limpar debounce timers
    for (const timer of this.debounceTimers.values()) {
      clearTimeout(timer);
    }
    this.debounceTimers.clear();
    
    // Limpar throttle flags
    this.throttleFlags.clear();
    
    // Limpar memo cache
    this.memoCache.clear();
  }
  
  /**
   * Obtém estatísticas de performance
   */
  getStats() {
    return {
      activeDebounces: this.debounceTimers.size,
      activeThrottles: this.throttleFlags.size,
      memoCacheSize: this.memoCache.size
    };
  }
}

// Instância global para uso no sistema
export const perfOptimizer = new PerformanceOptimizer();