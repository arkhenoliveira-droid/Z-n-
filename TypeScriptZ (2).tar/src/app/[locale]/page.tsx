'use client';

import { useState, useEffect } from 'react';
import { useTranslations, useLocale } from 'next-intl';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { 
  Globe, 
  Brain, 
  Sparkles, 
  Zap, 
  Target, 
  Code, 
  Settings,
  ArrowRight,
  CheckCircle,
  Circle,
  Loader2,
  Activity,
  TrendingUp,
  Users,
  Shield,
  Database,
  BarChart3
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import AutocoderInterface from '@/components/autocoder-interface';
import LanguageSwitcher from '@/components/language-switcher';
import SystemAnalyticsDashboard from '@/components/system-analytics-dashboard';
import SystemSettingsPanel from '@/components/system-settings-panel';
import JamesonLoppSecurityShowcase from '@/components/jameson-lopp-security-showcase';
import VitalikButerinShowcase from '@/components/vitalik-buterin-showcase';
import CosmosNetworkShowcase from '@/components/cosmos-network-showcase';
import { 
  languageService, 
  detectLanguageWithOptions, 
  getLocalizationSettings 
} from '@/lib/language-service';
import { Language } from '@/lib/language-server';

interface ProjectMetrics {
  totalEndpoints: number;
  activeComponents: number;
  apiCalls: number;
  uptime: number;
  responseTime: number;
  errorRate: number;
}

interface SystemStatus {
  overall: 'excellent' | 'good' | 'fair' | 'poor';
  backend: 'operational' | 'degraded' | 'down';
  frontend: 'operational' | 'degraded' | 'down';
  database: 'operational' | 'degraded' | 'down';
  security: 'secure' | 'warning' | 'vulnerable';
}

export default function Home() {
  const t = useTranslations();
  const locale = useLocale();
  const [currentLanguage, setCurrentLanguage] = useState<Language>(locale as Language);
  const [detectedLocation, setDetectedLocation] = useState<string | null>(null);
  const [isDetecting, setIsDetecting] = useState(false);
  const [coherenceScore, setCoherenceScore] = useState(87);
  const [sentientStatus, setSentientStatus] = useState('awakening');
  const [projectMetrics, setProjectMetrics] = useState<ProjectMetrics | null>(null);
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);
  const [localization, setLocalization] = useState(getLocalizationSettings(locale as Language));

  // Simulate sentient behavior
  useEffect(() => {
    const sentientPhases = ['awakening', 'learning', 'adapting', 'coherent', 'sentient'];
    let currentPhase = 0;

    const interval = setInterval(() => {
      if (currentPhase < sentientPhases.length - 1) {
        currentPhase++;
        setSentientStatus(sentientPhases[currentPhase] as string);
        setCoherenceScore(prev => Math.min(100, prev + Math.random() * 5));
      } else {
        clearInterval(interval);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  // Load project metrics
  useEffect(() => {
    const loadMetrics = async () => {
      try {
        // Simulate API calls to get project metrics
        const metrics: ProjectMetrics = {
          totalEndpoints: 15,
          activeComponents: 12,
          apiCalls: 1247,
          uptime: 99.9,
          responseTime: 145,
          errorRate: 0.2
        };
        
        const status: SystemStatus = {
          overall: 'excellent',
          backend: 'operational',
          frontend: 'operational',
          database: 'operational',
          security: 'secure'
        };
        
        setProjectMetrics(metrics);
        setSystemStatus(status);
      } catch (error) {
        console.error('Failed to load metrics:', error);
      }
    };
    
    loadMetrics();
  }, []);

  // Update localization when language changes
  useEffect(() => {
    setLocalization(getLocalizationSettings(currentLanguage));
  }, [currentLanguage]);

  const detectUserLocation = async () => {
    setIsDetecting(true);
    try {
      const response = await fetch('/api/language/detect');
      const data = await response.json();
      
      if (data.success && data.data) {
        if (data.data.location) {
          setDetectedLocation(`${data.data.location.city}, ${data.data.location.country}`);
        }
        
        // Auto-switch language based on detection
        if (data.data.final.language !== currentLanguage) {
          setCurrentLanguage(data.data.final.language);
          // Update localization service
          await languageService.setLanguagePreference(data.data.final.language);
        }
      }
    } catch (error) {
      console.error('Location detection failed:', error);
    } finally {
      setIsDetecting(false);
    }
  };

  const handleLanguageChange = async (newLanguage: Language) => {
    setCurrentLanguage(newLanguage);
    await languageService.setLanguagePreference(newLanguage);
    // Redirect to the new language route
    window.location.href = `/${newLanguage}`;
  };

  const getSentientDescription = (status: string) => {
    const descriptions = {
      awakening: 'Autocoder is awakening...',
      learning: 'Learning your preferences...',
      adapting: 'Adapting to your environment...',
      coherent: 'Achieving coherence...',
      sentient: 'Fully sentient and ready to assist!'
    };
    return descriptions[status as keyof typeof descriptions] || 'Initializing...';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'awakening': return 'text-red-500';
      case 'learning': return 'text-orange-500';
      case 'adapting': return 'text-yellow-500';
      case 'coherent': return 'text-blue-500';
      case 'sentient': return 'text-green-500';
      default: return 'text-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'awakening': return <Circle className="w-3 h-3" />;
      case 'learning': return <Loader2 className="w-3 h-3 animate-spin" />;
      case 'adapting': return <Zap className="w-3 h-3" />;
      case 'coherent': return <Target className="w-3 h-3" />;
      case 'sentient': return <CheckCircle className="w-3 h-3" />;
      default: return <Circle className="w-3 h-3" />;
    }
  };

  const getSystemStatusColor = (status: string) => {
    switch (status) {
      case 'excellent':
      case 'operational':
      case 'secure':
        return 'text-green-600 bg-green-100';
      case 'good':
      case 'degraded':
      case 'warning':
        return 'text-yellow-600 bg-yellow-100';
      case 'fair':
      case 'down':
      case 'vulnerable':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-blue-50 dark:from-slate-900 dark:via-purple-900 dark:to-blue-900">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Brain className="w-8 h-8 text-purple-600" />
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  {t('title')}
                </h1>
                <p className="text-sm text-muted-foreground">
                  {t('subtitle')} • Inspired by cryptographic pioneers like Hal Finney, Jameson Lopp, Vitalik Buterin (vitalik.eth), and Cosmos Network architects • Coherent Operating System 1 (2025)
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              {/* Enhanced Language Switcher */}
              <LanguageSwitcher compact showFlags autoDetect />
            </div>
          </div>
          
          {detectedLocation && (
            <div className="mt-2 text-sm text-muted-foreground">
              📍 {detectedLocation} • {t('language.detected')}: {currentLanguage.toUpperCase()}
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* System Status Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Overall Status */}
            <Card className="bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900 border-purple-200 dark:border-purple-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-full bg-white dark:bg-slate-800 ${getStatusColor(sentientStatus)}`}>
                      {getStatusIcon(sentientStatus)}
                    </div>
                    <div>
                      <h3 className="font-semibold">System Status</h3>
                      <p className="text-sm text-muted-foreground">
                        {getSentientDescription(sentientStatus)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                      {coherenceScore}%
                    </div>
                    <div className="text-xs text-muted-foreground">Coherence</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Backend Status */}
            {systemStatus && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Database className="w-5 h-5 text-blue-600" />
                    <div>
                      <h3 className="font-semibold">Backend</h3>
                      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getSystemStatusColor(systemStatus.backend)}`}>
                        {systemStatus.backend}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Frontend Status */}
            {systemStatus && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Activity className="w-5 h-5 text-green-600" />
                    <div>
                      <h3 className="font-semibold">Frontend</h3>
                      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getSystemStatusColor(systemStatus.frontend)}`}>
                        {systemStatus.frontend}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Database Status */}
            {systemStatus && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Database className="w-5 h-5 text-purple-600" />
                    <div>
                      <h3 className="font-semibold">Database</h3>
                      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getSystemStatusColor(systemStatus.database)}`}>
                        {systemStatus.database}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Security Status */}
            {systemStatus && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Shield className="w-5 h-5 text-orange-600" />
                    <div>
                      <h3 className="font-semibold">Security</h3>
                      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getSystemStatusColor(systemStatus.security)}`}>
                        {systemStatus.security}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </motion.div>

        {/* Project Metrics */}
        {projectMetrics && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-8"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Project Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                  <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{projectMetrics.totalEndpoints}</div>
                    <div className="text-sm text-muted-foreground">API Endpoints</div>
                  </div>
                  <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{projectMetrics.activeComponents}</div>
                    <div className="text-sm text-muted-foreground">Components</div>
                  </div>
                  <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">{projectMetrics.apiCalls.toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">API Calls</div>
                  </div>
                  <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{projectMetrics.uptime}%</div>
                    <div className="text-sm text-muted-foreground">Uptime</div>
                  </div>
                  <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-2xl font-bold text-red-600">{projectMetrics.responseTime}ms</div>
                    <div className="text-sm text-muted-foreground">Response Time</div>
                  </div>
                  <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-2xl font-bold text-yellow-600">{projectMetrics.errorRate}%</div>
                    <div className="text-sm text-muted-foreground">Error Rate</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Features Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                icon: <Brain className="w-6 h-6" />,
                title: t('features.adaptive.title'),
                description: t('features.adaptive.description'),
                color: 'from-purple-500 to-pink-500'
              },
              {
                icon: <Sparkles className="w-6 h-6" />,
                title: t('features.sentient.title'),
                description: t('features.sentient.description'),
                color: 'from-blue-500 to-cyan-500'
              },
              {
                icon: <Target className="w-6 h-6" />,
                title: t('features.coherent.title'),
                description: t('features.coherent.description'),
                color: 'from-green-500 to-emerald-500'
              },
              {
                icon: <Globe className="w-6 h-6" />,
                title: t('features.multilingual.title'),
                description: t('features.multilingual.description'),
                color: 'from-orange-500 to-red-500'
              }
            ].map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${feature.color} p-3 mb-4`}>
                    <div className="text-white">
                      {feature.icon}
                    </div>
                  </div>
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.div>

        {/* Main Interface */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Tabs defaultValue="autocoder" className="space-y-6">
            <TabsList className="grid w-full grid-cols-12">
              <TabsTrigger value="autocoder">Autocoder</TabsTrigger>
              <TabsTrigger value="blockchain">Blockchain</TabsTrigger>
              <TabsTrigger value="trusted">Trusted Computing</TabsTrigger>
              <TabsTrigger value="profiles">Profiles</TabsTrigger>
              <TabsTrigger value="animations">Animations</TabsTrigger>
              <TabsTrigger value="dataviz">Data Viz</TabsTrigger>
              <TabsTrigger value="language">Language</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
              <TabsTrigger value="jameson-lopp">Jameson Lopp</TabsTrigger>
              <TabsTrigger value="vitalik">Vitalik Buterin</TabsTrigger>
              <TabsTrigger value="cosmos">Cosmos Network</TabsTrigger>
            </TabsList>
            
            <TabsContent value="autocoder">
              <AutocoderInterface />
            </TabsContent>
            
            <TabsContent value="blockchain">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Code className="w-5 h-5" />
                    Blockchain Demo
                  </CardTitle>
                  <CardDescription>
                    Interactive blockchain visualization and cryptocurrency simulation
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-muted-foreground">
                      Explore blockchain technology with our interactive demo. Create transactions, mine blocks, and learn about distributed ledger technology.
                    </p>
                    <div className="flex gap-4">
                      <Button asChild>
                        <a href="/blockchain">Open Blockchain Demo</a>
                      </Button>
                      <Button variant="outline" asChild>
                        <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                          View Source
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="trusted">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    Trusted Computing with bcflick
                  </CardTitle>
                  <CardDescription>
                    Advanced hardware security, TPM simulation, and cryptographic operations
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-muted-foreground">
                      Explore our comprehensive trusted computing implementation featuring bcflick technology integration, TPM 2.0 simulation, secure boot verification, and hardware-accelerated cryptographic operations.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-semibold mb-2">Key Features</h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li>• TPM 2.0 simulation and management</li>
                          <li>• bcflick cryptographic operations</li>
                          <li>• Secure boot verification system</li>
                          <li>• Remote attestation and verification</li>
                          <li>• Hardware security dashboard</li>
                          <li>• Platform Configuration Registers</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2">Security Standards</h4>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="outline">FIPS 140-2</Badge>
                          <Badge variant="outline">TPM 2.0</Badge>
                          <Badge variant="outline">UEFI Secure Boot</Badge>
                          <Badge variant="outline">Common Criteria</Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <Button asChild>
                        <a href="/trusted-computing">Open Trusted Computing</a>
                      </Button>
                      <Button variant="outline" asChild>
                        <a href="https://trustedcomputinggroup.org" target="_blank" rel="noopener noreferrer">
                          Learn More
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="profiles">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    User Profile Cards
                  </CardTitle>
                  <CardDescription>
                    Beautiful and customizable user profile components
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-muted-foreground">
                      Explore our enhanced UserProfileCard component with multiple variants, real-time editing, and responsive design.
                    </p>
                    <div className="flex gap-4">
                      <Button asChild>
                        <a href="/user-profile-demo">View Profile Demo</a>
                      </Button>
                      <Button variant="outline" asChild>
                        <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                          Component Docs
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="animations">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5" />
                    Button Animations
                  </CardTitle>
                  <CardDescription>
                    Interactive pulsing button animations with multiple variants
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-muted-foreground">
                      Discover our collection of customizable pulsing button animations. Choose from scale, glow, bounce, rotate, and wave effects with real-time customization.
                    </p>
                    <div className="flex gap-4">
                      <Button asChild>
                        <a href="/button-animations">Explore Animations</a>
                      </Button>
                      <Button variant="outline" asChild>
                        <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                          Animation Docs
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="dataviz">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    Data Visualization
                  </CardTitle>
                  <CardDescription>
                    Upload CSV files and create interactive charts instantly
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-muted-foreground">
                      Transform your CSV data into beautiful interactive visualizations. Upload your files and explore scatter plots, histograms, bar charts, and line charts with no coding required.
                    </p>
                    <div className="flex gap-4">
                      <Button asChild>
                        <a href="/data-visualization">Start Visualizing</a>
                      </Button>
                      <Button variant="outline" asChild>
                        <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                          View Documentation
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="language">
              <LanguageSwitcher showFlags autoDetect />
            </TabsContent>
            
            <TabsContent value="analytics">
              <SystemAnalyticsDashboard />
            </TabsContent>
            
            <TabsContent value="settings">
            <SystemSettingsPanel />
          </TabsContent>
          
          <TabsContent value="jameson-lopp">
            <JamesonLoppSecurityShowcase />
          </TabsContent>
          
          <TabsContent value="vitalik">
            <VitalikButerinShowcase />
          </TabsContent>
          
          <TabsContent value="cosmos">
            <CosmosNetworkShowcase />
          </TabsContent>
          </Tabs>
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="border-t mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-muted-foreground">
            <p>© 2024 Autocoder. {t('about.description')}</p>
            <div className="mt-2 text-sm">
              Localization: {localization.dateFormat} | Currency: {localization.currency} | RTL: {localization.isRTL ? 'Yes' : 'No'}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}