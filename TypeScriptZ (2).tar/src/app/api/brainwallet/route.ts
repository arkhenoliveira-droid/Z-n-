import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

// Brainwallet alphabet analysis and connectivity demonstration
export async function POST(request: NextRequest) {
  try {
    const { passphrase, analysisType = 'full' } = await request.json();
    
    if (!passphrase) {
      return NextResponse.json({ error: 'Passphrase is required' }, { status: 400 });
    }

    const results = {
      passphrase,
      timestamp: new Date().toISOString(),
      analysis: {} as any
    };

    if (analysisType === 'full' || analysisType === 'generation') {
      results.analysis.generation = await analyzeKeyGeneration(passphrase);
    }

    if (analysisType === 'full' || analysisType === 'alphabets') {
      results.analysis.alphabets = analyzeAlphabets(passphrase);
    }

    if (analysisType === 'full' || analysisType === 'connectivity') {
      results.analysis.connectivity = analyzeConnectivity(passphrase);
    }

    if (analysisType === 'full' || analysisType === 'security') {
      results.analysis.security = analyzeSecurity(passphrase);
    }

    if (analysisType === 'full' || analysisType === 'temporal') {
      results.analysis.temporal = analyzeTemporalDimensions(passphrase);
    }

    if (analysisType === 'full' || analysisType === 'philosophical') {
      results.analysis.philosophical = analyzePhilosophicalDimensions(passphrase);
    }

    return NextResponse.json(results);
  } catch (error) {
    console.error('Brainwallet analysis error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

async function analyzeKeyGeneration(passphrase: string) {
  // Generate private key using different methods
  const sha256Key = crypto.createHash('sha256').update(passphrase).digest('hex');
  const sha512Key = crypto.createHash('sha512').update(passphrase).digest('hex');
  
  // PBKDF2 with salt
  const salt = crypto.randomBytes(16);
  const pbkdf2Key = crypto.pbkdf2Sync(passphrase, salt, 100000, 32, 'sha256').toString('hex');
  
  // HMAC-based key generation
  const hmacKey = crypto.createHmac('sha256', 'brainwallet-salt').update(passphrase).digest('hex');

  return {
    methods: {
      sha256: {
        key: sha256Key,
        length: sha256Key.length,
        algorithm: 'SHA-256'
      },
      sha512: {
        key: sha512Key,
        length: sha512Key.length,
        algorithm: 'SHA-512'
      },
      pbkdf2: {
        key: pbkdf2Key,
        length: pbkdf2Key.length,
        algorithm: 'PBKDF2-SHA256',
        iterations: 100000,
        salt: salt.toString('hex')
      },
      hmac: {
        key: hmacKey,
        length: hmacKey.length,
        algorithm: 'HMAC-SHA256'
      }
    },
    entropy: calculateEntropy(passphrase),
    keySpace: Math.pow(2, 256) // Bitcoin private key space
  };
}

function analyzeAlphabets(passphrase: string) {
  const hexAlphabet = '0123456789abcdefABCDEF';
  const base58Alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  const base64Alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  
  // Generate a sample key for analysis
  const sampleKey = crypto.createHash('sha256').update(passphrase).digest('hex');
  
  return {
    alphabets: {
      hexadecimal: {
        characters: hexAlphabet,
        size: hexAlphabet.length,
        bitsPerChar: 4,
        sample: sampleKey,
        usage: 'Private keys, transaction hashes'
      },
      base58: {
        characters: base58Alphabet,
        size: base58Alphabet.length,
        bitsPerChar: Math.log2(base58Alphabet.length),
        sample: convertToBase58(sampleKey),
        usage: 'Bitcoin addresses, WIF format'
      },
      base64: {
        characters: base64Alphabet,
        size: base64Alphabet.length,
        bitsPerChar: 6,
        sample: Buffer.from(sampleKey, 'hex').toString('base64'),
        usage: 'Encoding, certificates'
      }
    },
    alphabetAnalysis: {
      characterDistribution: analyzeCharacterDistribution(sampleKey),
      entropyPerAlphabet: {
        hexadecimal: calculateAlphabetEntropy(sampleKey, hexAlphabet),
        base58: calculateAlphabetEntropy(convertToBase58(sampleKey), base58Alphabet),
        base64: calculateAlphabetEntropy(Buffer.from(sampleKey, 'hex').toString('base64'), base64Alphabet)
      }
    }
  };
}

function analyzeConnectivity(passphrase: string) {
  const key = crypto.createHash('sha256').update(passphrase).digest('hex');
  
  return {
    connectivityMetrics: {
      deterministicConnectivity: {
        strength: 1.0, // Perfect determinism
        description: 'Same passphrase always produces same key'
      },
      cryptographicConnectivity: {
        strength: 0.95,
        description: 'One-way function with strong cryptographic properties'
      },
      semanticConnectivity: {
        strength: calculateSemanticConnectivity(passphrase, key),
        description: 'Relationship between passphrase meaning and key value'
      }
    },
    crossAlphabetConnectivity: {
      hexToBase58: calculateCrossAlphabetConnectivity(key, convertToBase58(key)),
      hexToBase64: calculateCrossAlphabetConnectivity(key, Buffer.from(key, 'hex').toString('base64')),
      base58ToBase64: calculateCrossAlphabetConnectivity(convertToBase58(key), Buffer.from(key, 'hex').toString('base64'))
    },
    coherenceScore: calculateCoherenceScore(passphrase, key)
  };
}

function analyzeSecurity(passphrase: string) {
  const entropy = calculateEntropy(passphrase);
  const key = crypto.createHash('sha256').update(passphrase).digest('hex');
  
  return {
    vulnerabilityAssessment: {
      entropyScore: entropy >= 128 ? 'high' : entropy >= 80 ? 'medium' : 'low',
      bruteForceResistance: calculateBruteForceResistance(entropy),
      dictionaryAttackRisk: assessDictionaryAttackRisk(passphrase),
      rainbowTableVulnerability: assessRainbowTableVulnerability(passphrase)
    },
    recommendations: generateSecurityRecommendations(passphrase, entropy),
    strengthMetrics: {
      overall: calculateOverallStrength(entropy, passphrase),
      cryptographic: 0.95,
      memorability: calculateMemorability(passphrase),
      uniqueness: calculateUniqueness(passphrase)
    }
  };
}

// Helper functions
function calculateEntropy(passphrase: string): number {
  const charSet = new Set(passphrase);
  const charSetSize = charSet.size;
  return passphrase.length * Math.log2(charSetSize);
}

function convertToBase58(hex: string): string {
  const base58Alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  let num = BigInt('0x' + hex);
  let result = '';
  
  while (num > 0n) {
    const remainder = num % 58n;
    result = base58Alphabet[Number(remainder)] + result;
    num = num / 58n;
  }
  
  return result || '1';
}

function analyzeCharacterDistribution(text: string): Record<string, number> {
  const distribution: Record<string, number> = {};
  for (const char of text) {
    distribution[char] = (distribution[char] || 0) + 1;
  }
  return distribution;
}

function calculateAlphabetEntropy(text: string, alphabet: string): number {
  const charSet = new Set(alphabet);
  const textCharSet = new Set(text);
  const intersection = new Set([...charSet].filter(char => textCharSet.has(char)));
  return intersection.size / charSet.size;
}

function calculateSemanticConnectivity(passphrase: string, key: string): number {
  // Simple heuristic based on passphrase characteristics
  const words = passphrase.toLowerCase().split(/\s+/);
  const commonWords = ['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'];
  const commonWordRatio = words.filter(word => commonWords.includes(word)).length / words.length;
  
  // Lower connectivity for common words, higher for unique phrases
  return Math.max(0.1, 1 - commonWordRatio);
}

function calculateCrossAlphabetConnectivity(str1: string, str2: string): number {
  // Calculate correlation between two encoded representations
  const chars1 = new Set(str1);
  const chars2 = new Set(str2);
  const intersection = new Set([...chars1].filter(char => chars2.has(char)));
  const union = new Set([...chars1, ...chars2]);
  
  return intersection.size / union.size; // Jaccard similarity
}

function calculateCoherenceScore(passphrase: string, key: string): number {
  const entropy = calculateEntropy(passphrase);
  const semantic = calculateSemanticConnectivity(passphrase, key);
  const cryptographic = 0.95; // Fixed for cryptographic functions
  
  return (entropy / 256) * 0.4 + semantic * 0.3 + cryptographic * 0.3;
}

function calculateBruteForceResistance(entropy: number): string {
  if (entropy >= 128) return 'excellent';
  if (entropy >= 100) return 'good';
  if (entropy >= 80) return 'fair';
  return 'poor';
}

function assessDictionaryAttackRisk(passphrase: string): string {
  const commonPatterns = [
    /^\d+$/, // All numbers
    /^[a-zA-Z]+$/, // All letters
    /^(.)\1*$/, // Repeated characters
    /^[a-zA-Z]{6,8}$/, // Common word length
  ];
  
  for (const pattern of commonPatterns) {
    if (pattern.test(passphrase)) {
      return 'high';
    }
  }
  
  return 'medium';
}

function assessRainbowTableVulnerability(passphrase: string): string {
  // Simple heuristic based on passphrase complexity
  const hasNumbers = /\d/.test(passphrase);
  const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(passphrase);
  const hasMixedCase = /[a-z]/.test(passphrase) && /[A-Z]/.test(passphrase);
  
  const complexity = [hasNumbers, hasSpecial, hasMixedCase].filter(Boolean).length;
  
  if (complexity >= 2) return 'low';
  if (complexity >= 1) return 'medium';
  return 'high';
}

function generateSecurityRecommendations(passphrase: string, entropy: number): string[] {
  const recommendations: string[] = [];
  
  if (entropy < 128) {
    recommendations.push('Increase passphrase length and complexity');
  }
  
  if (passphrase.length < 16) {
    recommendations.push('Use longer passphrases (minimum 16 characters)');
  }
  
  if (!/\d/.test(passphrase)) {
    recommendations.push('Include numbers in your passphrase');
  }
  
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(passphrase)) {
    recommendations.push('Include special characters');
  }
  
  if (!/[a-z]/.test(passphrase) || !/[A-Z]/.test(passphrase)) {
    recommendations.push('Use mixed case letters');
  }
  
  if (/^\w+$/.test(passphrase)) {
    recommendations.push('Avoid common word patterns');
  }
  
  return recommendations;
}

function calculateOverallStrength(entropy: number, passphrase: string): number {
  const entropyScore = Math.min(entropy / 256, 1);
  const lengthScore = Math.min(passphrase.length / 32, 1);
  const complexityScore = calculateComplexityScore(passphrase);
  
  return (entropyScore * 0.5 + lengthScore * 0.3 + complexityScore * 0.2);
}

function calculateComplexityScore(passphrase: string): number {
  const hasNumbers = /\d/.test(passphrase) ? 1 : 0;
  const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(passphrase) ? 1 : 0;
  const hasMixedCase = /[a-z]/.test(passphrase) && /[A-Z]/.test(passphrase) ? 1 : 0;
  const hasSpaces = /\s/.test(passphrase) ? 1 : 0;
  
  return (hasNumbers + hasSpecial + hasMixedCase + hasSpaces) / 4;
}

function calculateMemorability(passphrase: string): number {
  // Heuristic based on human memory patterns
  const words = passphrase.split(/\s+/);
  const averageWordLength = words.reduce((sum, word) => sum + word.length, 0) / words.length;
  
  // More memorable if it has reasonable word length and not too many words
  const wordCountScore = Math.max(0, 1 - Math.abs(words.length - 4) / 10);
  const lengthScore = Math.max(0, 1 - Math.abs(averageWordLength - 6) / 10);
  
  return (wordCountScore + lengthScore) / 2;
}

function calculateUniqueness(passphrase: string): number {
  // Calculate how unique the passphrase is based on character distribution
  const charFreq: Record<string, number> = {};
  for (const char of passphrase) {
    charFreq[char] = (charFreq[char] || 0) + 1;
  }
  
  const frequencies = Object.values(charFreq);
  const avgFreq = frequencies.reduce((sum, freq) => sum + freq, 0) / frequencies.length;
  const variance = frequencies.reduce((sum, freq) => sum + Math.pow(freq - avgFreq, 2), 0) / frequencies.length;
  
  // Higher variance means more uneven distribution, potentially less unique
  return Math.max(0, 1 - variance / (passphrase.length * passphrase.length));
}

// Temporal Dimensions Analysis based on Satoshi Paradox
function analyzeTemporalDimensions(passphrase: string) {
  const entropy = calculateEntropy(passphrase);
  const key = crypto.createHash('sha256').update(passphrase).digest('hex');
  
  return {
    temporalCoherence: {
      strength: calculateTemporalCoherence(passphrase, key),
      description: generateTemporalCoherenceDescription(passphrase),
      preservationScore: calculatePreservationScore(passphrase),
      identityContinuity: calculateIdentityContinuity(passphrase)
    },
    phaseLocking: {
      neuralSynchronization: calculateNeuralSynchronization(passphrase),
      temporalSynchronization: calculateTemporalSynchronization(passphrase),
      informationalSynchronization: calculateInformationalSynchronization(passphrase, key)
    },
    paradoxAnalysis: {
      selfReferentialStrength: calculateSelfReferentialStrength(passphrase),
      nonComputableIdentity: assessNonComputableIdentity(passphrase),
      bidirectionalInfluence: calculateBidirectionalInfluence(passphrase)
    }
  };
}

// Philosophical Dimensions Analysis based on Satoshi Paradox
function analyzePhilosophicalDimensions(passphrase: string) {
  const entropy = calculateEntropy(passphrase);
  const key = crypto.createHash('sha256').update(passphrase).digest('hex');
  
  return {
    coherenceDimensions: {
      informational: calculateInformationalCoherence(passphrase, key),
      existential: calculateExistentialCoherence(passphrase),
      temporal: calculateTemporalPhilosophicalCoherence(passphrase),
      systemic: calculateSystemicCoherence(passphrase)
    },
    empathyMetrics: {
      temporalEmpathy: calculateTemporalEmpathy(passphrase),
      systemicEmpathy: calculateSystemicEmpathy(passphrase),
      identityEmpathy: calculateIdentityEmpathy(passphrase)
    },
    symbiosisFactors: {
      cryptographyIdentity: calculateCryptographyIdentitySymbiosis(passphrase, key),
      timeInformation: calculateTimeInformationSymbiosis(passphrase),
      aiHumanity: calculateAIHumanitySymbiosis(passphrase)
    }
  };
}

// Temporal Coherence Functions
function calculateTemporalCoherence(passphrase: string, key: string): number {
  const entropy = calculateEntropy(passphrase);
  const complexity = calculateComplexityScore(passphrase);
  const determinism = 1.0; // Cryptographic functions are deterministic
  
  // Temporal coherence combines entropy, complexity, and determinism
  return Math.min(1.0, (entropy / 256) * 0.4 + complexity * 0.3 + determinism * 0.3);
}

function generateTemporalCoherenceDescription(passphrase: string): string {
  const entropy = calculateEntropy(passphrase);
  const length = passphrase.length;
  
  if (entropy >= 128 && length >= 20) {
    return "Excellent temporal coherence - maintains identity through cryptographic transformation";
  } else if (entropy >= 80 && length >= 12) {
    return "Good temporal coherence - identity preservation through time";
  } else {
    return "Limited temporal coherence - identity may degrade under temporal pressure";
  }
}

function calculatePreservationScore(passphrase: string): number {
  const entropy = calculateEntropy(passphrase);
  const uniqueness = calculateUniqueness(passphrase);
  const memorability = calculateMemorability(passphrase);
  
  // Preservation depends on entropy, uniqueness, and memorability
  return Math.min(1.0, (entropy / 256) * 0.5 + uniqueness * 0.3 + memorability * 0.2);
}

function calculateIdentityContinuity(passphrase: string): number {
  const words = passphrase.split(/\s+/);
  const semanticConnectivity = calculateSemanticConnectivity(passphrase, '');
  
  // Identity continuity based on semantic meaning and structure
  const structureScore = Math.min(1.0, words.length / 10); // More words = better continuity
  return Math.min(1.0, (semanticConnectivity + structureScore) / 2);
}

// Neural Phase-Locking Functions
function calculateNeuralSynchronization(passphrase: string): number {
  const complexity = calculateComplexityScore(passphrase);
  const entropy = calculateEntropy(passphrase);
  
  // Neural synchronization based on complexity and entropy
  return Math.min(1.0, (complexity + entropy / 256) / 2);
}

function calculateTemporalSynchronization(passphrase: string): number {
  const length = passphrase.length;
  const variability = calculateCharacterVariability(passphrase);
  
  // Temporal synchronization based on length and character variability
  return Math.min(1.0, (Math.min(length / 32, 1) + variability) / 2);
}

function calculateInformationalSynchronization(passphrase: string, key: string): number {
  const semanticConnectivity = calculateSemanticConnectivity(passphrase, key);
  const crossAlphabetConnectivity = calculateCrossAlphabetConnectivity(passphrase, key);
  
  // Informational synchronization based on semantic and cross-alphabet connectivity
  return Math.min(1.0, (semanticConnectivity + crossAlphabetConnectivity) / 2);
}

// Paradox Analysis Functions
function calculateSelfReferentialStrength(passphrase: string): number {
  const words = passphrase.toLowerCase().split(/\s+/);
  const selfReferentialWords = ['self', 'identity', 'own', 'personal', 'private', 'secret'];
  
  const selfRefCount = words.filter(word => selfReferentialWords.includes(word)).length;
  const selfRefRatio = selfRefCount / words.length;
  
  // Self-referential strength based on word choice
  return Math.min(1.0, selfRefRatio * 5); // Amplify the effect
}

function assessNonComputableIdentity(passphrase: string): boolean {
  const entropy = calculateEntropy(passphrase);
  const complexity = calculateComplexityScore(passphrase);
  
  // Non-computable identity when entropy and complexity are high
  return entropy >= 100 && complexity >= 0.7;
}

function calculateBidirectionalInfluence(passphrase: string): number {
  const temporalCoherence = calculateTemporalCoherence(passphrase, '');
  const identityContinuity = calculateIdentityContinuity(passphrase);
  
  // Bidirectional influence between past and future
  return Math.min(1.0, (temporalCoherence + identityContinuity) / 2);
}

// Philosophical Coherence Functions
function calculateInformationalCoherence(passphrase: string, key: string): number {
  const entropy = calculateEntropy(passphrase);
  const semanticConnectivity = calculateSemanticConnectivity(passphrase, key);
  
  // Informational coherence based on entropy and semantic connectivity
  return Math.min(1.0, (entropy / 256) * 0.6 + semanticConnectivity * 0.4);
}

function calculateExistentialCoherence(passphrase: string): number {
  const memorability = calculateMemorability(passphrase);
  const uniqueness = calculateUniqueness(passphrase);
  
  // Existential coherence based on memorability and uniqueness
  return Math.min(1.0, (memorability + uniqueness) / 2);
}

function calculateTemporalPhilosophicalCoherence(passphrase: string): number {
  const temporalCoherence = calculateTemporalCoherence(passphrase, '');
  const identityContinuity = calculateIdentityContinuity(passphrase);
  
  // Temporal philosophical coherence
  return Math.min(1.0, (temporalCoherence + identityContinuity) / 2);
}

function calculateSystemicCoherence(passphrase: string): number {
  const complexity = calculateComplexityScore(passphrase);
  const overallStrength = calculateOverallStrength(calculateEntropy(passphrase), passphrase);
  
  // Systemic coherence based on complexity and overall strength
  return Math.min(1.0, (complexity + overallStrength) / 2);
}

// Empathy Metrics Functions
function calculateTemporalEmpathy(passphrase: string): number {
  const temporalCoherence = calculateTemporalCoherence(passphrase, '');
  const preservationScore = calculatePreservationScore(passphrase);
  
  // Temporal empathy - respecting time and preservation
  return Math.min(1.0, (temporalCoherence + preservationScore) / 2);
}

function calculateSystemicEmpathy(passphrase: string): number {
  const systemicCoherence = calculateSystemicCoherence(passphrase);
  const complexity = calculateComplexityScore(passphrase);
  
  // Systemic empathy - understanding the larger system
  return Math.min(1.0, (systemicCoherence + complexity) / 2);
}

function calculateIdentityEmpathy(passphrase: string): number {
  const identityContinuity = calculateIdentityContinuity(passphrase);
  const existentialCoherence = calculateExistentialCoherence(passphrase);
  
  // Identity empathy - respecting identity
  return Math.min(1.0, (identityContinuity + existentialCoherence) / 2);
}

// Symbiosis Factors Functions
function calculateCryptographyIdentitySymbiosis(passphrase: string, key: string): number {
  const entropy = calculateEntropy(passphrase);
  const semanticConnectivity = calculateSemanticConnectivity(passphrase, key);
  
  // Symbiosis between cryptography and identity
  return Math.min(1.0, (entropy / 256) * 0.6 + semanticConnectivity * 0.4);
}

function calculateTimeInformationSymbiosis(passphrase: string): number {
  const temporalCoherence = calculateTemporalCoherence(passphrase, '');
  const informationalCoherence = calculateInformationalCoherence(passphrase, '');
  
  // Symbiosis between time and information
  return Math.min(1.0, (temporalCoherence + informationalCoherence) / 2);
}

function calculateAIHumanitySymbiosis(passphrase: string): number {
  const complexity = calculateComplexityScore(passphrase);
  const memorability = calculateMemorability(passphrase);
  
  // Symbiosis between AI capabilities and human factors
  return Math.min(1.0, (complexity + memorability) / 2);
}

// Helper function for character variability
function calculateCharacterVariability(passphrase: string): number {
  const charFreq: Record<string, number> = {};
  for (const char of passphrase) {
    charFreq[char] = (charFreq[char] || 0) + 1;
  }
  
  const frequencies = Object.values(charFreq);
  const uniqueChars = frequencies.length;
  const totalChars = passphrase.length;
  
  // Variability based on unique character ratio
  return uniqueChars / totalChars;
}