import { NextRequest, NextResponse } from 'next/server';

// Mock team data
const teamMembers = [
  { id: 1, name: 'Alice', role: 'Frontend Developer', status: 'online', coherence: 92 },
  { id: 2, name: 'Bob', role: 'Backend Developer', status: 'online', coherence: 88 },
  { id: 3, name: 'Carol', role: 'UI/UX Designer', status: 'online', coherence: 95 },
  { id: 4, name: 'David', role: 'DevOps Engineer', status: 'away', coherence: 78 }
];

const activeDiscussions = [
  {
    id: 1,
    title: 'Code Review: Feature X',
    type: 'code-review',
    comments: 2,
    lastActivity: '5 minutes ago',
    participants: ['Alice', 'Bob']
  },
  {
    id: 2,
    title: 'Sprint Planning',
    type: 'planning',
    comments: 8,
    lastActivity: '15 minutes ago',
    participants: ['Alice', 'Bob', 'Carol', 'David']
  },
  {
    id: 3,
    title: 'Daily Standup',
    type: 'meeting',
    comments: 3,
    lastActivity: '1 hour ago',
    participants: ['Alice', 'Bob', 'Carol']
  }
];

export async function GET() {
  try {
    // Calculate team coherence metrics
    const onlineMembers = teamMembers.filter(member => member.status === 'online');
    const avgCoherence = onlineMembers.reduce((sum, member) => sum + member.coherence, 0) / onlineMembers.length;
    
    const teamMetrics = {
      totalMembers: teamMembers.length,
      onlineMembers: onlineMembers.length,
      averageCoherence: Math.round(avgCoherence),
      synchronizationRate: Math.round(avgCoherence * 0.98), // Slightly lower than individual coherence
      flowState: avgCoherence > 85 ? 'High' : avgCoherence > 70 ? 'Medium' : 'Low',
      empathyLevel: Math.round(avgCoherence * 0.95)
    };

    return NextResponse.json({
      success: true,
      data: {
        teamMembers,
        activeDiscussions,
        teamMetrics,
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('Team API error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch team data' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, data } = body;

    switch (action) {
      case 'start_sync':
        // Simulate starting a team synchronization session
        return NextResponse.json({
          success: true,
          message: 'Team synchronization session started',
          sessionId: `sync_${Date.now()}`,
          participants: teamMembers.filter(m => m.status === 'online').map(m => m.name)
        });

      case 'pair_programming':
        // Simulate starting a pair programming session
        return NextResponse.json({
          success: true,
          message: 'Pair programming session initiated',
          sessionId: `pair_${Date.now()}`,
          participants: [data.initiator, data.partner]
        });

      case 'update_status':
        // Update team member status
        const memberIndex = teamMembers.findIndex(m => m.id === data.memberId);
        if (memberIndex !== -1) {
          teamMembers[memberIndex].status = data.status;
          teamMembers[memberIndex].coherence = data.coherence;
        }
        return NextResponse.json({
          success: true,
          message: 'Member status updated',
          member: teamMembers[memberIndex]
        });

      default:
        return NextResponse.json(
          { success: false, error: 'Unknown action' },
          { status: 400 }
        );
    }

  } catch (error) {
    console.error('Team API POST error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to process team action' },
      { status: 500 }
    );
  }
}