'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import PulsingButton, {
  PrimaryPulseButton,
  SuccessPulseButton,
  WarningPulseButton,
  DangerPulseButton,
  MagicPulseButton
} from '@/components/ui/pulsing-button';
import { 
  Zap, 
  Star, 
  Heart, 
  Sparkles, 
  Play, 
  Pause, 
  Settings,
  Palette,
  Activity,
  Target,
  Waves,
  RotateCcw
} from 'lucide-react';

export default function ButtonAnimationsDemo() {
  const [selectedVariant, setSelectedVariant] = useState('scale');
  const [selectedIntensity, setSelectedIntensity] = useState('medium');
  const [selectedSpeed, setSelectedSpeed] = useState('normal');
  const [pulseColor, setPulseColor] = useState('rgba(59, 130, 246, 0.5)');
  const [isContinuous, setIsContinuous] = useState(true);
  const [pulseOnHover, setPulseOnHover] = useState(false);
  const [customText, setCustomText] = useState('Click Me!');
  const [isAnimating, setIsAnimating] = useState(true);

  const colorPresets = [
    { name: 'Blue', value: 'rgba(59, 130, 246, 0.5)' },
    { name: 'Green', value: 'rgba(34, 197, 94, 0.5)' },
    { name: 'Yellow', value: 'rgba(251, 191, 36, 0.5)' },
    { name: 'Red', value: 'rgba(239, 68, 68, 0.5)' },
    { name: 'Purple', value: 'rgba(168, 85, 247, 0.5)' },
    { name: 'Pink', value: 'rgba(236, 72, 153, 0.5)' },
    { name: 'Cyan', value: 'rgba(6, 182, 212, 0.5)' },
    { name: 'Orange', value: 'rgba(251, 146, 60, 0.5)' }
  ];

  const variantDescriptions = {
    scale: 'Smooth scaling animation with optional shadow effects',
    glow: 'Pulsing glow effect that creates a luminous aura',
    bounce: 'Subtle vertical bouncing motion',
    rotate: 'Gentle rotation animation for dynamic effect',
    wave: 'Morphing border radius that creates a wave-like motion'
  };

  const handleButtonClick = () => {
    // Simulate button action
    console.log('Button clicked!');
  };

  return (
    <div className="container mx-auto py-8 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <Zap className="h-10 w-10 text-blue-600" />
          <h1 className="text-4xl font-bold">Pulsing Button Animations</h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Interactive demonstration of customizable pulsing button animations with multiple variants and real-time customization.
        </p>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="showcase" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="showcase">Showcase</TabsTrigger>
          <TabsTrigger value="presets">Presets</TabsTrigger>
          <TabsTrigger value="customizer">Customizer</TabsTrigger>
          <TabsTrigger value="examples">Examples</TabsTrigger>
        </TabsList>

        <TabsContent value="showcase" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Activity className="h-5 w-5" />
                <span>Animation Variants</span>
              </CardTitle>
              <CardDescription>
                Explore different pulsing animation styles and their characteristics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  { variant: 'scale', icon: <Target className="w-5 h-5" />, label: 'Scale' },
                  { variant: 'glow', icon: <Sparkles className="w-5 h-5" />, label: 'Glow' },
                  { variant: 'bounce', icon: <Waves className="w-5 h-5" />, label: 'Bounce' },
                  { variant: 'rotate', icon: <RotateCcw className="w-5 h-5" />, label: 'Rotate' },
                  { variant: 'wave', icon: <Activity className="w-5 h-5" />, label: 'Wave' }
                ].map(({ variant, icon, label }) => (
                  <Card key={variant} className="text-center">
                    <CardContent className="p-6 space-y-4">
                      <div className="flex justify-center">
                        {icon}
                      </div>
                      <h3 className="font-semibold">{label}</h3>
                      <p className="text-sm text-muted-foreground">
                        {variantDescriptions[variant as keyof typeof variantDescriptions]}
                      </p>
                      <PulsingButton
                        pulseVariant={variant as any}
                        pulseIntensity="medium"
                        onClick={handleButtonClick}
                      >
                        {label} Pulse
                      </PulsingButton>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Intensity Comparison */}
          <Card>
            <CardHeader>
              <CardTitle>Intensity Levels</CardTitle>
              <CardDescription>
                Compare different animation intensities for the same variant
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  { intensity: 'subtle', label: 'Subtle', color: 'bg-green-100 text-green-800' },
                  { intensity: 'medium', label: 'Medium', color: 'bg-yellow-100 text-yellow-800' },
                  { intensity: 'strong', label: 'Strong', color: 'bg-red-100 text-red-800' }
                ].map(({ intensity, label, color }) => (
                  <div key={intensity} className="text-center space-y-4">
                    <Badge className={color}>{label}</Badge>
                    <PulsingButton
                      pulseVariant="scale"
                      pulseIntensity={intensity as any}
                      onClick={handleButtonClick}
                    >
                      {label} Animation
                    </PulsingButton>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="presets" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Palette className="h-5 w-5" />
                <span>Preset Configurations</span>
              </CardTitle>
              <CardDescription>
                Ready-to-use button styles for common UI scenarios
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <CardContent className="p-6 space-y-4">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <Zap className="w-6 h-6 text-blue-600" />
                      </div>
                      <h3 className="font-semibold">Primary Action</h3>
                      <p className="text-sm text-muted-foreground">Main call-to-action buttons</p>
                    </div>
                    <PrimaryPulseButton onClick={handleButtonClick} className="w-full">
                      Primary Action
                    </PrimaryPulseButton>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 space-y-4">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <Star className="w-6 h-6 text-green-600" />
                      </div>
                      <h3 className="font-semibold">Success State</h3>
                      <p className="text-sm text-muted-foreground">Success confirmation buttons</p>
                    </div>
                    <SuccessPulseButton onClick={handleButtonClick} className="w-full">
                      Success
                    </SuccessPulseButton>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 space-y-4">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <Heart className="w-6 h-6 text-yellow-600" />
                      </div>
                      <h3 className="font-semibold">Warning Alert</h3>
                      <p className="text-sm text-muted-foreground">Warning or attention buttons</p>
                    </div>
                    <WarningPulseButton onClick={handleButtonClick} className="w-full">
                      Warning
                    </WarningPulseButton>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 space-y-4">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <Zap className="w-6 h-6 text-red-600" />
                      </div>
                      <h3 className="font-semibold">Danger Action</h3>
                      <p className="text-sm text-muted-foreground">Destructive action buttons</p>
                    </div>
                    <DangerPulseButton onClick={handleButtonClick} className="w-full">
                      Danger
                    </DangerPulseButton>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 space-y-4">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <Sparkles className="w-6 h-6 text-purple-600" />
                      </div>
                      <h3 className="font-semibold">Magic Effect</h3>
                      <p className="text-sm text-muted-foreground">Special or premium actions</p>
                    </div>
                    <MagicPulseButton onClick={handleButtonClick} className="w-full">
                      Magic
                    </MagicPulseButton>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 space-y-4">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                        <Play className="w-6 h-6 text-cyan-600" />
                      </div>
                      <h3 className="font-semibold">Play/Pause</h3>
                      <p className="text-sm text-muted-foreground">Media control buttons</p>
                    </div>
                    <PulsingButton
                      pulseVariant="bounce"
                      pulseColor="rgba(6, 182, 212, 0.5)"
                      icon={isAnimating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      onClick={() => setIsAnimating(!isAnimating)}
                      className="w-full"
                    >
                      {isAnimating ? 'Pause' : 'Play'}
                    </PulsingButton>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="customizer" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="h-5 w-5" />
                <span>Live Customizer</span>
              </CardTitle>
              <CardDescription>
                Customize your pulsing button in real-time and see the changes instantly
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Controls */}
                <div className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Animation Settings</h3>
                    
                    <div className="space-y-2">
                      <Label htmlFor="variant">Animation Variant</Label>
                      <Select value={selectedVariant} onValueChange={setSelectedVariant}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="scale">Scale</SelectItem>
                          <SelectItem value="glow">Glow</SelectItem>
                          <SelectItem value="bounce">Bounce</SelectItem>
                          <SelectItem value="rotate">Rotate</SelectItem>
                          <SelectItem value="wave">Wave</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="intensity">Intensity</Label>
                      <Select value={selectedIntensity} onValueChange={setSelectedIntensity}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="subtle">Subtle</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="strong">Strong</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="speed">Speed</Label>
                      <Select value={selectedSpeed} onValueChange={setSelectedSpeed}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="slow">Slow</SelectItem>
                          <SelectItem value="normal">Normal</SelectItem>
                          <SelectItem value="fast">Fast</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="color">Pulse Color</Label>
                      <div className="grid grid-cols-4 gap-2">
                        {colorPresets.map((color) => (
                          <button
                            key={color.value}
                            className={`w-full h-8 rounded border-2 ${
                              pulseColor === color.value ? 'border-primary' : 'border-border'
                            }`}
                            style={{ backgroundColor: color.value }}
                            onClick={() => setPulseColor(color.value)}
                            title={color.name}
                          />
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="text">Button Text</Label>
                      <Input
                        id="text"
                        value={customText}
                        onChange={(e) => setCustomText(e.target.value)}
                        placeholder="Enter button text..."
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="continuous">Continuous Animation</Label>
                      <Switch
                        id="continuous"
                        checked={isContinuous}
                        onCheckedChange={setIsContinuous}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="hover">Pulse on Hover</Label>
                      <Switch
                        id="hover"
                        checked={pulseOnHover}
                        onCheckedChange={setPulseOnHover}
                      />
                    </div>
                  </div>
                </div>

                {/* Preview */}
                <div className="space-y-6">
                  <div className="text-center">
                    <h3 className="text-lg font-semibold mb-4">Live Preview</h3>
                    <div className="space-y-8">
                      <PulsingButton
                        pulseVariant={selectedVariant as any}
                        pulseIntensity={selectedIntensity as any}
                        pulseSpeed={selectedSpeed as any}
                        pulseColor={pulseColor}
                        continuous={isContinuous}
                        pulseOnHover={pulseOnHover}
                        onClick={handleButtonClick}
                        size="lg"
                        className="text-lg px-8 py-4"
                      >
                        {customText}
                      </PulsingButton>

                      <div className="grid grid-cols-2 gap-4">
                        <PulsingButton
                          pulseVariant={selectedVariant as any}
                          pulseIntensity={selectedIntensity as any}
                          pulseSpeed={selectedSpeed as any}
                          pulseColor={pulseColor}
                          continuous={isContinuous}
                          pulseOnHover={pulseOnHover}
                          onClick={handleButtonClick}
                          icon={<Star className="w-4 h-4" />}
                        >
                          With Icon
                        </PulsingButton>

                        <PulsingButton
                          pulseVariant={selectedVariant as any}
                          pulseIntensity={selectedIntensity as any}
                          pulseSpeed={selectedSpeed as any}
                          pulseColor={pulseColor}
                          continuous={isContinuous}
                          pulseOnHover={pulseOnHover}
                          onClick={handleButtonClick}
                          variant="outline"
                        >
                          Outline Style
                        </PulsingButton>
                      </div>
                    </div>
                  </div>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Configuration Code</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <pre className="bg-muted p-4 rounded-lg text-sm overflow-auto">
                        {`<PulsingButton
  pulseVariant="${selectedVariant}"
  pulseIntensity="${selectedIntensity}"
  pulseSpeed="${selectedSpeed}"
  pulseColor="${pulseColor}"
  continuous={${isContinuous}}
  pulseOnHover={${pulseOnHover}}
  onClick={handleClick}
>
  ${customText}
</PulsingButton>`}
                      </pre>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="examples" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Real-World Usage Examples</CardTitle>
              <CardDescription>
                Practical examples of pulsing buttons in different contexts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              {/* Call to Action Section */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Call to Action Buttons</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center space-y-2">
                    <PrimaryPulseButton size="lg" className="w-full">
                      Get Started Free
                    </PrimaryPulseButton>
                    <p className="text-sm text-muted-foreground">Primary conversion button</p>
                  </div>
                  <div className="text-center space-y-2">
                    <MagicPulseButton size="lg" className="w-full">
                      Try Premium
                    </MagicPulseButton>
                    <p className="text-sm text-muted-foreground">Premium upgrade button</p>
                  </div>
                  <div className="text-center space-y-2">
                    <SuccessPulseButton size="lg" className="w-full">
                      Start Free Trial
                    </SuccessPulseButton>
                    <p className="text-sm text-muted-foreground">Trial activation button</p>
                  </div>
                </div>
              </div>

              {/* Status Indicators */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Status Indicators</h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="text-center space-y-2">
                    <SuccessPulseButton icon={<Star className="w-4 h-4" />}>
                      Online
                    </SuccessPulseButton>
                    <p className="text-sm text-muted-foreground">Active status</p>
                  </div>
                  <div className="text-center space-y-2">
                    <WarningPulseButton icon={<Heart className="w-4 h-4" />}>
                      Pending
                    </WarningPulseButton>
                    <p className="text-sm text-muted-foreground">Pending status</p>
                  </div>
                  <div className="text-center space-y-2">
                    <DangerPulseButton icon={<Zap className="w-4 h-4" />}>
                      Alert
                    </DangerPulseButton>
                    <p className="text-sm text-muted-foreground">Alert status</p>
                  </div>
                  <div className="text-center space-y-2">
                    <PulsingButton
                      pulseVariant="glow"
                      pulseColor="rgba(168, 85, 247, 0.5)"
                      icon={<Sparkles className="w-4 h-4" />}
                    >
                      New
                    </PulsingButton>
                    <p className="text-sm text-muted-foreground">New feature</p>
                  </div>
                </div>
              </div>

              {/* Interactive Controls */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Interactive Controls</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center space-y-2">
                    <PulsingButton
                      pulseVariant="bounce"
                      pulseColor="rgba(6, 182, 212, 0.5)"
                      icon={isAnimating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      onClick={() => setIsAnimating(!isAnimating)}
                    >
                      {isAnimating ? 'Pause' : 'Play'}
                    </PulsingButton>
                    <p className="text-sm text-muted-foreground">Media control</p>
                  </div>
                  <div className="text-center space-y-2">
                    <PulsingButton
                      pulseVariant="rotate"
                      pulseColor="rgba(251, 146, 60, 0.5)"
                      icon={<RotateCcw className="w-4 h-4" />}
                      onClick={() => {}}
                    >
                      Refresh
                    </PulsingButton>
                    <p className="text-sm text-muted-foreground">Refresh action</p>
                  </div>
                  <div className="text-center space-y-2">
                    <PulsingButton
                      pulseVariant="wave"
                      pulseColor="rgba(236, 72, 153, 0.5)"
                      icon={<Heart className="w-4 h-4" />}
                      onClick={() => {}}
                    >
                      Like
                    </PulsingButton>
                    <p className="text-sm text-muted-foreground">Social action</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}