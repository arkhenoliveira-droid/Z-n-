'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Shield, 
  Key, 
  Fingerprint, 
  Lock, 
  Unlock, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  RefreshCw,
  Download,
  Upload,
  Activity,
  Server,
  Cpu,
  HardDrive,
  Network,
  Clock,
  BarChart3,
  FileText,
  Settings,
  Eye,
  EyeOff
} from 'lucide-react';

// Import our trusted computing modules
import { 
  trustedComputingManager, 
  createAttestationRequest, 
  getTrustedComputingStatus 
} from '@/lib/trusted-computing';
import { 
  bcflickCryptoManager, 
  encryptData, 
  decryptData, 
  signData, 
  verifyData, 
  getCryptoSecurityStatus 
} from '@/lib/bcflick-crypto';
import { 
  tpmSimulationManager, 
  initializeTPM, 
  getTPMStatus 
} from '@/lib/tpm-simulation';
import { 
  secureBootVerificationManager, 
  verifySecureBoot, 
  getSecureBootStatus 
} from '@/lib/secure-boot';
import { HardwareSecurityDashboard } from '@/components/ui/hardware-security-dashboard';

interface AttestationData {
  type: string;
  nonce: string;
  quote: string;
  signature: string;
  pcrValues: any[];
  timestamp: number;
  valid: boolean;
}

interface VerificationResult {
  valid: boolean;
  timestamp: number;
  details: string;
  score: number;
}

export default function TrustedComputingPage() {
  const [loading, setLoading] = useState(false);
  const [attestationData, setAttestationData] = useState<AttestationData | null>(null);
  const [verificationResult, setVerificationResult] = useState<VerificationResult | null>(null);
  const [trustedStatus, setTrustedStatus] = useState<any>(null);
  const [cryptoStatus, setCryptoStatus] = useState<any>(null);
  const [tpmStatus, setTPMStatus] = useState<any>(null);
  const [secureBootStatus, setSecureBootStatus] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadAllStatuses();
  }, []);

  const loadAllStatuses = async () => {
    setLoading(true);
    try {
      const [trusted, crypto, tpm, secureBoot] = await Promise.all([
        Promise.resolve(getTrustedComputingStatus()),
        Promise.resolve(getCryptoSecurityStatus()),
        Promise.resolve(getTPMStatus()),
        Promise.resolve(getSecureBootStatus())
      ]);

      setTrustedStatus(trusted);
      setCryptoStatus(crypto);
      setTPMStatus(tpm);
      setSecureBootStatus(secureBoot);
    } catch (error) {
      console.error('Error loading statuses:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateAttestation = async () => {
    setLoading(true);
    try {
      const attestation = await createAttestationRequest();
      setAttestationData(attestation);
      
      // Simulate remote verification
      setTimeout(() => {
        const verification: VerificationResult = {
          valid: true,
          timestamp: Date.now(),
          details: 'Attestation verified successfully. Platform integrity confirmed.',
          score: 95
        };
        setVerificationResult(verification);
      }, 2000);
    } catch (error) {
      console.error('Error creating attestation:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifySecureBoot = async () => {
    setLoading(true);
    try {
      const result = await verifySecureBoot();
      console.log('Secure Boot verification result:', result);
      await loadAllStatuses();
    } catch (error) {
      console.error('Error verifying secure boot:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInitializeTPM = async () => {
    setLoading(true);
    try {
      await initializeTPM();
      await loadAllStatuses();
    } catch (error) {
      console.error('Error initializing TPM:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (valid: boolean) => {
    return valid ? 'bg-green-500' : 'bg-red-500';
  };

  const getStatusIcon = (valid: boolean) => {
    return valid ? <CheckCircle className="h-4 w-4 text-green-500" /> : <XCircle className="h-4 w-4 text-red-500" />;
  };

  const getSecurityScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Trusted Computing</h1>
          <p className="text-muted-foreground">
            Advanced security with bcflick technology and TPM integration • Inspired by cryptographic pioneers like Hal Finney • Coherent Operating System 1 (2025)
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={loadAllStatuses} disabled={loading} variant="outline">
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="attestation">Attestation</TabsTrigger>
          <TabsTrigger value="tpm">TPM</TabsTrigger>
          <TabsTrigger value="secure-boot">Secure Boot</TabsTrigger>
          <TabsTrigger value="crypto">Cryptography</TabsTrigger>
          <TabsTrigger value="hardware">Hardware Security</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">TPM Status</CardTitle>
                <Cpu className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {tpmStatus?.state?.initialized ? 'Active' : 'Inactive'}
                </div>
                <p className="text-xs text-muted-foreground">
                  {tpmStatus?.state?.initialized ? 'TPM 2.0 Ready' : 'TPM Not Initialized'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Secure Boot</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {secureBootStatus?.enabled ? 'Enabled' : 'Disabled'}
                </div>
                <p className="text-xs text-muted-foreground">
                  {secureBootStatus?.verified ? 'Verified' : 'Not Verified'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">bcflick Crypto</CardTitle>
                <Key className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {cryptoStatus?.hardwareAccelerated ? 'Hardware' : 'Software'}
                </div>
                <p className="text-xs text-muted-foreground">
                  {cryptoStatus?.totalKeys || 0} Active Keys
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Security Score</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${getSecurityScoreColor(85)}`}>
                  85%
                </div>
                <p className="text-xs text-muted-foreground">
                  Overall Security Rating
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>System Integrity</CardTitle>
                <CardDescription>
                  Platform integrity status and measurements
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Platform Configuration</span>
                    {getStatusIcon(true)}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Boot Components</span>
                    {getStatusIcon(secureBootStatus?.verified || false)}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Cryptographic Keys</span>
                    {getStatusIcon(cryptoStatus?.totalKeys > 0)}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">TPM Measurements</span>
                    {getStatusIcon(tpmStatus?.state?.initialized || false)}
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>PCR Registers</span>
                    <span>{tpmStatus?.pcrBankStatus?.reduce((sum: number, bank: any) => sum + bank.pcrCount, 0) || 0}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Active Sessions</span>
                    <span>{tpmStatus?.state?.activeHandles?.size || 0}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Security Level</span>
                    <Badge variant="secondary">High</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>
                  Latest trusted computing operations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[200px]">
                  <div className="space-y-2">
                    {tpmStatus?.recentEvents?.slice(0, 5).map((event: any, index: number) => (
                      <div key={index} className="flex items-center justify-between text-sm">
                        <span className="font-medium">{event.type}</span>
                        <span className="text-muted-foreground">
                          {new Date(event.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    ))}
                    {(!tpmStatus?.recentEvents || tpmStatus.recentEvents.length === 0) && (
                      <p className="text-sm text-muted-foreground">No recent activity</p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="attestation" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Remote Attestation</CardTitle>
                <CardDescription>
                  Generate and verify platform attestation
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={handleCreateAttestation} 
                  disabled={loading}
                  className="w-full"
                >
                  <Fingerprint className="h-4 w-4 mr-2" />
                  Generate Attestation
                </Button>

                {attestationData && (
                  <div className="space-y-2">
                    <Alert>
                      <CheckCircle className="h-4 w-4" />
                      <AlertTitle>Attestation Generated</AlertTitle>
                      <AlertDescription>
                        Platform attestation created successfully with nonce: {attestationData.nonce}
                      </AlertDescription>
                    </Alert>

                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Type:</span>
                        <Badge variant="outline">{attestationData.type}</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>PCR Values:</span>
                        <span>{attestationData.pcrValues.length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Valid:</span>
                        {getStatusIcon(attestationData.valid)}
                      </div>
                    </div>
                  </div>
                )}

                {verificationResult && (
                  <Alert className={verificationResult.valid ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
                    {verificationResult.valid ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-600" />
                    )}
                    <AlertTitle className={verificationResult.valid ? "text-green-800" : "text-red-800"}>
                      Verification {verificationResult.valid ? "Passed" : "Failed"}
                    </AlertTitle>
                    <AlertDescription className={verificationResult.valid ? "text-green-700" : "text-red-700"}>
                      {verificationResult.details}
                      <div className="mt-2">
                        Security Score: <span className={`font-bold ${getSecurityScoreColor(verificationResult.score)}`}>
                          {verificationResult.score}%
                        </span>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>PCR Values</CardTitle>
                <CardDescription>
                  Platform Configuration Register measurements
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px]">
                  <div className="space-y-2">
                    {trustedStatus?.pcrValues?.map((pcr: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-2 border rounded">
                        <div>
                          <div className="font-medium">PCR {pcr.index}</div>
                          <div className="text-sm text-muted-foreground">{pcr.description}</div>
                        </div>
                        <div className="text-xs font-mono bg-muted px-2 py-1 rounded">
                          {pcr.value.substring(0, 16)}...
                        </div>
                      </div>
                    ))}
                    {(!trustedStatus?.pcrValues || trustedStatus.pcrValues.length === 0) && (
                      <p className="text-sm text-muted-foreground">No PCR values available</p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tpm" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>TPM Management</CardTitle>
                <CardDescription>
                  Trusted Platform Module status and operations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={handleInitializeTPM} 
                  disabled={loading}
                  className="w-full"
                >
                  <Server className="h-4 w-4 mr-2" />
                  Initialize TPM
                </Button>

                {tpmStatus?.state && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Status</span>
                        <Badge variant={tpmStatus.state.initialized ? "default" : "secondary"}>
                          {tpmStatus.state.initialized ? "Initialized" : "Not Initialized"}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Commands</span>
                        <span>{tpmStatus.metrics.totalCommands}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Success Rate</span>
                        <span>{tpmStatus.metrics.successRate.toFixed(1)}%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Uptime</span>
                        <span>{Math.round(tpmStatus.metrics.uptime / 1000)}s</span>
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">PCR Banks</h4>
                      {tpmStatus.pcrBankStatus?.map((bank: any, index: number) => (
                        <div key={index} className="flex items-center justify-between text-sm">
                          <span>{bank.algorithm}</span>
                          <Badge variant="outline">{bank.pcrCount} PCRs</Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>TPM Operations</CardTitle>
                <CardDescription>
                  Recent TPM command history
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px]">
                  <div className="space-y-2">
                    {tpmStatus?.recentCommands?.map((cmd: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-2 border rounded">
                        <div>
                          <div className="font-medium">{cmd.command}</div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(cmd.timestamp).toLocaleTimeString()}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={cmd.status === "completed" ? "default" : "destructive"}>
                            {cmd.status}
                          </Badge>
                          {cmd.duration && (
                            <span className="text-xs text-muted-foreground">
                              {cmd.duration.toFixed(1)}ms
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                    {(!tpmStatus?.recentCommands || tpmStatus.recentCommands.length === 0) && (
                      <p className="text-sm text-muted-foreground">No TPM operations recorded</p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="secure-boot" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Secure Boot Verification</CardTitle>
                <CardDescription>
                  UEFI Secure Boot status and verification
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={handleVerifySecureBoot} 
                  disabled={loading}
                  className="w-full"
                >
                  <Shield className="h-4 w-4 mr-2" />
                  Verify Secure Boot
                </Button>

                {secureBootStatus && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Enabled</span>
                        {getStatusIcon(secureBootStatus.enabled)}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">State</span>
                        <Badge variant="outline">{secureBootStatus.state}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Verified Components</span>
                        <span>{secureBootStatus.verifiedComponents}/{secureBootStatus.totalComponents}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Platform Key</span>
                        {getStatusIcon(secureBootStatus.platformKeyValid)}
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Component Verification</h4>
                      <Progress 
                        value={(secureBootStatus.verifiedComponents / secureBootStatus.totalComponents) * 100} 
                        className="w-full"
                      />
                      <div className="text-xs text-muted-foreground">
                        {secureBootStatus.verifiedComponents} of {secureBootStatus.totalComponents} components verified
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Boot Components</CardTitle>
                <CardDescription>
                  Verified boot components status
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px]">
                  <div className="space-y-2">
                    {secureBootStatus?.components?.map((component: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-2 border rounded">
                        <div>
                          <div className="font-medium">{component.name}</div>
                          <div className="text-xs text-muted-foreground">{component.version}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(component.verified)}
                          <Badge variant={component.verified ? "default" : "destructive"}>
                            {component.verificationResult}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {(!secureBootStatus?.components || secureBootStatus.components.length === 0) && (
                      <p className="text-sm text-muted-foreground">No boot components available</p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="crypto" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>bcflick Cryptography</CardTitle>
                <CardDescription>
                  Hardware-accelerated cryptographic operations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {cryptoStatus && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Hardware Acceleration</span>
                        {getStatusIcon(cryptoStatus.hardwareAccelerated)}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Security Level</span>
                        <Badge variant="secondary">{cryptoStatus.securityLevel}/4</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Total Keys</span>
                        <span>{cryptoStatus.totalKeys}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Key Pairs</span>
                        <span>{cryptoStatus.totalKeyPairs}</span>
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Supported Standards</h4>
                      <div className="flex flex-wrap gap-1">
                        {cryptoStatus.supportedStandards?.map((standard: string, index: number) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {standard}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cryptographic Operations</CardTitle>
                <CardDescription>
                  Recent cryptographic operations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px]">
                  <div className="space-y-2">
                    {cryptoStatus?.recentOperations?.map((op: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-2 border rounded">
                        <div>
                          <div className="font-medium">{op.type}</div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(op.timestamp).toLocaleTimeString()}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={op.hardwareAccelerated ? "default" : "secondary"}>
                            {op.hardwareAccelerated ? "Hardware" : "Software"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {(!cryptoStatus?.recentOperations || cryptoStatus.recentOperations.length === 0) && (
                      <p className="text-sm text-muted-foreground">No cryptographic operations recorded</p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="hardware" className="space-y-4">
          <HardwareSecurityDashboard />
        </TabsContent>
      </Tabs>
    </div>
  );
}