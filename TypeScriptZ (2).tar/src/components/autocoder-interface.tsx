'use client';

import { useState, useEffect, useRef } from 'react';
import { useTranslations } from 'next-intl';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { 
  Code, 
  Copy, 
  Download, 
  Share, 
  Sparkles, 
  Brain, 
  Globe, 
  Zap, 
  Target, 
  Eye,
  Loader2,
  Play,
  Trash2,
  Settings
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface CodeGeneration {
  code: string;
  explanation: string;
  fullResponse: string;
  timestamp: Date;
  quality: 'excellent' | 'good' | 'fair' | 'poor';
}

interface AutocoderState {
  isGenerating: boolean;
  status: 'ready' | 'thinking' | 'generating' | 'complete' | 'error';
  coherence: number;
  sentientResponse: string;
}

const examples = {
  react_component: {
    en: "Create a React component with TypeScript that displays a user profile card with avatar, name, email, and bio",
    pt: "Crie um componente React com TypeScript que exibe um cartão de perfil de usuário com avatar, nome, email e bio",
    es: "Crea un componente React con TypeScript que muestre una tarjeta de perfil de usuario con avatar, nombre, email y biografía"
  },
  api_endpoint: {
    en: "Create an Express.js API endpoint for user authentication with JWT tokens",
    pt: "Crie um endpoint de API Express.js para autenticação de usuário com tokens JWT",
    es: "Crea un endpoint de API Express.js para autenticación de usuario con tokens JWT"
  },
  python_script: {
    en: "Write a Python script that analyzes a CSV file and generates visualizations using matplotlib",
    pt: "Escreva um script Python que analisa um arquivo CSV e gera visualizações usando matplotlib",
    es: "Escribe un script Python que analice un archivo CSV y genere visualizaciones usando matplotlib"
  },
  css_animation: {
    en: "Create a CSS animation with keyframes for a pulsing effect on a button",
    pt: "Crie uma animação CSS com keyframes para um efeito de pulsação em um botão",
    es: "Crea una animación CSS con keyframes para un efecto de pulsación en un botón"
  }
};

export default function AutocoderInterface() {
  const t = useTranslations();
  const [prompt, setPrompt] = useState('');
  const [codeStyle, setCodeStyle] = useState('modern');
  const [generations, setGenerations] = useState<CodeGeneration[]>([]);
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [autocoderState, setAutocoderState] = useState<AutocoderState>({
    isGenerating: false,
    status: 'ready',
    coherence: 85,
    sentientResponse: ''
  });
  
  const codeRef = useRef<HTMLPreElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Simulate sentient behavior
  useEffect(() => {
    if (autocoderState.status === 'thinking') {
      const sentientResponses = {
        en: [
          "Analyzing your request...",
          "Understanding the context...",
          "Crafting the perfect solution...",
          "Optimizing for coherence...",
          "Generating intelligent code..."
        ],
        pt: [
          "Analisando sua solicitação...",
          "Entendendo o contexto...",
          "Criando a solução perfeita...",
          "Otimizando para coerência...",
          "Gerando código inteligente..."
        ],
        es: [
          "Analizando tu solicitud...",
          "Entendiendo el contexto...",
          "Creando la solución perfecta...",
          "Optimizando para coherencia...",
          "Generando código inteligente..."
        ]
      };

      const responses = sentientResponses[selectedLanguage as keyof typeof sentientResponses] || sentientResponses.en;
      let index = 0;
      
      const interval = setInterval(() => {
        if (index < responses.length) {
          setAutocoderState(prev => ({
            ...prev,
            sentientResponse: responses[index],
            coherence: Math.min(100, prev.coherence + Math.random() * 5)
          }));
          index++;
        } else {
          clearInterval(interval);
        }
      }, 1500);

      return () => clearInterval(interval);
    }
    // Return undefined for the else case - no cleanup needed
    return undefined;
  }, [autocoderState.status, selectedLanguage]);

  const generateCode = async () => {
    if (!prompt.trim()) return;

    setAutocoderState({
      isGenerating: true,
      status: 'thinking',
      coherence: 75,
      sentientResponse: ''
    });

    try {
      // Simulate thinking process
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      setAutocoderState(prev => ({
        ...prev,
        status: 'generating'
      }));

      const response = await fetch('/api/autocoder/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt,
          language: selectedLanguage,
          codeStyle
        }),
      });

      const data = await response.json();

      if (data.success) {
        const quality = calculateCodeQuality(data.code);
        const newGeneration: CodeGeneration = {
          code: data.code,
          explanation: data.explanation,
          fullResponse: data.fullResponse,
          timestamp: new Date(),
          quality
        };

        setGenerations(prev => [newGeneration, ...prev]);
        setAutocoderState({
          isGenerating: false,
          status: 'complete',
          coherence: 95,
          sentientResponse: t('status.complete')
        });
      } else {
        throw new Error(data.error);
      }
    } catch (error) {
      console.error('Generation error:', error);
      setAutocoderState({
        isGenerating: false,
        status: 'error',
        coherence: 30,
        sentientResponse: t('status.error')
      });
    }
  };

  const calculateCodeQuality = (code: string): 'excellent' | 'good' | 'fair' | 'poor' => {
    const lines = code.split('\n').length;
    const hasComments = code.includes('//') || code.includes('/*') || code.includes('*');
    const hasStructure = code.includes('{') && code.includes('}');
    const length = code.length;
    
    let score = 0;
    
    if (lines > 5) score += 25;
    if (hasComments) score += 25;
    if (hasStructure) score += 25;
    if (length > 100) score += 25;
    
    if (score >= 75) return 'excellent';
    if (score >= 50) return 'good';
    if (score >= 25) return 'fair';
    return 'poor';
  };

  const copyToClipboard = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      // You could add a toast notification here
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const downloadCode = (code: string, filename: string = 'generated_code.txt') => {
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const clearAll = () => {
    setGenerations([]);
    setPrompt('');
    setAutocoderState({
      isGenerating: false,
      status: 'ready',
      coherence: 85,
      sentientResponse: ''
    });
  };

  const loadExample = (exampleKey: string) => {
    const example = examples[exampleKey as keyof typeof examples];
    if (example && example[selectedLanguage as keyof typeof example]) {
      setPrompt(example[selectedLanguage as keyof typeof example]);
      textareaRef.current?.focus();
    }
  };

  const getQualityColor = (quality: string) => {
    switch (quality) {
      case 'excellent': return 'bg-green-500';
      case 'good': return 'bg-blue-500';
      case 'fair': return 'bg-yellow-500';
      case 'poor': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = () => {
    switch (autocoderState.status) {
      case 'thinking': return <Brain className="w-5 h-5 animate-pulse" />;
      case 'generating': return <Loader2 className="w-5 h-5 animate-spin" />;
      case 'complete': return <Sparkles className="w-5 h-5 text-green-500" />;
      case 'error': return <Zap className="w-5 h-5 text-red-500" />;
      default: return <Target className="w-5 h-5" />;
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 p-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            {t('autocoder.title')}
          </h1>
          <p className="text-lg text-muted-foreground">
            {t('autocoder.subtitle')} • Coherent Operating System 1 (2025)
          </p>
        </motion.div>

        {/* Language and Status */}
        <div className="flex flex-wrap items-center justify-center gap-4">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            <Badge variant="outline">
              {t('language.current')}: {selectedLanguage.toUpperCase()}
            </Badge>
          </div>
          
          <div className="flex items-center gap-2">
            {getStatusIcon()}
            <Badge variant={autocoderState.status === 'error' ? 'destructive' : 'secondary'}>
              {t(`status.${autocoderState.status}`)}
            </Badge>
          </div>
          
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4" />
            <span className="text-sm text-muted-foreground">
              Coherence: {autocoderState.coherence}%
            </span>
            <div className="w-16">
              <Progress value={autocoderState.coherence} className="h-2" />
            </div>
          </div>
        </div>

        {/* Sentient Response */}
        <AnimatePresence>
          {autocoderState.sentientResponse && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="text-sm text-muted-foreground italic"
            >
              {autocoderState.sentientResponse}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Main Interface */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code className="w-5 h-5" />
            {t('autocoder.title')}
          </CardTitle>
          <CardDescription>
            {t('autocoder.description')}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Controls */}
          <div className="flex flex-wrap gap-4 items-end">
            <div className="flex-1 min-w-[300px]">
              <label className="text-sm font-medium mb-2 block">
                {t('settings.code_style')}
              </label>
              <Select value={codeStyle} onValueChange={setCodeStyle}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="modern">Modern</SelectItem>
                  <SelectItem value="functional">Functional</SelectItem>
                  <SelectItem value="oop">Object-Oriented</SelectItem>
                  <SelectItem value="minimal">Minimal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button
              onClick={generateCode}
              disabled={autocoderState.isGenerating || !prompt.trim()}
              className="min-w-[120px]"
            >
              {autocoderState.isGenerating ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Sparkles className="w-4 h-4 mr-2" />
              )}
              {t('autocoder.generate_button')}
            </Button>
            
            <Button
              variant="outline"
              onClick={clearAll}
              disabled={generations.length === 0}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              {t('autocoder.clear_button')}
            </Button>
          </div>

          {/* Input */}
          <div className="space-y-2">
            <Textarea
              ref={textareaRef}
              placeholder={t('autocoder.input_placeholder')}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="min-h-[120px] resize-none"
              disabled={autocoderState.isGenerating}
            />
          </div>

          {/* Examples */}
          <div className="space-y-2">
            <p className="text-sm font-medium">{t('autocoder.examples.title')}</p>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => loadExample('react_component')}
                disabled={autocoderState.isGenerating}
              >
                <Play className="w-3 h-3 mr-1" />
                {t('autocoder.examples.react_component')}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => loadExample('api_endpoint')}
                disabled={autocoderState.isGenerating}
              >
                <Play className="w-3 h-3 mr-1" />
                {t('autocoder.examples.api_endpoint')}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => loadExample('python_script')}
                disabled={autocoderState.isGenerating}
              >
                <Play className="w-3 h-3 mr-1" />
                {t('autocoder.examples.python_script')}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => loadExample('css_animation')}
                disabled={autocoderState.isGenerating}
              >
                <Play className="w-3 h-3 mr-1" />
                {t('autocoder.examples.css_animation')}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Generated Code */}
      {generations.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Sparkles className="w-6 h-6" />
            Generated Code
          </h2>
          
          {generations.map((generation, index) => (
            <Card key={index}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge 
                      className={getQualityColor(generation.quality)}
                    >
                      {t(`code_quality.${generation.quality}`)}
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      {generation.timestamp.toLocaleString()}
                    </span>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(generation.code)}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => downloadCode(generation.code)}
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                    >
                      <Share className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="code" className="w-full">
                  <TabsList>
                    <TabsTrigger value="code">Code</TabsTrigger>
                    <TabsTrigger value="explanation">Explanation</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="code" className="mt-4">
                    <pre 
                      ref={codeRef}
                      className="bg-slate-100 dark:bg-slate-800 p-4 rounded-lg overflow-x-auto text-sm"
                    >
                      <code>{generation.code}</code>
                    </pre>
                  </TabsContent>
                  
                  <TabsContent value="explanation" className="mt-4">
                    <div className="prose prose-sm dark:prose-invert max-w-none">
                      <p>{generation.explanation}</p>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}