'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Brain, 
  Atom, 
  Network, 
  Shield, 
  Key, 
  Expand, 
  TrendingUp, 
  RefreshCw, 
  Play, 
  Zap,
  Activity,
  Target,
  Layers,
  Gauge,
  BarChart3,
  LineChart,
  PieChart,
  AlertTriangle,
  CheckCircle,
  Info,
  Settings,
  Smile
} from 'lucide-react';

interface VectorAnalysis {
  id: string;
  type: string;
  currentCoherence: number;
  entropy: number;
  magnitude: number;
  phase: number;
  improvementPotential: number;
  issues: string[];
  recommendations: string[];
  priority: 'high' | 'medium' | 'low';
}

interface CoherenceAnalysis {
  opportunities: VectorAnalysis[];
  summary: {
    totalVectors: number;
    highPriority: number;
    mediumPriority: number;
    lowPriority: number;
    averageCoherence: number;
    averageImprovementPotential: number;
  };
}

interface StatusReport {
  totalVectors: number;
  coherenceDistribution: {
    excellent: number;
    good: number;
    fair: number;
    poor: number;
  };
  entropyDistribution: {
    optimal: number;
    low: number;
    high: number;
  };
  magnitudeDistribution: {
    optimal: number;
    low: number;
    high: number;
  };
  typeAnalysis: Record<string, any>;
}

interface OptimizationResult {
  vectorId: string;
  vectorType: string;
  initialCoherence: number;
  finalCoherence: number;
  improvement: number;
  entropyChange: number;
  magnitudeChange: number;
}

export default function CoherenceAnalyzer() {
  const [analysis, setAnalysis] = useState<CoherenceAnalysis | null>(null);
  const [statusReport, setStatusReport] = useState<StatusReport | null>(null);
  const [optimizationResults, setOptimizationResults] = useState<OptimizationResult[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [selectedVectors, setSelectedVectors] = useState<string[]>([]);

  // Carregar análise inicial
  useEffect(() => {
    loadCoherenceAnalysis();
  }, []);

  const loadCoherenceAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      const [analysisResponse, statusResponse] = await Promise.all([
        fetch('/api/coherence-analysis?action=analyze-coherence'),
        fetch('/api/coherence-analysis?action=vector-status')
      ]);

      if (analysisResponse.ok) {
        const analysisData = await analysisResponse.json();
        setAnalysis(analysisData.coherenceAnalysis);
      }

      if (statusResponse.ok) {
        const statusData = await statusResponse.json();
        setStatusReport(statusData.statusReport);
      }
    } catch (error) {
      console.error('Error loading coherence analysis:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const optimizeCoherence = async (vectorIds?: string[]) => {
    setIsOptimizing(true);
    try {
      const response = await fetch('/api/coherence-analysis', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'optimize-coherence',
          data: { vectorIds: vectorIds || selectedVectors }
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setOptimizationResults(data.optimizationResults.optimizedVectors);
        await loadCoherenceAnalysis(); // Recarregar análise
      }
    } catch (error) {
      console.error('Error optimizing coherence:', error);
    } finally {
      setIsOptimizing(false);
    }
  };

  const applyQuantumEnhancement = async () => {
    setIsOptimizing(true);
    try {
      const response = await fetch('/api/coherence-analysis', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'apply-quantum-coherence',
          data: { vectorIds: selectedVectors }
        }),
      });

      if (response.ok) {
        await loadCoherenceAnalysis();
      }
    } catch (error) {
      console.error('Error applying quantum enhancement:', error);
    } finally {
      setIsOptimizing(false);
    }
  };

  const applyNeuralOptimization = async () => {
    setIsOptimizing(true);
    try {
      const response = await fetch('/api/coherence-analysis', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'apply-neural-coherence',
          data: { vectorIds: selectedVectors }
        }),
      });

      if (response.ok) {
        await loadCoherenceAnalysis();
      }
    } catch (error) {
      console.error('Error applying neural optimization:', error);
    } finally {
      setIsOptimizing(false);
    }
  };

  const toggleVectorSelection = (vectorId: string) => {
    setSelectedVectors(prev => 
      prev.includes(vectorId) 
        ? prev.filter(id => id !== vectorId)
        : [...prev, vectorId]
    );
  };

  const selectAllVectors = () => {
    if (analysis) {
      const allVectorIds = analysis.opportunities.map(v => v.id);
      setSelectedVectors(allVectorIds);
    }
  };

  const clearSelection = () => {
    setSelectedVectors([]);
  };

  const getVectorIcon = (type: string) => {
    switch (type) {
      case 'coherence': return <Brain className="w-5 h-5" />;
      case 'quantum': return <Atom className="w-5 h-5" />;
      case 'neural': return <Network className="w-5 h-5" />;
      case 'cryptographic': return <Key className="w-5 h-5" />;
      case 'security': return <Shield className="w-5 h-5" />;
      case 'expansion': return <Expand className="w-5 h-5" />;
      default: return <Activity className="w-5 h-5" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high': return <Badge variant="destructive">High</Badge>;
      case 'medium': return <Badge variant="outline">Medium</Badge>;
      case 'low': return <Badge variant="secondary">Low</Badge>;
      default: return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getCoherenceColor = (coherence: number) => {
    if (coherence >= 0.9) return 'text-green-600';
    if (coherence >= 0.8) return 'text-blue-600';
    if (coherence >= 0.7) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getCoherenceBadge = (coherence: number) => {
    if (coherence >= 0.9) return <Badge className="bg-green-100 text-green-800">Excellent</Badge>;
    if (coherence >= 0.8) return <Badge className="bg-blue-100 text-blue-800">Good</Badge>;
    if (coherence >= 0.7) return <Badge className="bg-yellow-100 text-yellow-800">Fair</Badge>;
    return <Badge className="bg-red-100 text-red-800">Poor</Badge>;
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Target className="h-8 w-8" />
          Coherence Analysis & Optimization
        </h1>
        <p className="text-gray-600">
          Analyze and optimize vector coherence for maximum system performance • Coherent Operating System 1 (2025)
        </p>
      </div>

      {/* Controls */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Analysis Controls
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button 
              onClick={loadCoherenceAnalysis} 
              disabled={isAnalyzing}
              className="flex items-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${isAnalyzing ? 'animate-spin' : ''}`} />
              {isAnalyzing ? 'Analyzing...' : 'Analyze Coherence'}
            </Button>
            
            <Button 
              onClick={() => optimizeCoherence()} 
              disabled={isOptimizing}
              className="flex items-center gap-2"
            >
              <Play className="w-4 h-4" />
              {isOptimizing ? 'Optimizing...' : 'Optimize Selected'}
            </Button>
            
            <Button 
              onClick={applyQuantumEnhancement} 
              disabled={isOptimizing}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Zap className="w-4 h-4" />
              Quantum Enhancement
            </Button>
            
            <Button 
              onClick={applyNeuralOptimization} 
              disabled={isOptimizing}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Network className="w-4 h-4" />
              Neural Optimization
            </Button>
            
            <Button 
              onClick={selectAllVectors} 
              variant="outline"
              size="sm"
            >
              Select All
            </Button>
            
            <Button 
              onClick={clearSelection} 
              variant="outline"
              size="sm"
            >
              Clear Selection
            </Button>
          </div>
          
          <div className="mt-4">
            <p className="text-sm text-gray-600">
              Selected: {selectedVectors.length} vectors
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      {analysis && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Vectors</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analysis.summary.totalVectors}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">High Priority</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{analysis.summary.highPriority}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Avg Coherence</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getCoherenceColor(analysis.summary.averageCoherence)}`}>
                {Math.round(analysis.summary.averageCoherence * 100)}%
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Improvement Potential</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {Math.round(analysis.summary.averageImprovementPotential * 100)}%
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs defaultValue="analysis" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="analysis">Vector Analysis</TabsTrigger>
          <TabsTrigger value="status">System Status</TabsTrigger>
          <TabsTrigger value="optimization">Optimization Results</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
        </TabsList>

        <TabsContent value="analysis">
          <div className="space-y-4">
            {analysis?.opportunities.map((vector) => (
              <Card key={vector.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {getVectorIcon(vector.type)}
                      <div>
                        <CardTitle className="capitalize">{vector.type}</CardTitle>
                        <CardDescription>Vector ID: {vector.id.substring(0, 8)}...</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getPriorityBadge(vector.priority)}
                      <input
                        type="checkbox"
                        checked={selectedVectors.includes(vector.id)}
                        onChange={() => toggleVectorSelection(vector.id)}
                        className="w-4 h-4"
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                    <div>
                      <Label className="text-sm">Coherence</Label>
                      <div className="flex items-center gap-2">
                        <Progress value={vector.currentCoherence * 100} className="flex-1" />
                        <span className={`text-sm font-medium ${getCoherenceColor(vector.currentCoherence)}`}>
                          {Math.round(vector.currentCoherence * 100)}%
                        </span>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm">Entropy</Label>
                      <div className="flex items-center gap-2">
                        <Progress value={Math.min(100, vector.entropy * 20)} className="flex-1" />
                        <span className="text-sm font-medium">
                          {vector.entropy.toFixed(2)}
                        </span>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm">Magnitude</Label>
                      <p className="text-sm font-medium">
                        {vector.magnitude.toFixed(3)}
                      </p>
                    </div>
                    
                    <div>
                      <Label className="text-sm">Improvement Potential</Label>
                      <div className="flex items-center gap-2">
                        <Progress value={vector.improvementPotential * 100} className="flex-1" />
                        <span className="text-sm font-medium text-blue-600">
                          {Math.round(vector.improvementPotential * 100)}%
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    {vector.issues.length > 0 && (
                      <div>
                        <Label className="text-sm font-medium text-red-600">Issues</Label>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {vector.issues.map((issue, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {issue}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {vector.recommendations.length > 0 && (
                      <div>
                        <Label className="text-sm font-medium text-blue-600">Recommendations</Label>
                        <div className="mt-1 space-y-1">
                          {vector.recommendations.slice(0, 3).map((rec, index) => (
                            <div key={index} className="text-xs text-gray-600">
                              • {rec}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="status">
          {statusReport && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Coherence Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm">Excellent (≥90%)</span>
                        <Badge className="bg-green-100 text-green-800">
                          {statusReport.coherenceDistribution.excellent}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Good (80-89%)</span>
                        <Badge className="bg-blue-100 text-blue-800">
                          {statusReport.coherenceDistribution.good}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Fair (70-79%)</span>
                        <Badge className="bg-yellow-100 text-yellow-800">
                          {statusReport.coherenceDistribution.fair}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Poor (&lt;70%)</span>
                        <Badge className="bg-red-100 text-red-800">
                          {statusReport.coherenceDistribution.poor}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Entropy Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm">Optimal (1-3)</span>
                        <Badge className="bg-green-100 text-green-800">
                          {statusReport.entropyDistribution.optimal}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Low (&lt;1)</span>
                        <Badge className="bg-blue-100 text-blue-800">
                          {statusReport.entropyDistribution.low}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">High (&gt;3)</span>
                        <Badge className="bg-red-100 text-red-800">
                          {statusReport.entropyDistribution.high}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Magnitude Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm">Optimal (0.8-1.2)</span>
                        <Badge className="bg-green-100 text-green-800">
                          {statusReport.magnitudeDistribution.optimal}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Low (&lt;0.8)</span>
                        <Badge className="bg-blue-100 text-blue-800">
                          {statusReport.magnitudeDistribution.low}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">High (&gt;1.2)</span>
                        <Badge className="bg-red-100 text-red-800">
                          {statusReport.magnitudeDistribution.high}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Type Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {Object.entries(statusReport.typeAnalysis).map(([type, data]: [string, any]) => (
                      <div key={type} className="p-4 border rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          {getVectorIcon(type)}
                          <span className="font-medium capitalize">{type}</span>
                          {getCoherenceBadge(data.averageCoherence)}
                        </div>
                        <div className="space-y-1 text-sm">
                          <div>Coherence: {Math.round(data.averageCoherence * 100)}%</div>
                          <div>Entropy: {data.averageEntropy.toFixed(2)}</div>
                          <div>Magnitude: {data.averageMagnitude.toFixed(3)}</div>
                          <div>Status: <span className={`font-medium ${
                            data.status === 'optimal' ? 'text-green-600' :
                            data.status === 'good' ? 'text-blue-600' :
                            data.status === 'fair' ? 'text-yellow-600' : 'text-red-600'
                          }`}>{data.status}</span></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="optimization">
          <div className="space-y-4">
            {optimizationResults.length > 0 ? (
              optimizationResults.map((result, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {getVectorIcon(result.vectorType)}
                        <div>
                          <CardTitle className="capitalize">{result.vectorType}</CardTitle>
                          <CardDescription>Vector ID: {result.vectorId.substring(0, 8)}...</CardDescription>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {result.improvement > 0 ? (
                          <Badge className="bg-green-100 text-green-800">
                            +{Math.round(result.improvement * 100)}%
                          </Badge>
                        ) : (
                          <Badge className="bg-red-100 text-red-800">
                            {Math.round(result.improvement * 100)}%
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label className="text-sm">Coherence Change</Label>
                        <div className="flex items-center gap-2">
                          <span className="text-sm">{Math.round(result.initialCoherence * 100)}%</span>
                          <span className="text-gray-400">→</span>
                          <span className={`text-sm font-medium ${getCoherenceColor(result.finalCoherence)}`}>
                            {Math.round(result.finalCoherence * 100)}%
                          </span>
                        </div>
                      </div>
                      <div>
                        <Label className="text-sm">Entropy Change</Label>
                        <p className="text-sm">
                          {result.entropyChange > 0 ? '+' : ''}{result.entropyChange.toFixed(3)}
                        </p>
                      </div>
                      <div>
                        <Label className="text-sm">Magnitude Change</Label>
                        <p className="text-sm">
                          {result.magnitudeChange > 0 ? '+' : ''}{result.magnitudeChange.toFixed(3)}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="text-center py-8">
                  <Info className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600">No optimization results yet. Run optimization to see results.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="recommendations">
          <div className="space-y-4">
            {analysis?.opportunities
              .filter(vector => vector.priority === 'high')
              .map((vector) => (
                <Alert key={vector.id}>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle className="capitalize">
                    {vector.type} Vector - High Priority Optimization Needed
                  </AlertTitle>
                  <AlertDescription>
                    <div className="mt-2">
                      <p className="text-sm mb-2">
                        Current coherence: {Math.round(vector.currentCoherence * 100)}% - 
                        Improvement potential: {Math.round(vector.improvementPotential * 100)}%
                      </p>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Issues:</p>
                        {vector.issues.map((issue, index) => (
                          <p key={index} className="text-sm ml-4">• {issue}</p>
                        ))}
                      </div>
                      <div className="space-y-1 mt-2">
                        <p className="text-sm font-medium">Recommendations:</p>
                        {vector.recommendations.map((rec, index) => (
                          <p key={index} className="text-sm ml-4">• {rec}</p>
                        ))}
                      </div>
                    </div>
                  </AlertDescription>
                </Alert>
              ))}
            
            {analysis?.opportunities.filter(vector => vector.priority === 'high').length === 0 && (
              <Card>
                <CardContent className="text-center py-8">
                  <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-500" />
                  <p className="text-green-600 font-medium">All vectors are optimized!</p>
                  <p className="text-gray-600">No high priority optimizations needed at this time.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}