'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { 
  Shield, 
  Cpu, 
  HardDrive, 
  MemoryStick, 
  Network, 
  Fingerprint, 
  Key,
  Lock,
  Unlock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Activity,
  Zap,
  Server,
  Package,
  Thermometer,
  Battery,
  Wifi,
  Bluetooth,
  Usb,
  IdCard,
  Monitor,
  Smartphone,
  Router,
  Database,
  Cloud,
  Settings,
  RefreshCw,
  Eye,
  EyeOff
} from 'lucide-react';

interface HardwareSecurityFeature {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  status: 'active' | 'inactive' | 'warning' | 'error';
  securityLevel: number; // 0-100
  icon: React.ReactNode;
  category: 'cpu' | 'memory' | 'storage' | 'network' | 'tpm' | 'other';
  details?: {
    version?: string;
    vendor?: string;
    capabilities?: string[];
    threats?: string[];
    protections?: string[];
  };
}

interface SecurityMetrics {
  overallScore: number;
  threatLevel: 'low' | 'medium' | 'high' | 'critical';
  activeFeatures: number;
  totalFeatures: number;
  recentAlerts: SecurityAlert[];
  systemUptime: number;
  lastScan: number;
}

interface SecurityAlert {
  id: string;
  type: 'info' | 'warning' | 'error' | 'critical';
  feature: string;
  message: string;
  timestamp: number;
  resolved: boolean;
}

interface HardwareComponent {
  id: string;
  name: string;
  type: string;
  vendor: string;
  model: string;
  securityFeatures: string[];
  threatLevel: number;
  lastChecked: number;
  status: 'secure' | 'warning' | 'vulnerable';
}

export function HardwareSecurityDashboard() {
  const [loading, setLoading] = useState(false);
  const [features, setFeatures] = useState<HardwareSecurityFeature[]>([]);
  const [metrics, setMetrics] = useState<SecurityMetrics | null>(null);
  const [components, setComponents] = useState<HardwareComponent[]>([]);
  const [showDetails, setShowDetails] = useState(false);
  const [selectedFeature, setSelectedFeature] = useState<string | null>(null);

  useEffect(() => {
    loadSecurityData();
  }, []);

  const loadSecurityData = async () => {
    setLoading(true);
    try {
      // Simulate loading security data
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const securityFeatures = generateSecurityFeatures();
      const securityMetrics = generateSecurityMetrics(securityFeatures);
      const hardwareComponents = generateHardwareComponents();
      
      setFeatures(securityFeatures);
      setMetrics(securityMetrics);
      setComponents(hardwareComponents);
    } catch (error) {
      console.error('Error loading security data:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateSecurityFeatures = (): HardwareSecurityFeature[] => {
    return [
      {
        id: 'tpm-2.0',
        name: 'TPM 2.0',
        description: 'Trusted Platform Module for hardware-based security',
        enabled: true,
        status: 'active',
        securityLevel: 95,
        icon: <Shield className="h-5 w-5" />,
        category: 'tpm',
        details: {
          version: '2.0.18',
          vendor: 'bcflick Technologies',
          capabilities: ['Secure Boot', 'Remote Attestation', 'Sealed Storage', 'Platform Configuration Registers'],
          threats: ['Physical tampering', 'Side-channel attacks'],
          protections: ['Hardware encryption', 'Secure key storage', 'Integrity measurement']
        }
      },
      {
        id: 'sgx',
        name: 'Intel SGX',
        description: 'Software Guard Extensions for trusted execution',
        enabled: true,
        status: 'active',
        securityLevel: 88,
        icon: <Cpu className="h-5 w-5" />,
        category: 'cpu',
        details: {
          version: '1.0',
          vendor: 'Intel Corporation',
          capabilities: ['Enclave creation', 'Remote attestation', 'Sealed data'],
          threats: ['Side-channel attacks', 'Memory attacks'],
          protections: ['Memory encryption', 'Runtime protection', 'Isolated execution']
        }
      },
      {
        id: 'measured-boot',
        name: 'Measured Boot',
        description: 'Boot component measurement and verification',
        enabled: true,
        status: 'active',
        securityLevel: 92,
        icon: <Activity className="h-5 w-5" />,
        category: 'other',
        details: {
          version: '2.0',
          vendor: 'UEFI Forum',
          capabilities: ['Boot measurement', 'PCR extension', 'Secure launch'],
          threats: ['Bootkit attacks', 'Firmware tampering'],
          protections: ['Chain of trust', 'Early boot anti-malware', 'Firmware integrity']
        }
      },
      {
        id: 'memory-encryption',
        name: 'Memory Encryption',
        description: 'Full memory encryption with Intel MKTME',
        enabled: true,
        status: 'active',
        securityLevel: 85,
        icon: <MemoryStick className="h-5 w-5" />,
        category: 'memory',
        details: {
          version: '1.0',
          vendor: 'Intel Corporation',
          capabilities: ['Multi-key encryption', 'Memory protection', 'Data confidentiality'],
          threats: ['Cold boot attacks', 'DMA attacks'],
          protections: ['AES-256 encryption', 'Key management', 'Memory isolation']
        }
      },
      {
        id: 'secure-erase',
        name: 'Secure Erase',
        description: 'Cryptographic secure data erasure',
        enabled: true,
        status: 'active',
        securityLevel: 90,
        icon: <HardDrive className="h-5 w-5" />,
        category: 'storage',
        details: {
          version: '3.0',
          vendor: 'Various',
          capabilities: ['Data sanitization', 'Cryptographic erase', 'Verification'],
          threats: ['Data recovery', 'Forensic analysis'],
          protections: ['Multiple pass erasure', 'Cryptographic wiping', 'Verification protocols']
        }
      },
      {
        id: 'network-security',
        name: 'Network Security',
        description: 'Hardware-accelerated network security',
        enabled: true,
        status: 'warning',
        securityLevel: 75,
        icon: <Network className="h-5 w-5" />,
        category: 'network',
        details: {
          version: '2.5',
          vendor: 'Various',
          capabilities: ['Packet inspection', 'VPN acceleration', 'Firewall'],
          threats: ['Network attacks', 'Packet sniffing', 'MITM attacks'],
          protections: ['Hardware encryption', 'Packet filtering', 'Secure protocols']
        }
      },
      {
        id: 'virtualization-security',
        name: 'Virtualization Security',
        description: 'Hardware-assisted virtualization security',
        enabled: true,
        status: 'active',
        securityLevel: 82,
        icon: <Server className="h-5 w-5" />,
        category: 'cpu',
        details: {
          version: '2.0',
          vendor: 'AMD/Intel',
          capabilities: ['Nested virtualization', 'IOMMU', 'Secure VM'],
          threats: ['VM escape', 'Side-channel attacks'],
          protections: ['Hardware isolation', 'Memory protection', 'I/O protection']
        }
      },
      {
        id: 'biometric-security',
        name: 'Biometric Security',
        description: 'Hardware-based biometric authentication',
        enabled: false,
        status: 'inactive',
        securityLevel: 0,
        icon: <Fingerprint className="h-5 w-5" />,
        category: 'other',
        details: {
          version: '1.0',
          vendor: 'Various',
          capabilities: ['Fingerprint recognition', 'Face recognition', 'Liveness detection'],
          threats: ['Spoofing attacks', 'Replay attacks'],
          protections: ['Multi-factor authentication', 'Secure storage', 'Anti-spoofing']
        }
      }
    ];
  };

  const generateSecurityMetrics = (features: HardwareSecurityFeature[]): SecurityMetrics => {
    const activeFeatures = features.filter(f => f.enabled).length;
    const totalFeatures = features.length;
    const overallScore = Math.round(
      features.reduce((sum, f) => sum + (f.enabled ? f.securityLevel : 0), 0) / totalFeatures
    );
    
    const threatLevel = overallScore >= 90 ? 'low' : 
                       overallScore >= 70 ? 'medium' : 
                       overallScore >= 50 ? 'high' : 'critical';

    const recentAlerts = generateSecurityAlerts(features);

    return {
      overallScore,
      threatLevel,
      activeFeatures,
      totalFeatures,
      recentAlerts,
      systemUptime: 86400 * 7, // 7 days
      lastScan: Date.now() - 3600000 // 1 hour ago
    };
  };

  const generateSecurityAlerts = (features: HardwareSecurityFeature[]): SecurityAlert[] => {
    return [
      {
        id: 'alert-1',
        type: 'warning',
        feature: 'Network Security',
        message: 'Network security feature running with reduced capabilities',
        timestamp: Date.now() - 1800000, // 30 minutes ago
        resolved: false
      },
      {
        id: 'alert-2',
        type: 'info',
        feature: 'TPM 2.0',
        message: 'TPM firmware update available',
        timestamp: Date.now() - 7200000, // 2 hours ago
        resolved: false
      },
      {
        id: 'alert-3',
        type: 'error',
        feature: 'Biometric Security',
        message: 'Biometric security feature is disabled',
        timestamp: Date.now() - 14400000, // 4 hours ago
        resolved: false
      }
    ];
  };

  const generateHardwareComponents = (): HardwareComponent[] => {
    return [
      {
        id: 'cpu-1',
        name: 'Intel Core i7-12700K',
        type: 'CPU',
        vendor: 'Intel',
        model: 'Alder Lake',
        securityFeatures: ['SGX', 'TXT', 'VT-x', 'VT-d'],
        threatLevel: 15,
        lastChecked: Date.now() - 1800000,
        status: 'secure'
      },
      {
        id: 'memory-1',
        name: 'DDR5-4800 32GB',
        type: 'Memory',
        vendor: 'Corsair',
        model: 'Vengeance',
        securityFeatures: ['ECC', 'Encryption'],
        threatLevel: 8,
        lastChecked: Date.now() - 3600000,
        status: 'secure'
      },
      {
        id: 'storage-1',
        name: 'Samsung 980 PRO 1TB',
        type: 'SSD',
        vendor: 'Samsung',
        model: 'MZ-V8P1T0BW',
        securityFeatures: ['AES-256', 'TCG Opal', 'Secure Erase'],
        threatLevel: 12,
        lastChecked: Date.now() - 2400000,
        status: 'secure'
      },
      {
        id: 'network-1',
        name: 'Intel I225-V 2.5GbE',
        type: 'Network',
        vendor: 'Intel',
        model: 'I225-V',
        securityFeatures: ['MACsec', 'VT-c'],
        threatLevel: 25,
        lastChecked: Date.now() - 1200000,
        status: 'warning'
      }
    ];
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
      case 'secure':
        return 'text-green-600';
      case 'warning':
        return 'text-yellow-600';
      case 'error':
      case 'vulnerable':
        return 'text-red-600';
      case 'inactive':
        return 'text-gray-600';
      default:
        return 'text-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
      case 'secure':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'error':
      case 'vulnerable':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'inactive':
        return <XCircle className="h-4 w-4 text-gray-500" />;
      default:
        return <XCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getThreatLevelColor = (level: number) => {
    if (level <= 20) return 'text-green-600';
    if (level <= 40) return 'text-yellow-600';
    if (level <= 60) return 'text-orange-600';
    return 'text-red-600';
  };

  const getSecurityLevelColor = (level: number) => {
    if (level >= 90) return 'text-green-600';
    if (level >= 70) return 'text-yellow-600';
    if (level >= 50) return 'text-orange-600';
    return 'text-red-600';
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'cpu':
        return <Cpu className="h-4 w-4" />;
      case 'memory':
        return <MemoryStick className="h-4 w-4" />;
      case 'storage':
        return <HardDrive className="h-4 w-4" />;
      case 'network':
        return <Network className="h-4 w-4" />;
      case 'tpm':
        return <Shield className="h-4 w-4" />;
      default:
        return <Settings className="h-4 w-4" />;
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'critical':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'info':
        return <CheckCircle className="h-4 w-4 text-blue-500" />;
      default:
        return <CheckCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const featuresByCategory = features.reduce((acc, feature) => {
    if (!acc[feature.category]) {
      acc[feature.category] = [];
    }
    acc[feature.category].push(feature);
    return acc;
  }, {} as Record<string, HardwareSecurityFeature[]>);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Hardware Security Dashboard</h2>
          <p className="text-muted-foreground">
            Comprehensive hardware security features and threat monitoring
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={loadSecurityData} disabled={loading} variant="outline">
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Scan
          </Button>
          <Button 
            onClick={() => setShowDetails(!showDetails)} 
            variant="outline"
          >
            {showDetails ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
            {showDetails ? 'Hide Details' : 'Show Details'}
          </Button>
        </div>
      </div>

      {/* Security Metrics */}
      {metrics && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Security Score</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getSecurityLevelColor(metrics.overallScore)}`}>
                {metrics.overallScore}%
              </div>
              <p className="text-xs text-muted-foreground">
                Overall security rating
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Threat Level</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getThreatLevelColor(
                metrics.threatLevel === 'low' ? 15 : 
                metrics.threatLevel === 'medium' ? 35 : 
                metrics.threatLevel === 'high' ? 55 : 75
              )}`}>
                {metrics.threatLevel.toUpperCase()}
              </div>
              <p className="text-xs text-muted-foreground">
                Current threat assessment
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Features</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {metrics.activeFeatures}/{metrics.totalFeatures}
              </div>
              <p className="text-xs text-muted-foreground">
                Security features enabled
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">System Uptime</CardTitle>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {Math.round(metrics.systemUptime / 86400)}d
              </div>
              <p className="text-xs text-muted-foreground">
                Continuous operation
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Security Alerts */}
      {metrics && metrics.recentAlerts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Security Alerts</CardTitle>
            <CardDescription>
              Recent security alerts and notifications
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {metrics.recentAlerts.map((alert) => (
                <Alert key={alert.id} className={alert.type === 'critical' ? 'border-red-200 bg-red-50' : 
                                     alert.type === 'error' ? 'border-red-200 bg-red-50' :
                                     alert.type === 'warning' ? 'border-yellow-200 bg-yellow-50' :
                                     'border-blue-200 bg-blue-50'}>
                  {getAlertIcon(alert.type)}
                  <AlertTitle className={alert.type === 'critical' ? 'text-red-800' : 
                                     alert.type === 'error' ? 'text-red-800' :
                                     alert.type === 'warning' ? 'text-yellow-800' :
                                     'text-blue-800'}>
                    {alert.feature}: {alert.type.toUpperCase()}
                  </AlertTitle>
                  <AlertDescription className={alert.type === 'critical' ? 'text-red-700' : 
                                           alert.type === 'error' ? 'text-red-700' :
                                           alert.type === 'warning' ? 'text-yellow-700' :
                                           'text-blue-700'}>
                    {alert.message}
                    <div className="text-xs mt-1">
                      {new Date(alert.timestamp).toLocaleString()}
                    </div>
                  </AlertDescription>
                </Alert>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Hardware Components */}
      <Card>
        <CardHeader>
          <CardTitle>Hardware Components</CardTitle>
          <CardDescription>
            Security status of hardware components
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            {components.map((component) => (
              <div key={component.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="flex-shrink-0">
                    {component.type === 'CPU' && <Cpu className="h-5 w-5" />}
                    {component.type === 'Memory' && <MemoryStick className="h-5 w-5" />}
                    {component.type === 'SSD' && <HardDrive className="h-5 w-5" />}
                    {component.type === 'Network' && <Network className="h-5 w-5" />}
                  </div>
                  <div>
                    <div className="font-medium">{component.name}</div>
                    <div className="text-sm text-muted-foreground">
                      {component.vendor} {component.model}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(component.status)}
                    <span className={`text-sm font-medium ${getStatusColor(component.status)}`}>
                      {component.status.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Threat: {component.threatLevel}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Security Features by Category */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {Object.entries(featuresByCategory).map(([category, categoryFeatures]) => (
          <Card key={category}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {getCategoryIcon(category)}
                {category.charAt(0).toUpperCase() + category.slice(1)} Security
              </CardTitle>
              <CardDescription>
                {categoryFeatures.length} features in this category
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {categoryFeatures.map((feature) => (
                <div key={feature.id} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {feature.icon}
                      <span className="font-medium">{feature.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(feature.status)}
                      <Badge variant={feature.enabled ? "default" : "secondary"}>
                        {feature.enabled ? "Enabled" : "Disabled"}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-sm">
                      <span>Security Level</span>
                      <span className={`font-medium ${getSecurityLevelColor(feature.securityLevel)}`}>
                        {feature.securityLevel}%
                      </span>
                    </div>
                    <Progress value={feature.securityLevel} className="h-2" />
                  </div>

                  {showDetails && feature.details && (
                    <div className="text-xs text-muted-foreground space-y-1">
                      <div>{feature.description}</div>
                      {feature.details.version && (
                        <div>Version: {feature.details.version}</div>
                      )}
                      {feature.details.vendor && (
                        <div>Vendor: {feature.details.vendor}</div>
                      )}
                    </div>
                  )}

                  {selectedFeature === feature.id && showDetails && feature.details && (
                    <div className="mt-2 p-3 bg-muted rounded-lg space-y-2">
                      <div className="text-sm font-medium">Capabilities:</div>
                      <div className="flex flex-wrap gap-1">
                        {feature.details.capabilities?.map((capability, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {capability}
                          </Badge>
                        ))}
                      </div>
                      
                      <div className="text-sm font-medium">Protections:</div>
                      <div className="flex flex-wrap gap-1">
                        {feature.details.protections?.map((protection, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {protection}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {showDetails && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setSelectedFeature(selectedFeature === feature.id ? null : feature.id)}
                      className="w-full"
                    >
                      {selectedFeature === feature.id ? 'Hide Details' : 'Show Details'}
                    </Button>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}