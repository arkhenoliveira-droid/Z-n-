import { useState, useEffect } from 'react';

interface WeeklyData {
  day: string;
  coherenceScore: number;
  focusTime: number;
  stressLevel: number;
  productivity: number;
}

interface Insight {
  category: string;
  insights: string[];
}

interface SummaryMetrics {
  dailyAverage: {
    coherence: number;
    focusTime: number;
    stressLevel: number;
    productivity: number;
  };
  weeklyTrends: {
    coherence: string;
    focusTime: string;
    stressLevel: string;
    productivity: string;
  };
}

export const useAnalytics = () => {
  const [weeklyData, setWeeklyData] = useState<WeeklyData[]>([]);
  const [insights, setInsights] = useState<Insight[]>([]);
  const [summaryMetrics, setSummaryMetrics] = useState<SummaryMetrics | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchAnalyticsData();
  }, []);

  const fetchAnalyticsData = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/analytics');
      const result = await response.json();

      if (result.success) {
        setWeeklyData(result.data.weeklyData);
        setInsights(result.data.insights);
        setSummaryMetrics(result.data.summaryMetrics);
      } else {
        setError(result.error || 'Failed to fetch analytics data');
      }
    } catch (err) {
      setError('Network error while fetching analytics data');
    } finally {
      setIsLoading(false);
    }
  };

  const getPersonalAnalytics = async (timeRange: string = 'week') => {
    try {
      const response = await fetch('/api/analytics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          type: 'personal',
          timeRange,
          metrics: ['coherence', 'focus', 'stress', 'energy']
        }),
      });

      const result = await response.json();

      if (result.success) {
        return result.data;
      } else {
        throw new Error(result.error || 'Failed to fetch personal analytics');
      }
    } catch (err) {
      setError('Failed to fetch personal analytics');
      throw err;
    }
  };

  const getTeamAnalytics = async (timeRange: string = 'week') => {
    try {
      const response = await fetch('/api/analytics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          type: 'team',
          timeRange,
          metrics: ['synchronization', 'collaboration', 'productivity', 'satisfaction'],
          realtime: true
        }),
      });

      const result = await response.json();

      if (result.success) {
        return result.data;
      } else {
        throw new Error(result.error || 'Failed to fetch team analytics');
      }
    } catch (err) {
      setError('Failed to fetch team analytics');
      throw err;
    }
  };

  const getSystemAnalytics = async (timeRange: string = 'week') => {
    try {
      const response = await fetch('/api/analytics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          type: 'system',
          timeRange,
          metrics: ['uptime', 'responseTime', 'errorRate', 'throughput'],
          realtime: true
        }),
      });

      const result = await response.json();

      if (result.success) {
        return result.data;
      } else {
        throw new Error(result.error || 'Failed to fetch system analytics');
      }
    } catch (err) {
      setError('Failed to fetch system analytics');
      throw err;
    }
  };

  const getQuantumAnalytics = async (timeRange: string = 'week') => {
    try {
      const response = await fetch('/api/analytics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          type: 'quantum',
          timeRange,
          metrics: ['quantumCoherence', 'entanglementStrength', 'superpositionStability'],
          realtime: true
        }),
      });

      const result = await response.json();

      if (result.success) {
        return result.data;
      } else {
        throw new Error(result.error || 'Failed to fetch quantum analytics');
      }
    } catch (err) {
      setError('Failed to fetch quantum analytics');
      throw err;
    }
  };

  const getCoherenceOptimization = async () => {
    try {
      const response = await fetch('/api/analytics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          type: 'system',
          timeRange: 'realtime',
          metrics: ['coherence', 'optimization', 'quantumEfficiency'],
          realtime: true
        }),
      });

      const result = await response.json();

      if (result.success) {
        return result.data;
      } else {
        throw new Error(result.error || 'Failed to fetch coherence optimization data');
      }
    } catch (err) {
      setError('Failed to fetch coherence optimization data');
      throw err;
    }
  };

  const getMLPredictions = async (inputData: any) => {
    try {
      const response = await fetch('/api/analytics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          type: 'personal',
          timeRange: 'predictive',
          metrics: inputData,
          realtime: true,
          predictive: true
        }),
      });

      const result = await response.json();

      if (result.success) {
        return result.data;
      } else {
        throw new Error(result.error || 'Failed to fetch ML predictions');
      }
    } catch (err) {
      setError('Failed to fetch ML predictions');
      throw err;
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend.toLowerCase()) {
      case 'improving':
      case 'increasing':
      case 'excellent':
        return '📈';
      case 'decreasing':
        return '📉';
      default:
        return '➡️';
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend.toLowerCase()) {
      case 'improving':
      case 'increasing':
      case 'excellent':
        return 'text-green-600';
      case 'decreasing':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };

  const formatFocusTime = (hours: number) => {
    return `${hours}h`;
  };

  const getCoherenceStatus = (score: number) => {
    if (score >= 85) return { text: 'Excellent', color: 'text-green-600' };
    if (score >= 75) return { text: 'Good', color: 'text-blue-600' };
    if (score >= 65) return { text: 'Fair', color: 'text-yellow-600' };
    return { text: 'Needs Improvement', color: 'text-red-600' };
  };

  const getStressStatus = (level: number) => {
    if (level <= 15) return { text: 'Low', color: 'text-green-600' };
    if (level <= 25) return { text: 'Moderate', color: 'text-yellow-600' };
    return { text: 'High', color: 'text-red-600' };
  };

  const getProductivityStatus = (score: number) => {
    if (score >= 90) return { text: 'Excellent', color: 'text-green-600' };
    if (score >= 80) return { text: 'Good', color: 'text-blue-600' };
    if (score >= 70) return { text: 'Satisfactory', color: 'text-yellow-600' };
    return { text: 'Needs Improvement', color: 'text-red-600' };
  };

  return {
    weeklyData,
    insights,
    summaryMetrics,
    isLoading,
    error,
    fetchAnalyticsData,
    getPersonalAnalytics,
    getTeamAnalytics,
    getSystemAnalytics,
    getQuantumAnalytics,
    getCoherenceOptimization,
    getMLPredictions,
    getTrendIcon,
    getTrendColor,
    formatFocusTime,
    getCoherenceStatus,
    getStressStatus,
    getProductivityStatus
  };
};