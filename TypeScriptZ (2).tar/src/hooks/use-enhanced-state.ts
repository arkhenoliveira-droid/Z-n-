'use client'

import * as React from 'react'
import { utils } from '@/lib/utils'

export interface UseEnhancedStateOptions<T> {
  // Persistence
  persist?: boolean
  storageKey?: string
  storageType?: 'local' | 'session'
  
  // Validation
  validate?: (value: T) => boolean
  onError?: (error: string) => void
  
  // Debouncing
  debounce?: number
  
  // Throttling
  throttle?: number
  
  // Callbacks
  onBeforeChange?: (oldValue: T, newValue: T) => void
  onChange?: (value: T) => void
  onAfterChange?: (oldValue: T, newValue: T) => void
  
  // Initial state
  initialState?: T | (() => T)
}

export interface UseEnhancedStateReturn<T> {
  value: T
  setValue: (value: T | ((prev: T) => T)) => void
  reset: () => void
  isDirty: boolean
  isValid: boolean
  error: string | null
  isLoading: boolean
  history: {
    past: T[]
    future: T[]
    undo: () => void
    redo: () => void
    canUndo: boolean
    canRedo: boolean
  }
}

export function useEnhancedState<T>(
  initialValue: T,
  options: UseEnhancedStateOptions<T> = {}
): UseEnhancedStateReturn<T> {
  const {
    persist = false,
    storageKey,
    storageType = 'local',
    validate,
    onError,
    debounce,
    throttle,
    onBeforeChange,
    onChange,
    onAfterChange,
    initialState
  } = options

  // State management
  const [state, setState] = React.useState(() => {
    // Try to get persisted value first
    if (persist && storageKey) {
      const persistedValue = utils.storage[storageType].get<T>(storageKey)
      if (persistedValue !== null) {
        return persistedValue
      }
    }
    
    // Use initial state if provided
    if (initialState !== undefined) {
      return typeof initialState === 'function' ? (initialState as () => T)() : initialState
    }
    
    return initialValue
  })

  // Derived states
  const [isDirty, setIsDirty] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)
  const [isLoading, setIsLoading] = React.useState(false)

  // History management
  const [history, setHistory] = React.useState<{
    past: T[]
    future: T[]
  }>({
    past: [],
    future: []
  })

  // Refs for current values
  const stateRef = React.useRef(state)
  const historyRef = React.useRef(history)

  // Update refs
  React.useEffect(() => {
    stateRef.current = state
  }, [state])

  React.useEffect(() => {
    historyRef.current = history
  }, [history])

  // Validation
  const validateValue = (value: T): boolean => {
    if (validate) {
      try {
        return validate(value)
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Validation failed'
        setError(errorMessage)
        onError?.(errorMessage)
        return false
      }
    }
    return true
  }

  // Persistence
  const persistValue = (value: T) => {
    if (persist && storageKey) {
      try {
        utils.storage[storageType].set(storageKey, value)
      } catch (err) {
        console.error('Failed to persist state:', err)
      }
    }
  }

  // Create debounced/throttled setter
  const createSetter = React.useCallback((setter: (value: T | ((prev: T) => T)) => void) => {
    if (debounce) {
      return utils.async.debounce(setter, debounce)
    }
    if (throttle) {
      return utils.async.throttle(setter, throttle)
    }
    return setter
  }, [debounce, throttle])

  // Main setter function
  const setValue = React.useCallback((newValue: T | ((prev: T) => T)) => {
    const resolvedValue = typeof newValue === 'function' 
      ? (newValue as (prev: T) => T)(stateRef.current)
      : newValue

    // Before change callback
    onBeforeChange?.(stateRef.current, resolvedValue)

    // Validation
    if (!validateValue(resolvedValue)) {
      return
    }

    // Update history
    setHistory(prev => ({
      past: [...prev.past, stateRef.current],
      future: []
    }))

    // Update state
    setState(resolvedValue)
    setIsDirty(true)
    setError(null)

    // Persist value
    persistValue(resolvedValue)

    // Change callback
    onChange?.(resolvedValue)

    // After change callback
    if (onAfterChange) {
      setTimeout(() => {
        onAfterChange?.(stateRef.current, resolvedValue)
      }, 0)
    }
  }, [onBeforeChange, onChange, onAfterChange, validateValue, persistValue])

  // Create the actual setter with debouncing/throttling
  const debouncedSetValue = createSetter(setValue)

  // Reset function
  const reset = React.useCallback(() => {
    const resolvedInitialValue = typeof initialState === 'function' 
      ? (initialState as () => T)() 
      : initialState ?? initialValue

    setValue(resolvedInitialValue)
    setIsDirty(false)
    setError(null)
    setHistory({ past: [], future: [] })
  }, [initialValue, initialState, setValue])

  // History functions
  const undo = React.useCallback(() => {
    const { past, future } = historyRef.current
    if (past.length === 0) return

    const previous = past[past.length - 1]
    const newPast = past.slice(0, -1)

    setHistory({
      past: newPast,
      future: [...future, stateRef.current]
    })

    setValue(previous)
  }, [setValue])

  const redo = React.useCallback(() => {
    const { past, future } = historyRef.current
    if (future.length === 0) return

    const next = future[future.length - 1]
    const newFuture = future.slice(0, -1)

    setHistory({
      past: [...past, stateRef.current],
      future: newFuture
    })

    setValue(next)
  }, [setValue])

  // Effect to update dirty state
  React.useEffect(() => {
    const resolvedInitialValue = typeof initialState === 'function' 
      ? (initialState as () => T)() 
      : initialState ?? initialValue

    setIsDirty(JSON.stringify(state) !== JSON.stringify(resolvedInitialValue))
  }, [state, initialState, initialValue])

  // Effect to validate on mount
  React.useEffect(() => {
    validateValue(state)
  }, [])

  return {
    value: state,
    setValue: debouncedSetValue,
    reset,
    isDirty,
    isValid: error === null,
    error,
    isLoading,
    history: {
      past: history.past,
      future: history.future,
      undo,
      redo,
      canUndo: history.past.length > 0,
      canRedo: history.future.length > 0
    }
  }
}

// Hook for form state management
export interface UseFormStateOptions<T> extends UseEnhancedStateOptions<T> {
  // Form-specific options
  onSubmit?: (values: T) => Promise<void> | void
  onReset?: () => void
  validateOnChange?: boolean
  validateOnBlur?: boolean
}

export interface UseFormStateReturn<T> extends UseEnhancedStateReturn<T> {
  handleSubmit: (onSubmit?: (values: T) => Promise<void> | void) => (e: React.FormEvent) => void
  getFieldProps: (field: keyof T) => {
    value: any
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
    onBlur: () => void
    error?: string
  }
  setFieldValue: (field: keyof T, value: any) => void
  setFieldError: (field: keyof T, error: string) => void
  touched: Set<keyof T>
  errors: Partial<Record<keyof T, string>>
  isSubmitting: boolean
}

export function useFormState<T extends Record<string, any>>(
  initialValues: T,
  options: UseFormStateOptions<T> = {}
): UseFormStateReturn<T> {
  const {
    onSubmit,
    onReset,
    validateOnChange = true,
    validateOnBlur = true,
    ...enhancedOptions
  } = options

  const [touched, setTouched] = React.useState<Set<keyof T>>(new Set())
  const [errors, setErrors] = React.useState<Partial<Record<keyof T, string>>>({})
  const [isSubmitting, setIsSubmitting] = React.useState(false)

  const state = useEnhancedState(initialValues, enhancedOptions)

  // Validate form
  const validateForm = (values: T): Partial<Record<keyof T, string>> => {
    const newErrors: Partial<Record<keyof T, string>> = {}

    Object.keys(values).forEach(key => {
      const fieldKey = key as keyof T
      const value = values[fieldKey]

      if (enhancedOptions.validate) {
        try {
          enhancedOptions.validate(values)
        } catch (err) {
          if (err instanceof Error && err.message.includes(key)) {
            newErrors[fieldKey] = err.message
          }
        }
      }
    })

    return newErrors
  }

  // Handle form submission
  const handleSubmit = (customOnSubmit?: (values: T) => Promise<void> | void) => {
    return async (e: React.FormEvent) => {
      e.preventDefault()

      // Mark all fields as touched
      setTouched(new Set(Object.keys(state.value) as (keyof T)[]))

      // Validate form
      const formErrors = validateForm(state.value)
      setErrors(formErrors)

      if (Object.keys(formErrors).length > 0) {
        return
      }

      setIsSubmitting(true)

      try {
        const submitFunction = customOnSubmit || onSubmit
        if (submitFunction) {
          await submitFunction(state.value)
        }
      } catch (error) {
        console.error('Form submission error:', error)
      } finally {
        setIsSubmitting(false)
      }
    }
  }

  // Get field props
  const getFieldProps = (field: keyof T) => {
    return {
      value: state.value[field],
      onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = { ...state.value, [field]: e.target.value }
        state.setValue(newValue)

        if (validateOnChange) {
          const fieldErrors = validateForm(newValue)
          setErrors(fieldErrors)
        }
      },
      onBlur: () => {
        setTouched(prev => new Set(prev).add(field))

        if (validateOnBlur) {
          const fieldErrors = validateForm(state.value)
          setErrors(fieldErrors)
        }
      },
      error: touched.has(field) ? errors[field] : undefined
    }
  }

  // Set field value
  const setFieldValue = (field: keyof T, value: any) => {
    const newValue = { ...state.value, [field]: value }
    state.setValue(newValue)

    if (validateOnChange) {
      const fieldErrors = validateForm(newValue)
      setErrors(fieldErrors)
    }
  }

  // Set field error
  const setFieldError = (field: keyof T, error: string) => {
    setErrors(prev => ({ ...prev, [field]: error }))
  }

  // Reset form
  const handleReset = () => {
    state.reset()
    setTouched(new Set())
    setErrors({})
    onReset?.()
  }

  return {
    ...state,
    handleSubmit,
    getFieldProps,
    setFieldValue,
    setFieldError,
    touched,
    errors,
    isSubmitting,
    reset: handleReset
  }
}

// Hook for async state management
export interface UseAsyncStateOptions<T, E = Error> {
  // Initial state
  initialData?: T
  initialLoading?: boolean
  
  // Callbacks
  onSuccess?: (data: T) => void
  onError?: (error: E) => void
  onSettled?: (data: T | undefined, error: E | undefined) => void
  
  // Retry options
  retry?: boolean
  retryDelay?: number
  maxRetries?: number
  
  // Cache options
  cacheKey?: string
  cacheTime?: number
  staleTime?: number
}

export interface UseAsyncStateReturn<T, E = Error> {
  data: T | undefined
  error: E | undefined
  loading: boolean
  execute: (asyncFunction: () => Promise<T>) => Promise<T | undefined>
  reset: () => void
  refetch: () => Promise<T | undefined>
  isFetching: boolean
}

export function useAsyncState<T, E = Error>(
  options: UseAsyncStateOptions<T, E> = {}
): UseAsyncStateReturn<T, E> {
  const {
    initialData,
    initialLoading = false,
    onSuccess,
    onError,
    onSettled,
    retry = true,
    retryDelay = 1000,
    maxRetries = 3,
    cacheKey,
    cacheTime = 5 * 60 * 1000, // 5 minutes
    staleTime = 0
  } = options

  const [data, setData] = React.useState<T | undefined>(initialData)
  const [error, setError] = React.useState<E | undefined>()
  const [loading, setLoading] = React.useState(initialLoading)
  const [isFetching, setIsFetching] = React.useState(false)

  // Cache management
  const getCache = () => {
    if (!cacheKey) return null
    return utils.storage.session.get<{ data: T; timestamp: number }>(cacheKey)
  }

  const setCache = (cacheData: T) => {
    if (!cacheKey) return
    utils.storage.session.set(cacheKey, {
      data: cacheData,
      timestamp: Date.now()
    })
  }

  const isCacheValid = (cache: { data: T; timestamp: number } | null) => {
    if (!cache) return false
    return Date.now() - cache.timestamp < staleTime
  }

  // Execute async function
  const execute = React.useCallback(async (asyncFunction: () => Promise<T>) => {
    setIsFetching(true)
    
    try {
      // Check cache first
      if (cacheKey) {
        const cache = getCache()
        if (isCacheValid(cache)) {
          setData(cache!.data)
          onSuccess?.(cache!.data)
          onSettled?.(cache!.data, undefined)
          setIsFetching(false)
          return cache!.data
        }
      }

      setLoading(true)
      setError(undefined)

      const result = await asyncFunction()
      
      setData(result)
      setCache(result)
      onSuccess?.(result)
      onSettled?.(result, undefined)
      
      return result
    } catch (err) {
      const error = err as E
      setError(error)
      onError?.(error)
      onSettled?.(undefined, error)
      
      // Retry logic
      if (retry) {
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
          await new Promise(resolve => setTimeout(resolve, retryDelay * attempt))
          
          try {
            const retryResult = await asyncFunction()
            setData(retryResult)
            setCache(retryResult)
            onSuccess?.(retryResult)
            onSettled?.(retryResult, undefined)
            return retryResult
          } catch (retryError) {
            if (attempt === maxRetries) {
              break
            }
          }
        }
      }
      
      throw error
    } finally {
      setLoading(false)
      setIsFetching(false)
    }
  }, [retry, retryDelay, maxRetries, onSuccess, onError, onSettled, cacheKey])

  // Reset state
  const reset = React.useCallback(() => {
    setData(initialData)
    setError(undefined)
    setLoading(initialLoading)
    setIsFetching(false)
  }, [initialData, initialLoading])

  // Refetch data
  const refetch = React.useCallback(async () => {
    if (!data) return undefined
    
    try {
      // This would typically re-execute the original async function
      // For now, we'll just reset and indicate loading
      setLoading(true)
      setError(undefined)
      
      // In a real implementation, you'd store the original function
      // and re-execute it here
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      return data
    } catch (err) {
      const error = err as E
      setError(error)
      onError?.(error)
      return undefined
    } finally {
      setLoading(false)
    }
  }, [data, onError])

  return {
    data,
    error,
    loading,
    execute,
    reset,
    refetch,
    isFetching
  }
}

// All hooks are exported individually above