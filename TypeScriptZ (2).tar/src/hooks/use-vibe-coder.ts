import { useState, useEffect, useCallback } from 'react';
import { vibeCoder, VibeState, EvolutionMetrics, FeedbackLoop } from '@/lib/vibe-coder';

export interface VibeCoderHook {
  state: VibeState;
  metrics: EvolutionMetrics;
  history: VibeState[];
  feedbackLoops: FeedbackLoop[];
  stats: any;
  triggerEvolution: () => void;
  setCustomState: (newState: Partial<VibeState>) => void;
  setCustomMetrics: (newMetrics: Partial<EvolutionMetrics>) => void;
  reset: () => void;
  isEvolving: boolean;
  // Novas funcionalidades de coerência
  coherenceStatus: any;
  predictions: any[];
  updateCoherenceData: (biometrics: any, environmental: any) => void;
  executeCoherenceAdjustments: (adjustments: any[]) => Promise<any[]>;
  startCoherenceOptimization: () => void;
  stopCoherenceOptimization: () => void;
  resetCoherenceSystems: () => void;
  isCoherenceOptimizationActive: boolean;
}

export function useVibeCoder(): VibeCoderHook {
  const [state, setState] = useState<VibeState>(vibeCoder.getCurrentState());
  const [metrics, setMetrics] = useState<EvolutionMetrics>(vibeCoder.getCurrentMetrics());
  const [history, setHistory] = useState<VibeState[]>(vibeCoder.getStateHistory());
  const [feedbackLoops, setFeedbackLoops] = useState<FeedbackLoop[]>(vibeCoder.getFeedbackLoops());
  const [stats, setStats] = useState<any>(vibeCoder.getSystemStats());
  const [isEvolving, setIsEvolving] = useState(false);
  
  // Novos estados para funcionalidades de coerência
  const [coherenceStatus, setCoherenceStatus] = useState<any>(vibeCoder.getCoherenceStatus());
  const [predictions, setPredictions] = useState<any[]>(vibeCoder.getPredictions());
  const [isCoherenceOptimizationActive, setIsCoherenceOptimizationActive] = useState(false);

  // Atualizar estado periodicamente
  useEffect(() => {
    const interval = setInterval(() => {
      setState(vibeCoder.getCurrentState());
      setMetrics(vibeCoder.getCurrentMetrics());
      setHistory(vibeCoder.getStateHistory());
      setFeedbackLoops(vibeCoder.getFeedbackLoops());
      setStats(vibeCoder.getSystemStats());
      
      // Atualizar dados de coerência
      setCoherenceStatus(vibeCoder.getCoherenceStatus());
      setPredictions(vibeCoder.getPredictions());
      setIsCoherenceOptimizationActive(stats.coherenceOptimizationActive || false);
    }, 1000);

    return () => clearInterval(interval);
  }, [stats.coherenceOptimizationActive]);

  const triggerEvolution = useCallback(() => {
    setIsEvolving(true);
    vibeCoder.triggerEvolution();
    
    // Simular tempo de evolução
    setTimeout(() => {
      setIsEvolving(false);
    }, 2000);
  }, []);

  const setCustomState = useCallback((newState: Partial<VibeState>) => {
    vibeCoder.setCustomState(newState);
    setState(vibeCoder.getCurrentState());
  }, []);

  const setCustomMetrics = useCallback((newMetrics: Partial<EvolutionMetrics>) => {
    vibeCoder.setCustomMetrics(newMetrics);
    setMetrics(vibeCoder.getCurrentMetrics());
  }, []);

  const reset = useCallback(() => {
    vibeCoder.reset();
    setState(vibeCoder.getCurrentState());
    setMetrics(vibeCoder.getCurrentMetrics());
    setHistory(vibeCoder.getStateHistory());
    setFeedbackLoops(vibeCoder.getFeedbackLoops());
    setStats(vibeCoder.getSystemStats());
    setCoherenceStatus(vibeCoder.getCoherenceStatus());
    setPredictions(vibeCoder.getPredictions());
  }, []);

  // Novos métodos para funcionalidades de coerência
  const updateCoherenceData = useCallback((biometrics: any, environmental: any) => {
    vibeCoder.updateCoherenceData(biometrics, environmental);
  }, []);

  const executeCoherenceAdjustments = useCallback(async (adjustments: any[]) => {
    return await vibeCoder.executeCoherenceAdjustments(adjustments);
  }, []);

  const startCoherenceOptimization = useCallback(() => {
    vibeCoder.startCoherenceOptimization();
    setIsCoherenceOptimizationActive(true);
  }, []);

  const stopCoherenceOptimization = useCallback(() => {
    vibeCoder.stopCoherenceOptimization();
    setIsCoherenceOptimizationActive(false);
  }, []);

  const resetCoherenceSystems = useCallback(() => {
    vibeCoder.resetCoherenceSystems();
    setCoherenceStatus(vibeCoder.getCoherenceStatus());
    setPredictions(vibeCoder.getPredictions());
  }, []);

  return {
    state,
    metrics,
    history,
    feedbackLoops,
    stats,
    triggerEvolution,
    setCustomState,
    setCustomMetrics,
    reset,
    isEvolving,
    // Novas funcionalidades de coerência
    coherenceStatus,
    predictions,
    updateCoherenceData,
    executeCoherenceAdjustments,
    startCoherenceOptimization,
    stopCoherenceOptimization,
    resetCoherenceSystems,
    isCoherenceOptimizationActive
  };
}