/**
 * Generic Types for Coherent Programming Patterns
 * 
 * This module provides generic types and utility functions for implementing
 * coherent programming patterns throughout the application.
 */

import { CoherentBase, CoherenceScore, CoherenceMetrics } from '@/types';

// Base Generic Types
export interface CoherentEntity<T extends Record<string, unknown> = Record<string, unknown>> extends CoherentBase {
  data: T;
  entityType: string;
  version: number;
  checksum: string;
}

export interface CoherentCollection<T extends CoherentEntity = CoherentEntity> {
  id: string;
  entities: T[];
  metadata: CollectionMetadata;
  coherence: CoherenceScore;
  lastUpdated: number;
}

export interface CollectionMetadata {
  totalCount: number;
  totalSize: number;
  averageCoherence: number;
  minCoherence: number;
  maxCoherence: number;
  tags: string[];
  indexes: Record<string, unknown>;
}

// Result Types
export interface Result<T, E = Error> {
  success: boolean;
  data?: T;
  error?: E;
  message?: string;
  metadata?: Record<string, unknown>;
}

export interface AsyncResult<T, E = Error> extends Promise<Result<T, E>> {}

export interface PaginatedResult<T> extends Result<T[]> {
  pagination: PaginationInfo;
}

export interface PaginationInfo {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

// State Management Types
export interface State<T> {
  current: T;
  previous: T | null;
  lastUpdated: number;
  version: number;
  coherence: CoherenceScore;
}

export interface StateTransition<T, P = unknown> {
  from: T;
  to: T;
  payload: P;
  timestamp: number;
  transitionType: string;
  coherence: CoherenceScore;
}

export interface StateMachine<T, E = string, A = unknown> {
  currentState: T;
  states: Set<T>;
  transitions: Map<T, Map<E, { to: T; action?: (payload: A) => void }>>;
  history: StateTransition<T, A>[];
  coherence: CoherenceScore;
}

// Event System Types
export interface Event<T = unknown> {
  id: string;
  type: string;
  payload: T;
  timestamp: number;
  source: string;
  target?: string;
  metadata?: Record<string, unknown>;
  priority: 'low' | 'medium' | 'high' | 'critical';
}

export interface EventHandler<T = unknown> {
  id: string;
  eventType: string;
  handler: (event: Event<T>) => void | Promise<void>;
  once?: boolean;
  priority?: number;
  filters?: EventFilter<T>[];
}

export interface EventFilter<T = unknown> {
  field: keyof Event<T>;
  operator: 'equals' | 'contains' | 'greater' | 'less' | 'regex';
  value: unknown;
}

export interface EventBus<T = unknown> {
  on(eventType: string, handler: EventHandler<T>): void;
  off(eventType: string, handlerId: string): void;
  emit(event: Event<T>): void;
  once(eventType: string, handler: EventHandler<T>): void;
  removeAllListeners(eventType?: string): void;
  listenerCount(eventType: string): number;
}

// Pipeline Types
export interface Pipeline<T = unknown, R = unknown> {
  id: string;
  stages: PipelineStage[];
  context: PipelineContext;
  coherence: CoherenceScore;
}

export interface PipelineStage<T = unknown, R = unknown> {
  id: string;
  name: string;
  processor: (input: T, context: PipelineContext) => Promise<R>;
  validator?: (input: T) => boolean;
  errorHandler?: (error: Error, input: T, context: PipelineContext) => Promise<R>;
  metadata?: Record<string, unknown>;
}

export interface PipelineContext {
  requestId: string;
  timestamp: number;
  metadata: Record<string, unknown>;
  progress: {
    current: number;
    total: number;
    percentage: number;
  };
  logs: PipelineLog[];
}

export interface PipelineLog {
  timestamp: number;
  level: 'info' | 'warning' | 'error' | 'debug';
  message: string;
  stage?: string;
  metadata?: Record<string, unknown>;
}

// Cache Types
export interface Cache<K = string, V = unknown> {
  get(key: K): Promise<V | undefined>;
  set(key: K, value: V, ttl?: number): Promise<void>;
  delete(key: K): Promise<boolean>;
  clear(): Promise<void>;
  has(key: K): Promise<boolean>;
  size(): Promise<number>;
  keys(): Promise<K[]>;
  values(): Promise<V[]>;
  entries(): Promise<[K, V][]>;
}

export interface CacheEntry<V = unknown> {
  value: V;
  timestamp: number;
  ttl: number;
  hits: number;
  metadata?: Record<string, unknown>;
}

export interface CacheStats {
  hits: number;
  misses: number;
  hitRate: number;
  size: number;
  memoryUsage: number;
  evictionCount: number;
}

// Configuration Types
export interface Configuration<T = Record<string, unknown>> {
  id: string;
  data: T;
  schema: ConfigurationSchema;
  validation: ValidationResult;
  lastUpdated: number;
  version: number;
  environment: 'development' | 'staging' | 'production';
}

export interface ConfigurationSchema {
  type: 'object';
  properties: Record<string, PropertySchema>;
  required?: string[];
  additionalProperties?: boolean;
}

export interface PropertySchema {
  type: 'string' | 'number' | 'boolean' | 'array' | 'object';
  description?: string;
  enum?: unknown[];
  minimum?: number;
  maximum?: number;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  items?: PropertySchema;
  properties?: Record<string, PropertySchema>;
  required?: string[];
  default?: unknown;
}

// Validation Types
export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
  score: number;
  details: Record<string, unknown>;
}

export interface ValidationError {
  field: string;
  message: string;
  value: unknown;
  constraint: string;
  severity: 'error';
}

export interface ValidationWarning {
  field: string;
  message: string;
  value: unknown;
  constraint: string;
  severity: 'warning';
}

export interface Validator<T = unknown> {
  validate(value: T): ValidationResult;
  schema: ConfigurationSchema;
}

// Repository Types
export interface Repository<T extends CoherentEntity = CoherentEntity> {
  findById(id: string): Promise<T | null>;
  findAll(options?: FindOptions<T>): Promise<T[]>;
  create(entity: Omit<T, 'id' | 'timestamp' | 'coherence'>): Promise<T>;
  update(id: string, updates: Partial<T>): Promise<T>;
  delete(id: string): Promise<boolean>;
  count(options?: CountOptions): Promise<number>;
  exists(id: string): Promise<boolean>;
}

export interface FindOptions<T = unknown> {
  filter?: Record<string, unknown>;
  sort?: Record<string, 1 | -1>;
  limit?: number;
  skip?: number;
  projection?: Record<string, 1 | 0>;
}

export interface CountOptions {
  filter?: Record<string, unknown>;
}

// Service Types
export interface Service<T = unknown, I = unknown, O = unknown> {
  id: string;
  name: string;
  version: string;
  process(input: I): Promise<O>;
  health(): Promise<HealthStatus>;
  metrics(): Promise<ServiceMetrics>;
  configure(config: unknown): Promise<void>;
  start(): Promise<void>;
  stop(): Promise<void>;
}

export interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  checks: HealthCheck[];
  timestamp: number;
  uptime: number;
  version: string;
}

export interface HealthCheck {
  name: string;
  status: 'pass' | 'fail' | 'warn';
  duration: number;
  message?: string;
  metadata?: Record<string, unknown>;
}

export interface ServiceMetrics {
  requests: number;
  errors: number;
  averageResponseTime: number;
  lastRequestTime: number;
  memoryUsage: number;
  cpuUsage: number;
  uptime: number;
}

// Observer Pattern Types
export interface Observable<T = unknown> {
  subscribe(observer: Observer<T>): Subscription;
  unsubscribe(observer: Observer<T>): void;
  notify(value: T): void;
  complete(): void;
  error(error: Error): void;
}

export interface Observer<T = unknown> {
  next(value: T): void;
  error?(error: Error): void;
  complete?(): void;
}

export interface Subscription {
  unsubscribe(): void;
}

// Strategy Pattern Types
export interface Strategy<T = unknown, C = unknown, R = unknown> {
  name: string;
  execute(context: C, input: T): Promise<R>;
  isApplicable(context: C, input: T): boolean;
  getConfidence(context: C, input: T): number;
}

export interface StrategyRegistry<T = unknown, C = unknown, R = unknown> {
  register(strategy: Strategy<T, C, R>): void;
  unregister(strategyName: string): void;
  getStrategy(context: C, input: T): Strategy<T, C, R> | null;
  getAllStrategies(): Strategy<T, C, R>[];
  executeBestStrategy(context: C, input: T): Promise<R>;
}

// Factory Pattern Types
export interface Factory<T = unknown, P = unknown> {
  create(params: P): Promise<T>;
  getAvailableTypes(): string[];
  validateParams(params: P): ValidationResult;
}

export interface FactoryRegistry<T = unknown, P = unknown> {
  register(type: string, factory: Factory<T, P>): void;
  unregister(type: string): void;
  create(type: string, params: P): Promise<T>;
  getAvailableTypes(): string[];
}

// Decorator Pattern Types
export interface Decorator<T = unknown> {
  decorate(target: T): T;
  undecorate(target: T): T;
  isDecorated(target: T): boolean;
}

export interface DecoratorRegistry<T = unknown> {
  register(name: string, decorator: Decorator<T>): void;
  unregister(name: string): void;
  decorate(target: T, decoratorNames: string[]): T;
  undecorate(target: T, decoratorNames: string[]): T;
  getDecorators(target: T): string[];
}

// Command Pattern Types
export interface Command<T = unknown, R = unknown> {
  id: string;
  name: string;
  execute(payload: T): Promise<R>;
  undo?(payload: T): Promise<void>;
  canExecute(payload: T): boolean;
  getMetadata(): Record<string, unknown>;
}

export interface CommandBus<T = unknown, R = unknown> {
  execute(command: Command<T, R>, payload: T): Promise<R>;
  undo(commandId: string, payload: T): Promise<void>;
  canExecute(command: Command<T, R>, payload: T): boolean;
  getHistory(): CommandHistory<T, R>[];
  clearHistory(): void;
}

export interface CommandHistory<T = unknown, R = unknown> {
  commandId: string;
  commandName: string;
  payload: T;
  result?: R;
  timestamp: number;
  executionTime: number;
  success: boolean;
}

// Generic Utility Functions
export class CoherentUtils {
  /**
   * Creates a coherent entity with proper validation
   */
  static createEntity<T extends Record<string, unknown>>(
    data: T,
    entityType: string,
    validator?: (data: T) => ValidationResult
  ): CoherentEntity<T> {
    const id = `entity_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const timestamp = Date.now();
    const checksum = this.generateChecksum(data);
    
    // Validate if validator is provided
    let validation: ValidationResult = { valid: true, errors: [], warnings: [], score: 100, details: {} };
    if (validator) {
      validation = validator(data);
    }
    
    return {
      id,
      type: 'coherent-entity',
      timestamp,
      coherence: validation.score as CoherenceScore,
      data,
      entityType,
      version: 1,
      checksum
    };
  }
  
  /**
   * Creates a coherent collection
   */
  static createCollection<T extends CoherentEntity>(
    entities: T[],
    metadata: Partial<CollectionMetadata> = {}
  ): CoherentCollection<T> {
    const id = `collection_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const totalCount = entities.length;
    const totalSize = entities.reduce((sum, entity) => sum + JSON.stringify(entity).length, 0);
    
    const coherences = entities.map(e => e.coherence);
    const averageCoherence = coherences.length > 0 ? coherences.reduce((a, b) => a + b, 0) / coherences.length : 0;
    const minCoherence = coherences.length > 0 ? Math.min(...coherences) : 0;
    const maxCoherence = coherences.length > 0 ? Math.max(...coherences) : 0;
    
    const collectionMetadata: CollectionMetadata = {
      totalCount,
      totalSize,
      averageCoherence,
      minCoherence,
      maxCoherence,
      tags: metadata.tags || [],
      indexes: metadata.indexes || {}
    };
    
    return {
      id,
      entities,
      metadata: collectionMetadata,
      coherence: averageCoherence as CoherenceScore,
      lastUpdated: Date.now()
    };
  }
  
  /**
   * Creates a successful result
   */
  static success<T, E = Error>(data: T, message?: string, metadata?: Record<string, unknown>): Result<T, E> {
    return {
      success: true,
      data,
      message,
      metadata
    };
  }
  
  /**
   * Creates a failed result
   */
  static failure<T, E = Error>(error: E, message?: string, metadata?: Record<string, unknown>): Result<T, E> {
    return {
      success: false,
      error,
      message,
      metadata
    };
  }
  
  /**
   * Creates a paginated result
   */
  static paginated<T>(
    data: T[],
    pagination: PaginationInfo,
    message?: string,
    metadata?: Record<string, unknown>
  ): PaginatedResult<T> {
    return {
      success: true,
      data,
      pagination,
      message,
      metadata
    };
  }
  
  /**
   * Generates a checksum for data
   */
  private static generateChecksum(data: unknown): string {
    const str = JSON.stringify(data);
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString(16);
  }
}

// Type Guards
export function isCoherentEntity<T = Record<string, unknown>>(obj: unknown): obj is CoherentEntity<T> {
  return typeof obj === 'object' && obj !== null &&
         'id' in obj && 'type' in obj && 'data' in obj &&
         'entityType' in obj && 'version' in obj && 'checksum' in obj;
}

export function isCoherentCollection<T = CoherentEntity>(obj: unknown): obj is CoherentCollection<T> {
  return typeof obj === 'object' && obj !== null &&
         'id' in obj && 'entities' in obj && 'metadata' in obj &&
         'coherence' in obj && 'lastUpdated' in obj;
}

export function isResult<T = unknown, E = Error>(obj: unknown): obj is Result<T, E> {
  return typeof obj === 'object' && obj !== null &&
         'success' in obj;
}

export function isEvent<T = unknown>(obj: unknown): obj is Event<T> {
  return typeof obj === 'object' && obj !== null &&
         'id' in obj && 'type' in obj && 'payload' in obj &&
         'timestamp' in obj && 'source' in obj;
}

// Export all types and utilities
export type {
  CoherentEntity,
  CoherentCollection,
  CollectionMetadata,
  Result,
  AsyncResult,
  PaginatedResult,
  PaginationInfo,
  State,
  StateTransition,
  StateMachine,
  Event,
  EventHandler,
  EventFilter,
  EventBus,
  Pipeline,
  PipelineStage,
  PipelineContext,
  PipelineLog,
  Cache,
  CacheEntry,
  CacheStats,
  Configuration,
  ConfigurationSchema,
  PropertySchema,
  ValidationError,
  ValidationWarning,
  Validator,
  Repository,
  FindOptions,
  CountOptions,
  Service,
  HealthStatus,
  HealthCheck,
  ServiceMetrics,
  Observable,
  Observer,
  Subscription,
  Strategy,
  StrategyRegistry,
  Factory,
  FactoryRegistry,
  Decorator,
  DecoratorRegistry,
  Command,
  CommandBus,
  CommandHistory
};