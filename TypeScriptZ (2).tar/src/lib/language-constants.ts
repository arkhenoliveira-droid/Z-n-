export type Language = 'pt' | 'en' | 'es';

export const supportedLanguages: Language[] = ['pt', 'en', 'es'];

export const defaultLanguage: Language = 'en';