// Re-export types and utilities
export type { Language } from './language-detector-client';
export { 
  supportedLanguages, 
  defaultLanguage, 
  languageNames,
  getLanguageFromAcceptLanguage,
  getLanguageFromURL,
  createLocalizedUrl,
  removeLanguageFromPath,
  languageUtils,
  languagePreferences,
  useLanguageDetection
} from './language-detector-client';

// Simplified detection function
export async function detectLanguage(): Promise<import('./language-detector-client').Language> {
  // For client-side detection, use browser language
  if (typeof window !== 'undefined') {
    const { detectClientLanguage } = await import('./language-detector-client');
    return detectClientLanguage();
  }
  
  // For server-side detection, use default
  const { defaultLanguage } = await import('./language-detector-client');
  return defaultLanguage;
}