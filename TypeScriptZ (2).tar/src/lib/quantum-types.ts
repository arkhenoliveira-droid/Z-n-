/**
 * Enhanced Quantum Computing Type Definitions
 * 
 * This module provides comprehensive type definitions for quantum computing systems
 * with enhanced type safety and coherence features.
 */

import { CoherentBase, CoherenceScore, CoherenceMetrics } from '@/types';

// Quantum State Types
export interface QuantumState extends CoherentBase {
  type: 'quantum-state';
  amplitude: ComplexAmplitude;
  phase: number;
  probability: number;
  entangledWith?: string[];
  superposition: boolean;
  decoherenceRate: number;
  measurementBasis: 'computational' | 'hadamard' | 'custom';
  fidelity: number;
  purity: number;
  entropy: number;
}

export interface ComplexAmplitude {
  real: number;
  imaginary: number;
  magnitude: number;
  phase: number;
}

// Quantum Gate Types
export interface QuantumGate extends CoherentBase {
  type: 'quantum-gate';
  gateType: QuantumGateType;
  matrix: ComplexMatrix;
  controlled: boolean;
  targetQubits: number[];
  controlQubits?: number[];
  fidelity: number;
  errorRate: number;
  duration: number;
}

export type QuantumGateType = 
  | 'pauli-x' | 'pauli-y' | 'pauli-z'
  | 'hadamard' | 'cnot' | 'toffoli' | 'phase'
  | 'swap' | 'fredkin' | 'custom';

export interface ComplexMatrix {
  rows: number;
  cols: number;
  data: ComplexAmplitude[][];
}

// Quantum Circuit Types
export interface QuantumCircuit extends CoherentBase {
  type: 'quantum-circuit';
  qubits: number;
  gates: QuantumGate[];
  depth: number;
  fidelity: number;
  errorRate: number;
  optimizationLevel: number;
  executionTime: number;
  powerConsumption: number;
  coherenceScore: CoherenceScore;
}

// Quantum Measurement Types
export interface QuantumMeasurement extends CoherentBase {
  type: 'quantum-measurement';
  circuitId: string;
  results: MeasurementResult[];
  expectation: number;
  variance: number;
  collapseTime: number;
  measurementBasis: 'computational' | 'hadamard' | 'custom';
  accuracy: number;
  confidence: number;
}

export interface MeasurementResult {
  qubit: number;
  state: '0' | '1';
  probability: number;
  confidence: number;
  timestamp: number;
}

// Quantum Distortion Types
export interface QuantumDistortion extends CoherentBase {
  type: 'quantum-distortion';
  distortionType: DistortionType;
  severity: 'low' | 'medium' | 'high' | 'critical';
  magnitude: number;
  frequency: number;
  phase: number;
  location: {
    qubit?: number;
    gate?: string;
    circuit?: string;
  };
  impact: {
    fidelity: number;
    errorRate: number;
    coherence: number;
  };
  detected: number;
  resolved: boolean;
  resolution?: string;
}

export type DistortionType = 
  | 'phase-shift' | 'amplitude-damping' | 'dephasing'
  | 'entanglement-loss' | 'cross-talk' | 'thermal-noise'
  | 'control-error' | 'measurement-error' | 'custom';

// Quantum Protection Types
export interface QuantumProtection extends CoherentBase {
  type: 'quantum-protection';
  protectionType: ProtectionType;
  active: boolean;
  strength: number;
  coherence: number;
  efficiency: number;
  frequency: number;
  phase: number;
  coverage: {
    qubits: number[];
    gates: string[];
    circuits: string[];
  };
  parameters: ProtectionParameters;
  lastActivated: number;
  totalActivations: number;
}

export type ProtectionType = 
  | 'error-correction' | 'dynamical-decoupling' | 'quantum-shielding'
  | 'coherence-preservation' | 'entanglement-stabilization' | 'custom';

export interface ProtectionParameters {
  threshold: number;
  responseTime: number;
  powerConsumption: number;
  coolingRequirement: number;
  calibrationInterval: number;
}

// Quantum System Status Types
export interface QuantumSystemStatus extends CoherentBase {
  type: 'quantum-system-status';
  systemStatus: 'operational' | 'degraded' | 'critical' | 'offline';
  threatLevel: number;
  distortions: QuantumDistortion[];
  hallucinations: QuantumHallucination[];
  shields: QuantumProtection[];
  realityField: RealityField;
  metrics: QuantumMetrics;
  alerts: QuantumAlert[];
  lastUpdate: number;
}

export interface QuantumHallucination extends CoherentBase {
  type: 'quantum-hallucination';
  hallucinationType: HallucinationType;
  severity: 'low' | 'medium' | 'high' | 'critical';
  magnitude: number;
  frequency: number;
  location: {
    qubit?: number;
    gate?: string;
    circuit?: string;
  };
  impact: {
    measurementAccuracy: number;
    stateFidelity: number;
    coherence: number;
  };
  detected: number;
  resolved: boolean;
  resolution?: string;
}

export type HallucinationType = 
  | 'measurement-bias' | 'state-collapse' | 'entanglement-illusion'
  | 'superposition-ghost' | 'quantum-tunneling' | 'custom';

export interface RealityField {
  stability: number;
  integrity: number;
  coherence: number;
  resonance: number;
  damping: number;
  feedback: number;
  strength: number;
  frequency: number;
  phase: number;
}

export interface QuantumMetrics extends CoherenceMetrics {
  systemStatus: 'operational' | 'degraded' | 'critical' | 'offline';
  threatLevel: number;
  responseTime: number;
  threatsNeutralized: number;
  falsePositives: number;
  protectionEfficiency: number;
  lastScan: number;
  energyReserves: number;
  systemStability: number;
  quantumVolume: number;
  circuitDepth: number;
  gateFidelity: number;
  measurementAccuracy: number;
  errorCorrectionOverhead: number;
}

export interface QuantumAlert {
  id: string;
  type: 'warning' | 'error' | 'critical';
  category: 'distortion' | 'hallucination' | 'shield' | 'system';
  message: string;
  severity: number;
  timestamp: number;
  resolved: boolean;
  resolution?: string;
  metadata?: Record<string, unknown>;
}

// Quantum Protection System Types
export interface QuantumProtectionSystem extends CoherentBase {
  type: 'quantum-protection-system';
  status: QuantumSystemStatus;
  configuration: ProtectionConfiguration;
  history: ProtectionHistory;
  diagnostics: SystemDiagnostics;
  optimization: OptimizationEngine;
}

export interface ProtectionConfiguration {
  autoActivation: boolean;
  sensitivity: number;
  responseThreshold: number;
  protectionTypes: ProtectionType[];
  coverage: {
    qubits: number;
    gates: number;
    circuits: number;
  };
  parameters: {
    maxPower: number;
    coolingCapacity: number;
    calibrationFrequency: number;
  };
}

export interface ProtectionHistory {
  scans: ProtectionScan[];
  neutralizations: ThreatNeutralization[];
  shieldActivations: ShieldActivation[];
  energyConsumption: EnergyConsumption[];
  systemEvents: SystemEvent[];
}

export interface ProtectionScan {
  timestamp: number;
  distortionsFound: number;
  hallucinationsFound: number;
  scanDuration: number;
  accuracy: number;
  coverage: number;
}

export interface ThreatNeutralization {
  timestamp: number;
  threatsNeutralized: number;
  successRate: number;
  energyUsed: number;
  timeTaken: number;
}

export interface ShieldActivation {
  timestamp: number;
  shieldType: ProtectionType;
  activeShields: number;
  averageStrength: number;
  averageEfficiency: number;
  duration: number;
}

export interface EnergyConsumption {
  timestamp: number;
  energyLevel: number;
  consumptionRate: number;
  regenerationRate: number;
  efficiency: number;
}

export interface SystemEvent {
  timestamp: number;
  type: 'shield-activation' | 'threat-neutralized' | 'energy-low' | 'system-calibration';
  severity: 'low' | 'medium' | 'high';
  description: string;
  metadata?: Record<string, unknown>;
}

export interface SystemDiagnostics {
  systemHealth: SystemHealth;
  shieldDiagnostics: ShieldDiagnostic[];
  realityFieldDiagnostics: RealityFieldDiagnostics;
  performanceMetrics: PerformanceMetrics;
  recommendations: string[];
}

export interface SystemHealth {
  overall: 'excellent' | 'good' | 'fair' | 'poor' | 'critical';
  coherence: number;
  stability: number;
  energy: number;
  threatLevel: number;
  temperature: number;
  pressure: number;
  magneticField: number;
}

export interface ShieldDiagnostic {
  id: string;
  type: ProtectionType;
  health: number;
  coherence: number;
  efficiency: number;
  status: 'active' | 'inactive' | 'degraded' | 'failed';
  issues: string[];
  lastMaintenance: number;
  nextMaintenance: number;
}

export interface RealityFieldDiagnostics {
  stability: number;
  integrity: number;
  coherence: number;
  resonance: number;
  damping: number;
  feedback: number;
  strength: number;
  frequency: number;
  phase: number;
  anomalies: RealityAnomaly[];
}

export interface RealityAnomaly {
  type: 'instability' | 'integrity-breach' | 'coherence-loss' | 'resonance-failure';
  severity: 'low' | 'medium' | 'high' | 'critical';
  location: {
    x: number;
    y: number;
    z: number;
  };
  magnitude: number;
  detected: number;
  resolved: boolean;
}

export interface PerformanceMetrics {
  responseTime: number;
  threatsNeutralized: number;
  falsePositives: number;
  protectionEfficiency: number;
  lastScanTime: number;
  uptime: number;
  throughput: number;
  latency: number;
  errorRate: number;
}

export interface OptimizationEngine {
  enabled: boolean;
  strategy: 'aggressive' | 'balanced' | 'conservative';
  lastOptimization: number;
  optimizationHistory: OptimizationRecord[];
  performance: OptimizationPerformance;
}

export interface OptimizationRecord {
  timestamp: number;
  type: 'shield' | 'reality-field' | 'energy' | 'system';
  improvements: string[];
  before: number;
  after: number;
  efficiency: number;
}

export interface OptimizationPerformance {
  totalOptimizations: number;
  averageImprovement: number;
  successRate: number;
  lastOptimizationTime: number;
  nextOptimizationTime: number;
}

// Quantum Coherence Types
export interface QuantumCoherenceAnalyzer {
  analyzeCoherence(state: QuantumState): CoherenceAnalysis;
  optimizeCoherence(state: QuantumState): OptimizationResult;
  predictDecoherence(state: QuantumState): DecoherencePrediction;
  generateCoherenceReport(state: QuantumState): CoherenceReport;
}

export interface CoherenceAnalysis {
  overallCoherence: CoherenceScore;
  factors: CoherenceFactor[];
  threats: CoherenceThreat[];
  recommendations: string[];
  stability: number;
  predictability: number;
}

export interface CoherenceFactor {
  name: string;
  value: number;
  impact: 'low' | 'medium' | 'high';
  description: string;
}

export interface CoherenceThreat {
  type: 'decoherence' | 'entanglement-loss' | 'phase-shift' | 'amplitude-damping';
  severity: 'low' | 'medium' | 'high' | 'critical';
  probability: number;
  impact: number;
  mitigation: string;
}

export interface OptimizationResult {
  optimized: boolean;
  improvements: string[];
  newCoherence: CoherenceScore;
  recommendations: string[];
  confidence: number;
}

export interface DecoherencePrediction {
  predictedCoherence: CoherenceScore;
  timeToDecoherence: number;
  confidence: number;
  factors: string[];
  mitigation: string[];
}

export interface CoherenceReport {
  summary: string;
  currentCoherence: CoherenceScore;
  trend: 'improving' | 'stable' | 'declining';
  recommendations: string[];
  risks: string[];
  opportunities: string[];
  generated: number;
}

// Type Guards
export function isQuantumState(obj: unknown): obj is QuantumState {
  return typeof obj === 'object' && obj !== null && 
         (obj as QuantumState).type === 'quantum-state';
}

export function isQuantumGate(obj: unknown): obj is QuantumGate {
  return typeof obj === 'object' && obj !== null && 
         (obj as QuantumGate).type === 'quantum-gate';
}

export function isQuantumCircuit(obj: unknown): obj is QuantumCircuit {
  return typeof obj === 'object' && obj !== null && 
         (obj as QuantumCircuit).type === 'quantum-circuit';
}

export function isQuantumMeasurement(obj: unknown): obj is QuantumMeasurement {
  return typeof obj === 'object' && obj !== null && 
         (obj as QuantumMeasurement).type === 'quantum-measurement';
}

export function isQuantumDistortion(obj: unknown): obj is QuantumDistortion {
  return typeof obj === 'object' && obj !== null && 
         (obj as QuantumDistortion).type === 'quantum-distortion';
}

export function isQuantumProtection(obj: unknown): obj is QuantumProtection {
  return typeof obj === 'object' && obj !== null && 
         (obj as QuantumProtection).type === 'quantum-protection';
}

export function isQuantumSystemStatus(obj: unknown): obj is QuantumSystemStatus {
  return typeof obj === 'object' && obj !== null && 
         (obj as QuantumSystemStatus).type === 'quantum-system-status';
}

export function isQuantumHallucination(obj: unknown): obj is QuantumHallucination {
  return typeof obj === 'object' && obj !== null && 
         (obj as QuantumHallucination).type === 'quantum-hallucination';
}

// Utility Functions
export function createQuantumState(
  id: string,
  amplitude: ComplexAmplitude,
  phase: number,
  probability: number,
  decoherenceRate: number
): QuantumState {
  return {
    id,
    type: 'quantum-state',
    timestamp: Date.now(),
    coherence: 1.0,
    amplitude,
    phase,
    probability,
    decoherenceRate,
    measurementBasis: 'computational',
    fidelity: 1.0,
    purity: 1.0,
    entropy: 0.0,
    superposition: probability > 0 && probability < 1
  };
}

export function createComplexAmplitude(real: number, imaginary: number): ComplexAmplitude {
  const magnitude = Math.sqrt(real * real + imaginary * imaginary);
  const phase = Math.atan2(imaginary, real);
  
  return {
    real,
    imaginary,
    magnitude,
    phase
  };
}

export function createQuantumGate(
  id: string,
  gateType: QuantumGateType,
  matrix: ComplexMatrix,
  targetQubits: number[],
  controlQubits?: number[]
): QuantumGate {
  return {
    id,
    type: 'quantum-gate',
    timestamp: Date.now(),
    coherence: 1.0,
    gateType,
    matrix,
    controlled: controlQubits !== undefined && controlQubits.length > 0,
    targetQubits,
    controlQubits,
    fidelity: 1.0,
    errorRate: 0.0,
    duration: 0.0
  };
}

export function createComplexMatrix(rows: number, cols: number, data: ComplexAmplitude[][]): ComplexMatrix {
  return {
    rows,
    cols,
    data
  };
}

// Export all types and utilities
export type {
  ComplexAmplitude,
  QuantumGateType,
  ComplexMatrix,
  MeasurementResult,
  DistortionType,
  ProtectionType,
  ProtectionParameters,
  HallucinationType,
  RealityField,
  QuantumMetrics,
  QuantumAlert,
  ProtectionConfiguration,
  ProtectionScan,
  ThreatNeutralization,
  ShieldActivation,
  EnergyConsumption,
  SystemEvent,
  SystemHealth,
  ShieldDiagnostic,
  RealityFieldDiagnostics,
  RealityAnomaly,
  PerformanceMetrics,
  OptimizationRecord,
  OptimizationPerformance,
  CoherenceAnalysis,
  CoherenceFactor,
  CoherenceThreat,
  OptimizationResult,
  DecoherencePrediction,
  CoherenceReport
};