/**
 * Type Utilities for Coherent Programming
 * 
 * This module provides utility functions and type guards for maintaining
 * type safety and coherence across the entire application.
 */

import { 
  CoherentBase, 
  QuantumState, 
  NeuralNetwork, 
  CoherenceSystem, 
  SystemEvent,
  ApiResponse,
  ValidationResult,
  ValidationRule,
  CoherentError,
  QuantumCoherenceError,
  NeuralCoherenceError,
  CoherenceScore,
  CoherenceMetrics
} from '@/types';

// Type Safety Utilities
export class TypeSafety {
  /**
   * Ensures a value is not null or undefined
   */
  static nonNull<T>(value: T | null | undefined, message: string = 'Value cannot be null or undefined'): T {
    if (value === null || value === undefined) {
      throw new Error(message);
    }
    return value;
  }

  /**
   * Safe type assertion with runtime validation
   */
  static assertType<T>(value: unknown, typeGuard: (value: unknown) => value is T, message: string): T {
    if (!typeGuard(value)) {
      throw new Error(message);
    }
    return value;
  }

  /**
   * Safe property access with optional chaining and type checking
   */
  static safeGet<T, K extends keyof T>(obj: T | null | undefined, key: K): T[K] | undefined {
    return obj?.[key];
  }

  /**
   * Safe array access with bounds checking
   */
  static safeGetAt<T>(array: T[] | null | undefined, index: number): T | undefined {
    if (!array || index < 0 || index >= array.length) {
      return undefined;
    }
    return array[index];
  }

  /**
   * Ensures a string is not empty
   */
  static nonEmptyString(value: string | null | undefined, message: string = 'String cannot be empty'): string {
    if (!value || value.trim() === '') {
      throw new Error(message);
    }
    return value;
  }

  /**
   * Ensures a number is within a valid range
   */
  static inRange(value: number, min: number, max: number, message: string = `Value must be between ${min} and ${max}`): number {
    if (value < min || value > max) {
      throw new Error(message);
    }
    return value;
  }

  /**
   * Ensures a number is positive
   */
  static positiveNumber(value: number, message: string = 'Value must be positive'): number {
    if (value <= 0) {
      throw new Error(message);
    }
    return value;
  }

  /**
   * Ensures a number is non-negative
   */
  static nonNegativeNumber(value: number, message: string = 'Value must be non-negative'): number {
    if (value < 0) {
      throw new Error(message);
    }
    return value;
  }
}

// Enhanced Type Guards
export class TypeGuards {
  /**
   * Checks if a value is a valid CoherentBase
   */
  static isCoherentBase(obj: unknown): obj is CoherentBase {
    return typeof obj === 'object' && obj !== null &&
           typeof (obj as CoherentBase).id === 'string' &&
           typeof (obj as CoherentBase).timestamp === 'number' &&
           typeof (obj as CoherentBase).coherence === 'number';
  }

  /**
   * Checks if a value is a valid number (not NaN)
   */
  static isValidNumber(value: unknown): value is number {
    return typeof value === 'number' && !isNaN(value);
  }

  /**
   * Checks if a value is a valid integer
   */
  static isInteger(value: unknown): value is number {
    return typeof value === 'number' && Number.isInteger(value);
  }

  /**
   * Checks if a value is a valid positive number
   */
  static isPositiveNumber(value: unknown): value is number {
    return TypeGuards.isValidNumber(value) && value > 0;
  }

  /**
   * Checks if a value is a valid percentage (0-100)
   */
  static isPercentage(value: unknown): value is number {
    return TypeGuards.isValidNumber(value) && value >= 0 && value <= 100;
  }

  /**
   * Checks if a value is a valid probability (0-1)
   */
  static isProbability(value: unknown): value is number {
    return TypeGuards.isValidNumber(value) && value >= 0 && value <= 1;
  }

  /**
   * Checks if a value is a valid non-empty string
   */
  static isNonEmptyString(value: unknown): value is string {
    return typeof value === 'string' && value.trim().length > 0;
  }

  /**
   * Checks if a value is a valid array
   */
  static isArray<T = unknown>(value: unknown, itemGuard?: (item: unknown) => item is T): value is T[] {
    if (!Array.isArray(value)) {
      return false;
    }
    
    if (itemGuard) {
      return value.every(itemGuard);
    }
    
    return true;
  }

  /**
   * Checks if a value is a valid non-empty array
   */
  static isNonEmptyArray<T = unknown>(value: unknown, itemGuard?: (item: unknown) => item is T): value is T[] {
    return TypeGuards.isArray(value, itemGuard) && value.length > 0;
  }

  /**
   * Checks if a value is a valid object
   */
  static isObject<T = Record<string, unknown>>(value: unknown): value is T {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
  }

  /**
   * Checks if a value is a valid Date object
   */
  static isDate(value: unknown): value is Date {
    return value instanceof Date && !isNaN(value.getTime());
  }

  /**
   * Checks if a value is a valid function
   */
  static isFunction<T extends (...args: unknown[]) => unknown>(value: unknown): value is T {
    return typeof value === 'function';
  }

  /**
   * Checks if a value is a valid Promise
   */
  static isPromise<T = unknown>(value: unknown): value is Promise<T> {
    return value instanceof Promise;
  }

  /**
   * Checks if a value is a valid boolean
   */
  static isBoolean(value: unknown): value is boolean {
    return typeof value === 'boolean';
  }

  /**
   * Checks if a value is null or undefined
   */
  static isNullOrUndefined(value: unknown): value is null | undefined {
    return value === null || value === undefined;
  }

  /**
   * Checks if a value is a valid URL
   */
  static isURL(value: unknown): value is string {
    if (typeof value !== 'string') {
      return false;
    }
    
    try {
      new URL(value);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Checks if a value is a valid email address
   */
  static isEmail(value: unknown): value is string {
    if (typeof value !== 'string') {
      return false;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(value);
  }
}

// Validation System
export class ValidationSystem {
  /**
   * Creates a validation rule
   */
  static createRule<T>(
    field: string,
    type: ValidationRule<T>['type'],
    validator: ValidationRule<T>['validator'],
    message: string,
    severity: ValidationRule<T>['severity'] = 'error'
  ): ValidationRule<T> {
    return { field, type, validator, message, severity };
  }

  /**
   * Validates a value against a set of rules
   */
  static validate<T>(value: T, rules: ValidationRule<T>[]): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];
    let score = 100;

    for (const rule of rules) {
      if (!rule.validator(value)) {
        if (rule.severity === 'error') {
          errors.push(rule.message);
          score -= 20;
        } else {
          warnings.push(rule.message);
          score -= 5;
        }
      }
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
      score: Math.max(0, score),
      details: { value, rules: rules.length }
    };
  }

  /**
   * Common validation rules
   */
  static rules = {
    required: <T>(field: string) => ValidationSystem.createRule<T>(
      field,
      'required',
      (value) => !TypeGuards.isNullOrUndefined(value),
      `${field} is required`
    ),

    string: (field: string) => ValidationSystem.createRule(
      field,
      'type',
      (value: unknown) => typeof value === 'string',
      `${field} must be a string`
    ),

    number: (field: string) => ValidationSystem.createRule(
      field,
      'type',
      (value: unknown) => TypeGuards.isValidNumber(value),
      `${field} must be a number`
    ),

    boolean: (field: string) => ValidationSystem.createRule(
      field,
      'type',
      (value: unknown) => TypeGuards.isBoolean(value),
      `${field} must be a boolean`
    ),

    array: (field: string) => ValidationSystem.createRule(
      field,
      'type',
      (value: unknown) => Array.isArray(value),
      `${field} must be an array`
    ),

    object: (field: string) => ValidationSystem.createRule(
      field,
      'type',
      (value: unknown) => TypeGuards.isObject(value),
      `${field} must be an object`
    ),

    min: (field: string, min: number) => ValidationSystem.createRule(
      field,
      'range',
      (value: unknown) => TypeGuards.isValidNumber(value) && value >= min,
      `${field} must be at least ${min}`
    ),

    max: (field: string, max: number) => ValidationSystem.createRule(
      field,
      'range',
      (value: unknown) => TypeGuards.isValidNumber(value) && value <= max,
      `${field} must be at most ${max}`
    ),

    range: (field: string, min: number, max: number) => ValidationSystem.createRule(
      field,
      'range',
      (value: unknown) => TypeGuards.isValidNumber(value) && value >= min && value <= max,
      `${field} must be between ${min} and ${max}`
    ),

    minLength: (field: string, min: number) => ValidationSystem.createRule(
      field,
      'range',
      (value: unknown) => typeof value === 'string' && value.length >= min,
      `${field} must be at least ${min} characters long`
    ),

    maxLength: (field: string, max: number) => ValidationSystem.createRule(
      field,
      'range',
      (value: unknown) => typeof value === 'string' && value.length <= max,
      `${field} must be at most ${max} characters long`
    ),

    pattern: (field: string, regex: RegExp, message?: string) => ValidationSystem.createRule(
      field,
      'pattern',
      (value: unknown) => typeof value === 'string' && regex.test(value),
      message || `${field} format is invalid`
    ),

    email: (field: string) => ValidationSystem.createRule(
      field,
      'pattern',
      (value: unknown) => TypeGuards.isEmail(value),
      `${field} must be a valid email address`
    ),

    url: (field: string) => ValidationSystem.createRule(
      field,
      'pattern',
      (value: unknown) => TypeGuards.isURL(value),
      `${field} must be a valid URL`
    )
  };
}

// Coherence Calculation Utilities
export class CoherenceUtils {
  /**
   * Calculates a coherence score from metrics
   */
  static calculateCoherence(metrics: CoherenceMetrics): CoherenceScore {
    const weights = {
      systemCoherence: 0.3,
      quantumCoherence: 0.25,
      neuralCoherence: 0.2,
      temporalCoherence: 0.1,
      spatialCoherence: 0.1,
      energyEfficiency: 0.05
    };

    const weightedSum = 
      metrics.systemCoherence * weights.systemCoherence +
      metrics.quantumCoherence * weights.quantumCoherence +
      metrics.neuralCoherence * weights.neuralCoherence +
      metrics.temporalCoherence * weights.temporalCoherence +
      metrics.spatialCoherence * weights.spatialCoherence +
      metrics.energyEfficiency * weights.energyEfficiency;

    return weightedSum as CoherenceScore;
  }

  /**
   * Normalizes a coherence score to 0-1 range
   */
  static normalizeCoherence(score: number): CoherenceScore {
    return Math.max(0, Math.min(1, score)) as CoherenceScore;
  }

  /**
   * Checks if coherence is above threshold
   */
  static isCoherent(coherence: CoherenceScore, threshold: number = 0.7): boolean {
    return coherence >= threshold;
  }

  /**
   * Gets coherence level description
   */
  static getCoherenceLevel(coherence: CoherenceScore): string {
    if (coherence >= 0.9) return 'Excellent';
    if (coherence >= 0.8) return 'Good';
    if (coherence >= 0.7) return 'Fair';
    if (coherence >= 0.6) return 'Poor';
    return 'Critical';
  }

  /**
   * Generates coherence improvement recommendations
   */
  static generateRecommendations(metrics: CoherenceMetrics): string[] {
    const recommendations: string[] = [];

    if (metrics.systemCoherence < 0.8) {
      recommendations.push('Improve system coherence through optimization');
    }

    if (metrics.quantumCoherence < 0.7) {
      recommendations.push('Enhance quantum coherence with error correction');
    }

    if (metrics.neuralCoherence < 0.75) {
      recommendations.push('Optimize neural network parameters');
    }

    if (metrics.energyEfficiency < 0.6) {
      recommendations.push('Improve energy efficiency through resource management');
    }

    if (metrics.errorRate > 0.1) {
      recommendations.push('Reduce error rate with better error handling');
    }

    return recommendations;
  }
}

// Error Handling Utilities
export class ErrorUtils {
  /**
   * Creates a coherent error with proper typing
   */
  static createError(
    message: string,
    type: CoherentError['type'] = 'system',
    severity: CoherentError['severity'] = 'medium',
    context?: Record<string, unknown>
  ): CoherentError {
    const error = new Error(message) as CoherentError;
    error.id = `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    error.type = type;
    error.severity = severity;
    error.timestamp = Date.now();
    error.context = context;
    error.recoverable = severity !== 'critical';
    
    return error;
  }

  /**
   * Creates a quantum coherence error
   */
  static createQuantumError(
    message: string,
    severity: QuantumCoherenceError['severity'] = 'medium',
    context?: Record<string, unknown>
  ): QuantumCoherenceError {
    return new QuantumCoherenceError(message, severity);
  }

  /**
   * Creates a neural coherence error
   */
  static createNeuralError(
    message: string,
    severity: NeuralCoherenceError['severity'] = 'medium',
    context?: Record<string, unknown>
  ): NeuralCoherenceError {
    return new NeuralCoherenceError(message, severity);
  }

  /**
   * Safely executes a function with error handling
   */
  static async safeExecute<T>(
    fn: () => Promise<T>,
    fallback: T,
    errorHandler?: (error: Error) => void
  ): Promise<T> {
    try {
      return await fn();
    } catch (error) {
      if (errorHandler) {
        errorHandler(error as Error);
      }
      return fallback;
    }
  }

  /**
   * Safely executes a synchronous function with error handling
   */
  static safeExecuteSync<T>(
    fn: () => T,
    fallback: T,
    errorHandler?: (error: Error) => void
  ): T {
    try {
      return fn();
    } catch (error) {
      if (errorHandler) {
        errorHandler(error as Error);
      }
      return fallback;
    }
  }
}

// API Response Utilities
export class ApiResponseUtils {
  /**
   * Creates a successful API response
   */
  static success<T>(data: T, message?: string): ApiResponse<T> {
    return {
      success: true,
      data,
      message,
      timestamp: Date.now(),
      requestId: `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };
  }

  /**
   * Creates an error API response
   */
  static error<T = never>(error: string, details?: Record<string, unknown>): ApiResponse<T> {
    return {
      success: false,
      error,
      timestamp: Date.now(),
      requestId: `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...details
    };
  }

  /**
   * Safely executes an API handler
   */
  static async safeHandler<T>(
    handler: () => Promise<T>,
    errorMessage: string = 'Internal server error'
  ): Promise<ApiResponse<T>> {
    try {
      const result = await handler();
      return ApiResponseUtils.success(result);
    } catch (error) {
      console.error('API handler error:', error);
      return ApiResponseUtils.error(errorMessage);
    }
  }
}

// Export all utilities
export {
  TypeSafety,
  TypeGuards,
  ValidationSystem,
  CoherenceUtils,
  ErrorUtils,
  ApiResponseUtils
};