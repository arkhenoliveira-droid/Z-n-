/**
 * Coherent Type System for Quantum Computing and Neural Networks
 * 
 * This type system provides comprehensive type definitions for maintaining
 * type coherence across quantum computing systems, neural networks, and
 * AI-powered applications.
 */

// Base types for coherent programming
export interface CoherentBase {
  id: string;
  timestamp: number;
  coherence: number;
  metadata?: Record<string, unknown>;
}

// Quantum Computing Types
export interface QuantumState extends CoherentBase {
  type: 'quantum-state';
  amplitude: ComplexNumber;
  phase: number;
  probability: number;
  entangledWith?: string[];
  superposition: boolean;
  decoherenceRate: number;
}

export interface ComplexNumber {
  real: number;
  imaginary: number;
  magnitude: number;
  angle: number;
}

export interface QuantumGate extends CoherentBase {
  type: 'quantum-gate';
  gateType: 'pauli-x' | 'pauli-y' | 'pauli-z' | 'hadamard' | 'cnot' | 'toffoli' | 'phase' | 'custom';
  matrix: ComplexNumber[][];
  controlled: boolean;
  targetQubits: number[];
  controlQubits?: number[];
}

export interface QuantumCircuit extends CoherentBase {
  type: 'quantum-circuit';
  qubits: number;
  gates: QuantumGate[];
  depth: number;
  fidelity: number;
  errorRate: number;
  optimizationLevel: number;
}

export interface QuantumMeasurement extends CoherentBase {
  type: 'quantum-measurement';
  circuitId: string;
  results: MeasurementResult[];
  expectation: number;
  variance: number;
  collapseTime: number;
  measurementBasis: 'computational' | 'hadamard' | 'custom';
}

export interface MeasurementResult {
  qubit: number;
  state: '0' | '1';
  probability: number;
  confidence: number;
}

// Neural Network Types
export interface NeuralNetwork extends CoherentBase {
  type: 'neural-network';
  architecture: 'feedforward' | 'convolutional' | 'recurrent' | 'transformer' | 'custom';
  layers: NeuralLayer[];
  parameters: number;
  activationFunction: 'relu' | 'sigmoid' | 'tanh' | 'softmax' | 'custom';
  learningRate: number;
  optimizer: 'sgd' | 'adam' | 'rmsprop' | 'custom';
  lossFunction: 'mse' | 'cross-entropy' | 'custom';
  accuracy: number;
  loss: number;
  epochs: number;
  batchSize: number;
}

export interface NeuralLayer extends CoherentBase {
  type: 'neural-layer';
  layerType: 'dense' | 'conv2d' | 'maxpool2d' | 'lstm' | 'attention' | 'custom';
  units: number;
  activation: string;
  weights: number[][];
  biases: number[];
  dropoutRate?: number;
  batchNorm?: boolean;
}

export interface TrainingData extends CoherentBase {
  type: 'training-data';
  inputs: number[][];
  outputs: number[][];
  size: number;
  inputShape: number[];
  outputShape: number[];
  normalized: boolean;
  splitRatio: {
    train: number;
    validation: number;
    test: number;
  };
}

// Coherence System Types
export interface CoherenceSystem extends CoherentBase {
  type: 'coherence-system';
  coherenceLevel: number;
  stability: number;
  resonance: number;
  entanglementStrength: number;
  quantumState: QuantumState;
  monitoringInterval: number;
  alerts: CoherenceAlert[];
  metrics: CoherenceMetrics;
}

export interface CoherenceAlert {
  id: string;
  type: 'warning' | 'error' | 'critical';
  message: string;
  timestamp: number;
  severity: number;
  resolved: boolean;
  resolution?: string;
}

export interface CoherenceMetrics {
  systemCoherence: number;
  quantumCoherence: number;
  neuralCoherence: number;
  temporalCoherence: number;
  spatialCoherence: number;
  energyEfficiency: number;
  errorRate: number;
  throughput: number;
  latency: number;
}

// API Response Types
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  timestamp: number;
  requestId: string;
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  pagination: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

export interface StreamResponse<T> extends ApiResponse<T> {
  stream: boolean;
  chunkSize?: number;
  totalChunks?: number;
}

// Settings Types
export interface SystemSettings {
  general: GeneralSettings;
  performance: PerformanceSettings;
  quantum: QuantumSettings;
  interface: InterfaceSettings;
  security: SecuritySettings;
  notifications: NotificationSettings;
}

export interface GeneralSettings {
  systemName: string;
  coherenceThreshold: number;
  autoUpdate: boolean;
  telemetryEnabled: boolean;
  debugMode: boolean;
}

export interface PerformanceSettings {
  maxMemoryUsage: number;
  cpuPriority: 'low' | 'normal' | 'high';
  cacheSize: number;
  compressionEnabled: boolean;
  parallelProcessing: boolean;
}

export interface QuantumSettings {
  quantumCoherence: number;
  entanglementStrength: number;
  superpositionStability: number;
  decoherenceRate: number;
  quantumAlgorithm: 'standard' | 'advanced' | 'experimental';
}

export interface InterfaceSettings {
  theme: 'light' | 'dark' | 'auto';
  language: 'en' | 'pt' | 'es';
  animations: boolean;
  compactMode: boolean;
  highContrast: boolean;
}

export interface SecuritySettings {
  encryptionLevel: 'standard' | 'enhanced' | 'maximum';
  twoFactorAuth: boolean;
  sessionTimeout: number;
  auditLogging: boolean;
  ipWhitelist: string[];
}

export interface NotificationSettings {
  emailNotifications: boolean;
  pushNotifications: boolean;
  systemAlerts: boolean;
  coherenceWarnings: boolean;
  updateNotifications: boolean;
}

// Validation Types
export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  score: number;
  details: Record<string, unknown>;
}

export interface ValidationRule<T = unknown> {
  field: string;
  type: 'required' | 'type' | 'range' | 'pattern' | 'custom';
  validator: (value: T) => boolean;
  message: string;
  severity: 'error' | 'warning';
}

// Event System Types
export interface SystemEvent extends CoherentBase {
  type: 'system-event';
  eventType: 'info' | 'warning' | 'error' | 'success';
  category: 'quantum' | 'neural' | 'system' | 'security' | 'performance';
  message: string;
  details: Record<string, unknown>;
  source: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
}

export interface EventHandler<T = unknown> {
  id: string;
  eventType: string;
  handler: (event: T) => void | Promise<void>;
  once?: boolean;
  priority?: number;
}

// Analytics Types
export interface AnalyticsData extends CoherentBase {
  type: 'analytics-data';
  metrics: AnalyticsMetrics;
  events: SystemEvent[];
  performance: PerformanceMetrics;
  usage: UsageMetrics;
  timeRange: {
    start: number;
    end: number;
  };
}

export interface AnalyticsMetrics {
  totalRequests: number;
  errorRate: number;
  averageResponseTime: number;
  throughput: number;
  uptime: number;
  memoryUsage: number;
  cpuUsage: number;
}

export interface PerformanceMetrics {
  quantumOperations: number;
  neuralInferences: number;
  coherenceLevel: number;
  energyEfficiency: number;
  errorRate: number;
  optimizationScore: number;
}

export interface UsageMetrics {
  activeUsers: number;
  sessionDuration: number;
  featureUsage: Record<string, number>;
  peakUsage: number;
  resourceUtilization: number;
}

// Utility Types
export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;

export type OptionalFields<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export type AsyncFunction<T = unknown> = (...args: unknown[]) => Promise<T>;

export type EventHandlerFunction<T = unknown> = (event: T) => void | Promise<void>;

export type ValidatorFunction<T = unknown> = (value: T) => boolean;

export type CoherenceScore = number & { readonly __coherenceScore: unique symbol };

// Type Guards
export function isQuantumState(obj: unknown): obj is QuantumState {
  return typeof obj === 'object' && obj !== null && 
         (obj as QuantumState).type === 'quantum-state';
}

export function isNeuralNetwork(obj: unknown): obj is NeuralNetwork {
  return typeof obj === 'object' && obj !== null && 
         (obj as NeuralNetwork).type === 'neural-network';
}

export function isCoherenceSystem(obj: unknown): obj is CoherenceSystem {
  return typeof obj === 'object' && obj !== null && 
         (obj as CoherenceSystem).type === 'coherence-system';
}

export function isSystemEvent(obj: unknown): obj is SystemEvent {
  return typeof obj === 'object' && obj !== null && 
         (obj as SystemEvent).type === 'system-event';
}

export function isApiResponse<T = unknown>(obj: unknown): obj is ApiResponse<T> {
  return typeof obj === 'object' && obj !== null && 
         'success' in obj && 'timestamp' in obj && 'requestId' in obj;
}

// Coherence Utilities
export interface CoherenceCalculator {
  calculateSystemCoherence(metrics: CoherenceMetrics): CoherenceScore;
  calculateQuantumCoherence(state: QuantumState): CoherenceScore;
  calculateNeuralCoherence(network: NeuralNetwork): CoherenceScore;
  optimizeCoherence(target: CoherenceScore): OptimizationResult;
}

export interface OptimizationResult {
  optimized: boolean;
  improvements: string[];
  newCoherence: CoherenceScore;
  recommendations: string[];
}

// Error Types
export interface CoherentError extends Error {
  id: string;
  type: 'quantum' | 'neural' | 'system' | 'validation' | 'network';
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: number;
  context?: Record<string, unknown>;
  recoverable: boolean;
  recovery?: () => Promise<void>;
}

export class QuantumCoherenceError extends Error implements CoherentError {
  id: string;
  type: 'quantum' = 'quantum';
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: number;
  context?: Record<string, unknown>;
  recoverable: boolean;
  recovery?: () => Promise<void>;

  constructor(message: string, severity: 'low' | 'medium' | 'high' | 'critical' = 'medium') {
    super(message);
    this.name = 'QuantumCoherenceError';
    this.id = `quantum_error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    this.severity = severity;
    this.timestamp = Date.now();
    this.recoverable = severity !== 'critical';
  }
}

export class NeuralCoherenceError extends Error implements CoherentError {
  id: string;
  type: 'neural' = 'neural';
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: number;
  context?: Record<string, unknown>;
  recoverable: boolean;
  recovery?: () => Promise<void>;

  constructor(message: string, severity: 'low' | 'medium' | 'high' | 'critical' = 'medium') {
    super(message);
    this.name = 'NeuralCoherenceError';
    this.id = `neural_error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    this.severity = severity;
    this.timestamp = Date.now();
    this.recoverable = severity !== 'critical';
  }
}

// Configuration Types
export interface SystemConfiguration {
  environment: 'development' | 'staging' | 'production';
  version: string;
  features: Record<string, boolean>;
  limits: {
    maxMemory: number;
    maxCpu: number;
    maxConnections: number;
    maxRequests: number;
  };
  integrations: {
    database: boolean;
    cache: boolean;
    queue: boolean;
    monitoring: boolean;
  };
}

// WebSocket Types
export interface WebSocketMessage {
  id: string;
  type: string;
  payload: unknown;
  timestamp: number;
  source: string;
  target?: string;
}

export interface WebSocketClient {
  id: string;
  connected: boolean;
  lastPing: number;
  subscriptions: string[];
  metadata: Record<string, unknown>;
}

// Database Types
export interface DatabaseEntity extends CoherentBase {
  type: 'database-entity';
  collection: string;
  data: Record<string, unknown>;
  version: number;
  createdAt: number;
  updatedAt: number;
  createdBy?: string;
  updatedBy?: string;
}

export interface QueryOptions {
  filter?: Record<string, unknown>;
  sort?: Record<string, 1 | -1>;
  limit?: number;
  skip?: number;
  projection?: Record<string, 1 | 0>;
}

export interface QueryResult<T = unknown> {
  success: boolean;
  data?: T[];
  total?: number;
  error?: string;
  executionTime: number;
  cached: boolean;
}

// Export all types for easy importing
export type {
  ComplexNumber,
  MeasurementResult,
  NeuralLayer,
  TrainingData,
  CoherenceAlert,
  CoherenceMetrics,
  ValidationResult,
  ValidationRule,
  AnalyticsMetrics,
  PerformanceMetrics,
  UsageMetrics,
  AsyncFunction,
  EventHandlerFunction,
  ValidatorFunction,
  WebSocketMessage,
  WebSocketClient,
  QueryOptions,
  QueryResult,
  DeepPartial,
  RequiredFields,
  OptionalFields
};