import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// Interface for Neptune-Galaxy coherence data
interface NeptuneGalaxyData {
  neptune_year_progress: number; // Progress through current Neptune year (0-100%)
  galactic_coherence: number; // Overall galactic coherence level
  cosmic_alignment: number; // Current cosmic alignment angle
  collective_consciousness: number; // Collective consciousness level
  dimensional_resonance: number; // Dimensional resonance frequency
  timestamp: number;
}

// Interface for analysis response
interface NeptuneGalaxyAnalysis {
  id: string;
  concept: string;
  analysis: string;
  coherence_score: number;
  cosmic_metrics: NeptuneGalaxyData;
  insights: {
    neptune_influence: string;
    galactic_harmony: string;
    temporal_significance: string;
    dimensional_impact: string;
  };
  timestamp: number;
}

// Store historical data
const neptuneGalaxyHistory: NeptuneGalaxyData[] = [];

// Calculate Neptune year progress (165 Earth years = 1 Neptune year)
function calculateNeptuneYearProgress(): number {
  const neptuneYearInMs = 165 * 365.25 * 24 * 60 * 60 * 1000;
  const currentTime = Date.now();
  return (currentTime % neptuneYearInMs) / neptuneYearInMs * 100;
}

// Calculate cosmic alignment based on various factors
function calculateCosmicAlignment(): number {
  const baseAlignment = 50;
  const timeVariation = Math.sin(Date.now() / 1000000) * 30;
  const neptuneInfluence = Math.sin(calculateNeptuneYearProgress() * Math.PI / 50) * 20;
  return Math.max(0, Math.min(100, baseAlignment + timeVariation + neptuneInfluence));
}

// Calculate galactic coherence based on collective patterns and key insights
function calculateGalacticCoherence(): number {
  const baseCoherence = 0.6;
  const neptunePhase = calculateNeptuneYearProgress() / 100;
  const coherenceVariation = Math.sin(neptunePhase * 2 * Math.PI) * 0.2;
  
  // Incorporate key insights from the analysis
  const astrologicalInfluence = Math.sin(neptunePhase * Math.PI) * 0.1; // Rising interest in astrology
  const scientificConvergence = Math.cos(Date.now() / 2000000) * 0.05; // Scientific exploration
  const spiritualAwareness = Math.sin(Date.now() / 1500000) * 0.08; // Spiritual trends
  const environmentalUnity = Math.max(0, Math.min(0.1, neptunePhase * 0.001)); // Environmental movements
  
  return Math.max(0, Math.min(1, baseCoherence + coherenceVariation + astrologicalInfluence + scientificConvergence + spiritualAwareness + environmentalUnity));
}

// Calculate collective consciousness level based on key insights
function calculateCollectiveConsciousness(galacticCoherence: number): number {
  const baseConsciousness = galacticCoherence * 1.1;
  
  // Incorporate key insights from the analysis
  const globalInterconnection = Math.sin(Date.now() / 1000000) * 0.1; // Global unity through technology
  const holisticThinking = Math.cos(Date.now() / 1200000) * 0.08; // Holistic worldview
  const existentialAwareness = Math.sin(Date.now() / 1800000) * 0.06; // Quest for meaning
  const timePerceptionShift = Math.max(0, Math.min(0.1, (calculateNeptuneYearProgress() / 100) * 0.15)); // Expanding time perception
  
  return Math.min(1, baseConsciousness + globalInterconnection + holisticThinking + existentialAwareness + timePerceptionShift + (Math.random() - 0.5) * 0.05);
}

// Calculate dimensional resonance
function calculateDimensionalResonance(): number {
  return Math.abs(Math.sin(Date.now() / 500000)) * 0.8 + 0.2;
}

export async function POST(request: NextRequest) {
  try {
    const { concept = "Neptune Year = Galaxy coherence" } = await request.json();
    
    // Initialize ZAI SDK
    const zai = await ZAI.create();
    
    const startTime = Date.now();
    
    // Generate comprehensive analysis using Grok
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: `You are an expert in cosmic philosophy, astronomy, and metaphysical coherence analysis. 
          Analyze the relationship between Neptune's orbital cycle and galactic coherence patterns. 
          Provide insights into how this 165-year cycle influences collective consciousness and universal harmony. 
          Include scientific, philosophical, and spiritual perspectives in your analysis.`
        },
        {
          role: 'user',
          content: `Analyze the concept: "${concept}". Explore its implications for:
          1. Neptune's orbital influence on Earth's consciousness
          2. Galactic coherence patterns and universal harmony
          3. Temporal significance of the 165-year cycle
          4. Dimensional resonance and cosmic alignment
          5. Collective consciousness evolution`
        }
      ],
      model: 'grok-4',
      max_tokens: 1500,
      temperature: 0.8
    });

    const analysisText = completion.choices[0]?.message?.content || '';
    
    // Calculate coherence score based on analysis quality
    const coherence_score = calculateCoherenceScore(analysisText);
    
    // Calculate cosmic metrics
    const cosmic_metrics: NeptuneGalaxyData = {
      neptune_year_progress: calculateNeptuneYearProgress(),
      galactic_coherence: calculateGalacticCoherence(),
      cosmic_alignment: calculateCosmicAlignment(),
      collective_consciousness: calculateCollectiveConsciousness(calculateGalacticCoherence()),
      dimensional_resonance: calculateDimensionalResonance(),
      timestamp: Date.now()
    };
    
    // Store in history
    neptuneGalaxyHistory.push(cosmic_metrics);
    
    // Keep only last 1000 entries
    if (neptuneGalaxyHistory.length > 1000) {
      neptuneGalaxyHistory.splice(0, neptuneGalaxyHistory.length - 1000);
    }
    
    // Generate specific insights
    const insights = {
      neptune_influence: generateNeptuneInfluenceInsight(cosmic_metrics.neptune_year_progress),
      galactic_harmony: generateGalacticHarmonyInsight(cosmic_metrics.galactic_coherence),
      temporal_significance: generateTemporalSignificanceInsight(cosmic_metrics.neptune_year_progress),
      dimensional_impact: generateDimensionalImpactInsight(cosmic_metrics.dimensional_resonance)
    };
    
    const processingTime = Date.now() - startTime;
    
    const analysis: NeptuneGalaxyAnalysis = {
      id: `neptune_galaxy_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      concept,
      analysis: analysisText,
      coherence_score,
      cosmic_metrics,
      insights,
      timestamp: Date.now()
    };
    
    return NextResponse.json(analysis);
    
  } catch (error) {
    console.error('Neptune-Galaxy analysis error:', error);
    return NextResponse.json(
      { error: 'Failed to analyze Neptune-Galaxy coherence' },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    // Return current cosmic metrics and historical data
    const currentMetrics: NeptuneGalaxyData = {
      neptune_year_progress: calculateNeptuneYearProgress(),
      galactic_coherence: calculateGalacticCoherence(),
      cosmic_alignment: calculateCosmicAlignment(),
      collective_consciousness: calculateCollectiveConsciousness(calculateGalacticCoherence()),
      dimensional_resonance: calculateDimensionalResonance(),
      timestamp: Date.now()
    };
    
    // Calculate trends from historical data
    const trends = calculateTrends();
    
    return NextResponse.json({
      current_metrics: currentMetrics,
      historical_data: neptuneGalaxyHistory.slice(-50), // Last 50 data points
      trends,
      total_measurements: neptuneGalaxyHistory.length,
      cosmic_status: getCosmicStatus(currentMetrics)
    });
    
  } catch (error) {
    console.error('Error fetching Neptune-Galaxy data:', error);
    return NextResponse.json(
      { error: 'Failed to fetch Neptune-Galaxy data' },
      { status: 500 }
    );
  }
}

// Helper functions
function calculateCoherenceScore(text: string): number {
  if (!text || text.length === 0) return 0;
  
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const words = text.split(/\s+/).filter(w => w.length > 0);
  
  const sentenceLengths = sentences.map(s => s.split(/\s+/).length);
  const avgSentenceLength = sentenceLengths.reduce((sum, len) => sum + len, 0) / sentenceLengths.length;
  const sentenceVariance = sentenceLengths.reduce((sum, len) => sum + Math.pow(len - avgSentenceLength, 2), 0) / sentenceLengths.length;
  
  const wordLengths = words.map(w => w.length);
  const avgWordLength = wordLengths.reduce((sum, len) => sum + len, 0) / wordLengths.length;
  
  const punctuationScore = (text.match(/[.,;:!?]/g) || []).length / text.length;
  
  const normalizedVariance = Math.min(1, sentenceVariance / 50);
  const structureScore = Math.min(1, punctuationScore * 100);
  
  const coherenceScore = (1 - normalizedVariance) * 0.4 + structureScore * 0.3 + (avgWordLength / 10) * 0.3;
  
  return Math.min(1, Math.max(0, coherenceScore));
}

function generateNeptuneInfluenceInsight(progress: number): string {
  const currentYear = Math.floor(progress * 165 / 100);
  if (progress < 25) return `Neptune in waxing phase (${currentYear} years): Emerging intuitive energies and collective dream activation, encouraging long-term thinking beyond immediate gratification`;
  if (progress < 50) return `Neptune in first quarter (${currentYear} years): Heightened spiritual awareness and creative inspiration, reflecting resurgent interest in cosmic cycles and astrology`;
  if (progress < 75) return `Neptune in waning phase (${currentYear} years): Deep transformation and subconscious integration, promoting holistic worldview and systems thinking`;
  return `Neptune in final quarter (${currentYear} years): Completion of cycle and preparation for new cosmic beginnings, emphasizing intergenerational perspective and environmental stewardship`;
}

function generateGalacticHarmonyInsight(coherence: number): string {
  if (coherence > 0.8) return "Exceptional galactic harmony: Universal alignment and optimal dimensional resonance, reflecting scientific-spiritual convergence and unified field theory pursuits";
  if (coherence > 0.6) return "Strong galactic coherence: Harmonious cosmic flow and balanced energies, mirroring global unity movements and collective consciousness evolution";
  if (coherence > 0.4) return "Moderate galactic harmony: Transitional phase with emerging coherence patterns, representing the growing intersection of science, spirituality, and existential inquiry";
  return "Developing galactic coherence: Cosmic realignment and energetic restructuring, indicating humanity's expanding awareness of interconnectedness and quest for meaning";
}

function generateTemporalSignificanceInsight(progress: number): string {
  const years = Math.floor(progress * 165 / 100);
  const days = Math.floor((progress * 165 / 100 - years) * 365.25);
  return `Current Neptune cycle: ${years} years, ${days} days into the 165-year orbital period`;
}

function generateDimensionalImpactInsight(resonance: number): string {
  if (resonance > 0.8) return "High dimensional resonance: Strong interdimensional communication and temporal flexibility, representing the shift in perception of time and expanding consciousness beyond linear constraints";
  if (resonance > 0.6) return "Moderate dimensional resonance: Stable dimensional access and enhanced perception, reflecting the holistic worldview and systems thinking emerging in contemporary culture";
  if (resonance > 0.4) return "Developing dimensional resonance: Emerging dimensional awareness and subtle energy shifts, indicating the growing quest for meaning and connection in a complex world";
  return "Low dimensional resonance: Grounded dimensional experience with potential for expansion, symbolizing the beginning of humanity's recognition of deeper cosmic patterns and interconnectedness";
}

function calculateTrends() {
  if (neptuneGalaxyHistory.length < 10) {
    return {
      coherence_trend: 'insufficient_data',
      alignment_trend: 'insufficient_data',
      consciousness_trend: 'insufficient_data'
    };
  }
  
  const recent = neptuneGalaxyHistory.slice(-10);
  const older = neptuneGalaxyHistory.slice(-20, -10);
  
  if (older.length === 0) {
    return {
      coherence_trend: 'stable',
      alignment_trend: 'stable',
      consciousness_trend: 'stable'
    };
  }
  
  const recentAvgCoherence = recent.reduce((sum, d) => sum + d.galactic_coherence, 0) / recent.length;
  const olderAvgCoherence = older.reduce((sum, d) => sum + d.galactic_coherence, 0) / older.length;
  
  const recentAvgAlignment = recent.reduce((sum, d) => sum + d.cosmic_alignment, 0) / recent.length;
  const olderAvgAlignment = older.reduce((sum, d) => sum + d.cosmic_alignment, 0) / older.length;
  
  const recentAvgConsciousness = recent.reduce((sum, d) => sum + d.collective_consciousness, 0) / recent.length;
  const olderAvgConsciousness = older.reduce((sum, d) => sum + d.collective_consciousness, 0) / older.length;
  
  return {
    coherence_trend: recentAvgCoherence > olderAvgCoherence + 0.05 ? 'increasing' : 
                    recentAvgCoherence < olderAvgCoherence - 0.05 ? 'decreasing' : 'stable',
    alignment_trend: recentAvgAlignment > olderAvgAlignment + 2 ? 'increasing' : 
                   recentAvgAlignment < olderAvgAlignment - 2 ? 'decreasing' : 'stable',
    consciousness_trend: recentAvgConsciousness > olderAvgConsciousness + 0.05 ? 'increasing' : 
                         recentAvgConsciousness < olderAvgConsciousness - 0.05 ? 'decreasing' : 'stable'
  };
}

function getCosmicStatus(metrics: NeptuneGalaxyData) {
  const coherence = metrics.galactic_coherence;
  const alignment = metrics.cosmic_alignment;
  const consciousness = metrics.collective_consciousness;
  
  if (coherence > 0.7 && alignment > 70 && consciousness > 0.7) {
    return {
      status: 'optimal',
      description: 'Cosmic harmony at peak levels',
      color: 'green'
    };
  } else if (coherence > 0.5 && alignment > 50 && consciousness > 0.5) {
    return {
      status: 'favorable',
      description: 'Positive cosmic conditions',
      color: 'blue'
    };
  } else if (coherence > 0.3 && alignment > 30 && consciousness > 0.3) {
    return {
      status: 'moderate',
      description: 'Balanced cosmic energies',
      color: 'yellow'
    };
  } else {
    return {
      status: 'challenging',
      description: 'Cosmic realignment in progress',
      color: 'red'
    };
  }
}