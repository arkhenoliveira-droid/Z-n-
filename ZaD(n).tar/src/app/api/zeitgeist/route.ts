import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// Interface for coherence vector
interface CoherenceVector {
  id: string;
  data: number[];
  timestamp: number;
  source: string;
  coherence_score: number;
}

// Interface for Zeitgeist analysis response
interface ZeitgeistAnalysis {
  id: string;
  prompt: string;
  response: string;
  embedding: number[];
  coherence_score: number;
  timestamp: number;
  metadata: {
    model: string;
    processing_time: number;
    source_confidence: number;
  };
}

// Interface for coherence curve data point
interface CoherenceCurvePoint {
  z_n: number; // Parameter (time, iteration, etc.)
  coherence: number;
  timestamp: number;
}

// Store coherence vectors in memory (in production, use a database)
const coherenceVectors: CoherenceVector[] = [];
const coherenceCurve: CoherenceCurvePoint[] = [];

export async function POST(request: NextRequest) {
  try {
    const { prompt, searchParameters = {} } = await request.json();
    
    if (!prompt) {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create();
    
    const startTime = Date.now();
    
    // Generate response using Grok
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a sophisticated AI assistant that analyzes and synthesizes information about current trends, cultural phenomena, and the collective consciousness (Zeitgeist). Provide coherent, well-structured insights that capture the essence of the topic in relation to contemporary reality.'
        },
        {
          role: 'user',
          content: `Analyze the following topic in the context of current Zeitgeist: ${prompt}`
        }
      ],
      model: 'grok-4',
      max_tokens: 1000,
      temperature: 0.7
    });

    const responseText = completion.choices[0]?.message?.content || '';
    
    // Generate a simple coherence score based on response characteristics
    const coherence_score = calculateCoherenceScore(responseText);
    
    // Create a simple embedding-like vector based on text characteristics
    const embedding = generateTextEmbedding(responseText);
    
    // Store coherence vector
    const vector: CoherenceVector = {
      id: `vector_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      data: embedding,
      timestamp: Date.now(),
      source: 'zeitgeist_analysis',
      coherence_score
    };
    
    coherenceVectors.push(vector);
    
    // Update coherence curve
    const curvePoint: CoherenceCurvePoint = {
      z_n: coherenceCurve.length + 1, // Using iteration count as Z(n)
      coherence: coherence_score,
      timestamp: Date.now()
    };
    
    coherenceCurve.push(curvePoint);
    
    // Keep only last 1000 points in memory
    if (coherenceCurve.length > 1000) {
      coherenceCurve.splice(0, coherenceCurve.length - 1000);
    }
    
    const processingTime = Date.now() - startTime;
    
    const analysis: ZeitgeistAnalysis = {
      id: `analysis_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      prompt,
      response: responseText,
      embedding,
      coherence_score,
      timestamp: Date.now(),
      metadata: {
        model: 'grok-4',
        processing_time: processingTime,
        source_confidence: Math.min(0.95, 0.7 + (coherence_score * 0.25))
      }
    };
    
    return NextResponse.json(analysis);
    
  } catch (error) {
    console.error('Zeitgeist analysis error:', error);
    return NextResponse.json(
      { error: 'Failed to analyze Zeitgeist data' },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    // Return current coherence curve data
    return NextResponse.json({
      coherence_curve: coherenceCurve,
      total_vectors: coherenceVectors.length,
      latest_coherence: coherenceCurve.length > 0 ? coherenceCurve[coherenceCurve.length - 1].coherence : 0,
      average_coherence: coherenceCurve.length > 0 
        ? coherenceCurve.reduce((sum, point) => sum + point.coherence, 0) / coherenceCurve.length 
        : 0
    });
  } catch (error) {
    console.error('Error fetching coherence data:', error);
    return NextResponse.json(
      { error: 'Failed to fetch coherence data' },
      { status: 500 }
    );
  }
}

// Helper function to calculate coherence score from text
function calculateCoherenceScore(text: string): number {
  if (!text || text.length === 0) return 0;
  
  // Calculate text-based coherence metrics
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const words = text.split(/\s+/).filter(w => w.length > 0);
  
  // Sentence length variance (coherent texts have consistent sentence lengths)
  const sentenceLengths = sentences.map(s => s.split(/\s+/).length);
  const avgSentenceLength = sentenceLengths.reduce((sum, len) => sum + len, 0) / sentenceLengths.length;
  const sentenceVariance = sentenceLengths.reduce((sum, len) => sum + Math.pow(len - avgSentenceLength, 2), 0) / sentenceLengths.length;
  
  // Word length diversity
  const wordLengths = words.map(w => w.length);
  const avgWordLength = wordLengths.reduce((sum, len) => sum + len, 0) / wordLengths.length;
  
  // Text structure score (based on punctuation and structure)
  const punctuationScore = (text.match(/[.,;:!?]/g) || []).length / text.length;
  
  // Normalize scores
  const normalizedVariance = Math.min(1, sentenceVariance / 50);
  const structureScore = Math.min(1, punctuationScore * 100);
  
  // Combine metrics for coherence score
  const coherenceScore = (1 - normalizedVariance) * 0.4 + structureScore * 0.3 + (avgWordLength / 10) * 0.3;
  
  return Math.min(1, Math.max(0, coherenceScore));
}

// Helper function to generate a simple embedding-like vector from text
function generateTextEmbedding(text: string): number[] {
  // Create a simple 10-dimensional vector based on text characteristics
  const words = text.toLowerCase().split(/\s+/);
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  
  return [
    Math.min(1, words.length / 100), // Text length
    Math.min(1, sentences.length / 20), // Sentence count
    Math.min(1, words.reduce((sum, w) => sum + w.length, 0) / words.length / 10), // Average word length
    Math.min(1, (text.match(/[aeiou]/g) || []).length / text.length * 10), // Vowel ratio
    Math.min(1, (text.match(/[bcdfghjklmnpqrstvwxyz]/g) || []).length / text.length * 10), // Consonant ratio
    Math.min(1, (text.match(/[.,;:!?]/g) || []).length / text.length * 50), // Punctuation density
    Math.min(1, (text.match(/\b(the|and|or|but|in|on|at|to|for|of|with|by)\b/gi) || []).length / words.length * 10), // Common word ratio
    Math.min(1, (text.match(/\b(is|are|was|were|be|been|being)\b/gi) || []).length / words.length * 20), // Verb ratio
    Math.min(1, (text.match(/\b(a|an|the)\b/gi) || []).length / words.length * 10), // Article ratio
    Math.min(1, (text.match(/[A-Z]/g) || []).length / text.length * 20) // Capital letter ratio
  ];
}