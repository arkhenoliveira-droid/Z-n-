import ZeitgeistDashboard from '@/components/zeitgeist-dashboard';

export default function Home() {
  return <ZeitgeistDashboard />;
}