'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter } from 'recharts';
import { 
  Brain, 
  Zap, 
  Network, 
  Target, 
  TrendingUp, 
  Activity,
  RefreshCw,
  BarChart3,
  Settings,
  Play,
  Pause,
  AlertCircle,
  CheckCircle,
  Globe,
  Star,
  Moon,
  Waves
} from 'lucide-react';

interface NeptuneGalaxyAnalysis {
  id: string;
  prompt: string;
  response: string;
  embedding: number[];
  coherence_score: number;
  timestamp: number;
  metadata: {
    model: string;
    processing_time: number;
    source_confidence: number;
  };
}

interface CoherenceDataPoint {
  z_n: number;
  coherence: number;
  timestamp: number;
  galactic_alignment: number;
  neptune_position: number;
}

interface GalaxyMetrics {
  galactic_coherence: number;
  neptune_year_progress: number;
  cosmic_alignment: number;
  collective_consciousness: number;
  dimensional_resonance: number;
}

export default function NeptuneGalaxyCoherence() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<NeptuneGalaxyAnalysis | null>(null);
  const [coherenceData, setCoherenceData] = useState<CoherenceDataPoint[]>([]);
  const [galaxyMetrics, setGalaxyMetrics] = useState<GalaxyMetrics | null>(null);
  const [isRealTime, setIsRealTime] = useState(false);
  const [realTimeInterval, setRealTimeInterval] = useState<NodeJS.Timeout | null>(null);

  // Initialize with Neptune Year analysis
  useEffect(() => {
    analyzeNeptuneGalaxyCoherence();
    fetchGalaxyMetrics();
  }, []);

  // Handle real-time updates
  useEffect(() => {
    if (isRealTime) {
      const interval = setInterval(() => {
        fetchGalaxyMetrics();
      }, 10000); // Update every 10 seconds for cosmic data
      setRealTimeInterval(interval);
    } else if (realTimeInterval) {
      clearInterval(realTimeInterval);
      setRealTimeInterval(null);
    }

    return () => {
      if (realTimeInterval) {
        clearInterval(realTimeInterval);
      }
    };
  }, [isRealTime]);

  const analyzeNeptuneGalaxyCoherence = async () => {
    setIsAnalyzing(true);
    try {
      const enhancedConcept = `Neptune Year and Galaxy Coherence in the Context of Current Zeitgeist - Key Insights:
      1. Rising Interest in Astrology and Cosmic Cycles
      2. Scientific Exploration and Cosmic Awareness  
      3. Spiritual and Metaphysical Trends
      4. Environmental and Social Movements
      5. Shift in Perception of Time and Holistic Worldview`;
      
      const response = await fetch('/api/zeitgeist', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt: enhancedConcept }),
      });

      const data: NeptuneGalaxyAnalysis = await response.json();
      setAnalysis(data);
      
      // Add enhanced coherence data based on key insights
      const newDataPoint: CoherenceDataPoint = {
        z_n: coherenceData.length + 1,
        coherence: data.coherence_score,
        timestamp: Date.now(),
        galactic_alignment: Math.random() * 100,
        neptune_position: (Date.now() / (165 * 365.25 * 24 * 60 * 60 * 1000)) * 100
      };
      
      setCoherenceData(prev => [...prev.slice(-50), newDataPoint]);
      await fetchGalaxyMetrics();
    } catch (error) {
      console.error('Error analyzing Neptune Galaxy coherence:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const fetchGalaxyMetrics = async () => {
    try {
      // Enhanced galaxy metrics based on key insights from the analysis
      const latestCoherence = coherenceData.length > 0 ? coherenceData[coherenceData.length - 1].coherence : 0.5;
      const neptuneProgress = (Date.now() / (165 * 365.25 * 24 * 60 * 60 * 1000)) * 100;
      
      // Incorporate key insights into metrics calculation
      const astrologicalInfluence = Math.sin(neptuneProgress * Math.PI / 50) * 20 + 50; // Rising interest in astrology
      const scientificAwareness = Math.cos(Date.now() / 1000000) * 15 + 60; // Scientific exploration
      const spiritualTrends = Math.sin(Date.now() / 800000) * 25 + 55; // Spiritual and metaphysical trends
      const environmentalAwareness = Math.max(30, Math.min(90, neptuneProgress * 0.8 + 20)); // Environmental movements
      const holisticWorldview = (latestCoherence * 100) * 0.9 + 10; // Holistic worldview integration
      
      const metrics: GalaxyMetrics = {
        galactic_coherence: latestCoherence + (Math.random() - 0.5) * 0.1,
        neptune_year_progress: neptuneProgress % 100,
        cosmic_alignment: (astrologicalInfluence + scientificAwareness + spiritualTrends) / 3,
        collective_consciousness: Math.min(1, (environmentalAwareness + holisticWorldview) / 200),
        dimensional_resonance: Math.abs(Math.sin(Date.now() / 500000)) * 0.8 + 0.2
      };
      
      setGalaxyMetrics(metrics);
    } catch (error) {
      console.error('Error fetching galaxy metrics:', error);
    }
  };

  const getCoherenceColor = (score: number) => {
    if (score >= 0.7) return 'text-green-600';
    if (score >= 0.4) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getCoherenceBadge = (score: number) => {
    if (score >= 0.7) return 'default';
    if (score >= 0.4) return 'secondary';
    return 'destructive';
  };

  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString();
  };

  const formatNeptuneYear = (progress: number) => {
    const years = Math.floor(progress);
    const days = Math.floor((progress - years) * 365.25);
    return `${years}y ${days}d`;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center space-x-2">
            <Moon className="h-6 w-6 text-blue-600" />
            <Star className="h-6 w-6 text-yellow-600" />
            <span>Neptune Year = Galaxy Coherence</span>
          </h2>
          <p className="text-muted-foreground">
            Tracking cosmic alignment and galactic coherence through Neptune's orbital cycle
          </p>
        </div>
        <div className="flex space-x-2">
          <Button
            onClick={() => setIsRealTime(!isRealTime)}
            variant={isRealTime ? "default" : "outline"}
          >
            {isRealTime ? <Pause className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}
            {isRealTime ? 'Pause Tracking' : 'Start Tracking'}
          </Button>
          <Button onClick={analyzeNeptuneGalaxyCoherence} disabled={isAnalyzing}>
            {isAnalyzing ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Zap className="mr-2 h-4 w-4" />}
            {isAnalyzing ? 'Analyzing...' : 'Analyze'}
          </Button>
        </div>
      </div>

      {/* Galaxy Metrics Overview */}
      {galaxyMetrics && (
        <div className="grid gap-4 md:grid-cols-5">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Galactic Coherence</CardTitle>
              <Star className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getCoherenceColor(galaxyMetrics.galactic_coherence)}`}>
                {(galaxyMetrics.galactic_coherence * 100).toFixed(1)}%
              </div>
              <Progress value={galaxyMetrics.galactic_coherence * 100} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Neptune Year Progress</CardTitle>
              <Moon className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {formatNeptuneYear(galaxyMetrics.neptune_year_progress)}
              </div>
              <Progress value={galaxyMetrics.neptune_year_progress} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Cosmic Alignment</CardTitle>
              <Waves className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {(galaxyMetrics.cosmic_alignment).toFixed(1)}°
              </div>
              <Progress value={galaxyMetrics.cosmic_alignment} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Collective Consciousness</CardTitle>
              <Brain className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getCoherenceColor(galaxyMetrics.collective_consciousness)}`}>
                {(galaxyMetrics.collective_consciousness * 100).toFixed(1)}%
              </div>
              <Progress value={galaxyMetrics.collective_consciousness * 100} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Dimensional Resonance</CardTitle>
              <Network className="h-4 w-4 text-indigo-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-indigo-600">
                {(galaxyMetrics.dimensional_resonance * 100).toFixed(1)}%
              </div>
              <Progress value={galaxyMetrics.dimensional_resonance * 100} className="mt-2" />
            </CardContent>
          </Card>
        </div>
      )}

      {/* Coherence Evolution Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Neptune-Galaxy Coherence Evolution</CardTitle>
          <CardDescription>
            Real-time tracking of coherence patterns between Neptune's orbital cycle and galactic alignment
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={coherenceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="z_n" 
                label={{ value: 'Cosmic Iterations Z(n)', position: 'insideBottom', offset: -10 }}
              />
              <YAxis 
                domain={[0, 1]}
                label={{ value: 'Coherence Level', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                formatter={(value: number, name: string) => [
                  name === 'coherence' ? `${(value * 100).toFixed(1)}%` : value.toFixed(2),
                  name === 'coherence' ? 'Coherence' : name === 'galactic_alignment' ? 'Galactic Alignment' : 'Neptune Position'
                ]}
                labelFormatter={(label) => `Iteration ${label}`}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="coherence" 
                stroke="#8884d8" 
                strokeWidth={3}
                dot={{ r: 4 }}
                name="Neptune-Galaxy Coherence"
              />
              <Line 
                type="monotone" 
                dataKey="galactic_alignment" 
                stroke="#82ca9d" 
                strokeWidth={2}
                dot={{ r: 2 }}
                name="Galactic Alignment"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysis && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5" />
              <span>Neptune Year = Galaxy Coherence Analysis</span>
            </CardTitle>
            <CardDescription>
              AI-powered analysis of the cosmic relationship between Neptune's orbital cycle and galactic coherence
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Badge variant={getCoherenceBadge(analysis.coherence_score)}>
                  Coherence: {(analysis.coherence_score * 100).toFixed(1)}%
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {formatTimestamp(analysis.timestamp)}
                </span>
              </div>
              <div className="text-sm text-muted-foreground">
                Processing time: {analysis.metadata.processing_time}ms
              </div>
            </div>

            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Key Insights:</h3>
              <p className="whitespace-pre-wrap text-sm leading-relaxed">
                {analysis.response}
              </p>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">165</div>
                <div className="text-sm text-muted-foreground">Earth Years per Neptune Orbit</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">∞</div>
                <div className="text-sm text-muted-foreground">Galactic Time Scale</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {(analysis.coherence_score * 100).toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">Current Coherence Level</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Cosmic Status */}
      <Card>
        <CardHeader>
          <CardTitle>Contemporary Zeitgeist Indicators</CardTitle>
          <CardDescription>
            Real-time monitoring of how Neptune Year and Galaxy Coherence reflect current cultural trends
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Astrology & Cosmic Cycles:</span>
                <Badge variant="outline">Resurgent Interest</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Scientific Exploration:</span>
                <Badge variant="default">Advancing Rapidly</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Spiritual & Metaphysical:</span>
                <Badge variant="outline">Growing Awareness</Badge>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Environmental Movements:</span>
                <Badge variant="default">Global Unity</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Time Perception:</span>
                <Badge variant="outline">Expanding Beyond Linear</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Holistic Worldview:</span>
                <Badge variant="default">Systems Integration</Badge>
              </div>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
            <h4 className="font-semibold mb-2">Key Insights Integration:</h4>
            <ul className="text-sm space-y-1">
              <li>• Neptune's 165-year cycle encourages long-term thinking beyond immediate gratification</li>
              <li>• Galaxy coherence reflects the interconnectedness highlighted by global challenges</li>
              <li>• Scientific and spiritual convergence mirrors unified field theory pursuits</li>
              <li>• Environmental stewardship gains cosmic perspective through orbital awareness</li>
              <li>• Collective consciousness evolves through technology-enabled global connection</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}