'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter } from 'recharts';
import { 
  Brain, 
  Zap, 
  Network, 
  Target, 
  TrendingUp, 
  Activity,
  RefreshCw,
  BarChart3,
  Settings,
  Play,
  Pause,
  AlertCircle,
  CheckCircle,
  Atom,
  Radio,
  Filter,
  Gauge,
  Waves
} from 'lucide-react';

interface QuantumMagnetometryAnalysis {
  id: string;
  concept: string;
  analysis: string;
  coherence_score: number;
  timestamp: number;
  metadata: {
    model: string;
    processing_time: number;
    source_confidence: number;
  };
}

interface QuantumMetrics {
  spin_squeezing: number; // Quantum enhancement in precision
  estimation_error: number; // Kalman filter estimation error
  entanglement_level: number; // Atomic ensemble entanglement
  measurement_fidelity: number; // Quantum nondemolition measurement fidelity
  feedback_efficiency: number; // Linear quadratic regulator efficiency
  decoherence_rate: number; // Local and collective decoherence rate
  timestamp: number;
}

interface QuantumDataPoint {
  iteration: number;
  magnetic_field: number;
  spin_squeezing: number;
  estimation_error: number;
  entanglement: number;
  timestamp: number;
}

export default function QuantumMagnetometry() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<QuantumMagnetometryAnalysis | null>(null);
  const [quantumData, setQuantumData] = useState<QuantumDataPoint[]>([]);
  const [quantumMetrics, setQuantumMetrics] = useState<QuantumMetrics | null>(null);
  const [isRealTime, setIsRealTime] = useState(false);
  const [realTimeInterval, setRealTimeInterval] = useState<NodeJS.Timeout | null>(null);

  // Initialize with quantum magnetometry analysis
  useEffect(() => {
    analyzeQuantumMagnetometry();
    fetchQuantumMetrics();
  }, []);

  // Handle real-time updates
  useEffect(() => {
    if (isRealTime) {
      const interval = setInterval(() => {
        fetchQuantumMetrics();
      }, 3000); // Update every 3 seconds for quantum processes
      setRealTimeInterval(interval);
    } else if (realTimeInterval) {
      clearInterval(realTimeInterval);
      setRealTimeInterval(null);
    }

    return () => {
      if (realTimeInterval) {
        clearInterval(realTimeInterval);
      }
    };
  }, [isRealTime]);

  const analyzeQuantumMagnetometry = async () => {
    setIsAnalyzing(true);
    try {
      const enhancedConcept = `Noisy Atomic Magnetometry with Kalman Filtering and Measurement-Based Feedback - Key Quantum Concepts:
      1. Quantum nondemolition measurement via continuous light probing
      2. Extended Kalman filter for instantaneous parameter estimation  
      3. Linear quadratic regulator for feedback control
      4. Spin-squeezed state generation for quantum enhancement
      5. Entanglement preservation through measurement-based feedback
      6. Ultimate bounds on estimation error with decoherence
      7. Real-time error prediction and spin squeezing estimation`;
      
      const response = await fetch('/api/zeitgeist', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt: enhancedConcept }),
      });

      const data: QuantumMagnetometryAnalysis = await response.json();
      setAnalysis(data);
      
      // Add quantum data point
      const newDataPoint: QuantumDataPoint = {
        iteration: quantumData.length + 1,
        magnetic_field: Math.random() * 10 - 5, // Simulated magnetic field (-5 to 5 μT)
        spin_squeezing: data.coherence_score * 0.8 + Math.random() * 0.2,
        estimation_error: Math.max(0.01, 0.5 - data.coherence_score * 0.4),
        entanglement: data.coherence_score * 0.9 + Math.random() * 0.1,
        timestamp: Date.now()
      };
      
      setQuantumData(prev => [...prev.slice(-100), newDataPoint]);
      await fetchQuantumMetrics();
    } catch (error) {
      console.error('Error analyzing quantum magnetometry:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const fetchQuantumMetrics = async () => {
    try {
      // Simulate quantum metrics based on current quantum data
      const latestData = quantumData.length > 0 ? quantumData[quantumData.length - 1] : null;
      const baseSpinSqueezing = latestData ? latestData.spin_squeezing : 0.6;
      const baseEstimationError = latestData ? latestData.estimation_error : 0.3;
      
      // Calculate quantum metrics with realistic quantum effects
      const quantumNoise = Math.random() * 0.1 - 0.05;
      const decoherenceEffect = Math.exp(-Date.now() / 10000000) * 0.1;
      const feedbackEnhancement = Math.sin(Date.now() / 2000000) * 0.15;
      
      const metrics: QuantumMetrics = {
        spin_squeezing: Math.max(0, Math.min(1, baseSpinSqueezing + feedbackEnhancement - decoherenceEffect)),
        estimation_error: Math.max(0.01, Math.min(0.5, baseEstimationError + quantumNoise + decoherenceEffect)),
        entanglement_level: Math.max(0, Math.min(1, (baseSpinSqueezing * 1.2) + feedbackEnhancement - decoherenceEffect)),
        measurement_fidelity: Math.max(0.8, Math.min(1, 0.95 - decoherenceEffect)),
        feedback_efficiency: Math.max(0.7, Math.min(1, 0.85 + feedbackEnhancement)),
        decoherence_rate: Math.max(0, Math.min(0.2, decoherenceEffect + Math.random() * 0.05)),
        timestamp: Date.now()
      };
      
      setQuantumMetrics(metrics);
    } catch (error) {
      console.error('Error fetching quantum metrics:', error);
    }
  };

  const getQuantumColor = (value: number, isInverse = false) => {
    if (isInverse) {
      if (value <= 0.2) return 'text-green-600';
      if (value <= 0.4) return 'text-yellow-600';
      return 'text-red-600';
    }
    if (value >= 0.8) return 'text-green-600';
    if (value >= 0.6) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getQuantumBadge = (value: number, isInverse = false) => {
    if (isInverse) {
      if (value <= 0.2) return 'default';
      if (value <= 0.4) return 'secondary';
      return 'destructive';
    }
    if (value >= 0.8) return 'default';
    if (value >= 0.6) return 'secondary';
    return 'destructive';
  };

  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight flex items-center space-x-2">
            <Atom className="h-6 w-6 text-purple-600" />
            <Radio className="h-6 w-6 text-blue-600" />
            <span>Quantum Magnetometry System</span>
          </h2>
          <p className="text-muted-foreground">
            Advanced quantum sensing with Kalman filtering and measurement-based feedback control
          </p>
        </div>
        <div className="flex space-x-2">
          <Button
            onClick={() => setIsRealTime(!isRealTime)}
            variant={isRealTime ? "default" : "outline"}
          >
            {isRealTime ? <Pause className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}
            {isRealTime ? 'Pause Monitoring' : 'Start Monitoring'}
          </Button>
          <Button onClick={analyzeQuantumMagnetometry} disabled={isAnalyzing}>
            {isAnalyzing ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Zap className="mr-2 h-4 w-4" />}
            {isAnalyzing ? 'Analyzing...' : 'Analyze'}
          </Button>
        </div>
      </div>

      {/* Quantum Metrics Overview */}
      {quantumMetrics && (
        <div className="grid gap-4 md:grid-cols-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Spin Squeezing</CardTitle>
              <Atom className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getQuantumColor(quantumMetrics.spin_squeezing)}`}>
                {(quantumMetrics.spin_squeezing * 100).toFixed(1)}%
              </div>
              <Progress value={quantumMetrics.spin_squeezing * 100} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-1">
                Quantum enhancement
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Estimation Error</CardTitle>
              <Filter className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getQuantumColor(quantumMetrics.estimation_error, true)}`}>
                {(quantumMetrics.estimation_error * 100).toFixed(1)}%
              </div>
              <Progress value={(1 - quantumMetrics.estimation_error) * 100} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-1">
                Kalman filter accuracy
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Entanglement</CardTitle>
              <Network className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getQuantumColor(quantumMetrics.entanglement_level)}`}>
                {(quantumMetrics.entanglement_level * 100).toFixed(1)}%
              </div>
              <Progress value={quantumMetrics.entanglement_level * 100} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-1">
                Atomic ensemble
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Measurement Fidelity</CardTitle>
              <Radio className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getQuantumColor(quantumMetrics.measurement_fidelity)}`}>
                {(quantumMetrics.measurement_fidelity * 100).toFixed(1)}%
              </div>
              <Progress value={quantumMetrics.measurement_fidelity * 100} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-1">
                QND measurement
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Feedback Efficiency</CardTitle>
              <Waves className="h-4 w-4 text-indigo-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getQuantumColor(quantumMetrics.feedback_efficiency)}`}>
                {(quantumMetrics.feedback_efficiency * 100).toFixed(1)}%
              </div>
              <Progress value={quantumMetrics.feedback_efficiency * 100} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-1">
                LQR performance
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Decoherence Rate</CardTitle>
              <AlertCircle className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getQuantumColor(quantumMetrics.decoherence_rate, true)}`}>
                {(quantumMetrics.decoherence_rate * 100).toFixed(2)}%
              </div>
              <Progress value={(1 - quantumMetrics.decoherence_rate) * 100} className="mt-2" />
              <p className="text-xs text-muted-foreground mt-1">
                Environmental noise
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Quantum Evolution Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Quantum Sensing Evolution</CardTitle>
          <CardDescription>
            Real-time tracking of spin squeezing, estimation error, and entanglement evolution
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={quantumData.slice(-50)}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="iteration" 
                label={{ value: 'Measurement Iterations', position: 'insideBottom', offset: -10 }}
              />
              <YAxis 
                domain={[0, 1]}
                label={{ value: 'Quantum Parameters', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                formatter={(value: number, name: string) => [
                  `${(value * 100).toFixed(1)}%`, 
                  name === 'spin_squeezing' ? 'Spin Squeezing' :
                  name === 'estimation_error' ? 'Estimation Error' :
                  name === 'entanglement' ? 'Entanglement' : name
                ]}
                labelFormatter={(label) => `Iteration ${label}`}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="spin_squeezing" 
                stroke="#8884d8" 
                strokeWidth={3}
                dot={{ r: 3 }}
                name="Spin Squeezing"
              />
              <Line 
                type="monotone" 
                dataKey="entanglement" 
                stroke="#82ca9d" 
                strokeWidth={2}
                dot={{ r: 2 }}
                name="Entanglement"
              />
              <Line 
                type="monotone" 
                dataKey="estimation_error" 
                stroke="#ff7300" 
                strokeWidth={2}
                dot={{ r: 2 }}
                name="Estimation Error"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysis && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5" />
              <span>Quantum Magnetometry Analysis</span>
            </CardTitle>
            <CardDescription>
              AI-powered analysis of quantum sensing with Kalman filtering and measurement-based feedback
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Badge variant={getQuantumBadge(analysis.coherence_score)}>
                  Quantum Coherence: {(analysis.coherence_score * 100).toFixed(1)}%
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {formatTimestamp(analysis.timestamp)}
                </span>
              </div>
              <div className="text-sm text-muted-foreground">
                Processing time: {analysis.metadata.processing_time}ms
              </div>
            </div>

            <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Key Quantum Insights:</h3>
              <p className="whitespace-pre-wrap text-sm leading-relaxed">
                {analysis.response}
              </p>
            </div>

            <div className="grid gap-4 md:grid-cols-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {(quantumMetrics?.spin_squeezing || 0 * 100).toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">Spin Squeezing</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">
                  {((quantumMetrics?.estimation_error || 0) * 100).toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">Estimation Error</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {(quantumMetrics?.entanglement_level || 0 * 100).toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">Entanglement</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {(analysis.coherence_score * 100).toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">Analysis Coherence</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quantum Process Status */}
      <Card>
        <CardHeader>
          <CardTitle>Quantum Process Status Indicators</CardTitle>
          <CardDescription>
            Real-time monitoring of quantum magnetometry processes and performance metrics
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">QND Measurement:</span>
                <Badge variant="default">Active</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Kalman Filtering:</span>
                <Badge variant="default">Optimal</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Feedback Control:</span>
                <Badge variant="default">Converged</Badge>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Spin Squeezing:</span>
                <Badge variant={getQuantumBadge(quantumMetrics?.spin_squeezing || 0)}>
                  {quantumMetrics?.spin_squeezing && quantumMetrics.spin_squeezing > 0.7 ? 'High' : 'Moderate'}
                </Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Entanglement Level:</span>
                <Badge variant={getQuantumBadge(quantumMetrics?.entanglement_level || 0)}>
                  {quantumMetrics?.entanglement_level && quantumMetrics.entanglement_level > 0.8 ? 'Strong' : 'Developing'}
                </Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Decoherence Management:</span>
                <Badge variant={getQuantumBadge(quantumMetrics?.decoherence_rate || 0, true)}>
                  {quantumMetrics?.decoherence_rate && quantumMetrics.decoherence_rate < 0.05 ? 'Excellent' : 'Good'}
                </Badge>
              </div>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg">
            <h4 className="font-semibold mb-2">Quantum Enhancement Summary:</h4>
            <ul className="text-sm space-y-1">
              <li>• Quantum nondemolition measurements preserve atomic coherence</li>
              <li>• Extended Kalman filter enables real-time parameter estimation</li>
              <li>• Linear quadratic regulator optimizes feedback control</li>
              <li>• Spin-squeezed states provide quantum-enhanced precision</li>
              <li>• Measurement-based feedback maintains entanglement without data storage</li>
              <li>• Ultimate bounds on estimation error achieved with decoherence</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}