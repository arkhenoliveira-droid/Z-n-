/**
 * HLZ (Harmonic-Lattice-Z) Orbit Simulator
 * 
 * Implementation of resonance-based gravity simulation with φ⁴ scaling
 * and r(3), r(7) shell structures as described in the mathematical formulation.
 */

import { ID, AsyncResult, ok, err, createId } from '@/types/utils';

// Core mathematical interfaces
export interface HLZMathematicalModel {
  phi: number;           // Golden ratio φ ≈ 1.618
  phi4: number;          // φ⁴ ≈ 6.854
  alpha: number;         // Coupling constant (can absorb φ⁴)
  V: number;             // Normalization volume
  epsilon: number;       // Softening parameter to avoid singularities
}

export interface SpectralWeight {
  k: number;             // Mode index (integer)
  Z: number;            // Z-function (spectral weight)
  rho: number;          // Density ρ(k) = Z(k)/V
  radius: number;       // Effective radius r(k) = √(1/ρ(k))
}

export interface HLZBody {
  id: ID;
  position: [number, number, number];  // 3D position [x, y, z]
  velocity: [number, number, number];  // 3D velocity [vx, vy, vz]
  mass: number;
  mode: number;         // Associated spectral mode k
  glyph?: string;       // Optional glyph identifier
  metadata?: Record<string, any>; // Additional metadata
}

export interface HLZSimulationState {
  bodies: HLZBody[];
  time: number;
  step: number;
  energy: number;
  model: HLZMathematicalModel;
}

export interface SimulationParameters {
  dt: number;           // Time step
  nSteps: number;      // Total number of steps
  saveInterval: number; // Save state every N steps
  modes: number[];     // Spectral modes to use [3, 7, ...]
  bodiesPerMode: number[]; // Number of bodies per mode
  useSoftening: boolean;
  couplingStrength: number; // Additional scaling for alpha
}

export class HLZOrbitSimulator {
  private model: HLZMathematicalModel;
  private state: HLZSimulationState;
  private trajectory: HLZSimulationState[];
  private spectralWeights: Map<number, SpectralWeight>;

  constructor(params: Partial<SimulationParameters> = {}) {
    // Initialize mathematical model
    this.model = this.initializeMathematicalModel(params.couplingStrength || 1.0);
    
    // Initialize spectral weights for different modes
    this.spectralWeights = this.initializeSpectralWeights();
    
    // Initialize simulation state
    this.state = {
      bodies: [],
      time: 0,
      step: 0,
      energy: 0,
      model: this.model
    };
    
    this.trajectory = [];
    
    // Initialize bodies if parameters provided
    if (params.modes && params.bodiesPerMode) {
      this.initializeBodies(params.modes, params.bodiesPerMode);
    }
  }

  /**
   * Initialize the mathematical model with golden ratio constants
   */
  private initializeMathematicalModel(couplingStrength: number = 1.0): HLZMathematicalModel {
    const phi = (1 + Math.sqrt(5)) / 2;  // Golden ratio
    const phi4 = Math.pow(phi, 4);       // φ⁴ ≈ 6.854
    
    return {
      phi,
      phi4,
      alpha: phi4 * couplingStrength,     // Coupling constant
      V: 1.0,                             // Normalization volume
      epsilon: 1e-6                       // Softening parameter
    };
  }

  /**
   * Initialize spectral weights Z(k) for different modes
   */
  private initializeSpectralWeights(): Map<number, SpectralWeight> {
    const weights = new Map<number, SpectralWeight>();
    
    // Pre-compute for modes 1 through 20 (can be extended)
    for (let k = 1; k <= 20; k++) {
      const Z = this.computeSpectralWeight(k);
      const rho = Z / this.model.V;
      const radius = Math.sqrt(1 / rho);
      
      weights.set(k, {
        k,
        Z,
        rho,
        radius
      });
    }
    
    return weights;
  }

  /**
   * Compute spectral weight Z(k) - can be customized with different formulas
   */
  private computeSpectralWeight(k: number): number {
    // Example: Power-law decay with mode number
    // This can be replaced with your own analytical form or lookup table
    return 1.0 / (k * k + 1.0);
    
    // Alternative forms you might want to try:
    // return Math.exp(-k / 5.0);  // Exponential decay
    // return 1.0 / Math.pow(k, 1.5);  // Power law with different exponent
    // return Math.cos(k * this.model.phi) / (k + 1);  // Oscillatory decay
  }

  /**
   * Initialize HLZ bodies on specified spectral shells
   */
  private initializeBodies(modes: number[], bodiesPerMode: number[]): void {
    const bodies: HLZBody[] = [];
    
    modes.forEach((mode, modeIndex) => {
      const numBodies = bodiesPerMode[modeIndex] || 4;
      const spectralWeight = this.spectralWeights.get(mode);
      
      if (!spectralWeight) {
        console.warn(`No spectral weight found for mode ${mode}`);
        return;
      }
      
      const radius = spectralWeight.radius;
      
      for (let i = 0; i < numBodies; i++) {
        // Random angle for initial position
        const theta = Math.random() * 2 * Math.PI;
        const phi = Math.random() * Math.PI;  // For 3D distribution
        
        // Position on spherical shell
        const x = radius * Math.sin(phi) * Math.cos(theta);
        const y = radius * Math.sin(phi) * Math.sin(theta);
        const z = radius * Math.cos(phi);
        
        // Circular velocity for r⁻⁴ force: v = √(α/r³)
        const speed = Math.sqrt(this.model.alpha / Math.pow(radius, 3));
        
        // Velocity perpendicular to radius vector (for circular orbit)
        // In 3D, we create velocity in the tangential direction
        const vx = -speed * Math.sin(theta);
        const vy = speed * Math.cos(theta);
        const vz = 0;  // Initially in xy-plane
        
        bodies.push({
          id: createId(),
          position: [x, y, z],
          velocity: [vx, vy, vz],
          mass: 1.0,
          mode,
          glyph: `glyph_${mode}_${i}`,
          metadata: {
            spectralMode: mode,
            shellRadius: radius,
            orbitalSpeed: speed,
            creationTime: Date.now()
          }
        });
      }
    });
    
    this.state.bodies = bodies;
    this.state.energy = this.computeTotalEnergy();
  }

  /**
   * Compute pairwise forces between all bodies (r⁻⁴ law)
   */
  private computeAccelerations(bodies: HLZBody[]): number[][] {
    const N = bodies.length;
    const accelerations: number[][] = Array(N).fill(null).map(() => [0, 0, 0]);
    
    for (let i = 0; i < N; i++) {
      for (let j = i + 1; j < N; j++) {
        const [xi, yi, zi] = bodies[i]?.position ?? [0, 0, 0];
        const [xj, yj, zj] = bodies[j]?.position ?? [0, 0, 0];
        
        // Distance vector from j to i
        const rx = xi - xj;
        const ry = yi - yj;
        const rz = zi - zj;
        
        // Squared distance
        const r2 = rx * rx + ry * ry + rz * rz;
        
        // Avoid singularity with softening parameter
        const r2_soft = r2 + this.model.epsilon;
        const r4_soft = r2_soft * r2_soft;
        
        // Force magnitude: F = α / r⁴
        const forceMagnitude = this.model.alpha / r4_soft;
        
        // Unit vector from j to i
        const r = Math.sqrt(r2);
        const ux = rx / r;
        const uy = ry / r;
        const uz = rz / r;
        
        // Force components
        const fx = forceMagnitude * ux;
        const fy = forceMagnitude * uy;
        const fz = forceMagnitude * uz;
        
        // Apply Newton's third law
        // @ts-ignore
        accelerations[i][0] += fx / (bodies[i]?.mass ?? 1);
        // @ts-ignore
        accelerations[i][1] += fy / (bodies[i]?.mass ?? 1);
        // @ts-ignore
        accelerations[i][2] += fz / (bodies[i]?.mass ?? 1);
        
        // @ts-ignore
        accelerations[j][0] -= fx / (bodies[j]?.mass ?? 1);
        // @ts-ignore
        accelerations[j][1] -= fy / (bodies[j]?.mass ?? 1);
        // @ts-ignore
        accelerations[j][2] -= fz / (bodies[j]?.mass ?? 1);
      }
    }
    
    return accelerations;
  }

  /**
   * Compute total energy of the system (kinetic + potential)
   */
  private computeTotalEnergy(): number {
    let kineticEnergy = 0;
    let potentialEnergy = 0;
    const N = this.state.bodies.length;
    
    // Kinetic energy: Σ(½mv²)
    for (let i = 0; i < N; i++) {
      // @ts-ignore
      const [vx, vy, vz] = this.state.bodies[i]?.velocity ?? [0, 0, 0];
      const v2 = vx * vx + vy * vy + vz * vz;
      kineticEnergy += 0.5 * (this.state.bodies[i]?.mass ?? 1) * v2;
    }
    
    // Potential energy: Σ(α/2r²) for all pairs
    for (let i = 0; i < N; i++) {
      for (let j = i + 1; j < N; j++) {
        // @ts-ignore
        const [xi, yi, zi] = this.state.bodies[i]?.position ?? [0, 0, 0];
        // @ts-ignore
        const [xj, yj, zj] = this.state.bodies[j]?.position ?? [0, 0, 0];
        
        const rx = xi - xj;
        const ry = yi - yj;
        const rz = zi - zj;
        const r2 = rx * rx + ry * ry + rz * rz;
        
        potentialEnergy += this.model.alpha / (2 * r2);
      }
    }
    
    return kineticEnergy + potentialEnergy;
  }

  /**
   * Leap-frog integration step
   */
  private leapFrogStep(dt: number): void {
    const bodies = this.state.bodies;
    
    // Compute accelerations at current positions
    const accelerations = this.computeAccelerations(bodies);
    
    // Update velocities by half step
    for (let i = 0; i < bodies.length; i++) {
      if (bodies[i]!.velocity && accelerations[i]) {
        bodies[i]!.velocity[0] += 0.5 * dt * accelerations[i]![0];
        bodies[i]!.velocity[1] += 0.5 * dt * accelerations[i]![1];
        bodies[i]!.velocity[2] += 0.5 * dt * accelerations[i]![2];
      }
    }
    
    // Update positions by full step
    for (let i = 0; i < bodies.length; i++) {
      if (bodies[i]!.position && bodies[i]!.velocity) {
        bodies[i]!.position[0] += dt * bodies[i]!.velocity[0];
        bodies[i]!.position[1] += dt * bodies[i]!.velocity[1];
        bodies[i]!.position[2] += dt * bodies[i]!.velocity[2];
      }
    }
    
    // Compute new accelerations
    const newAccelerations = this.computeAccelerations(bodies);
    
    // Update velocities by another half step
    for (let i = 0; i < bodies.length; i++) {
      if (bodies[i]!.velocity && newAccelerations[i]) {
        bodies[i]!.velocity[0] += 0.5 * dt * newAccelerations[i]![0];
        bodies[i]!.velocity[1] += 0.5 * dt * newAccelerations[i]![1];
        bodies[i]!.velocity[2] += 0.5 * dt * newAccelerations[i]![2];
      }
    }
    
    // Update time and step
    this.state.time += dt;
    this.state.step += 1;
    this.state.energy = this.computeTotalEnergy();
  }

  /**
   * Run the simulation
   */
  async runSimulation(params: SimulationParameters): AsyncResult<HLZSimulationState[]> {
    try {
      // Initialize bodies if not already done
      if (this.state.bodies.length === 0) {
        this.initializeBodies(params.modes, params.bodiesPerMode);
      }
      
      // Clear previous trajectory
      this.trajectory = [];
      
      // Save initial state
      this.trajectory.push({
        ...this.state,
        bodies: this.state.bodies.map(b => ({...b}))
      });
      
      // Run simulation
      for (let step = 0; step < params.nSteps; step++) {
        this.leapFrogStep(params.dt);
        
        // Save state at specified intervals
        if (step % params.saveInterval === 0) {
          this.trajectory.push({
            ...this.state,
            bodies: this.state.bodies.map(b => ({...b}))
          });
        }
      }
      
      // Save final state
      this.trajectory.push({
        ...this.state,
        bodies: this.state.bodies.map(b => ({...b}))
      });
      
      return ok(this.trajectory);
    } catch (error) {
      return err(error as Error);
    }
  }

  /**
   * Get current simulation state
   */
  getCurrentState(): HLZSimulationState {
    return {
      ...this.state,
      bodies: this.state.bodies.map(b => ({...b}))
    };
  }

  /**
   * Get trajectory data
   */
  getTrajectory(): HLZSimulationState[] {
    return this.trajectory.map(state => ({
      ...state,
      bodies: state.bodies.map(b => ({...b}))
    }));
  }

  /**
   * Get spectral weights for analysis
   */
  getSpectralWeights(): SpectralWeight[] {
    return Array.from(this.spectralWeights.values());
  }

  /**
   * Reset simulation to initial state
   */
  reset(): void {
    this.state = {
      bodies: [],
      time: 0,
      step: 0,
      energy: 0,
      model: this.model
    };
    this.trajectory = [];
  }

  /**
   * Add a new body to the simulation
   */
  addBody(body: Omit<HLZBody, 'id'>): void {
    const newBody: HLZBody = {
      ...body,
      id: createId()
    };
    
    this.state.bodies.push(newBody);
    this.state.energy = this.computeTotalEnergy();
  }

  /**
   * Remove a body from the simulation
   */
  removeBody(bodyId: ID): boolean {
    const index = this.state.bodies.findIndex(b => b.id === bodyId);
    if (index !== -1) {
      this.state.bodies.splice(index, 1);
      this.state.energy = this.computeTotalEnergy();
      return true;
    }
    return false;
  }

  /**
   * Get system statistics
   */
  getStatistics(): {
    totalBodies: number;
    totalEnergy: number;
    time: number;
    step: number;
    modes: number[];
    averageRadius: number;
    energyDrift: number;
  } {
    const modes = [...new Set(this.state.bodies.map(b => b.mode))];
    const radii = this.state.bodies.map(b => {
      const [x, y, z] = b.position;
      return Math.sqrt(x * x + y * y + z * z);
    });
    const averageRadius = radii.reduce((sum, r) => sum + r, 0) / radii.length;
    
    const initialEnergy = this.trajectory.length > 0 ? this.trajectory[0].energy : this.state.energy;
    const energyDrift = Math.abs((this.state.energy - initialEnergy) / initialEnergy);
    
    return {
      totalBodies: this.state.bodies.length,
      totalEnergy: this.state.energy,
      time: this.state.time,
      step: this.state.step,
      modes,
      averageRadius,
      energyDrift
    };
  }
}