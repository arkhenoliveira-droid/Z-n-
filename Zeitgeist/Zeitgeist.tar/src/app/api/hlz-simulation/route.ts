import { NextRequest, NextResponse } from "next/server";
import { HLZPythonStyleSimulation } from "@/simulations/hlz-python-style-simulation";
import { HLZQuantumIntegration } from "@/integrations/hlz-quantum-integration";
import { HLZMathematicalFormulations } from "@/algorithms/hlz-mathematical-formulations";

// Simulation state storage (in production, use a proper database)
const simulations = new Map<string, any>();

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, simulationId, params } = body;

    switch (action) {
      case "create":
        return await createSimulation(params);
      case "run":
        return await runSimulation(simulationId, params);
      case "status":
        return await getSimulationStatus(simulationId);
      case "results":
        return await getSimulationResults(simulationId);
      case "visualize":
        return await getVisualizationData(simulationId);
      case "integrate":
        return await runIntegration(simulationId, params);
      case "delete":
        return await deleteSimulation(simulationId);
      default:
        return NextResponse.json({ error: "Unknown action" }, { status: 400 });
    }
  } catch (error) {
    console.error("HLZ Simulation API error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get("action");

    switch (action) {
      case "list":
        return await listSimulations();
      case "constants":
        return await getMathematicalConstants();
      case "validate":
        return await validateParameters(searchParams);
      default:
        return NextResponse.json({ error: "Unknown action" }, { status: 400 });
    }
  } catch (error) {
    console.error("HLZ Simulation API error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

async function createSimulation(params: any) {
  const simulationId = `hlz_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  // Validate parameters
  const requiredParams = ["dt", "nSteps", "modes", "bodiesPerMode"];
  for (const param of requiredParams) {
    if (!params[param]) {
      return NextResponse.json(
        { error: `Missing required parameter: ${param}` },
        { status: 400 }
      );
    }
  }

  // Create simulation with default values
  const simulationParams = {
    dt: params.dt || 0.001,
    nSteps: params.nSteps || 1000,
    saveInterval: params.saveInterval || 10,
    modes: params.modes || [3, 7],
    bodiesPerMode: params.bodiesPerMode || [4, 6],
    couplingStrength: params.couplingStrength || 1.0,
    useSoftening: params.useSoftening !== false,
    seed: params.seed || 42
  };

  try {
    const simulation = new HLZPythonStyleSimulation(simulationParams);
    const initialState = simulation.getCurrentState();
    
    simulations.set(simulationId, {
      simulation,
      params: simulationParams,
      status: "created",
      createdAt: Date.now(),
      currentState: initialState,
      results: null
    });

    return NextResponse.json({
      simulationId,
      status: "created",
      params: simulationParams,
      initialState,
      message: "Simulation created successfully"
    });
  } catch (error) {
    return NextResponse.json(
      { error: `Failed to create simulation: ${error}` },
      { status: 500 }
    );
  }
}

async function runSimulation(simulationId: string, params: any) {
  const simData = simulations.get(simulationId);
  if (!simData) {
    return NextResponse.json({ error: "Simulation not found" }, { status: 404 });
  }

  try {
    simData.status = "running";
    simData.startedAt = Date.now();

    // Run simulation
    const result = await simData.simulation.runSimulation();
    
    if (result.isOk()) {
      simData.status = "completed";
      simData.results = result.value;
      simData.completedAt = Date.now();
      
      return NextResponse.json({
        simulationId,
        status: "completed",
        results: {
          frameCount: result.value.length,
          totalTime: result.value[result.value.length - 1]?.time || 0,
          finalEnergy: result.value[result.value.length - 1]?.energy || 0,
          statistics: simData.simulation.getStatistics()
        },
        message: "Simulation completed successfully"
      });
    } else {
      simData.status = "failed";
      simData.error = result.error;
      
      return NextResponse.json({
        simulationId,
        status: "failed",
        error: result.error.message,
        message: "Simulation failed"
      }, { status: 500 });
    }
  } catch (error) {
    simData.status = "failed";
    simData.error = error;
    
    return NextResponse.json(
      {
        simulationId,
        status: "failed",
        error: error instanceof Error ? error.message : "Unknown error",
        message: "Simulation failed"
      },
      { status: 500 }
    );
  }
}

async function getSimulationStatus(simulationId: string) {
  const simData = simulations.get(simulationId);
  if (!simData) {
    return NextResponse.json({ error: "Simulation not found" }, { status: 404 });
  }

  const status = {
    simulationId,
    status: simData.status,
    createdAt: simData.createdAt,
    startedAt: simData.startedAt,
    completedAt: simData.completedAt,
    params: simData.params,
    error: simData.error,
    statistics: simData.simulation?.getStatistics() || null
  };

  return NextResponse.json(status);
}

async function getSimulationResults(simulationId: string) {
  const simData = simulations.get(simulationId);
  if (!simData) {
    return NextResponse.json({ error: "Simulation not found" }, { status: 404 });
  }

  if (simData.status !== "completed") {
    return NextResponse.json(
      { error: "Simulation not completed" },
      { status: 400 }
    );
  }

  const results = {
    simulationId,
    trajectory: simData.simulation.getTrajectory(),
    visualizationData: simData.simulation.getTrajectoryForVisualization(),
    statistics: simData.simulation.getStatistics(),
    phiAlignment: simData.simulation.verifyPhiAlignment(),
    exportData: simData.simulation.exportData(),
    completedAt: simData.completedAt
  };

  return NextResponse.json(results);
}

async function getVisualizationData(simulationId: string) {
  const simData = simulations.get(simulationId);
  if (!simData) {
    return NextResponse.json({ error: "Simulation not found" }, { status: 404 });
  }

  if (simData.status !== "completed") {
    return NextResponse.json(
      { error: "Simulation not completed" },
      { status: 400 }
    );
  }

  const vizData = simData.simulation.getTrajectoryForVisualization();
  
  return NextResponse.json({
    simulationId,
    visualizationData: vizData,
    frameCount: vizData.positions.length,
    bodyCount: vizData.modes.length,
    timeRange: {
      start: vizData.times[0],
      end: vizData.times[vizData.times.length - 1]
    }
  });
}

async function runIntegration(simulationId: string, params: any) {
  const simData = simulations.get(simulationId);
  if (!simData) {
    return NextResponse.json({ error: "Simulation not found" }, { status: 404 });
  }

  try {
    const integrationParams = {
      coherenceCoupling: params.coherenceCoupling || 0.8,
      quantumResonanceStrength: params.quantumResonanceStrength || 1.2,
      fieldInteractionStrength: params.fieldInteractionStrength || 1.0,
      temporalCoherenceFactor: params.temporalCoherenceFactor || 0.9,
      spatialCoherenceFactor: params.spatialCoherenceFactor || 0.8,
      emergenceThreshold: params.emergenceThreshold || 0.7
    };

    const integration = new HLZQuantumIntegration(integrationParams);
    await integration.initialize();
    
    const integrationSteps = params.integrationSteps || 50;
    const result = await integration.runIntegratedSimulation(integrationSteps);
    
    if (result.isOk()) {
      return NextResponse.json({
        simulationId,
        integrationStatus: "completed",
        integrationSteps: result.value.length,
        emergenceAnalysis: integration.analyzeEmergencePatterns(),
        exportData: integration.exportIntegrationData(),
        message: "Integration completed successfully"
      });
    } else {
      return NextResponse.json(
        {
          simulationId,
          integrationStatus: "failed",
          error: result.error.message,
          message: "Integration failed"
        },
        { status: 500 }
      );
    }
  } catch (error) {
    return NextResponse.json(
      {
        simulationId,
        integrationStatus: "failed",
        error: error instanceof Error ? error.message : "Unknown error",
        message: "Integration failed"
      },
      { status: 500 }
    );
  }
}

async function deleteSimulation(simulationId: string) {
  const simData = simulations.get(simulationId);
  if (!simData) {
    return NextResponse.json({ error: "Simulation not found" }, { status: 404 });
  }

  simulations.delete(simulationId);
  
  return NextResponse.json({
    simulationId,
    status: "deleted",
    message: "Simulation deleted successfully"
  });
}

async function listSimulations() {
  const simulationList = Array.from(simulations.entries()).map(([id, data]) => ({
    simulationId: id,
    status: data.status,
    createdAt: data.createdAt,
    params: data.params,
    statistics: data.simulation?.getStatistics() || null,
    hasResults: data.results !== null
  }));

  return NextResponse.json({
    simulations: simulationList,
    count: simulationList.length
  });
}

async function getMathematicalConstants() {
  const formulations = new HLZMathematicalFormulations();
  const constants = formulations.getConstants();
  const specialRadii = formulations.computeSpecialRadii();
  const phiAlignment = formulations.verifyPhiAlignment();

  return NextResponse.json({
    constants,
    specialRadii,
    phiAlignment,
    spectralWeights: formulations.getSpectralWeights().slice(0, 10) // First 10 modes
  });
}

async function validateParameters(searchParams: URLSearchParams) {
  const dt = parseFloat(searchParams.get("dt") || "0.001");
  const nSteps = parseInt(searchParams.get("nSteps") || "1000");
  const modes = searchParams.get("modes")?.split(",").map(Number) || [3, 7];
  const bodiesPerMode = searchParams.get("bodiesPerMode")?.split(",").map(Number) || [4, 6];

  const validations = {
    dt: { value: dt, valid: dt > 0 && dt < 0.1, message: dt > 0 && dt < 0.1 ? "Valid" : "Should be between 0 and 0.1" },
    nSteps: { value: nSteps, valid: nSteps > 0 && nSteps <= 10000, message: nSteps > 0 && nSteps <= 10000 ? "Valid" : "Should be between 1 and 10000" },
    modes: { value: modes, valid: modes.every(m => m > 0 && m <= 20), message: modes.every(m => m > 0 && m <= 20) ? "Valid" : "Modes should be between 1 and 20" },
    bodiesPerMode: { value: bodiesPerMode, valid: bodiesPerMode.every(b => b > 0 && b <= 20), message: bodiesPerMode.every(b => b > 0 && b <= 20) ? "Valid" : "Bodies per mode should be between 1 and 20" }
  };

  const allValid = Object.values(validations).every(v => v.valid);
  
  return NextResponse.json({
    valid: allValid,
    validations,
    totalBodies: bodiesPerMode.reduce((a, b) => a + b, 0),
    estimatedDuration: nSteps * dt * 1000 // Rough estimate in ms
  });
}