'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Activity, 
  Zap, 
  Network, 
  Target, 
  TrendingUp, 
  Users, 
  Globe,
  BarChart3,
  Settings,
  RefreshCw,
  Lightbulb,
  Layers,
  Database,
  Cpu,
  Code,
  GitBranch,
  CheckCircle
} from 'lucide-react';

// System health metrics interface
interface SystemHealth {
  id: string;
  name: string;
  status: 'healthy' | 'warning' | 'error';
  performance: number;
  uptime: number;
  lastCheck: number;
}

// Performance metrics interface
interface PerformanceMetrics {
  cpu: number;
  memory: number;
  storage: number;
  network: number;
  responseTime: number;
  throughput: number;
}

// Development metrics interface
interface DevelopmentMetrics {
  codeQuality: number;
  testCoverage: number;
  bugRate: number;
  featureCompletion: number;
  documentation: number;
}

// Mock data for demonstration
const mockSystemHealth: SystemHealth[] = [
  {
    id: 'api_server',
    name: 'API Server',
    status: 'healthy',
    performance: 92,
    uptime: 99.9,
    lastCheck: Date.now() - 30000
  },
  {
    id: 'database',
    name: 'Database',
    status: 'healthy',
    performance: 87,
    uptime: 99.8,
    lastCheck: Date.now() - 45000
  },
  {
    id: 'cache_service',
    name: 'Cache Service',
    status: 'warning',
    performance: 78,
    uptime: 98.5,
    lastCheck: Date.now() - 60000
  },
  {
    id: 'message_queue',
    name: 'Message Queue',
    status: 'healthy',
    performance: 95,
    uptime: 99.7,
    lastCheck: Date.now() - 15000
  }
];

const mockPerformanceMetrics: PerformanceMetrics = {
  cpu: 65,
  memory: 78,
  storage: 45,
  network: 82,
  responseTime: 120,
  throughput: 1250
};

const mockDevelopmentMetrics: DevelopmentMetrics = {
  codeQuality: 85,
  testCoverage: 72,
  bugRate: 0.8,
  featureCompletion: 68,
  documentation: 45
};

export default function SystemDashboard() {
  const [systemHealth, setSystemHealth] = useState<SystemHealth[]>(mockSystemHealth);
  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetrics>(mockPerformanceMetrics);
  const [developmentMetrics, setDevelopmentMetrics] = useState<DevelopmentMetrics>(mockDevelopmentMetrics);
  
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleRefreshMetrics = async () => {
    setIsRefreshing(true);
    setTimeout(() => {
      // Simulate metric updates with small variations
      setPerformanceMetrics(prev => ({
        cpu: Math.max(0, Math.min(100, prev.cpu + (Math.random() - 0.5) * 10)),
        memory: Math.max(0, Math.min(100, prev.memory + (Math.random() - 0.5) * 10)),
        storage: Math.max(0, Math.min(100, prev.storage + (Math.random() - 0.5) * 5)),
        network: Math.max(0, Math.min(100, prev.network + (Math.random() - 0.5) * 10)),
        responseTime: Math.max(10, prev.responseTime + (Math.random() - 0.5) * 20),
        throughput: Math.max(100, prev.throughput + (Math.random() - 0.5) * 200)
      }));
      setIsRefreshing(false);
    }, 2000);
  };

  const handleOptimizeSystem = async () => {
    setIsOptimizing(true);
    setTimeout(() => {
      // Simulate optimization improvements
      setPerformanceMetrics(prev => ({
        cpu: Math.max(0, prev.cpu * 0.9),
        memory: Math.max(0, prev.memory * 0.95),
        storage: prev.storage,
        network: Math.min(100, prev.network * 1.05),
        responseTime: Math.max(10, prev.responseTime * 0.85),
        throughput: Math.min(2000, prev.throughput * 1.1)
      }));
      setIsOptimizing(false);
    }, 3000);
  };

  const handleAnalyzeCode = async () => {
    setIsAnalyzing(true);
    setTimeout(() => {
      // Simulate code analysis results
      setDevelopmentMetrics(prev => ({
        codeQuality: Math.min(100, prev.codeQuality + Math.random() * 5),
        testCoverage: Math.min(100, prev.testCoverage + Math.random() * 3),
        bugRate: Math.max(0, prev.bugRate - Math.random() * 0.2),
        featureCompletion: Math.min(100, prev.featureCompletion + Math.random() * 2),
        documentation: Math.min(100, prev.documentation + Math.random() * 8)
      }));
      setIsAnalyzing(false);
    }, 4000);
  };

  const getStatusColor = (status: SystemHealth['status']) => {
    switch (status) {
      case 'healthy': return 'bg-green-500';
      case 'warning': return 'bg-yellow-500';
      case 'error': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: SystemHealth['status']) => {
    switch (status) {
      case 'healthy': return 'Healthy';
      case 'warning': return 'Warning';
      case 'error': return 'Error';
      default: return 'Unknown';
    }
  };

  const getMetricColor = (value: number) => {
    if (value >= 80) return 'text-green-600';
    if (value >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">System Dashboard</h1>
          <p className="text-muted-foreground">
            Monitor and manage your application systems and performance
          </p>
        </div>
        <div className="flex space-x-2">
          <Button 
            onClick={handleRefreshMetrics} 
            disabled={isRefreshing}
            variant="outline"
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            {isRefreshing ? 'Refreshing...' : 'Refresh'}
          </Button>
          <Button 
            onClick={handleOptimizeSystem} 
            disabled={isOptimizing}
          >
            <Settings className="mr-2 h-4 w-4" />
            {isOptimizing ? 'Optimizing...' : 'Optimize'}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="development">Development</TabsTrigger>
          <TabsTrigger value="systems">Systems</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">System Health</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {systemHealth.filter(s => s.status === 'healthy').length}/{systemHealth.length}
                </div>
                <p className="text-xs text-muted-foreground">
                  Systems operational
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">CPU Usage</CardTitle>
                <Cpu className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${getMetricColor(performanceMetrics.cpu)}`}>
                  {performanceMetrics.cpu.toFixed(1)}%
                </div>
                <p className="text-xs text-muted-foreground">
                  Current utilization
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Response Time</CardTitle>
                <Zap className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${getMetricColor(100 - (performanceMetrics.responseTime / 200) * 100)}`}>
                  {performanceMetrics.responseTime.toFixed(0)}ms
                </div>
                <p className="text-xs text-muted-foreground">
                  Average response
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Code Quality</CardTitle>
                <Code className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${getMetricColor(developmentMetrics.codeQuality)}`}>
                  {developmentMetrics.codeQuality.toFixed(0)}%
                </div>
                <p className="text-xs text-muted-foreground">
                  Quality score
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>System Health Status</CardTitle>
                <CardDescription>
                  Current status of all system components
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {systemHealth.map((system) => (
                  <div key={system.id} className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${getStatusColor(system.status)}`} />
                      <span className="font-medium">{system.name}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={system.status === 'healthy' ? 'default' : system.status === 'warning' ? 'secondary' : 'destructive'}>
                        {getStatusText(system.status)}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        {system.performance.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Development Progress</CardTitle>
                <CardDescription>
                  Current development metrics and progress
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Test Coverage</span>
                    <span>{developmentMetrics.testCoverage.toFixed(0)}%</span>
                  </div>
                  <Progress value={developmentMetrics.testCoverage} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Feature Completion</span>
                    <span>{developmentMetrics.featureCompletion.toFixed(0)}%</span>
                  </div>
                  <Progress value={developmentMetrics.featureCompletion} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Documentation</span>
                    <span>{developmentMetrics.documentation.toFixed(0)}%</span>
                  </div>
                  <Progress value={developmentMetrics.documentation} className="h-2" />
                </div>
                <Button 
                  onClick={handleAnalyzeCode} 
                  disabled={isAnalyzing}
                  className="w-full"
                  variant="outline"
                >
                  <GitBranch className="mr-2 h-4 w-4" />
                  {isAnalyzing ? 'Analyzing...' : 'Analyze Code'}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Resource Utilization</CardTitle>
                <CardDescription>
                  Current system resource usage
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>CPU Usage</span>
                    <span>{performanceMetrics.cpu.toFixed(1)}%</span>
                  </div>
                  <Progress value={performanceMetrics.cpu} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Memory Usage</span>
                    <span>{performanceMetrics.memory.toFixed(1)}%</span>
                  </div>
                  <Progress value={performanceMetrics.memory} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Storage Usage</span>
                    <span>{performanceMetrics.storage.toFixed(1)}%</span>
                  </div>
                  <Progress value={performanceMetrics.storage} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Network Usage</span>
                    <span>{performanceMetrics.network.toFixed(1)}%</span>
                  </div>
                  <Progress value={performanceMetrics.network} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
                <CardDescription>
                  Application performance indicators
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-muted-foreground" />
                    <span>Response Time</span>
                  </div>
                  <span className={`font-semibold ${getMetricColor(100 - (performanceMetrics.responseTime / 200) * 100)}`}>
                    {performanceMetrics.responseTime.toFixed(0)}ms
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                    <span>Throughput</span>
                  </div>
                  <span className={`font-semibold ${getMetricColor((performanceMetrics.throughput / 2000) * 100)}`}>
                    {performanceMetrics.throughput.toFixed(0)} req/s
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Network className="h-4 w-4 text-muted-foreground" />
                    <span>Error Rate</span>
                  </div>
                  <span className="font-semibold text-green-600">
                    0.2%
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span>Active Users</span>
                  </div>
                  <span className="font-semibold">
                    1,247
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="development" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Code Quality Metrics</CardTitle>
                <CardDescription>
                  Software development quality indicators
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Overall Quality Score</span>
                  <Badge variant={developmentMetrics.codeQuality >= 80 ? 'default' : developmentMetrics.codeQuality >= 60 ? 'secondary' : 'destructive'}>
                    {developmentMetrics.codeQuality.toFixed(0)}%
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Test Coverage</span>
                  <span>{developmentMetrics.testCoverage.toFixed(0)}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Bug Rate</span>
                  <span>{developmentMetrics.bugRate.toFixed(1)} per KLOC</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Documentation Coverage</span>
                  <span>{developmentMetrics.documentation.toFixed(0)}%</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Development Progress</CardTitle>
                <CardDescription>
                  Current development status and milestones
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Sprint Progress</span>
                    <span>{developmentMetrics.featureCompletion.toFixed(0)}%</span>
                  </div>
                  <Progress value={developmentMetrics.featureCompletion} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Authentication Module</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm">API Integration</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-yellow-600" />
                    <span className="text-sm">Dashboard UI</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="h-4 w-4 border-2 border-gray-300 rounded-full" />
                    <span className="text-sm">Reporting Module</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="systems" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>System Components</CardTitle>
              <CardDescription>
                Detailed status and information about all system components
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {systemHealth.map((system) => (
                  <div key={system.id} className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 border rounded-lg">
                    <div>
                      <div className="flex items-center space-x-2">
                        <div className={`w-3 h-3 rounded-full ${getStatusColor(system.status)}`} />
                        <span className="font-medium">{system.name}</span>
                      </div>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Performance</span>
                      <div className="font-semibold">{system.performance.toFixed(0)}%</div>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Uptime</span>
                      <div className="font-semibold">{system.uptime.toFixed(1)}%</div>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Last Check</span>
                      <div className="font-semibold">
                        {Math.floor((Date.now() - system.lastCheck) / 1000)}s ago
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}