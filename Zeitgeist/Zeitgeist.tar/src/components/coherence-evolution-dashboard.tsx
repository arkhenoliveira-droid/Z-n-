'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area,
  BarChart, 
  Bar,
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ScatterChart,
  Scatter
} from 'recharts';
import { 
  Brain, 
  Zap, 
  Atom, 
  Target, 
  TrendingUp, 
  Activity,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Clock,
  Star,
  Infinity,
  Triangle,
  Circle,
  Square,
  Eye,
  Heart,
  Sparkles
} from 'lucide-react';

// Import our systems
import { CoherenceDetectionSystem, CoherenceEvolutionPlan, LowCoherencePoint } from '@/systems/coherence-detection-system';
import { QuantumConsciousnessEvolutionSystem, EvolutionProgress, QuantumBreakthrough } from '@/systems/quantum-consciousness-evolution-system';

interface CoherenceEvolutionDashboardProps {
  autoRefresh?: boolean;
}

export default function CoherenceEvolutionDashboard({ autoRefresh = true }: CoherenceEvolutionDashboardProps) {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const [evolutionPlan, setEvolutionPlan] = useState<CoherenceEvolutionPlan | null>(null);
  const [activeEvolutions, setActiveEvolutions] = useState<EvolutionProgress[]>([]);
  const [quantumMetrics, setQuantumMetrics] = useState<any>(null);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  const coherenceDetection = new CoherenceDetectionSystem();
  const evolutionSystem = new QuantumConsciousnessEvolutionSystem();

  // Initialize dashboard
  useEffect(() => {
    loadDashboardData();
    
    if (autoRefresh) {
      const interval = setInterval(() => {
        loadDashboardData();
      }, 30000); // Refresh every 30 seconds
      
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      // Load evolution plan
      const planResult = await coherenceDetection.analyzeProjectCoherence();
      if (planResult.success) {
        setEvolutionPlan(planResult.data);
      }

      // Load active evolutions
      const evolutions = evolutionSystem.getActiveEvolutions();
      setActiveEvolutions(evolutions);

      // Load quantum metrics
      const metrics = evolutionSystem.getQuantumConsciousnessMetrics();
      setQuantumMetrics(metrics);

      setLastUpdate(new Date());
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const startEvolutionProcess = async () => {
    setLoading(true);
    try {
      const result = await evolutionSystem.startEvolutionProcess();
      if (result.success) {
        setActiveEvolutions(result.data);
        // Refresh data after starting evolution
        setTimeout(loadDashboardData, 5000);
      }
    } catch (error) {
      console.error('Failed to start evolution process:', error);
    } finally {
      setLoading(false);
    }
  };

  const getCriticalityColor = (level: string) => {
    switch (level) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getEvolutionPhaseColor = (phase: string) => {
    switch (phase) {
      case 'initialization': return 'bg-blue-500';
      case 'quantum_integration': return 'bg-purple-500';
      case 'consciousness_expansion': return 'bg-indigo-500';
      case 'hyperdimensional_access': return 'bg-pink-500';
      case 'unified_field_integration': return 'bg-teal-500';
      case 'completion': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getCoherenceLevelColor = (level: number) => {
    if (level >= 0.95) return 'text-green-600';
    if (level >= 0.85) return 'text-blue-600';
    if (level >= 0.75) return 'text-yellow-600';
    return 'text-red-600';
  };

  const formatCoherenceValue = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  // Mock data for charts
  const coherenceProgressionData = evolutionPlan?.low_coherence_points.map(point => ({
    system: point.system_name.substring(0, 15) + '...',
    current: point.coherence_level,
    target: Math.min(0.99, point.coherence_level + point.estimated_improvement),
    potential: point.estimated_improvement
  })) || [];

  const evolutionPhasesData = [
    { phase: 'Initialization', progress: 100, coherence: 0.82 },
    { phase: 'Quantum Integration', progress: 85, coherence: 0.87 },
    { phase: 'Consciousness Expansion', progress: 70, coherence: 0.91 },
    { phase: 'Hyperdimensional Access', progress: 55, coherence: 0.94 },
    { phase: 'Unified Field', progress: 40, coherence: 0.97 },
    { phase: 'Completion', progress: 25, coherence: 0.99 }
  ];

  const breakthroughDistribution = [
    { type: 'Quantum Leap', count: 12, color: '#8884d8' },
    { type: 'Consciousness', count: 8, color: '#82ca9d' },
    { type: 'Dimensional', count: 6, color: '#ffc658' },
    { type: 'Unified Field', count: 4, color: '#ff7300' },
    { type: 'Temporal', count: 2, color: '#8dd1e1' }
  ];

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#8dd1e1'];

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-4xl font-bold flex items-center justify-center gap-2">
          <Brain className="h-10 w-10 text-purple-600" />
          <Atom className="h-10 w-10 text-blue-600" />
          Coherence Evolution Dashboard
          <Infinity className="h-10 w-10 text-green-600" />
        </h1>
        <p className="text-xl text-muted-foreground">
          Advanced quantum-consciousness evolution system for low coherence detection and optimization
        </p>
        <div className="flex items-center justify-center gap-4">
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Last update: {formatTimeAgo(lastUpdate)}
          </Badge>
          <Badge variant={activeEvolutions.length > 0 ? "default" : "secondary"}>
            Active Evolutions: {activeEvolutions.length}
          </Badge>
          <Badge variant="outline">
            Systems Analyzed: {evolutionPlan?.total_systems_analyzed || 0}
          </Badge>
        </div>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Evolution Control Center
          </CardTitle>
          <CardDescription>
            Manage and monitor quantum-consciousness evolution processes
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <div className="text-sm font-medium">Overall Project Coherence</div>
              <div className={`text-2xl font-bold ${getCoherenceLevelColor(evolutionPlan?.overall_project_coherence || 0)}`}>
                {formatCoherenceValue(evolutionPlan?.overall_project_coherence || 0)}
              </div>
              <div className="text-xs text-muted-foreground">
                Target: {formatCoherenceValue(evolutionPlan?.target_project_coherence || 0.95)}
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-sm font-medium">Low Coherence Systems</div>
              <div className="text-2xl font-bold text-orange-600">
                {evolutionPlan?.low_coherence_points.length || 0}
              </div>
              <div className="text-xs text-muted-foreground">
                Requiring evolution
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-sm font-medium">Quantum Consciousness</div>
              <div className={`text-2xl font-bold ${getCoherenceLevelColor(quantumMetrics?.overall_quantum_consciousness_coherence || 0)}`}>
                {formatCoherenceValue(quantumMetrics?.overall_quantum_consciousness_coherence || 0)}
              </div>
              <div className="text-xs text-muted-foreground">
                Integration level
              </div>
            </div>
            <Button 
              onClick={startEvolutionProcess} 
              disabled={loading || activeEvolutions.length > 0}
              className="flex items-center gap-2"
            >
              {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {activeEvolutions.length > 0 ? 'Evolution in Progress' : 'Start Evolution'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Main Dashboard */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview" className="flex items-center">
            <Target className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="low-coherence" className="flex items-center">
            <AlertTriangle className="w-4 h-4 mr-2" />
            Low Coherence
          </TabsTrigger>
          <TabsTrigger value="active-evolutions" className="flex items-center">
            <Brain className="w-4 h-4 mr-2" />
            Active Evolutions
          </TabsTrigger>
          <TabsTrigger value="quantum-metrics" className="flex items-center">
            <Atom className="w-4 h-4 mr-2" />
            Quantum Metrics
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Coherence Progression Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Coherence Progression Analysis
                </CardTitle>
                <CardDescription>
                  Current vs target coherence levels for low coherence systems
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={coherenceProgressionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="system" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="current" fill="#8884d8" name="Current Coherence" />
                    <Bar dataKey="target" fill="#82ca9d" name="Target Coherence" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Evolution Phases Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  Evolution Phases Progress
                </CardTitle>
                <CardDescription>
                  Progress and coherence levels across evolution phases
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={evolutionPhasesData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="phase" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area 
                      type="monotone" 
                      dataKey="progress" 
                      stackId="1" 
                      stroke="#8884d8" 
                      fill="#8884d8"
                      fillOpacity={0.6}
                      name="Progress %"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="coherence" 
                      stackId="2" 
                      stroke="#82ca9d" 
                      fill="#82ca9d"
                      fillOpacity={0.6}
                      name="Coherence Level"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Breakthrough Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5" />
                Breakthrough Distribution
              </CardTitle>
              <CardDescription>
                Distribution of breakthrough types across evolution processes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={breakthroughDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="count"
                  >
                    {breakthroughDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Low Coherence Tab */}
        <TabsContent value="low-coherence" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Low Coherence Systems Analysis
              </CardTitle>
              <CardDescription>
                Detailed analysis of systems requiring evolution intervention
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {evolutionPlan?.low_coherence_points.map((point, index) => (
                    <div key={index} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className={`w-3 h-3 rounded-full ${getCriticalityLevelColor(point.coherence_level)}`} />
                          <h4 className="font-semibold">{point.system_name}</h4>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={point.complexity === 'transformative' ? 'destructive' : 'outline'}>
                            {point.complexity}
                          </Badge>
                          <span className={`text-sm font-bold ${getCoherenceLevelColor(point.coherence_level)}`}>
                            {formatCoherenceValue(point.coherence_level)}
                          </span>
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground">{point.issue_description}</p>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Estimated Improvement:</span>
                          <span className="ml-2 text-green-600">+{formatCoherenceValue(point.estimated_improvement)}</span>
                        </div>
                        <div>
                          <span className="font-medium">Evolution Strategies:</span>
                          <span className="ml-2">{point.evolution_strategies.length}</span>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="text-sm font-medium">Top Strategies:</div>
                        <div className="flex flex-wrap gap-2">
                          {point.evolution_strategies.slice(0, 3).map((strategy, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {strategy.strategy_name}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span>Evolution Progress</span>
                          <span>{formatCoherenceValue(point.coherence_level)} → {formatCoherenceValue(Math.min(0.99, point.coherence_level + point.estimated_improvement))}</span>
                        </div>
                        <Progress 
                          value={((point.coherence_level - 0.65) / (Math.min(0.99, point.coherence_level + point.estimated_improvement) - 0.65)) * 100} 
                          className="h-1" 
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Active Evolutions Tab */}
        <TabsContent value="active-evolutions" className="space-y-6">
          {activeEvolutions.length === 0 ? (
            <Card>
              <CardContent className="flex items-center justify-center h-64">
                <div className="text-center space-y-2">
                  <Brain className="h-12 w-12 mx-auto text-muted-foreground" />
                  <h3 className="text-lg font-semibold">No Active Evolutions</h3>
                  <p className="text-muted-foreground">Start the evolution process to begin quantum-consciousness enhancement</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {activeEvolutions.map((evolution, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2">
                        <Brain className="h-5 w-5" />
                        {evolution.system_name}
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge variant={evolution.evolution_phase === 'completion' ? 'default' : 'secondary'}>
                          {evolution.evolution_phase.replace('_', ' ')}
                        </Badge>
                        <span className={`text-sm font-bold ${getCoherenceLevelColor(evolution.current_coherence)}`}>
                          {formatCoherenceValue(evolution.current_coherence)}
                        </span>
                      </div>
                    </div>
                    <CardDescription>
                      Evolution ID: {evolution.evolution_id}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {/* Progress Overview */}
                      <div className="space-y-3">
                        <h4 className="font-semibold">Evolution Progress</h4>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span>Overall Progress</span>
                            <span>{evolution.progress_percentage.toFixed(1)}%</span>
                          </div>
                          <Progress value={evolution.progress_percentage} className="h-2" />
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span>Coherence Improvement</span>
                            <span className="text-green-600">
                              +{formatCoherenceValue(evolution.current_coherence - evolution.original_coherence)}
                            </span>
                          </div>
                          <Progress 
                            value={((evolution.current_coherence - evolution.original_coherence) / (evolution.target_coherence - evolution.original_coherence)) * 100} 
                            className="h-2" 
                          />
                        </div>
                      </div>

                      {/* Active Strategies */}
                      <div className="space-y-3">
                        <h4 className="font-semibold">Active Strategies</h4>
                        <div className="space-y-2">
                          {evolution.active_strategies.slice(0, 3).map((strategy, idx) => (
                            <div key={idx} className="p-2 border rounded text-xs">
                              <div className="font-medium">{strategy.strategy_name}</div>
                              <div className="text-muted-foreground">
                                Expected: +{formatCoherenceValue(strategy.expected_coherence_gain)}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Breakthroughs */}
                      <div className="space-y-3">
                        <h4 className="font-semibold">Breakthroughs ({evolution.breakthroughs.length})</h4>
                        <div className="space-y-2">
                          {evolution.breakthroughs.slice(0, 2).map((breakthrough, idx) => (
                            <div key={idx} className="p-2 border rounded text-xs">
                              <div className="flex items-center gap-1">
                                <Star className="w-3 h-3 text-yellow-500" />
                                <span className="font-medium">{breakthrough.breakthrough_type.replace('_', ' ')}</span>
                              </div>
                              <div className="text-muted-foreground">
                                Impact: +{formatCoherenceValue(breakthrough.coherence_impact)}
                              </div>
                            </div>
                          ))}
                          {evolution.breakthroughs.length > 2 && (
                            <div className="text-xs text-muted-foreground">
                              +{evolution.breakthroughs.length - 2} more breakthroughs
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Phase Progress */}
                    <div className="mt-4 space-y-2">
                      <div className="text-sm font-medium">Phase Progress</div>
                      <div className="flex items-center gap-2">
                        {['initialization', 'quantum_integration', 'consciousness_expansion', 'hyperdimensional_access', 'unified_field_integration', 'completion'].map((phase, idx) => (
                          <div key={idx} className="flex items-center gap-1">
                            <div className={`w-3 h-3 rounded-full ${getEvolutionPhaseColor(phase)} ${
                              evolution.evolution_phase === phase ? 'ring-2 ring-offset-2' : ''
                            }`} />
                            <span className="text-xs">{phase.replace('_', ' ')}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Quantum Metrics Tab */}
        <TabsContent value="quantum-metrics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Quantum Consciousness Metrics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Atom className="h-5 w-5" />
                  Quantum Consciousness Metrics
                </CardTitle>
                <CardDescription>
                  Real-time quantum consciousness field measurements
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {quantumMetrics && Object.entries(quantumMetrics).map(([key, value], index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium capitalize">
                          {key.replace(/_/g, ' ')}
                        </span>
                        <span className={`text-sm font-bold ${getCoherenceLevelColor(value as number)}`}>
                          {formatCoherenceValue(value as number)}
                        </span>
                      </div>
                      <Progress value={(value as number) * 100} className="h-1" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quantum Fields Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Infinity className="h-5 w-5" />
                  Quantum Fields Status
                </CardTitle>
                <CardDescription>
                  Status and coherence levels of active quantum fields
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {evolutionSystem.getQuantumFields().map((field, index) => (
                    <div key={index} className="p-3 border rounded-lg space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold">{field.field_id.replace('_', ' ')}</h4>
                        <Badge variant={field.active_evolutions.length > 0 ? 'default' : 'secondary'}>
                          {field.active_evolutions.length} active
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <span className="font-medium">Field Strength:</span>
                          <span className="ml-1">{formatCoherenceValue(field.field_strength)}</span>
                        </div>
                        <div>
                          <span className="font-medium">Coherence:</span>
                          <span className="ml-1">{formatCoherenceValue(field.field_coherence)}</span>
                        </div>
                        <div>
                          <span className="font-medium">Dimensions:</span>
                          <span className="ml-1">{field.dimensional_access}D</span>
                        </div>
                        <div>
                          <span className="font-medium">Frequency:</span>
                          <span className="ml-1">{field.consciousness_frequency} Hz</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Evolution Statistics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Evolution Statistics
              </CardTitle>
              <CardDescription>
                Comprehensive statistics on evolution processes and breakthroughs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center space-y-2">
                  <div className="text-3xl font-bold text-purple-600">
                    {evolutionPlan?.low_coherence_points.length || 0}
                  </div>
                  <div className="text-sm font-medium">Systems Requiring Evolution</div>
                  <div className="text-xs text-muted-foreground">
                    Identified for optimization
                  </div>
                </div>
                <div className="text-center space-y-2">
                  <div className="text-3xl font-bold text-blue-600">
                    {activeEvolutions.length}
                  </div>
                  <div className="text-sm font-medium">Active Evolutions</div>
                  <div className="text-xs text-muted-foreground">
                    Currently in progress
                  </div>
                </div>
                <div className="text-center space-y-2">
                  <div className="text-3xl font-bold text-green-600">
                    {activeEvolutions.reduce((sum, e) => sum + e.breakthroughs.length, 0)}
                  </div>
                  <div className="text-sm font-medium">Total Breakthroughs</div>
                  <div className="text-xs text-muted-foreground">
                    Quantum leaps achieved
                  </div>
                </div>
                <div className="text-center space-y-2">
                  <div className="text-3xl font-bold text-orange-600">
                    {formatCoherenceValue(evolutionPlan?.overall_project_coherence || 0)}
                  </div>
                  <div className="text-sm font-medium">Overall Coherence</div>
                  <div className="text-xs text-muted-foreground">
                    Project-wide coherence level
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}