'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Upload, 
  Download, 
  Plus, 
  Trash2, 
  Eye,
  Edit,
  Save,
  RotateCcw,
  Palette,
  Sparkles,
  Star,
  Circle,
  Square,
  Triangle,
  Hexagon,
  Diamond
} from 'lucide-react';

// Glyph types and interfaces
export interface GlyphDefinition {
  id: string;
  name: string;
  symbol: string;
  description: string;
  category: 'geometric' | 'spiritual' | 'quantum' | 'cosmic' | 'mathematical';
  color: string;
  size: number;
  rotation: number;
  metadata: Record<string, any>;
  svg?: string; // Optional SVG path data
  imageData?: string; // Base64 encoded image data
}

export interface GlyphInstance {
  id: string;
  glyphId: string;
  position: [number, number, number];
  rotation: number;
  scale: number;
  opacity: number;
  animation?: {
    type: 'pulse' | 'rotate' | 'orbit' | 'float';
    speed: number;
    amplitude: number;
  };
}

export interface GlyphSystemConfig {
  maxGlyphs: number;
  defaultSize: number;
  defaultColor: string;
  enableAnimations: boolean;
  enableInteractions: boolean;
  renderMode: 'svg' | 'canvas' | 'webgl';
}

interface HLZGlyphSystemProps {
  glyphs?: GlyphDefinition[];
  instances?: GlyphInstance[];
  config?: Partial<GlyphSystemConfig>;
  onGlyphSelect?: (glyph: GlyphDefinition) => void;
  onInstanceUpdate?: (instance: GlyphInstance) => void;
  className?: string;
}

// Predefined glyph library
const PREDEFINED_GLYPHS: GlyphDefinition[] = [
  {
    id: 'phi_spiral',
    name: 'Phi Spiral',
    symbol: '⟲',
    description: 'Golden ratio spiral representing harmonic resonance',
    category: 'mathematical',
    color: '#FFD700',
    size: 32,
    rotation: 0,
    metadata: { phi: 1.618, sacredGeometry: true }
  },
  {
    id: 'quantum_entanglement',
    name: 'Quantum Entanglement',
    symbol: '⚛',
    description: 'Quantum entanglement symbol',
    category: 'quantum',
    color: '#00CED1',
    size: 28,
    rotation: 0,
    metadata: { quantum: true, entanglement: true }
  },
  {
    id: 'sacred_triangle',
    name: 'Sacred Triangle',
    symbol: '▲',
    description: 'Sacred geometric triangle',
    category: 'geometric',
    color: '#FF6347',
    size: 30,
    rotation: 0,
    metadata: { sacredGeometry: true, elements: 3 }
  },
  {
    id: 'cosmic_eye',
    name: 'Cosmic Eye',
    symbol: '◉',
    description: 'All-seeing cosmic eye',
    category: 'cosmic',
    color: '#9370DB',
    size: 35,
    rotation: 0,
    metadata: { cosmic: true, perception: true }
  },
  {
    id: 'spiritual_star',
    name: 'Spiritual Star',
    symbol: '★',
    description: 'Five-pointed spiritual star',
    category: 'spiritual',
    color: '#FF1493',
    size: 32,
    rotation: 0,
    metadata: { spiritual: true, points: 5 }
  },
  {
    id: 'infinity_loop',
    name: 'Infinity Loop',
    symbol: '∞',
    description: 'Infinity symbol representing eternal cycles',
    category: 'mathematical',
    color: '#32CD32',
    size: 36,
    rotation: 0,
    metadata: { infinity: true, cycles: true }
  },
  {
    id: 'hexagon_flower',
    name: 'Hexagon Flower',
    symbol: '⬢',
    description: 'Sacred hexagonal pattern',
    category: 'geometric',
    color: '#FF69B4',
    size: 34,
    rotation: 0,
    metadata: { sacredGeometry: true, sides: 6 }
  },
  {
    id: 'quantum_wave',
    name: 'Quantum Wave',
    symbol: '〜',
    description: 'Quantum wave function',
    category: 'quantum',
    color: '#00BFFF',
    size: 40,
    rotation: 0,
    metadata: { quantum: true, wave: true }
  }
];

export default function HLZGlyphSystem({ 
  glyphs = PREDEFINED_GLYPHS,
  instances = [],
  config = {},
  onGlyphSelect,
  onInstanceUpdate,
  className = ""
}: HLZGlyphSystemProps) {
  const [glyphDefinitions, setGlyphDefinitions] = useState<GlyphDefinition[]>(glyphs);
  const [glyphInstances, setGlyphInstances] = useState<GlyphInstance[]>(instances);
  const [selectedGlyph, setSelectedGlyph] = useState<GlyphDefinition | null>(null);
  const [selectedInstance, setSelectedInstance] = useState<GlyphInstance | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [newGlyph, setNewGlyph] = useState<Partial<GlyphDefinition>>({
    name: '',
    symbol: '',
    description: '',
    category: 'geometric',
    color: '#ffffff',
    size: 32,
    rotation: 0,
    metadata: {}
  });
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const defaultConfig: GlyphSystemConfig = {
    maxGlyphs: 100,
    defaultSize: 32,
    defaultColor: '#ffffff',
    enableAnimations: true,
    enableInteractions: true,
    renderMode: 'canvas',
    ...config
  };

  // Animation loop
  useEffect(() => {
    if (!defaultConfig.enableAnimations || defaultConfig.renderMode !== 'canvas') return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Render glyph instances
      glyphInstances.forEach(instance => {
        const glyph = glyphDefinitions.find(g => g.id === instance.glyphId);
        if (!glyph) return;

        const [x, y, z] = instance.position;
        const screenX = (x + 2) * canvas.width / 4; // Map from [-2, 2] to [0, width]
        const screenY = (y + 2) * canvas.height / 4; // Map from [-2, 2] to [0, height]

        ctx.save();
        ctx.translate(screenX, screenY);
        ctx.rotate(instance.rotation);
        ctx.scale(instance.scale, instance.scale);
        ctx.globalAlpha = instance.opacity;

        // Apply animation
        if (instance.animation) {
          const time = Date.now() / 1000;
          switch (instance.animation.type) {
            case 'pulse':
              const pulseScale = 1 + Math.sin(time * instance.animation.speed) * instance.animation.amplitude * 0.1;
              ctx.scale(pulseScale, pulseScale);
              break;
            case 'rotate':
              ctx.rotate(time * instance.animation.speed);
              break;
            case 'float':
              ctx.translate(0, Math.sin(time * instance.animation.speed) * instance.animation.amplitude * 10);
              break;
          }
        }

        // Render glyph
        ctx.fillStyle = glyph.color;
        ctx.font = `${glyph.size}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(glyph.symbol, 0, 0);

        // Highlight selected instance
        if (selectedInstance?.id === instance.id) {
          ctx.strokeStyle = '#ffff00';
          ctx.lineWidth = 2;
          ctx.strokeRect(-glyph.size/2, -glyph.size/2, glyph.size, glyph.size);
        }

        ctx.restore();
      });

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
    };
  }, [glyphInstances, glyphDefinitions, selectedInstance, defaultConfig]);

  const handleGlyphSelect = (glyph: GlyphDefinition) => {
    setSelectedGlyph(glyph);
    setSelectedInstance(null);
    if (onGlyphSelect) {
      onGlyphSelect(glyph);
    }
  };

  const handleInstanceCreate = (glyph: GlyphDefinition) => {
    const newInstance: GlyphInstance = {
      id: `instance_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      glyphId: glyph.id,
      position: [Math.random() * 4 - 2, Math.random() * 4 - 2, 0], // Random position in [-2, 2]
      rotation: 0,
      scale: 1,
      opacity: 1,
      animation: {
        type: 'pulse',
        speed: 1,
        amplitude: 0.5
      }
    };

    setGlyphInstances(prev => [...prev, newInstance]);
    setSelectedInstance(newInstance);
  };

  const handleInstanceUpdate = (updates: Partial<GlyphInstance>) => {
    if (!selectedInstance) return;

    const updatedInstance = { ...selectedInstance, ...updates };
    setGlyphInstances(prev => 
      prev.map(instance => 
        instance.id === selectedInstance.id ? updatedInstance : instance
      )
    );
    setSelectedInstance(updatedInstance);
    
    if (onInstanceUpdate) {
      onInstanceUpdate(updatedInstance);
    }
  };

  const handleInstanceDelete = (instanceId: string) => {
    setGlyphInstances(prev => prev.filter(instance => instance.id !== instanceId));
    if (selectedInstance?.id === instanceId) {
      setSelectedInstance(null);
    }
  };

  const handleGlyphCreate = () => {
    if (!newGlyph.name || !newGlyph.symbol) return;

    const glyph: GlyphDefinition = {
      id: `glyph_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: newGlyph.name,
      symbol: newGlyph.symbol,
      description: newGlyph.description || '',
      category: newGlyph.category || 'geometric',
      color: newGlyph.color || '#ffffff',
      size: newGlyph.size || 32,
      rotation: 0,
      metadata: newGlyph.metadata || {}
    };

    setGlyphDefinitions(prev => [...prev, glyph]);
    setNewGlyph({
      name: '',
      symbol: '',
      description: '',
      category: 'geometric',
      color: '#ffffff',
      size: 32,
      rotation: 0,
      metadata: {}
    });
    setIsEditing(false);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const imageData = e.target?.result as string;
      if (selectedGlyph) {
        setGlyphDefinitions(prev => 
          prev.map(glyph => 
            glyph.id === selectedGlyph.id 
              ? { ...glyph, imageData }
              : glyph
          )
        );
      }
    };
    reader.readAsDataURL(file);
  };

  const exportGlyphs = () => {
    const data = {
      glyphs: glyphDefinitions,
      instances: glyphInstances,
      config: defaultConfig,
      timestamp: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'hlz-glyphs.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  const categorizedGlyphs = glyphDefinitions.reduce((acc, glyph) => {
    if (!acc[glyph.category]) {
      acc[glyph.category] = [];
    }
    acc[glyph.category].push(glyph);
    return acc;
  }, {} as Record<string, GlyphDefinition[]>);

  return (
    <div className={`space-y-4 ${className}`}>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                HLZ Glyph System
              </CardTitle>
              <CardDescription>
                Manage and visualize symbolic glyphs for HLZ orbital dynamics
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={exportGlyphs}>
                <Download className="w-4 h-4" />
                Export
              </Button>
              <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                <Plus className="w-4 h-4" />
                New Glyph
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="library" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="library">Glyph Library</TabsTrigger>
              <TabsTrigger value="instances">Instances</TabsTrigger>
              <TabsTrigger value="canvas">Canvas</TabsTrigger>
            </TabsList>
            
            <TabsContent value="library" className="space-y-4">
              {isEditing && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Create New Glyph</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="glyph-name">Name</Label>
                        <Input
                          id="glyph-name"
                          value={newGlyph.name}
                          onChange={(e) => setNewGlyph(prev => ({ ...prev, name: e.target.value }))}
                          placeholder="Enter glyph name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="glyph-symbol">Symbol</Label>
                        <Input
                          id="glyph-symbol"
                          value={newGlyph.symbol}
                          onChange={(e) => setNewGlyph(prev => ({ ...prev, symbol: e.target.value }))}
                          placeholder="Enter symbol"
                        />
                      </div>
                      <div>
                        <Label htmlFor="glyph-category">Category</Label>
                        <select
                          id="glyph-category"
                          value={newGlyph.category}
                          onChange={(e) => setNewGlyph(prev => ({ ...prev, category: e.target.value as any }))}
                          className="w-full p-2 border rounded"
                        >
                          <option value="geometric">Geometric</option>
                          <option value="spiritual">Spiritual</option>
                          <option value="quantum">Quantum</option>
                          <option value="cosmic">Cosmic</option>
                          <option value="mathematical">Mathematical</option>
                        </select>
                      </div>
                      <div>
                        <Label htmlFor="glyph-color">Color</Label>
                        <Input
                          id="glyph-color"
                          type="color"
                          value={newGlyph.color}
                          onChange={(e) => setNewGlyph(prev => ({ ...prev, color: e.target.value }))}
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="glyph-description">Description</Label>
                      <Textarea
                        id="glyph-description"
                        value={newGlyph.description}
                        onChange={(e) => setNewGlyph(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Enter glyph description"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <Button onClick={handleGlyphCreate}>
                        <Save className="w-4 h-4" />
                        Create Glyph
                      </Button>
                      <Button variant="outline" onClick={() => setIsEditing(false)}>
                        <RotateCcw className="w-4 h-4" />
                        Cancel
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="space-y-4">
                {Object.entries(categorizedGlyphs).map(([category, glyphs]) => (
                  <Card key={category}>
                    <CardHeader>
                      <CardTitle className="text-lg capitalize">{category}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                        {glyphs.map((glyph) => (
                          <div
                            key={glyph.id}
                            className={`p-4 border rounded-lg cursor-pointer transition-all ${
                              selectedGlyph?.id === glyph.id
                                ? 'border-blue-500 bg-blue-50'
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                            onClick={() => handleGlyphSelect(glyph)}
                          >
                            <div className="text-center space-y-2">
                              <div
                                className="text-2xl mx-auto"
                                style={{ color: glyph.color }}
                              >
                                {glyph.symbol}
                              </div>
                              <div className="text-xs font-medium">{glyph.name}</div>
                              <Badge variant="outline" className="text-xs">
                                {glyph.category}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="instances" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Glyph Instances</h3>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">
                    {glyphInstances.length} instances
                  </Badge>
                  {selectedGlyph && (
                    <Button
                      size="sm"
                      onClick={() => handleInstanceCreate(selectedGlyph)}
                    >
                      <Plus className="w-4 h-4" />
                      Add Instance
                    </Button>
                  )}
                </div>
              </div>

              {selectedInstance && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Edit Instance</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label>Position X</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={selectedInstance.position[0]}
                          onChange={(e) => handleInstanceUpdate({
                            position: [
                              parseFloat(e.target.value),
                              selectedInstance.position[1],
                              selectedInstance.position[2]
                            ]
                          })}
                        />
                      </div>
                      <div>
                        <Label>Position Y</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={selectedInstance.position[1]}
                          onChange={(e) => handleInstanceUpdate({
                            position: [
                              selectedInstance.position[0],
                              parseFloat(e.target.value),
                              selectedInstance.position[2]
                            ]
                          })}
                        />
                      </div>
                      <div>
                        <Label>Rotation</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={selectedInstance.rotation}
                          onChange={(e) => handleInstanceUpdate({
                            rotation: parseFloat(e.target.value)
                          })}
                        />
                      </div>
                      <div>
                        <Label>Scale</Label>
                        <Input
                          type="number"
                          step="0.1"
                          min="0.1"
                          value={selectedInstance.scale}
                          onChange={(e) => handleInstanceUpdate({
                            scale: parseFloat(e.target.value)
                          })}
                        />
                      </div>
                      <div>
                        <Label>Opacity</Label>
                        <Input
                          type="number"
                          step="0.1"
                          min="0"
                          max="1"
                          value={selectedInstance.opacity}
                          onChange={(e) => handleInstanceUpdate({
                            opacity: parseFloat(e.target.value)
                          })}
                        />
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleInstanceDelete(selectedInstance.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                        Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {glyphInstances.map((instance) => {
                  const glyph = glyphDefinitions.find(g => g.id === instance.glyphId);
                  if (!glyph) return null;

                  return (
                    <Card
                      key={instance.id}
                      className={`cursor-pointer transition-all ${
                        selectedInstance?.id === instance.id
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => setSelectedInstance(instance)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div
                              className="text-2xl"
                              style={{ color: glyph.color }}
                            >
                              {glyph.symbol}
                            </div>
                            <div>
                              <div className="font-medium">{glyph.name}</div>
                              <div className="text-xs text-gray-500">
                                Position: ({instance.position[0].toFixed(1)}, {instance.position[1].toFixed(1)})
                              </div>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleInstanceDelete(instance.id);
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>
            
            <TabsContent value="canvas" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Glyph Canvas</h3>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">
                    {glyphInstances.length} glyphs rendered
                  </Badge>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    style={{ display: 'none' }}
                  />
                  {selectedGlyph && (
                    <Button
                      size="sm"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Upload className="w-4 h-4" />
                      Upload Image
                    </Button>
                  )}
                </div>
              </div>

              <div className="relative bg-black rounded-lg overflow-hidden">
                <canvas
                  ref={canvasRef}
                  width={800}
                  height={600}
                  className="w-full h-auto border border-gray-300"
                />
                <div className="absolute top-4 left-4 text-white text-sm bg-black bg-opacity-50 p-2 rounded">
                  Click and drag to interact with glyphs
                </div>
              </div>

              {selectedGlyph && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Selected Glyph</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4">
                      <div
                        className="text-4xl"
                        style={{ color: selectedGlyph.color }}
                      >
                        {selectedGlyph.symbol}
                      </div>
                      <div>
                        <div className="font-medium">{selectedGlyph.name}</div>
                        <div className="text-sm text-gray-600">{selectedGlyph.description}</div>
                        <Badge variant="outline" className="mt-1">
                          {selectedGlyph.category}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}