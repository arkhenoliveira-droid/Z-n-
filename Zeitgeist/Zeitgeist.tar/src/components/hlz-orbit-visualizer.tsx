'use client';

import React, { useEffect, useRef, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Download, 
  Settings,
  TrendingUp,
  Activity,
  Zap,
  Target,
  RefreshCw,
  Eye,
  Lightbulb,
  Layers,
  Infinity,
  Cpu,
  Atom,
  Waves,
  Calculator
} from 'lucide-react';

// Types for visualization
interface HLZOrbitData {
  positions: number[][][];  // [frame][body][coordinate]
  velocities: number[][][]; // [frame][body][coordinate]
  times: number[];          // [frame]
  energies: number[];        // [frame]
  modes: number[];          // [body]
  glyphs: string[];         // [body]
}

interface VisualizationSettings {
  showTrails: boolean;
  showVelocity: boolean;
  showEnergy: boolean;
  showGrid: boolean;
  showLabels: boolean;
  trailLength: number;
  animationSpeed: number;
  pointSize: number;
  colorByMode: boolean;
}

interface HLZOrbitVisualizerProps {
  data: HLZOrbitData;
  width?: number;
  height?: number;
  onFrameChange?: (frame: number) => void;
  className?: string;
}

export default function HLZOrbitVisualizer({ 
  data, 
  width = 800, 
  height = 600, 
  onFrameChange,
  className = ""
}: HLZOrbitVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const [currentFrame, setCurrentFrame] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [settings, setSettings] = useState<VisualizationSettings>({
    showTrails: true,
    showVelocity: false,
    showEnergy: true,
    showGrid: true,
    showLabels: true,
    trailLength: 50,
    animationSpeed: 1.0,
    pointSize: 6,
    colorByMode: true
  });

  // Colors for different modes
  const modeColors = {
    3: '#ff6b6b',  // Red for mode 3
    7: '#4ecdc4',  // Teal for mode 7
    5: '#45b7d1',  // Blue for mode 5
    11: '#96ceb4', // Green for mode 11
    13: '#feca57', // Yellow for mode 13
  };

  // Animation loop
  useEffect(() => {
    if (!isPlaying) return;

    const animate = () => {
      setCurrentFrame(prev => {
        const nextFrame = prev + settings.animationSpeed;
        if (nextFrame >= data.times.length) {
          setIsPlaying(false);
          return 0;
        }
        return nextFrame;
      });
      
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, settings.animationSpeed, data.times.length]);

  // Draw on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Set up coordinate system (center at origin)
    ctx.save();
    ctx.translate(width / 2, height / 2);
    const scale = Math.min(width, height) / 4;
    ctx.scale(scale, scale);

    // Draw grid if enabled
    if (settings.showGrid) {
      drawGrid(ctx);
    }

    // Draw trails if enabled
    if (settings.showTrails) {
      drawTrails(ctx);
    }

    // Draw current positions
    drawCurrentPositions(ctx);

    // Draw velocity vectors if enabled
    if (settings.showVelocity) {
      drawVelocityVectors(ctx);
    }

    // Draw labels if enabled
    if (settings.showLabels) {
      drawLabels(ctx);
    }

    ctx.restore();

    // Draw energy plot if enabled
    if (settings.showEnergy) {
      drawEnergyPlot(ctx);
    }

    // Notify parent of frame change
    if (onFrameChange) {
      onFrameChange(Math.floor(currentFrame));
    }
  }, [currentFrame, settings, data, width, height]);

  const drawGrid = (ctx: CanvasRenderingContext2D) => {
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 1 / Math.min(width, height) * 4;

    // Draw concentric circles
    for (let r = 0.5; r <= 3; r += 0.5) {
      ctx.beginPath();
      ctx.arc(0, 0, r, 0, 2 * Math.PI);
      ctx.stroke();
    }

    // Draw radial lines
    for (let angle = 0; angle < 2 * Math.PI; angle += Math.PI / 6) {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(angle) * 3, Math.sin(angle) * 3);
      ctx.stroke();
    }
  };

  const drawTrails = (ctx: CanvasRenderingContext2D) => {
    const trailStart = Math.max(0, currentFrame - settings.trailLength);
    
    data.modes.forEach((mode, bodyIndex) => {
      const color = settings.colorByMode ? 
        (modeColors as any)[mode] || '#ffffff' : 
        '#ffffff';
      
      ctx.strokeStyle = color;
      ctx.lineWidth = 2 / Math.min(width, height) * 4;
      ctx.globalAlpha = 0.6;
      
      ctx.beginPath();
      for (let frame = trailStart; frame <= currentFrame; frame++) {
        const pos = data.positions[frame][bodyIndex];
        const x = pos[0];
        const y = pos[1];
        
        if (frame === trailStart) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
      ctx.globalAlpha = 1;
    });
  };

  const drawCurrentPositions = (ctx: CanvasRenderingContext2D) => {
    const frame = Math.floor(currentFrame);
    
    data.modes.forEach((mode, bodyIndex) => {
      const pos = data.positions[frame][bodyIndex];
      const x = pos[0];
      const y = pos[1];
      const z = pos[2];
      
      const color = settings.colorByMode ? 
        (modeColors as any)[mode] || '#ffffff' : 
        '#ffffff';
      
      // Draw point
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(x, y, settings.pointSize / Math.min(width, height) * 4, 0, 2 * Math.PI);
      ctx.fill();
      
      // Draw glow effect
      const gradient = ctx.createRadialGradient(x, y, 0, x, y, settings.pointSize * 2 / Math.min(width, height) * 4);
      gradient.addColorStop(0, color);
      gradient.addColorStop(1, 'transparent');
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(x, y, settings.pointSize * 2 / Math.min(width, height) * 4, 0, 2 * Math.PI);
      ctx.fill();
    });
  };

  const drawVelocityVectors = (ctx: CanvasRenderingContext2D) => {
    const frame = Math.floor(currentFrame);
    
    data.modes.forEach((mode, bodyIndex) => {
      const pos = data.positions[frame][bodyIndex];
      const vel = data.velocities[frame][bodyIndex];
      const x = pos[0];
      const y = pos[1];
      const vx = vel[0] * 0.1; // Scale velocity for visualization
      const vy = vel[1] * 0.1;
      
      const color = settings.colorByMode ? 
        (modeColors as any)[mode] || '#ffffff' : 
        '#ffffff';
      
      ctx.strokeStyle = color;
      ctx.lineWidth = 2 / Math.min(width, height) * 4;
      
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + vx, y + vy);
      ctx.stroke();
      
      // Draw arrowhead
      const angle = Math.atan2(vy, vx);
      const arrowLength = 0.1;
      ctx.beginPath();
      ctx.moveTo(x + vx, y + vy);
      ctx.lineTo(
        x + vx - arrowLength * Math.cos(angle - Math.PI / 6),
        y + vy - arrowLength * Math.sin(angle - Math.PI / 6)
      );
      ctx.moveTo(x + vx, y + vy);
      ctx.lineTo(
        x + vx - arrowLength * Math.cos(angle + Math.PI / 6),
        y + vy - arrowLength * Math.sin(angle + Math.PI / 6)
      );
      ctx.stroke();
    });
  };

  const drawLabels = (ctx: CanvasRenderingContext2D) => {
    const frame = Math.floor(currentFrame);
    
    ctx.fillStyle = 'white';
    ctx.font = `${12 / Math.min(width, height) * 4}px Arial`;
    ctx.textAlign = 'center';
    
    data.modes.forEach((mode, bodyIndex) => {
      const pos = data.positions[frame][bodyIndex];
      const x = pos[0];
      const y = pos[1];
      const glyph = data.glyphs[bodyIndex];
      
      ctx.fillText(`${glyph} (k=${mode})`, x, y - 0.2);
    });
  };

  const drawEnergyPlot = (ctx: CanvasRenderingContext2D) => {
    const plotWidth = width * 0.3;
    const plotHeight = height * 0.2;
    const plotX = width - plotWidth - 20;
    const plotY = height - plotHeight - 20;
    
    // Draw plot background
    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    ctx.fillRect(plotX, plotY, plotWidth, plotHeight);
    
    // Draw plot border
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.lineWidth = 1;
    ctx.strokeRect(plotX, plotY, plotWidth, plotHeight);
    
    // Draw energy curve
    ctx.strokeStyle = '#4ecdc4';
    ctx.lineWidth = 2;
    ctx.beginPath();
    
    const maxEnergy = Math.max(...data.energies);
    const minEnergy = Math.min(...data.energies);
    const energyRange = maxEnergy - minEnergy || 1;
    
    for (let i = 0; i < data.energies.length; i++) {
      const x = plotX + (i / data.energies.length) * plotWidth;
      const y = plotY + plotHeight - ((data.energies[i] - minEnergy) / energyRange) * plotHeight;
      
      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.stroke();
    
    // Draw current energy indicator
    const currentEnergy = data.energies[Math.floor(currentFrame)];
    const currentX = plotX + (currentFrame / data.energies.length) * plotWidth;
    const currentY = plotY + plotHeight - ((currentEnergy - minEnergy) / energyRange) * plotHeight;
    
    ctx.fillStyle = '#ff6b6b';
    ctx.beginPath();
    ctx.arc(currentX, currentY, 4, 0, 2 * Math.PI);
    ctx.fill();
    
    // Draw energy text
    ctx.fillStyle = 'white';
    ctx.font = '12px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(`Energy: ${currentEnergy.toFixed(4)}`, plotX + 5, plotY + 15);
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleReset = () => {
    setCurrentFrame(0);
    setIsPlaying(false);
  };

  const handleFrameChange = (frame: number) => {
    setCurrentFrame(Math.max(0, Math.min(frame, data.times.length - 1)));
  };

  const exportFrame = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const link = document.createElement('a');
    link.download = `hlz-orbit-frame-${Math.floor(currentFrame)}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  const currentEnergy = data.energies[Math.floor(currentFrame)] || 0;
  const currentTime = data.times[Math.floor(currentFrame)] || 0;
  const progress = (currentFrame / (data.times.length - 1)) * 100;

  return (
    <div className={`space-y-4 ${className}`}>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Atom className="w-5 h-5" />
                HLZ Orbit Visualizer
              </CardTitle>
              <CardDescription>
                Real-time visualization of harmonic-lattice-Z orbital dynamics
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline">
                Frame: {Math.floor(currentFrame)}/{data.times.length - 1}
              </Badge>
              <Badge variant="outline">
                Time: {currentTime.toFixed(3)}
              </Badge>
              <Badge variant="outline">
                Energy: {currentEnergy.toFixed(4)}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Canvas */}
            <div className="relative bg-black rounded-lg overflow-hidden">
              <canvas
                ref={canvasRef}
                width={width}
                height={height}
                className="w-full h-auto"
              />
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button
                  variant={isPlaying ? "secondary" : "default"}
                  size="sm"
                  onClick={handlePlayPause}
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  {isPlaying ? "Pause" : "Play"}
                </Button>
                <Button variant="outline" size="sm" onClick={handleReset}>
                  <RotateCcw className="w-4 h-4" />
                  Reset
                </Button>
                <Button variant="outline" size="sm" onClick={exportFrame}>
                  <Download className="w-4 h-4" />
                  Export
                </Button>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm">Speed:</span>
                  <input
                    type="range"
                    min="0.1"
                    max="3"
                    step="0.1"
                    value={settings.animationSpeed}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      animationSpeed: parseFloat(e.target.value)
                    }))}
                    className="w-20"
                  />
                  <span className="text-sm w-8">{settings.animationSpeed}x</span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-sm">Frame:</span>
                  <input
                    type="range"
                    min="0"
                    max={data.times.length - 1}
                    value={currentFrame}
                    onChange={(e) => handleFrameChange(parseInt(e.target.value))}
                    className="w-32"
                  />
                </div>
              </div>
            </div>

            {/* Progress bar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Simulation Progress</span>
                <span>{progress.toFixed(1)}%</span>
              </div>
              <Progress value={progress} className="w-full" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Settings Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Visualization Settings
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="display" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="display">Display</TabsTrigger>
              <TabsTrigger value="advanced">Advanced</TabsTrigger>
            </TabsList>
            
            <TabsContent value="display" className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="showTrails"
                    checked={settings.showTrails}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      showTrails: e.target.checked
                    }))}
                  />
                  <label htmlFor="showTrails" className="text-sm">Show Trails</label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="showVelocity"
                    checked={settings.showVelocity}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      showVelocity: e.target.checked
                    }))}
                  />
                  <label htmlFor="showVelocity" className="text-sm">Show Velocity</label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="showEnergy"
                    checked={settings.showEnergy}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      showEnergy: e.target.checked
                    }))}
                  />
                  <label htmlFor="showEnergy" className="text-sm">Show Energy</label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="showGrid"
                    checked={settings.showGrid}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      showGrid: e.target.checked
                    }))}
                  />
                  <label htmlFor="showGrid" className="text-sm">Show Grid</label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="showLabels"
                    checked={settings.showLabels}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      showLabels: e.target.checked
                    }))}
                  />
                  <label htmlFor="showLabels" className="text-sm">Show Labels</label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="colorByMode"
                    checked={settings.colorByMode}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      colorByMode: e.target.checked
                    }))}
                  />
                  <label htmlFor="colorByMode" className="text-sm">Color by Mode</label>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="advanced" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm">Trail Length</label>
                  <input
                    type="range"
                    min="10"
                    max="200"
                    value={settings.trailLength}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      trailLength: parseInt(e.target.value)
                    }))}
                    className="w-full"
                  />
                  <span className="text-sm">{settings.trailLength} frames</span>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm">Point Size</label>
                  <input
                    type="range"
                    min="2"
                    max="20"
                    value={settings.pointSize}
                    onChange={(e) => setSettings(prev => ({
                      ...prev,
                      pointSize: parseInt(e.target.value)
                    }))}
                    className="w-full"
                  />
                  <span className="text-sm">{settings.pointSize} px</span>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Mode Legend */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Mode Legend
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            {Array.from(new Set(data.modes)).map(mode => (
              <div key={mode} className="flex items-center gap-2">
                <div
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: (modeColors as any)[mode] || '#ffffff' }}
                />
                <span className="text-sm">Mode k={mode}</span>
                <Badge variant="outline" className="text-xs">
                  {data.modes.filter(m => m === mode).length} bodies
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}