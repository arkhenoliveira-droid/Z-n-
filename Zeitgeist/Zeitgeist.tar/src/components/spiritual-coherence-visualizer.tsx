'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area,
  BarChart, 
  Bar,
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { 
  Activity, 
  Zap, 
  Heart, 
  Brain, 
  Users, 
  Target, 
  TrendingUp, 
  Star,
  BookOpen,
  User,
  Calendar,
  Award,
  Lightbulb,
  Shield,
  Eye,
  Hand,
  Sparkles,
  Infinity
} from 'lucide-react';

// Import our systems and types
import { 
  AndreLuizTeaching, 
  TeachingCategory, 
  SpiritualLevel,
  MediumisticCoherence,
  SpiritualDimensionType 
} from '@/systems/andre-luiz-teachings';
import { 
  SpiritualCoherenceMetrics,
  CoherenceIntegrationResult 
} from '@/systems/spiritual-coherence-system';
import { 
  EnhancedCoherenceMetrics,
  MediumisticDevelopmentMetrics,
  SpiritualEmergenceMetrics
} from '@/algorithms/spiritual-coherence-calculator';
import { 
  MediumisticProfile,
  DevelopmentReport,
  SessionType,
  MediumisticFaculty
} from '@/modules/mediumistic-coherence-analyzer';

interface SpiritualCoherenceVisualizerProps {
  mediumId?: string;
  profile?: MediumisticProfile;
}

export default function SpiritualCoherenceVisualizer({ 
  mediumId = "default_medium", 
  profile 
}: SpiritualCoherenceVisualizerProps) {
  const [selectedView, setSelectedView] = useState<'overview' | 'detailed' | 'development'>('overview');
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'quarter' | 'year'>('month');
  const [activeTab, setActiveTab] = useState('coherence');
  const [loading, setLoading] = useState(false);

  // Mock data for demonstration
  const [coherenceMetrics, setCoherenceMetrics] = useState<SpiritualCoherenceMetrics>({
    spiritual_coherence_level: 0.78,
    mediumistic_development: 0.72,
    consciousness_expansion: 0.85,
    energetic_harmony: 0.68,
    ethical_alignment: 0.91,
    healing_capacity: 0.74,
    collective_resonance: 0.76,
    evolutionary_progress: 0.82,
    overall_spiritual_coherence: 0.78,
    teaching_integration: new Map(),
    spiritual_field_strength: 0.79,
    dimensional_harmony: 0.77
  });

  const [developmentMetrics, setDevelopmentMetrics] = useState<MediumisticDevelopmentMetrics>({
    mediumistic_sensitivity: 0.75,
    communication_clarity: 0.72,
    energetic_control: 0.68,
    spiritual_discernment: 0.85,
    ethical_foundation: 0.91,
    healing_ability: 0.74,
    overall_development: 0.77,
    development_stage: 'intermediate',
    recommended_practices: [
      'Meditação diária de 20 minutos',
      'Estudo sistemático da doutrina',
      'Participação em grupos mediúnicos',
      'Exercícios de proteção energética'
    ],
    areas_for_improvement: [
      'Equilíbrio energético',
      'Comunicação clara com espíritos',
      'Trabalho em grupo'
    ]
  });

  // Mock dimensional coherence data
  const dimensionalData = [
    { dimension: 'Mediunidade', coherence: 0.8, fullMark: 1 },
    { dimension: 'Consciência', coherence: 0.75, fullMark: 1 },
    { dimension: 'Energético', coherence: 0.7, fullMark: 1 },
    { dimension: 'Ético', coherence: 0.85, fullMark: 1 },
    { dimension: 'Cura', coherence: 0.75, fullMark: 1 },
    { dimension: 'Coletivo', coherence: 0.7, fullMark: 1 },
    { dimension: 'Evolução', coherence: 0.8, fullMark: 1 }
  ];

  // Mock coherence progression data
  const coherenceProgressionData = [
    { month: 'Jan', coherence: 0.65, spiritual: 0.68, mediumistic: 0.62 },
    { month: 'Fev', coherence: 0.68, spiritual: 0.70, mediumistic: 0.65 },
    { month: 'Mar', coherence: 0.70, spiritual: 0.72, mediumistic: 0.67 },
    { month: 'Abr', coherence: 0.72, spiritual: 0.74, mediumistic: 0.69 },
    { month: 'Mai', coherence: 0.75, spiritual: 0.77, mediumistic: 0.71 },
    { month: 'Jun', coherence: 0.78, spiritual: 0.80, mediumistic: 0.74 }
  ];

  // Mock teaching effectiveness data
  const teachingEffectivenessData = [
    { category: 'Desenvolvimento', effectiveness: 0.85 },
    { category: 'Comunicação', effectiveness: 0.72 },
    { category: 'Energético', effectiveness: 0.68 },
    { category: 'Ético', effectiveness: 0.91 },
    { category: 'Cura', effectiveness: 0.74 },
    { category: 'Consciência', effectiveness: 0.82 },
    { category: 'Coletivo', effectiveness: 0.76 },
    { category: 'Evolução', effectiveness: 0.80 }
  ];

  // Mock faculty distribution data
  const facultyData = [
    { name: 'Intuição', value: 0.85, color: '#8884d8' },
    { name: 'Clarividência', value: 0.78, color: '#82ca9d' },
    { name: 'Cura', value: 0.74, color: '#ffc658' },
    { name: 'Psicofonia', value: 0.68, color: '#ff7c7c' },
    { name: 'Psicografia', value: 0.62, color: '#8dd1e1' }
  ];

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1'];

  const getDevelopmentStageColor = (stage: string) => {
    switch (stage) {
      case 'beginner': return 'bg-red-500';
      case 'developing': return 'bg-orange-500';
      case 'intermediate': return 'bg-blue-500';
      case 'advanced': return 'bg-purple-500';
      case 'mastery': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getCoherenceLevelColor = (level: number) => {
    if (level >= 0.9) return 'text-green-600';
    if (level >= 0.8) return 'text-blue-600';
    if (level >= 0.7) return 'text-yellow-600';
    return 'text-red-600';
  };

  const formatCoherenceValue = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <Sparkles className="h-8 w-8 text-purple-600" />
          Visualizador de Coerência Espiritual
        </h1>
        <p className="text-muted-foreground">
          Análise abrangente da coerência espiritual e desenvolvimento mediúnico
          baseada nos ensinamentos de André Luiz
        </p>
      </div>

      {/* Main Dashboard */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="coherence" className="flex items-center">
            <Activity className="w-4 h-4 mr-2" />
            Coerência
          </TabsTrigger>
          <TabsTrigger value="development" className="flex items-center">
            <TrendingUp className="w-4 h-4 mr-2" />
            Desenvolvimento
          </TabsTrigger>
          <TabsTrigger value="teachings" className="flex items-center">
            <BookOpen className="w-4 h-4 mr-2" />
            Ensinos
          </TabsTrigger>
          <TabsTrigger value="profile" className="flex items-center">
            <User className="w-4 h-4 mr-2" />
            Perfil
          </TabsTrigger>
        </TabsList>

        {/* Coherence Tab */}
        <TabsContent value="coherence" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Overall Coherence Metrics */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Coerência Geral
                </CardTitle>
                <CardDescription>
                  Métricas principais de coerência espiritual
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Coerência Espiritual</span>
                      <span className={`text-sm font-bold ${getCoherenceLevelColor(coherenceMetrics.overall_spiritual_coherence)}`}>
                        {formatCoherenceValue(coherenceMetrics.overall_spiritual_coherence)}
                      </span>
                    </div>
                    <Progress value={coherenceMetrics.overall_spiritual_coherence * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Desenvolvimento Mediúnico</span>
                      <span className={`text-sm font-bold ${getCoherenceLevelColor(coherenceMetrics.mediumistic_development)}`}>
                        {formatCoherenceValue(coherenceMetrics.mediumistic_development)}
                      </span>
                    </div>
                    <Progress value={coherenceMetrics.mediumistic_development * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Expansão da Consciência</span>
                      <span className={`text-sm font-bold ${getCoherenceLevelColor(coherenceMetrics.consciousness_expansion)}`}>
                        {formatCoherenceValue(coherenceMetrics.consciousness_expansion)}
                      </span>
                    </div>
                    <Progress value={coherenceMetrics.consciousness_expansion * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Alinhamento Ético</span>
                      <span className={`text-sm font-bold ${getCoherenceLevelColor(coherenceMetrics.ethical_alignment)}`}>
                        {formatCoherenceValue(coherenceMetrics.ethical_alignment)}
                      </span>
                    </div>
                    <Progress value={coherenceMetrics.ethical_alignment * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Capacidade de Cura</span>
                      <span className={`text-sm font-bold ${getCoherenceLevelColor(coherenceMetrics.healing_capacity)}`}>
                        {formatCoherenceValue(coherenceMetrics.healing_capacity)}
                      </span>
                    </div>
                    <Progress value={coherenceMetrics.healing_capacity * 100} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Coherence Progression Chart */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Progressão da Coerência
                </CardTitle>
                <CardDescription>
                  Evolução temporal das métricas de coerência
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={coherenceProgressionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area 
                      type="monotone" 
                      dataKey="coherence" 
                      stackId="1" 
                      stroke="#8884d8" 
                      fill="#8884d8" 
                      fillOpacity={0.6}
                      name="Coerência Geral"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="spiritual" 
                      stackId="2" 
                      stroke="#82ca9d" 
                      fill="#82ca9d" 
                      fillOpacity={0.6}
                      name="Coerência Espiritual"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="mediumistic" 
                      stackId="3" 
                      stroke="#ffc658" 
                      fill="#ffc658" 
                      fillOpacity={0.6}
                      name="Desenvolvimento Mediúnico"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Dimensional Analysis */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Análise Dimensional
              </CardTitle>
              <CardDescription>
                Coerência através das dimensões espirituais
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <RadarChart data={dimensionalData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="dimension" />
                  <PolarRadiusAxis angle={0} domain={[0, 1]} />
                  <Radar
                    name="Coerência Dimensional"
                    dataKey="coherence"
                    stroke="#8884d8"
                    fill="#8884d8"
                    fillOpacity={0.6}
                  />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Development Tab */}
        <TabsContent value="development" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Development Stage */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Estágio de Desenvolvimento
                </CardTitle>
                <CardDescription>
                  Nível atual de desenvolvimento mediúnico
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center space-y-2">
                  <div className={`w-16 h-16 rounded-full ${getDevelopmentStageColor(developmentMetrics.development_stage)} mx-auto flex items-center justify-center`}>
                    <Star className="h-8 w-8 text-white" />
                  </div>
                  <div className="text-lg font-bold uppercase">
                    {developmentMetrics.development_stage}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Nível de desenvolvimento: {formatCoherenceValue(developmentMetrics.overall_development)}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-sm font-medium">Próximo estágio:</div>
                  <Badge variant="outline">Avançado</Badge>
                  <div className="text-xs text-muted-foreground">
                    Preparação: 75% completa
                  </div>
                  <Progress value={75} className="h-2" />
                </div>
              </CardContent>
            </Card>

            {/* Development Metrics */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  Métricas de Desenvolvimento
                </CardTitle>
                <CardDescription>
                  Análise detalhada das capacidades mediúnicas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Sensibilidade</span>
                        <span className="text-sm">{formatCoherenceValue(developmentMetrics.mediumistic_sensitivity)}</span>
                      </div>
                      <Progress value={developmentMetrics.mediumistic_sensitivity * 100} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Comunicação</span>
                        <span className="text-sm">{formatCoherenceValue(developmentMetrics.communication_clarity)}</span>
                      </div>
                      <Progress value={developmentMetrics.communication_clarity * 100} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Controle Energético</span>
                        <span className="text-sm">{formatCoherenceValue(developmentMetrics.energetic_control)}</span>
                      </div>
                      <Progress value={developmentMetrics.energetic_control * 100} className="h-2" />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Discernimento</span>
                        <span className="text-sm">{formatCoherenceValue(developmentMetrics.spiritual_discernment)}</span>
                      </div>
                      <Progress value={developmentMetrics.spiritual_discernment * 100} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Fundamento Ético</span>
                        <span className="text-sm">{formatCoherenceValue(developmentMetrics.ethical_foundation)}</span>
                      </div>
                      <Progress value={developmentMetrics.ethical_foundation * 100} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Capacidade de Cura</span>
                        <span className="text-sm">{formatCoherenceValue(developmentMetrics.healing_ability)}</span>
                      </div>
                      <Progress value={developmentMetrics.healing_ability * 100} className="h-2" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recommendations and Practices */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5" />
                  Práticas Recomendadas
                </CardTitle>
                <CardDescription>
                  Práticas sugeridas para seu desenvolvimento
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-48">
                  <div className="space-y-2">
                    {developmentMetrics.recommended_practices.map((practice, index) => (
                      <div key={index} className="flex items-start gap-2 p-2 bg-muted/50 rounded">
                        <Hand className="h-4 w-4 mt-0.5 text-blue-600" />
                        <span className="text-sm">{practice}</span>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Áreas para Melhoria
                </CardTitle>
                <CardDescription>
                  Foco para desenvolvimento futuro
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-48">
                  <div className="space-y-2">
                    {developmentMetrics.areas_for_improvement.map((area, index) => (
                      <div key={index} className="flex items-start gap-2 p-2 bg-muted/50 rounded">
                        <Shield className="h-4 w-4 mt-0.5 text-orange-600" />
                        <span className="text-sm">{area}</span>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Teachings Tab */}
        <TabsContent value="teachings" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Teaching Effectiveness */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Efetividade dos Ensinos
                </CardTitle>
                <CardDescription>
                  Integração dos ensinamentos de André Luiz
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={teachingEffectivenessData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="category" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="effectiveness" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Faculty Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="h-5 w-5" />
                  Distribuição de Faculdades
                </CardTitle>
                <CardDescription>
                  Desenvolvimento das faculdades mediúnicas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={facultyData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${formatCoherenceValue(value)}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {facultyData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Key Teachings Integration */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Infinity className="h-5 w-5" />
                Ensinos Fundamentais Integrados
              </CardTitle>
              <CardDescription>
                Principais ensinamentos de André Luiz e sua aplicação
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg space-y-2">
                  <div className="flex items-center gap-2">
                    <Heart className="h-5 w-5 text-red-600" />
                    <h4 className="font-semibold">Desenvolvimento Mediúnico</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Desenvolvimento gradual e equilibrado das faculdades mediúnicas com base no estudo e disciplina moral.
                  </p>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">85% integrado</Badge>
                  </div>
                </div>

                <div className="p-4 border rounded-lg space-y-2">
                  <div className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-blue-600" />
                    <h4 className="font-semibold">Comunicação Espiritual</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Busca de elevação moral e esclarecimento nas comunicações com espíritos.
                  </p>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">72% integrado</Badge>
                  </div>
                </div>

                <div className="p-4 border rounded-lg space-y-2">
                  <div className="flex items-center gap-2">
                    <Shield className="h-5 w-5 text-green-600" />
                    <h4 className="font-semibold">Fundamentos Éticos</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Responsabilidade moral e compromisso com o bem coletivo no exercício da mediunidade.
                  </p>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">91% integrado</Badge>
                  </div>
                </div>

                <div className="p-4 border rounded-lg space-y-2">
                  <div className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-yellow-600" />
                    <h4 className="font-semibold">Equilíbrio Energético</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Harmonia nas trocas energéticas e proteção nos intercâmbios mediúnicos.
                  </p>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">68% integrado</Badge>
                  </div>
                </div>

                <div className="p-4 border rounded-lg space-y-2">
                  <div className="flex items-center gap-2">
                    <Hand className="h-5 w-5 text-purple-600" />
                    <h4 className="font-semibold">Capacidade de Cura</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Desenvolvimento da cura espiritual através da fé, conhecimento e amor.
                  </p>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">74% integrado</Badge>
                  </div>
                </div>

                <div className="p-4 border rounded-lg space-y-2">
                  <div className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-indigo-600" />
                    <h4 className="font-semibold">Evolução Espiritual</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Progresso contínuo na escala evolutiva através do serviço e do amor.
                  </p>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">82% integrado</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Profile Tab */}
        <TabsContent value="profile" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Profile Overview */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Perfil Mediúnico
                </CardTitle>
                <CardDescription>
                  Informações gerais do perfil
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center space-y-2">
                  <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full mx-auto flex items-center justify-center">
                    <User className="h-10 w-10 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Médium em Desenvolvimento</h3>
                    <p className="text-sm text-muted-foreground">ID: {mediumId}</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Estágio Atual</span>
                    <Badge variant="outline">{developmentMetrics.development_stage}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Experiência</span>
                    <span className="text-sm">2 anos</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Sessões</span>
                    <span className="text-sm">156</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Última Atividade</span>
                    <span className="text-sm">Hoje</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Atividade Recente
                </CardTitle>
                <CardDescription>
                  Sessões e marcos de desenvolvimento recentes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-3 bg-green-50 rounded-lg">
                    <div className="w-10 h-10 bg-green-200 rounded-full flex items-center justify-center">
                      <Award className="h-5 w-5 text-green-700" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">Marco de Desenvolvimento</div>
                      <div className="text-sm text-muted-foreground">
                        Desenvolvimento de clarividência básica alcançado
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">2 dias atrás</div>
                  </div>

                  <div className="flex items-center gap-4 p-3 bg-blue-50 rounded-lg">
                    <div className="w-10 h-10 bg-blue-200 rounded-full flex items-center justify-center">
                      <Activity className="h-5 w-5 text-blue-700" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">Sessão de Desenvolvimento</div>
                      <div className="text-sm text-muted-foreground">
                        Sessão produtiva com 85% de eficácia
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">5 dias atrás</div>
                  </div>

                  <div className="flex items-center gap-4 p-3 bg-purple-50 rounded-lg">
                    <div className="w-10 h-10 bg-purple-200 rounded-full flex items-center justify-center">
                      <BookOpen className="h-5 w-5 text-purple-700" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">Conclusão de Estudo</div>
                      <div className="text-sm text-muted-foreground">
                        "Mecanismos da Mediunidade" - Capítulos 1-10
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">1 semana atrás</div>
                  </div>

                  <div className="flex items-center gap-4 p-3 bg-orange-50 rounded-lg">
                    <div className="w-10 h-10 bg-orange-200 rounded-full flex items-center justify-center">
                      <Target className="h-5 w-5 text-orange-700" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">Desafio Superado</div>
                      <div className="text-sm text-muted-foreground">
                        Melhora significativa no equilíbrio energético
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">2 semanas atrás</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Development Goals */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Objetivos de Desenvolvimento
              </CardTitle>
              <CardDescription>
                Metas e plano de ação para evolução mediúnica
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <Brain className="h-4 w-4 text-blue-600" />
                    </div>
                    <h4 className="font-semibold">Curto Prazo</h4>
                  </div>
                  <ul className="text-sm space-y-1">
                    <li>• Melhorar proteção energética</li>
                    <li>• Desenvolver clariaudiência</li>
                    <li>• Estabelecer rotina de meditação</li>
                  </ul>
                  <div className="text-xs text-muted-foreground">
                    Prazo: 1-3 meses
                  </div>
                </div>

                <div className="p-4 border rounded-lg space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <TrendingUp className="h-4 w-4 text-green-600" />
                    </div>
                    <h4 className="font-semibold">Médio Prazo</h4>
                  </div>
                  <ul className="text-sm space-y-1">
                    <li>• Desenvolver faculdades de cura</li>
                    <li>• Participar de grupo assistencial</li>
                    <li>• Orientar novos médiuns</li>
                  </ul>
                  <div className="text-xs text-muted-foreground">
                    Prazo: 3-6 meses
                  </div>
                </div>

                <div className="p-4 border rounded-lg space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                      <Infinity className="h-4 w-4 text-purple-600" />
                    </div>
                    <h4 className="font-semibold">Longo Prazo</h4>
                  </div>
                  <ul className="text-sm space-y-1">
                    <li>• Tornar-se médium de cura</li>
                    <li>• Contribuir para obras assistenciais</li>
                    <li>• Transmitir conhecimentos</li>
                  </ul>
                  <div className="text-xs text-muted-foreground">
                    Prazo: 6-12 meses
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}