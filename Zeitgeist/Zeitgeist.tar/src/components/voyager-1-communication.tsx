'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Satellite, 
  Radio, 
  Zap, 
  Network, 
  Globe, 
  Star,
  Rocket,
  Brain,
  Heart,
  Infinity,
  Activity,
  Target,
  RefreshCw,
  Play,
  Pause,
  Settings,
  Send,
  Download,
  Wifi,
  WifiOff,
  Signal,
  SignalHigh,
  SignalLow,
  AlertTriangle,
  CheckCircle,
  Clock,
  Waves,
  Antenna,
  Telescope,
  Space,
  History,
  FileText
} from 'lucide-react';

interface Voyager1Signal {
  timestamp: string;
  signal_strength: number;
  frequency: number;
  data_rate: number;
  distance_from_earth: number;
  signal_quality: 'excellent' | 'good' | 'fair' | 'poor' | 'none';
  message: string;
  hash: string;
}

interface CommunicationStatus {
  is_connected: boolean;
  signal_strength: number;
  last_contact: string;
  transmission_queue: number;
  received_messages: number;
  sent_messages: number;
}

const Voyager1Communication: React.FC = () => {
  const [communicationHash, setCommunicationHash] = useState<string>('e6ec281d37c083cdc048b60e87d40d279b73498c');
  const [status, setStatus] = useState<CommunicationStatus>({
    is_connected: false,
    signal_strength: 0,
    last_contact: 'Never',
    transmission_queue: 0,
    received_messages: 0,
    sent_messages: 0
  });
  const [currentSignal, setCurrentSignal] = useState<Voyager1Signal | null>(null);
  const [messageToSend, setMessageToSend] = useState<string>('');
  const [isTransmitting, setIsTransmitting] = useState<boolean>(false);
  const [isReceiving, setIsReceiving] = useState<boolean>(false);
  const [signalHistory, setSignalHistory] = useState<Voyager1Signal[]>([]);
  const [connectionLog, setConnectionLog] = useState<string[]>([]);

  // Add log entry
  const addLogEntry = (message: string) => {
    const timestamp = new Date().toISOString();
    const logEntry = `[${timestamp}] ${message}`;
    setConnectionLog(prev => [logEntry, ...prev].slice(0, 50)); // Keep last 50 entries
  };

  // Simulate establishing connection with Voyager 1
  const establishConnection = async () => {
    addLogEntry('Attempting to establish connection with Voyager 1...');
    setIsTransmitting(true);
    
    // Simulate connection delay
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Simulate successful connection
    setStatus(prev => ({
      ...prev,
      is_connected: true,
      signal_strength: Math.random() * 0.3 + 0.7, // 70-100% signal strength
      last_contact: new Date().toISOString()
    }));
    
    setIsTransmitting(false);
    addLogEntry('Connection established with Voyager 1 successfully!');
    addLogEntry(`Using communication hash: ${communicationHash}`);
  };

  // Simulate receiving signal from Voyager 1
  const receiveSignal = async () => {
    if (!status.is_connected) {
      addLogEntry('Cannot receive signal: No connection established');
      return;
    }

    setIsReceiving(true);
    addLogEntry('Listening for Voyager 1 signal...');

    // Simulate signal reception delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Generate simulated signal data
    const newSignal: Voyager1Signal = {
      timestamp: new Date().toISOString(),
      signal_strength: Math.random() * 0.4 + 0.6, // 60-100%
      frequency: 8420 + Math.random() * 10, // Around 8420 MHz (X-band)
      data_rate: 160 + Math.random() * 40, // Around 160 bps
      distance_from_earth: 238000000000 + Math.random() * 1000000000, // ~23.8 billion km
      signal_quality: ['excellent', 'good', 'fair'][Math.floor(Math.random() * 3)] as 'excellent' | 'good' | 'fair',
      message: generateVoyagerMessage(),
      hash: communicationHash
    };

    setCurrentSignal(newSignal);
    setSignalHistory(prev => [newSignal, ...prev].slice(0, 20)); // Keep last 20 signals
    setStatus(prev => ({
      ...prev,
      signal_strength: newSignal.signal_strength,
      last_contact: newSignal.timestamp,
      received_messages: prev.received_messages + 1
    }));

    setIsReceiving(false);
    addLogEntry(`Signal received from Voyager 1! Signal strength: ${(newSignal.signal_strength * 100).toFixed(1)}%`);
    addLogEntry(`Message: ${newSignal.message}`);
  };

  // Generate simulated Voyager 1 message
  const generateVoyagerMessage = (): string => {
    const messages = [
      "Systems nominal. Continuing journey into interstellar space.",
      "Golden Record still intact. Broadcasting cosmic greeting.",
      "Detecting cosmic ray density increase. Confirming interstellar medium.",
      "Magnetic field measurements consistent with interstellar conditions.",
      "Plasma wave instrument detecting interstellar plasma oscillations.",
      "Power systems functioning within expected parameters.",
      "Temperature sensors reporting deep space conditions.",
      "Attitude control system maintaining Earth orientation.",
      "Continuing to transmit scientific data.",
      "Voyager 1 still calling home from the stars."
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  };

  // Send message to Voyager 1
  const sendMessage = async () => {
    if (!messageToSend.trim()) {
      addLogEntry('Cannot send empty message');
      return;
    }

    if (!status.is_connected) {
      addLogEntry('Cannot send message: No connection established');
      return;
    }

    setIsTransmitting(true);
    addLogEntry(`Sending message to Voyager 1: "${messageToSend}"`);

    // Simulate transmission delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    setStatus(prev => ({
      ...prev,
      sent_messages: prev.sent_messages + 1,
      transmission_queue: Math.max(0, prev.transmission_queue - 1)
    }));

    setIsTransmitting(false);
    addLogEntry('Message sent successfully!');
    setMessageToSend('');
  };

  // Disconnect from Voyager 1
  const disconnectConnection = () => {
    setStatus(prev => ({
      ...prev,
      is_connected: false,
      signal_strength: 0
    }));
    setCurrentSignal(null);
    addLogEntry('Disconnected from Voyager 1');
  };

  // Auto-receive signals when connected
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (status.is_connected) {
      interval = setInterval(() => {
        if (Math.random() > 0.3) { // 70% chance to receive signal
          receiveSignal();
        }
      }, 10000); // Check every 10 seconds
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [status.is_connected]);

  const getSignalQualityColor = (quality: string) => {
    switch (quality) {
      case 'excellent': return 'text-green-600 bg-green-50';
      case 'good': return 'text-blue-600 bg-blue-50';
      case 'fair': return 'text-yellow-600 bg-yellow-50';
      case 'poor': return 'text-orange-600 bg-orange-50';
      case 'none': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getSignalIcon = (strength: number) => {
    if (strength > 0.8) return <SignalHigh className="h-4 w-4" />;
    if (strength > 0.5) return <Signal className="h-4 w-4" />;
    return <SignalLow className="h-4 w-4" />;
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <Satellite className="h-8 w-8 text-blue-500" />
          Voyager 1 Communication System
        </h1>
        <p className="text-muted-foreground">
          Deep Space Communication with NASA's Voyager 1 Spacecraft
        </p>
      </div>

      <Tabs defaultValue="control" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="control">Mission Control</TabsTrigger>
          <TabsTrigger value="signals">Signal Analysis</TabsTrigger>
          <TabsTrigger value="history">Signal History</TabsTrigger>
          <TabsTrigger value="logs">Connection Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="control" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Connection Status Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {status.is_connected ? <Wifi className="h-5 w-5 text-green-500" /> : <WifiOff className="h-5 w-5 text-red-500" />}
                  Connection Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Status:</span>
                  <Badge variant={status.is_connected ? "default" : "destructive"}>
                    {status.is_connected ? "Connected" : "Disconnected"}
                  </Badge>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span>Signal Strength:</span>
                    <span>{(status.signal_strength * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={status.signal_strength * 100} className="w-full" />
                </div>

                <div className="text-sm space-y-1">
                  <div className="flex justify-between">
                    <span>Last Contact:</span>
                    <span>{status.last_contact === 'Never' ? 'Never' : new Date(status.last_contact).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Messages Received:</span>
                    <span>{status.received_messages}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Messages Sent:</span>
                    <span>{status.sent_messages}</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  {!status.is_connected ? (
                    <Button 
                      onClick={establishConnection} 
                      disabled={isTransmitting}
                      className="flex-1"
                    >
                      {isTransmitting ? (
                        <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <Radio className="h-4 w-4 mr-2" />
                      )}
                      Connect
                    </Button>
                  ) : (
                    <Button 
                      onClick={disconnectConnection} 
                      variant="destructive"
                      className="flex-1"
                    >
                      <WifiOff className="h-4 w-4 mr-2" />
                      Disconnect
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Communication Hash Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Communication Parameters
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="comm-hash">Communication Hash</Label>
                  <Input
                    id="comm-hash"
                    value={communicationHash}
                    onChange={(e) => setCommunicationHash(e.target.value)}
                    className="font-mono text-sm"
                  />
                </div>
                
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    This hash is used for authentication and encryption of communication with Voyager 1.
                  </AlertDescription>
                </Alert>

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Frequency:</span>
                    <span>8420 MHz (X-band)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Data Rate:</span>
                    <span>160 bps</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Distance:</span>
                    <span>~23.8 billion km</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Light Time:</span>
                    <span>~22 hours</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Current Signal Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Waves className="h-5 w-5" />
                  Current Signal
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {currentSignal ? (
                  <>
                    <div className="flex items-center justify-between">
                      <span>Quality:</span>
                      <Badge className={getSignalQualityColor(currentSignal.signal_quality)}>
                        {currentSignal.signal_quality}
                      </Badge>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Frequency:</span>
                        <span>{currentSignal.frequency.toFixed(2)} MHz</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Data Rate:</span>
                        <span>{currentSignal.data_rate.toFixed(0)} bps</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Distance:</span>
                        <span>{(currentSignal.distance_from_earth / 1000000000).toFixed(1)}B km</span>
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm">Latest Message:</Label>
                      <p className="text-xs mt-1 p-2 bg-muted rounded">
                        {currentSignal.message}
                      </p>
                    </div>

                    <Button 
                      onClick={receiveSignal} 
                      disabled={isReceiving || !status.is_connected}
                      className="w-full"
                    >
                      {isReceiving ? (
                        <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <Download className="h-4 w-4 mr-2" />
                      )}
                      Receive Signal
                    </Button>
                  </>
                ) : (
                  <div className="text-center text-muted-foreground">
                    <Antenna className="h-8 w-8 mx-auto mb-2" />
                    <p>No signal received yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Message Transmission Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Send className="h-5 w-5" />
                Message Transmission
              </CardTitle>
              <CardDescription>
                Send commands and messages to Voyager 1
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="message">Message to Voyager 1</Label>
                <Textarea
                  id="message"
                  placeholder="Enter your message or command for Voyager 1..."
                  value={messageToSend}
                  onChange={(e) => setMessageToSend(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                <Button 
                  onClick={sendMessage} 
                  disabled={isTransmitting || !status.is_connected || !messageToSend.trim()}
                  className="flex-1"
                >
                  {isTransmitting ? (
                    <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Send className="h-4 w-4 mr-2" />
                  )}
                  Send Message
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setMessageToSend('')}
                  disabled={!messageToSend.trim()}
                >
                  Clear
                </Button>
              </div>

              {status.transmission_queue > 0 && (
                <Alert>
                  <Clock className="h-4 w-4" />
                  <AlertDescription>
                    {status.transmission_queue} messages in transmission queue
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="signals" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Signal Analysis
              </CardTitle>
              <CardDescription>
                Real-time analysis of Voyager 1 signal characteristics
              </CardDescription>
            </CardHeader>
            <CardContent>
              {currentSignal ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold">Signal Metrics</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Signal Strength:</span>
                        <span>{(currentSignal.signal_strength * 100).toFixed(1)}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Frequency:</span>
                        <span>{currentSignal.frequency.toFixed(2)} MHz</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Data Rate:</span>
                        <span>{currentSignal.data_rate.toFixed(0)} bps</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Distance:</span>
                        <span>{(currentSignal.distance_from_earth / 1000000000).toFixed(1)} billion km</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold">Quality Assessment</h3>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span>Signal Quality:</span>
                        <Badge className={getSignalQualityColor(currentSignal.signal_quality)}>
                          {currentSignal.signal_quality}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Bit Error Rate:</span>
                        <span>{(Math.random() * 0.001).toFixed(6)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>SNR:</span>
                        <span>{(Math.random() * 20 + 10).toFixed(1)} dB</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Lock Status:</span>
                        <Badge variant="outline">Locked</Badge>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold">Communication Data</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Timestamp:</span>
                        <span className="text-xs">{new Date(currentSignal.timestamp).toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Hash:</span>
                        <span className="text-xs font-mono">{currentSignal.hash.substring(0, 8)}...</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Protocol:</span>
                        <span>CCSDS</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Frame Count:</span>
                        <span>{Math.floor(Math.random() * 10000)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center text-muted-foreground">
                  <Telescope className="h-12 w-12 mx-auto mb-4" />
                  <p>No signal data available. Connect to Voyager 1 and receive a signal first.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                Signal History
              </CardTitle>
              <CardDescription>
                Historical record of received signals from Voyager 1
              </CardDescription>
            </CardHeader>
            <CardContent>
              {signalHistory.length > 0 ? (
                <div className="space-y-4">
                  {signalHistory.map((signal, index) => (
                    <div key={index} className="border rounded-lg p-4 space-y-2">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2">
                          {getSignalIcon(signal.signal_strength)}
                          <span className="font-medium">
                            {new Date(signal.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <Badge className={getSignalQualityColor(signal.signal_quality)}>
                          {signal.signal_quality}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Strength:</span>
                          <span className="ml-1">{(signal.signal_strength * 100).toFixed(1)}%</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Frequency:</span>
                          <span className="ml-1">{signal.frequency.toFixed(2)} MHz</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Data Rate:</span>
                          <span className="ml-1">{signal.data_rate.toFixed(0)} bps</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Distance:</span>
                          <span className="ml-1">{(signal.distance_from_earth / 1000000000).toFixed(1)}B km</span>
                        </div>
                      </div>
                      
                      <div>
                        <span className="text-sm text-muted-foreground">Message:</span>
                        <p className="text-sm mt-1">{signal.message}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center text-muted-foreground">
                  <Clock className="h-12 w-12 mx-auto mb-4" />
                  <p>No signal history available. Start receiving signals from Voyager 1.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Connection Logs
              </CardTitle>
              <CardDescription>
                Detailed log of all communication activities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {connectionLog.length > 0 ? (
                  connectionLog.map((log, index) => (
                    <div key={index} className="text-sm font-mono p-2 bg-muted rounded">
                      {log}
                    </div>
                  ))
                ) : (
                  <div className="text-center text-muted-foreground">
                    <FileText className="h-12 w-12 mx-auto mb-4" />
                    <p>No connection logs available. Start communicating with Voyager 1.</p>
                  </div>
                )}
              </div>
              
              {connectionLog.length > 0 && (
                <div className="mt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setConnectionLog([])}
                    className="w-full"
                  >
                    Clear Logs
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Voyager1Communication;