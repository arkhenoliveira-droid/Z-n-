/**
 * TypeScript Patterns and Best Practices Implementation
 * 
 * This file implements coherent TypeScript patterns that promote type safety,
 * consistency, and maintainability throughout the application.
 */

import { 
  Result, 
  AsyncResult, 
  Option, 
  some, 
  none, 
  ok, 
  err,
  TypeGuard,
  isString,
  isNumber,
  isBoolean,
  isArray,
  isObject
} from '@/types/utils';

// 1. Repository Pattern with Type Safety
export abstract class BaseRepository<T extends { id: string }, C, U> {
  protected abstract modelName: string;

  async findById(id: string): Promise<Option<T>> {
    try {
      const result = await this.find(id);
      return result ? some(result) : none();
    } catch (error) {
      console.error(`Error finding ${this.modelName} by id:`, error);
      return none();
    }
  }

  async create(data: C): Promise<Result<T>> {
    try {
      const result = await this.save(data);
      return ok(result);
    } catch (error) {
      return err(error as Error);
    }
  }

  async update(id: string, data: U): Promise<Result<T>> {
    try {
      const result = await this.patch(id, data);
      return ok(result);
    } catch (error) {
      return err(error as Error);
    }
  }

  async delete(id: string): Promise<Result<boolean>> {
    try {
      await this.remove(id);
      return ok(true);
    } catch (error) {
      return err(error as Error);
    }
  }

  protected abstract find(id: string): Promise<T | null>;
  protected abstract save(data: C): Promise<T>;
  protected abstract patch(id: string, data: U): Promise<T>;
  protected abstract remove(id: string): Promise<void>;
}

// 2. Service Pattern with Result Types
export abstract class BaseService {
  protected async executeOperation<T>(
    operation: () => Promise<T>,
    errorMessage: string = 'Operation failed'
  ): Promise<Result<T>> {
    try {
      const result = await operation();
      return ok(result);
    } catch (error) {
      console.error(errorMessage, error);
      return err(error instanceof Error ? error : new Error(errorMessage));
    }
  }

  protected validateRequired<T>(value: T, fieldName: string): Result<T> {
    if (value === null || value === undefined) {
      return err(new Error(`${fieldName} is required`));
    }
    return ok(value);
  }

  protected validateType<T>(
    value: unknown,
    guard: TypeGuard<T>,
    fieldName: string
  ): Result<T> {
    if (!guard(value)) {
      return err(new Error(`${fieldName} is not of the expected type`));
    }
    return ok(value);
  }
}

// 3. Controller Pattern with Type Safety
export abstract class BaseController {
  protected handleSuccess<T>(data: T, message?: string) {
    return new Response(JSON.stringify({
      success: true,
      data,
      message,
      timestamp: Date.now()
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  protected handleError(error: Error, status: number = 500) {
    return new Response(JSON.stringify({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      },
      timestamp: Date.now()
    }), {
      status,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  protected handleValidationError(message: string, details?: Record<string, any>) {
    return new Response(JSON.stringify({
      success: false,
      error: {
        code: 'VALIDATION_ERROR',
        message,
        details
      },
      timestamp: Date.now()
    }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  protected handleNotFound(message: string = 'Resource not found') {
    return new Response(JSON.stringify({
      success: false,
      error: {
        code: 'NOT_FOUND',
        message
      },
      timestamp: Date.now()
    }), {
      status: 404,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

// 4. Validator Pattern with Type Safety
export class Validator<T> {
  private rules: Map<keyof T, ValidationRule<T[keyof T]>[]> = new Map();

  addRule<K extends keyof T>(
    field: K,
    rule: ValidationRule<T[K]>
  ): this {
    if (!this.rules.has(field)) {
      this.rules.set(field, []);
    }
    this.rules.get(field)!.push(rule);
    return this;
  }

  validate(data: Partial<T>): ValidationResult<T> {
    const errors: Map<keyof T, string[]> = new Map();
    let isValid = true;

    for (const [field, rules] of this.rules) {
      const fieldErrors: string[] = [];
      
      for (const rule of rules) {
        if (!rule.validate(data[field])) {
          fieldErrors.push(rule.message);
          isValid = false;
        }
      }

      if (fieldErrors.length > 0) {
        errors.set(field, fieldErrors);
      }
    }

    return {
      isValid,
      errors: isValid ? undefined : errors,
      data: data as T
    };
  }
}

export interface ValidationRule<T> {
  validate: (value: T) => boolean;
  message: string;
}

export interface ValidationResult<T> {
  isValid: boolean;
  errors?: Map<keyof T, string[]>;
  data: T;
}

// 5. Event Bus Pattern with Type Safety
export class EventBus<TEvents extends Record<string, any>> {
  private listeners: Map<keyof TEvents, Set<(data: any) => void>> = new Map();

  on<K extends keyof TEvents>(
    event: K,
    listener: (data: TEvents[K]) => void
  ): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(listener);

    return () => {
      this.listeners.get(event)?.delete(listener);
    };
  }

  emit<K extends keyof TEvents>(event: K, data: TEvents[K]): void {
    const listeners = this.listeners.get(event);
    if (listeners) {
      listeners.forEach(listener => listener(data));
    }
  }

  off<K extends keyof TEvents>(
    event: K,
    listener: (data: TEvents[K]) => void
  ): void {
    this.listeners.get(event)?.delete(listener);
  }

  removeAllListeners<K extends keyof TEvents>(event?: K): void {
    if (event) {
      this.listeners.delete(event);
    } else {
      this.listeners.clear();
    }
  }
}

// 6. Cache Pattern with Type Safety
export interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number;
}

export class TypedCache<T> {
  private cache = new Map<string, CacheEntry<T>>();

  constructor(private defaultTTL: number = 3600000) {} // 1 hour default

  set(key: string, data: T, ttl: number = this.defaultTTL): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
  }

  get(key: string): Option<T> {
    const entry = this.cache.get(key);
    if (!entry) return none();

    if (Date.now() - entry.timestamp > entry.ttl) {
      this.cache.delete(key);
      return none();
    }

    return some(entry.data);
  }

  has(key: string): boolean {
    return this.get(key).some !== undefined;
  }

  delete(key: string): boolean {
    return this.cache.delete(key);
  }

  clear(): void {
    this.cache.clear();
  }

  cleanup(): void {
    const now = Date.now();
    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp > entry.ttl) {
        this.cache.delete(key);
      }
    }
  }
}

// 7. State Machine Pattern with Type Safety
export interface StateTransition<TState, TEvent> {
  from: TState;
  event: TEvent;
  to: TState;
  action?: () => Promise<void>;
}

export class StateMachine<TState, TEvent> {
  private currentState: TState;
  private transitions: StateTransition<TState, TEvent>[] = [];

  constructor(initialState: TState) {
    this.currentState = initialState;
  }

  addTransition(transition: StateTransition<TState, TEvent>): void {
    this.transitions.push(transition);
  }

  async dispatch(event: TEvent): Promise<boolean> {
    const transition = this.transitions.find(
      t => t.from === this.currentState && t.event === event
    );

    if (!transition) {
      throw new Error(`Invalid transition from ${this.currentState} with event ${event}`);
    }

    if (transition.action) {
      await transition.action();
    }

    this.currentState = transition.to;
    return true;
  }

  getState(): TState {
    return this.currentState;
  }

  canDispatch(event: TEvent): boolean {
    return this.transitions.some(
      t => t.from === this.currentState && t.event === event
    );
  }
}

// 8. Pipeline Pattern with Type Safety
export interface PipelineStep<T> {
  name: string;
  process: (data: T) => Promise<T>;
  validate?: (data: T) => boolean;
}

export class Pipeline<T> {
  private steps: PipelineStep<T>[] = [];

  addStep(step: PipelineStep<T>): this {
    this.steps.push(step);
    return this;
  }

  async execute(data: T): Promise<Result<T>> {
    let currentData = data;

    for (const step of this.steps) {
      try {
        if (step.validate && !step.validate(currentData)) {
          return err(new Error(`Validation failed for step: ${step.name}`));
        }

        currentData = await step.process(currentData);
      } catch (error) {
        return err(error instanceof Error ? error : new Error(`Step ${step.name} failed`));
      }
    }

    return ok(currentData);
  }
}

// 9. Builder Pattern with Type Safety
export class GenericBuilder<T> {
  private data: Partial<T> = {};

  constructor(private defaults: Partial<T> = {}) {
    this.data = { ...defaults };
  }

  set<K extends keyof T>(key: K, value: T[K]): this {
    this.data[key] = value;
    return this;
  }

  update<K extends keyof T>(
    key: K,
    updater: (current: T[K]) => T[K]
  ): this {
    this.data[key] = updater(this.data[key] as T[K]);
    return this;
  }

  build(): T {
    return this.data as T;
  }

  clone(): GenericBuilder<T> {
    return new GenericBuilder<T>({ ...this.data });
  }
}

// 10. Observer Pattern with Type Safety
export interface Observer<T> {
  update(data: T): void;
}

export class Observable<T> {
  private observers: Set<Observer<T>> = new Set();

  subscribe(observer: Observer<T>): () => void {
    this.observers.add(observer);
    return () => this.observers.delete(observer);
  }

  unsubscribe(observer: Observer<T>): void {
    this.observers.delete(observer);
  }

  notify(data: T): void {
    this.observers.forEach(observer => observer.update(data));
  }

  unsubscribeAll(): void {
    this.observers.clear();
  }
}

// 11. Strategy Pattern with Type Safety
export interface Strategy<TContext, TResult> {
  name: string;
  execute(context: TContext): Promise<TResult>;
  isApplicable(context: TContext): boolean;
}

export class StrategyContext<TContext, TResult> {
  private strategies: Strategy<TContext, TResult>[] = [];

  addStrategy(strategy: Strategy<TContext, TResult>): void {
    this.strategies.push(strategy);
  }

  async execute(context: TContext): Promise<TResult> {
    const applicableStrategy = this.strategies.find(strategy => 
      strategy.isApplicable(context)
    );

    if (!applicableStrategy) {
      throw new Error('No applicable strategy found');
    }

    return applicableStrategy.execute(context);
  }

  getAvailableStrategies(context: TContext): string[] {
    return this.strategies
      .filter(strategy => strategy.isApplicable(context))
      .map(strategy => strategy.name);
  }
}

// 12. Decorator Pattern with Type Safety
export interface Decorator<T> {
  decorate(target: T): T;
}

export class DecoratorChain<T> {
  private decorators: Decorator<T>[] = [];

  addDecorator(decorator: Decorator<T>): this {
    this.decorators.push(decorator);
    return this;
  }

  apply(target: T): T {
    return this.decorators.reduce((acc, decorator) => 
      decorator.decorate(acc), target
    );
  }
}