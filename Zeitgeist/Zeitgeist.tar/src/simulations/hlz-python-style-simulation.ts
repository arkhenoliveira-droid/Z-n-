/**
 * HLZ Python-Style Simulation
 * 
 * A NumPy/SciPy-style implementation of the HLZ orbit simulator
 * that closely follows the Python prototype provided in the quick-start guide.
 */

import { NumPy, NDArray, Complex } from '@/utils/numpty';
import { HLZMathematicalFormulations } from '@/algorithms/hlz-mathematical-formulations';
import { ID, AsyncResult, Result, ok, err } from '@/types/utils';

export interface PythonStyleSimulationParams {
  dt: number;                    // Time step
  nSteps: number;                // Total number of steps
  saveInterval: number;          // Save state every N steps
  modes: number[];               // Spectral modes [3, 7, ...]
  bodiesPerMode: number[];       // Number of bodies per mode
  couplingStrength: number;     // Additional scaling for alpha
  useSoftening: boolean;         // Use softening parameter
  seed?: number;                 // Random seed for reproducibility
}

export interface SimulationBody {
  id: string;
  position: NDArray;            // 3D position vector
  velocity: NDArray;            // 3D velocity vector
  mass: number;
  mode: number;                  // Associated spectral mode k
  glyph?: string;                // Optional glyph identifier
  metadata: Record<string, any>;  // Additional metadata
}

export interface SimulationState {
  bodies: SimulationBody[];
  time: number;
  step: number;
  energy: number;
  parameters: PythonStyleSimulationParams;
}

export class HLZPythonStyleSimulation {
  private formulations: HLZMathematicalFormulations;
  private params: PythonStyleSimulationParams;
  private state: SimulationState;
  private trajectory: SimulationState[];
  private constants: any;

  constructor(params: PythonStyleSimulationParams) {
    this.params = params;
    this.formulations = new HLZMathematicalFormulations();
    this.constants = this.formulations.getConstants();
    
    // Set random seed if provided
    if (params.seed !== undefined) {
      this.setRandomSeed(params.seed);
    }
    
    // Initialize simulation state
    this.state = {
      bodies: [],
      time: 0,
      step: 0,
      energy: 0,
      parameters: params
    };
    
    this.trajectory = [];
    
    // Initialize bodies
    this.initializeBodies();
  }

  /**
   * Set random seed for reproducibility
   */
  private setRandomSeed(seed: number): void {
    // Simple seed implementation - in practice, you'd use a proper PRNG
    const originalRandom = Math.random;
    let state = seed;
    
    Math.random = () => {
      state = (state * 9301 + 49297) % 233280;
      return state / 233280;
    };
    
    // Store original random function to restore later
    (Math.random as any).original = originalRandom;
  }

  /**
   * Restore original random function
   */
  private restoreRandom(): void {
    if ((Math.random as any).original) {
      Math.random = (Math.random as any).original;
    }
  }

  /**
   * Initialize bodies on specified spectral shells (following Python prototype)
   */
  private initializeBodies(): void {
    const bodies: SimulationBody[] = [];
    let bodyId = 0;
    
    this.params.modes.forEach((mode, modeIndex) => {
      const numBodies = this.params.bodiesPerMode[modeIndex] || 4;
      
      // Compute radius for this mode using the mathematical formulation
      const radius = this.formulations.computeRadius(mode);
      
      for (let i = 0; i < numBodies; i++) {
        // Random angle for initial position (2D for simplicity, can extend to 3D)
        const theta = Math.random() * 2 * Math.PI;
        
        // Position on circular shell
        const x = radius * Math.cos(theta);
        const y = radius * Math.sin(theta);
        const z = 0.0;  // Start in xy-plane
        
        // Create position vector
        const position = NumPy.array([x, y, z]);
        
        // Circular velocity for r⁻⁴ force: v = √(α/r³)
        const alpha = this.constants.PHI4 * this.params.couplingStrength;
        const speed = Math.sqrt(alpha / Math.pow(radius, 3));
        
        // Velocity perpendicular to radius vector (for circular orbit)
        const vx = -speed * Math.sin(theta);
        const vy = speed * Math.cos(theta);
        const vz = 0.0;
        
        // Create velocity vector
        const velocity = NumPy.array([vx, vy, vz]);
        
        bodies.push({
          id: `body_${bodyId++}`,
          position,
          velocity,
          mass: 1.0,
          mode,
          glyph: `glyph_${mode}_${i}`,
          metadata: {
            spectralMode: mode,
            shellRadius: radius,
            orbitalSpeed: speed,
            creationTime: Date.now(),
            theta: theta
          }
        });
      }
    });
    
    this.state.bodies = bodies;
    this.state.energy = this.computeTotalEnergy();
  }

  /**
   * Compute pairwise forces between all bodies (r⁻⁴ law)
   */
  private computeAccelerations(): NDArray {
    const N = this.state.bodies.length;
    const accelerations = NumPy.zeros([N, 3]);
    
    for (let i = 0; i < N; i++) {
      for (let j = i + 1; j < N; j++) {
        // Get position vectors
        const pos_i = this.state.bodies[i].position;
        const pos_j = this.state.bodies[j].position;
        
        // Distance vector from j to i
        const rij = NumPy.subtract(pos_i, pos_j);
        
        // Squared distance
        const r2 = NumPy.sum(NumPy.multiply(rij, rij)).data[0];
        
        // Avoid singularity with softening parameter
        const epsilon = this.params.useSoftening ? 1e-6 : 0;
        const r2_soft = r2 + epsilon;
        const r4_soft = r2_soft * r2_soft;
        
        // Force magnitude: F = α / r⁴
        const alpha = this.constants.PHI4 * this.params.couplingStrength;
        const forceMagnitude = alpha / r4_soft;
        
        // Unit vector from j to i
        const r = Math.sqrt(r2);
        const unit_rij = NumPy.divide(rij, NumPy.array([r, r, r]));
        
        // Force vector
        const force = NumPy.multiply(unit_rij, NumPy.array([forceMagnitude, forceMagnitude, forceMagnitude]));
        
        // Apply Newton's third law
        const acc_i = NumPy.divide(force, NumPy.array([this.state.bodies[i].mass, this.state.bodies[i].mass, this.state.bodies[i].mass]));
        const acc_j = NumPy.divide(force, NumPy.array([this.state.bodies[j].mass, this.state.bodies[j].mass, this.state.bodies[j].mass]));
        
        // Update accelerations
        const current_acc_i = accelerations.data.slice(i * 3, (i + 1) * 3);
        const current_acc_j = accelerations.data.slice(j * 3, (j + 1) * 3);
        
        for (let k = 0; k < 3; k++) {
          accelerations.data[i * 3 + k] += acc_i.data[k];
          accelerations.data[j * 3 + k] -= acc_j.data[k];
        }
      }
    }
    
    return accelerations;
  }

  /**
   * Compute total energy of the system (kinetic + potential)
   */
  private computeTotalEnergy(): number {
    let kineticEnergy = 0;
    let potentialEnergy = 0;
    const N = this.state.bodies.length;
    
    // Kinetic energy: Σ(½mv²)
    for (let i = 0; i < N; i++) {
      const vel = this.state.bodies[i].velocity;
      const v2 = NumPy.sum(NumPy.multiply(vel, vel)).data[0];
      kineticEnergy += 0.5 * this.state.bodies[i].mass * v2;
    }
    
    // Potential energy: Σ(α/2r²) for all pairs
    const alpha = this.constants.PHI4 * this.params.couplingStrength;
    for (let i = 0; i < N; i++) {
      for (let j = i + 1; j < N; j++) {
        const pos_i = this.state.bodies[i].position;
        const pos_j = this.state.bodies[j].position;
        const rij = NumPy.subtract(pos_i, pos_j);
        const r2 = NumPy.sum(NumPy.multiply(rij, rij)).data[0];
        
        potentialEnergy += alpha / (2 * r2);
      }
    }
    
    return kineticEnergy + potentialEnergy;
  }

  /**
   * Leap-frog integration step (following Python prototype)
   */
  private leapFrogStep(): void {
    const dt = this.params.dt;
    
    // Compute accelerations at current positions
    const accelerations = this.computeAccelerations();
    
    // Update velocities by half step
    for (let i = 0; i < this.state.bodies.length; i++) {
      const vel = this.state.bodies[i].velocity;
      const acc = accelerations.data.slice(i * 3, (i + 1) * 3);
      
      const newVel = NumPy.add(vel, NumPy.multiply(NumPy.array(acc), NumPy.array([0.5 * dt, 0.5 * dt, 0.5 * dt])));
      this.state.bodies[i].velocity = newVel;
    }
    
    // Update positions by full step
    for (let i = 0; i < this.state.bodies.length; i++) {
      const pos = this.state.bodies[i].position;
      const vel = this.state.bodies[i].velocity;
      
      const newPos = NumPy.add(pos, NumPy.multiply(vel, NumPy.array([dt, dt, dt])));
      this.state.bodies[i].position = newPos;
    }
    
    // Compute new accelerations
    const newAccelerations = this.computeAccelerations();
    
    // Update velocities by another half step
    for (let i = 0; i < this.state.bodies.length; i++) {
      const vel = this.state.bodies[i].velocity;
      const acc = newAccelerations.data.slice(i * 3, (i + 1) * 3);
      
      const newVel = NumPy.add(vel, NumPy.multiply(NumPy.array(acc), NumPy.array([0.5 * dt, 0.5 * dt, 0.5 * dt])));
      this.state.bodies[i].velocity = newVel;
    }
    
    // Update time and step
    this.state.time += dt;
    this.state.step += 1;
    this.state.energy = this.computeTotalEnergy();
  }

  /**
   * Run the simulation (following Python prototype)
   */
  async runSimulation(): AsyncResult<SimulationState[]> {
    try {
      // Clear previous trajectory
      this.trajectory = [];
      
      // Save initial state
      this.trajectory.push(this.cloneState());
      
      // Run simulation
      for (let step = 0; step < this.params.nSteps; step++) {
        this.leapFrogStep();
        
        // Save state at specified intervals
        if (step % this.params.saveInterval === 0) {
          this.trajectory.push(this.cloneState());
          
          // Log progress
          if (step % (this.params.saveInterval * 10) === 0) {
            console.log(`Step ${step}/${this.params.nSteps}, Time: ${this.state.time.toFixed(3)}, Energy: ${this.state.energy.toFixed(6)}`);
          }
        }
      }
      
      // Save final state
      this.trajectory.push(this.cloneState());
      
      // Restore original random function
      this.restoreRandom();
      
      console.log(`Simulation completed: ${this.trajectory.length} frames saved`);
      return ok(this.trajectory);
    } catch (error) {
      this.restoreRandom();
      return err(error as Error);
    }
  }

  /**
   * Clone current state for trajectory storage
   */
  private cloneState(): SimulationState {
    return {
      bodies: this.state.bodies.map(body => ({
        ...body,
        position: NumPy.array([...body.position.data]),
        velocity: NumPy.array([...body.velocity.data])
      })),
      time: this.state.time,
      step: this.state.step,
      energy: this.state.energy,
      parameters: { ...this.state.parameters }
    };
  }

  /**
   * Get current simulation state
   */
  getCurrentState(): SimulationState {
    return this.cloneState();
  }

  /**
   * Get trajectory data
   */
  getTrajectory(): SimulationState[] {
    return this.trajectory.map(state => ({
      bodies: state.bodies.map(body => ({
        ...body,
        position: NumPy.array([...body.position.data]),
        velocity: NumPy.array([...body.velocity.data])
      })),
      time: state.time,
      step: state.step,
      energy: state.energy,
      parameters: { ...state.parameters }
    }));
  }

  /**
   * Get trajectory data formatted for visualization
   */
  getTrajectoryForVisualization(): {
    positions: number[][][];  // [frame][body][coordinate]
    velocities: number[][][]; // [frame][body][coordinate]
    times: number[];          // [frame]
    energies: number[];        // [frame]
    modes: number[];          // [body]
    glyphs: string[];         // [body]
  } {
    const positions: number[][][] = [];
    const velocities: number[][][] = [];
    const times: number[] = [];
    const energies: number[] = [];
    
    this.trajectory.forEach(state => {
      const framePositions: number[][] = [];
      const frameVelocities: number[][] = [];
      
      state.bodies.forEach(body => {
        framePositions.push([...body.position.data]);
        frameVelocities.push([...body.velocity.data]);
      });
      
      positions.push(framePositions);
      velocities.push(frameVelocities);
      times.push(state.time);
      energies.push(state.energy);
    });
    
    const modes = this.state.bodies.map(body => body.mode);
    const glyphs = this.state.bodies.map(body => body.glyph || '');
    
    return {
      positions,
      velocities,
      times,
      energies,
      modes,
      glyphs
    };
  }

  /**
   * Get system statistics
   */
  getStatistics(): {
    totalBodies: number;
    totalEnergy: number;
    time: number;
    step: number;
    modes: number[];
    averageRadius: number;
    energyDrift: number;
    couplingStrength: number;
    phi4: number;
  } {
    const modes = [...new Set(this.state.bodies.map(b => b.mode))];
    const radii = this.state.bodies.map(b => {
      const pos = b.position;
      return Math.sqrt(pos.data[0] * pos.data[0] + pos.data[1] * pos.data[1] + pos.data[2] * pos.data[2]);
    });
    const averageRadius = radii.reduce((sum, r) => sum + r, 0) / radii.length;
    
    const initialEnergy = this.trajectory.length > 0 ? this.trajectory[0].energy : this.state.energy;
    const energyDrift = Math.abs((this.state.energy - initialEnergy) / initialEnergy);
    
    return {
      totalBodies: this.state.bodies.length,
      totalEnergy: this.state.energy,
      time: this.state.time,
      step: this.state.step,
      modes,
      averageRadius,
      energyDrift,
      couplingStrength: this.params.couplingStrength,
      phi4: this.constants.PHI4
    };
  }

  /**
   * Verify φ⁴ alignment with r(3), r(7) as in the mathematical formulation
   */
  verifyPhiAlignment(): {
    phi4: number;
    r3: number;
    r7: number;
    ratio: number;
    alignment: number;
    theoreticalRatio: number;
  } {
    const alignment = this.formulations.verifyPhiAlignment();
    
    return {
      phi4: alignment.phi4,
      r3: alignment.r3,
      r7: alignment.r7,
      ratio: alignment.ratio,
      alignment: alignment.alignment,
      theoreticalRatio: this.constants.PHI4
    };
  }

  /**
   * Reset simulation to initial state
   */
  reset(): void {
    this.state = {
      bodies: [],
      time: 0,
      step: 0,
      energy: 0,
      parameters: this.params
    };
    this.trajectory = [];
    this.initializeBodies();
  }

  /**
   * Add a new body to the simulation
   */
  addBody(body: Omit<SimulationBody, 'id'>): void {
    const newBody: SimulationBody = {
      ...body,
      id: `body_${Date.now()}_${Math.random()}`
    };
    
    this.state.bodies.push(newBody);
    this.state.energy = this.computeTotalEnergy();
  }

  /**
   * Remove a body from the simulation
   */
  removeBody(bodyId: string): boolean {
    const index = this.state.bodies.findIndex(b => b.id === bodyId);
    if (index !== -1) {
      this.state.bodies.splice(index, 1);
      this.state.energy = this.computeTotalEnergy();
      return true;
    }
    return false;
  }

  /**
   * Export simulation data for external analysis
   */
  exportData(): {
    trajectory: SimulationState[];
    parameters: PythonStyleSimulationParams;
    statistics: any;
    phiAlignment: any;
    timestamp: string;
  } {
    return {
      trajectory: this.getTrajectory(),
      parameters: this.params,
      statistics: this.getStatistics(),
      phiAlignment: this.verifyPhiAlignment(),
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Import simulation data from external source
   */
  importData(data: any): Result<void> {
    try {
      if (data.trajectory && data.parameters) {
        this.trajectory = data.trajectory;
        this.params = data.parameters;
        if (data.trajectory.length > 0) {
          this.state = this.cloneState();
        }
        return ok(undefined);
      }
      return err(new Error('Invalid data format'));
    } catch (error) {
      return err(error as Error);
    }
  }
}