/**
 * NumPy-style array operations for TypeScript
 * 
 * Provides NumPy-like functionality for mathematical operations
 * needed for the HLZ orbit simulation and other scientific computations.
 */

export interface NDArray {
  data: number[];
  shape: number[];
  dtype: 'float32' | 'float64' | 'int32' | 'int64';
  strides: number[];
}

export interface ComplexNumber {
  real: number;
  imag: number;
}

export class NumPy {
  /**
   * Create a new n-dimensional array
   */
  static array(data: number | number[] | number[][], shape?: number[]): NDArray {
    const flatData = this.flatten(data);
    const inferredShape = shape || this.inferShape(data);
    const strides = this.computeStrides(inferredShape);
    
    return {
      data: flatData,
      shape: inferredShape,
      dtype: 'float64',
      strides
    };
  }

  /**
   * Create an array filled with zeros
   */
  static zeros(shape: number[]): NDArray {
    const size = shape.reduce((a, b) => a * b, 1);
    return {
      data: new Array(size).fill(0),
      shape,
      dtype: 'float64',
      strides: this.computeStrides(shape)
    };
  }

  /**
   * Create an array filled with ones
   */
  static ones(shape: number[]): NDArray {
    const size = shape.reduce((a, b) => a * b, 1);
    return {
      data: new Array(size).fill(1),
      shape,
      dtype: 'float64',
      strides: this.computeStrides(shape)
    };
  }

  /**
   * Create an array with evenly spaced values
   */
  static linspace(start: number, stop: number, num: number = 50): NDArray {
    const step = (stop - start) / (num - 1);
    const data = Array.from({ length: num }, (_, i) => start + i * step);
    
    return {
      data,
      shape: [num],
      dtype: 'float64',
      strides: [1]
    };
  }

  /**
   * Create an array with values in a range
   */
  static arange(start: number, stop?: number, step: number = 1): NDArray {
    const actualStop = stop !== undefined ? stop : start;
    const actualStart = stop !== undefined ? start : 0;
    const num = Math.ceil((actualStop - actualStart) / step);
    const data = Array.from({ length: num }, (_, i) => actualStart + i * step);
    
    return {
      data,
      shape: [num],
      dtype: 'float64',
      strides: [1]
    };
  }

  /**
   * Create a random array with values between 0 and 1
   */
  static random(shape: number[]): NDArray {
    const size = shape.reduce((a, b) => a * b, 1);
    const data = Array.from({ length: size }, () => Math.random());
    
    return {
      data,
      shape,
      dtype: 'float64',
      strides: this.computeStrides(shape)
    };
  }

  /**
   * Create a random array with normal distribution
   */
  static randomNormal(shape: number[], mean: number = 0, std: number = 1): NDArray {
    const size = shape.reduce((a, b) => a * b, 1);
    const data = Array.from({ length: size }, () => {
      // Box-Muller transform
      const u1 = Math.random();
      const u2 = Math.random();
      const z0 = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
      return mean + std * z0;
    });
    
    return {
      data,
      shape,
      dtype: 'float64',
      strides: this.computeStrides(shape)
    };
  }

  /**
   * Reshape an array
   */
  static reshape(arr: NDArray, newShape: number[]): NDArray {
    const newSize = newShape.reduce((a, b) => a * b, 1);
    const currentSize = arr.data.length;
    
    if (newSize !== currentSize) {
      throw new Error(`Cannot reshape array of size ${currentSize} into shape ${newShape}`);
    }
    
    return {
      data: [...arr.data],
      shape: newShape,
      dtype: arr.dtype,
      strides: this.computeStrides(newShape)
    };
  }

  /**
   * Transpose an array
   */
  static transpose(arr: NDArray, axes?: number[]): NDArray {
    if (arr.shape.length !== 2) {
      throw new Error('Transpose currently only supports 2D arrays');
    }
    
    const [rows, cols] = arr.shape;
    const newData = new Array(cols * rows);
    
    for (let i = 0; i < rows; i++) {
      for (let j = 0; j < cols; j++) {
        newData[j * rows + i] = arr.data[i * cols + j];
      }
    }
    
    return {
      data: newData,
      shape: [cols, rows],
      dtype: arr.dtype,
      strides: [rows, 1]
    };
  }

  /**
   * Element-wise addition
   */
  static add(a: NDArray, b: NDArray): NDArray {
    this.assertShapesMatch(a.shape, b.shape);
    
    const result = this.zeros(a.shape);
    for (let i = 0; i < a.data.length; i++) {
      result.data[i] = a.data[i] + b.data[i];
    }
    
    return result;
  }

  /**
   * Element-wise subtraction
   */
  static subtract(a: NDArray, b: NDArray): NDArray {
    this.assertShapesMatch(a.shape, b.shape);
    
    const result = this.zeros(a.shape);
    for (let i = 0; i < a.data.length; i++) {
      result.data[i] = a.data[i] - b.data[i];
    }
    
    return result;
  }

  /**
   * Element-wise multiplication
   */
  static multiply(a: NDArray, b: NDArray): NDArray {
    this.assertShapesMatch(a.shape, b.shape);
    
    const result = this.zeros(a.shape);
    for (let i = 0; i < a.data.length; i++) {
      result.data[i] = a.data[i] * b.data[i];
    }
    
    return result;
  }

  /**
   * Element-wise division
   */
  static divide(a: NDArray, b: NDArray): NDArray {
    this.assertShapesMatch(a.shape, b.shape);
    
    const result = this.zeros(a.shape);
    for (let i = 0; i < a.data.length; i++) {
      if (b.data[i] === 0) {
        throw new Error('Division by zero');
      }
      result.data[i] = a.data[i] / b.data[i];
    }
    
    return result;
  }

  /**
   * Matrix multiplication
   */
  static matmul(a: NDArray, b: NDArray): NDArray {
    if (a.shape.length !== 2 || b.shape.length !== 2) {
      throw new Error('Matrix multiplication requires 2D arrays');
    }
    
    const [m, n] = a.shape;
    const [n2, p] = b.shape;
    
    if (n !== n2) {
      throw new Error(`Matrix dimension mismatch: ${a.shape} and ${b.shape}`);
    }
    
    const result = this.zeros([m, p]);
    
    for (let i = 0; i < m; i++) {
      for (let j = 0; j < p; j++) {
        let sum = 0;
        for (let k = 0; k < n; k++) {
          sum += a.data[i * n + k] * b.data[k * p + j];
        }
        result.data[i * p + j] = sum;
      }
    }
    
    return result;
  }

  /**
   * Dot product
   */
  static dot(a: NDArray, b: NDArray): NDArray {
    if (a.shape.length === 1 && b.shape.length === 1) {
      // Vector dot product
      if (a.shape[0] !== b.shape[0]) {
        throw new Error('Vector length mismatch');
      }
      let sum = 0;
      for (let i = 0; i < a.shape[0]; i++) {
        sum += a.data[i] * b.data[i];
      }
      return this.array([sum]);
    } else if (a.shape.length === 2 && b.shape.length === 2) {
      // Matrix multiplication
      return this.matmul(a, b);
    } else {
      throw new Error('Dot product not supported for these shapes');
    }
  }

  /**
   * Sum of all elements
   */
  static sum(arr: NDArray, axis?: number): NDArray {
    if (axis === undefined) {
      // Sum all elements
      const total = arr.data.reduce((sum, val) => sum + val, 0);
      return this.array([total]);
    }
    
    // Sum along axis
    if (axis < 0 || axis >= arr.shape.length) {
      throw new Error(`Axis ${axis} out of bounds for array with ${arr.shape.length} dimensions`);
    }
    
    const newShape = arr.shape.filter((_, i) => i !== axis);
    const result = this.zeros(newShape);
    
    // This is a simplified implementation
    // In practice, you'd need more complex indexing logic
    if (arr.shape.length === 2) {
      if (axis === 0) {
        // Sum along rows
        for (let j = 0; j < arr.shape[1]; j++) {
          let sum = 0;
          for (let i = 0; i < arr.shape[0]; i++) {
            sum += arr.data[i * arr.shape[1] + j];
          }
          result.data[j] = sum;
        }
      } else {
        // Sum along columns
        for (let i = 0; i < arr.shape[0]; i++) {
          let sum = 0;
          for (let j = 0; j < arr.shape[1]; j++) {
            sum += arr.data[i * arr.shape[1] + j];
          }
          result.data[i] = sum;
        }
      }
    }
    
    return result;
  }

  /**
   * Mean of all elements
   */
  static mean(arr: NDArray, axis?: number): NDArray {
    const sum = this.sum(arr, axis);
    const count = axis === undefined ? 
      arr.data.length : 
      arr.shape[axis];
    
    return this.divide(sum, this.array([count]));
  }

  /**
   * Standard deviation
   */
  static std(arr: NDArray, axis?: number): NDArray {
    const mean = this.mean(arr, axis);
    const squaredDiff = this.subtract(arr, mean);
    const squared = this.multiply(squaredDiff, squaredDiff);
    const variance = this.mean(squared, axis);
    
    return this.sqrt(variance);
  }

  /**
   * Square root
   */
  static sqrt(arr: NDArray): NDArray {
    const result = this.zeros(arr.shape);
    for (let i = 0; i < arr.data.length; i++) {
      if (arr.data[i] < 0) {
        throw new Error('Square root of negative number');
      }
      result.data[i] = Math.sqrt(arr.data[i]);
    }
    return result;
  }

  /**
   * Power
   */
  static power(arr: NDArray, exponent: number): NDArray {
    const result = this.zeros(arr.shape);
    for (let i = 0; i < arr.data.length; i++) {
      result.data[i] = Math.pow(arr.data[i], exponent);
    }
    return result;
  }

  /**
   * Absolute value
   */
  static abs(arr: NDArray): NDArray {
    const result = this.zeros(arr.shape);
    for (let i = 0; i < arr.data.length; i++) {
      result.data[i] = Math.abs(arr.data[i]);
    }
    return result;
  }

  /**
   * Element-wise comparison
   */
  static equal(a: NDArray, b: NDArray): NDArray {
    this.assertShapesMatch(a.shape, b.shape);
    
    const result = this.zeros(a.shape);
    for (let i = 0; i < a.data.length; i++) {
      result.data[i] = a.data[i] === b.data[i] ? 1 : 0;
    }
    return result;
  }

  /**
   * Get element at specific indices
   */
  static get(arr: NDArray, indices: number[]): number {
    if (indices.length !== arr.shape.length) {
      throw new Error(`Expected ${arr.shape.length} indices, got ${indices.length}`);
    }
    
    let index = 0;
    for (let i = 0; i < indices.length; i++) {
      if (indices[i] < 0 || indices[i] >= arr.shape[i]) {
        throw new Error(`Index ${indices[i]} out of bounds for dimension ${i}`);
      }
      index += indices[i] * arr.strides[i];
    }
    
    return arr.data[index];
  }

  /**
   * Set element at specific indices
   */
  static set(arr: NDArray, indices: number[], value: number): void {
    if (indices.length !== arr.shape.length) {
      throw new Error(`Expected ${arr.shape.length} indices, got ${indices.length}`);
    }
    
    let index = 0;
    for (let i = 0; i < indices.length; i++) {
      if (indices[i] < 0 || indices[i] >= arr.shape[i]) {
        throw new Error(`Index ${indices[i]} out of bounds for dimension ${i}`);
      }
      index += indices[i] * arr.strides[i];
    }
    
    arr.data[index] = value;
  }

  /**
   * Convert array to JavaScript array
   */
  static toArray(arr: NDArray): number | number[] | number[][] {
    if (arr.shape.length === 0) {
      return arr.data[0];
    } else if (arr.shape.length === 1) {
      return [...arr.data];
    } else if (arr.shape.length === 2) {
      const [rows, cols] = arr.shape;
      const result: number[][] = [];
      for (let i = 0; i < rows; i++) {
        result.push(arr.data.slice(i * cols, (i + 1) * cols));
      }
      return result;
    } else {
      throw new Error('Conversion to JavaScript array only supports up to 2D arrays');
    }
  }

  /**
   * Flatten nested array structure
   */
  private static flatten(data: number | number[] | number[][]): number[] {
    if (typeof data === 'number') {
      return [data];
    } else if (Array.isArray(data[0])) {
      // 2D array
      return (data as number[][]).flat();
    } else {
      // 1D array
      return data as number[];
    }
  }

  /**
   * Infer shape from nested array structure
   */
  private static inferShape(data: number | number[] | number[][]): number[] {
    if (typeof data === 'number') {
      return [];
    } else if (Array.isArray(data[0])) {
      // 2D array
      const arr2d = data as number[][];
      return [arr2d.length, arr2d[0]?.length || 0];
    } else {
      // 1D array
      return [(data as number[]).length];
    }
  }

  /**
   * Compute strides for given shape
   */
  private static computeStrides(shape: number[]): number[] {
    const strides = new Array(shape.length);
    strides[shape.length - 1] = 1;
    
    for (let i = shape.length - 2; i >= 0; i--) {
      strides[i] = strides[i + 1] * shape[i + 1];
    }
    
    return strides;
  }

  /**
   * Assert that two shapes match
   */
  private static assertShapesMatch(shape1: number[], shape2: number[]): void {
    if (shape1.length !== shape2.length) {
      throw new Error(`Shape mismatch: ${shape1} and ${shape2}`);
    }
    
    for (let i = 0; i < shape1.length; i++) {
      if (shape1[i] !== shape2[i]) {
        throw new Error(`Shape mismatch: ${shape1} and ${shape2}`);
      }
    }
  }
}

// Complex number operations
export class Complex {
  /**
   * Create complex number from real and imaginary parts
   */
  static create(real: number, imag: number = 0): ComplexNumber {
    return { real, imag };
  }

  /**
   * Add two complex numbers
   */
  static add(a: ComplexNumber, b: ComplexNumber): ComplexNumber {
    return {
      real: a.real + b.real,
      imag: a.imag + b.imag
    };
  }

  /**
   * Subtract two complex numbers
   */
  static subtract(a: ComplexNumber, b: ComplexNumber): ComplexNumber {
    return {
      real: a.real - b.real,
      imag: a.imag - b.imag
    };
  }

  /**
   * Multiply two complex numbers
   */
  static multiply(a: ComplexNumber, b: ComplexNumber): ComplexNumber {
    return {
      real: a.real * b.real - a.imag * b.imag,
      imag: a.real * b.imag + a.imag * b.real
    };
  }

  /**
   * Divide two complex numbers
   */
  static divide(a: ComplexNumber, b: ComplexNumber): ComplexNumber {
    const denominator = b.real * b.real + b.imag * b.imag;
    return {
      real: (a.real * b.real + a.imag * b.imag) / denominator,
      imag: (a.imag * b.real - a.real * b.imag) / denominator
    };
  }

  /**
   * Complex conjugate
   */
  static conjugate(z: ComplexNumber): ComplexNumber {
    return {
      real: z.real,
      imag: -z.imag
    };
  }

  /**
   * Magnitude (absolute value)
   */
  static magnitude(z: ComplexNumber): number {
    return Math.sqrt(z.real * z.real + z.imag * z.imag);
  }

  /**
   * Phase (argument)
   */
  static phase(z: ComplexNumber): number {
    return Math.atan2(z.imag, z.real);
  }

  /**
   * Complex exponential
   */
  static exp(z: ComplexNumber): ComplexNumber {
    const expReal = Math.exp(z.real);
    return {
      real: expReal * Math.cos(z.imag),
      imag: expReal * Math.sin(z.imag)
    };
  }

  /**
   * Complex natural logarithm
   */
  static log(z: ComplexNumber): ComplexNumber {
    return {
      real: Math.log(this.magnitude(z)),
      imag: this.phase(z)
    };
  }

  /**
   * Complex power
   */
  static power(z: ComplexNumber, exponent: number): ComplexNumber {
    const r = this.magnitude(z);
    const theta = this.phase(z);
    const newR = Math.pow(r, exponent);
    const newTheta = exponent * theta;
    
    return {
      real: newR * Math.cos(newTheta),
      imag: newR * Math.sin(newTheta)
    };
  }
}

// Linear algebra utilities
export class Linalg {
  /**
   * Create identity matrix
   */
  static eye(n: number): NDArray {
    const result = NumPy.zeros([n, n]);
    for (let i = 0; i < n; i++) {
      NumPy.set(result, [i, i], 1);
    }
    return result;
  }

  /**
   * Matrix determinant (2x2 only)
   */
  static det(arr: NDArray): number {
    if (arr.shape.length !== 2 || arr.shape[0] !== arr.shape[1]) {
      throw new Error('Determinant only implemented for square matrices');
    }
    
    if (arr.shape[0] === 2) {
      const [[a, b], [c, d]] = NumPy.toArray(arr) as number[][];
      return a * d - b * c;
    } else {
      throw new Error('Determinant only implemented for 2x2 matrices');
    }
  }

  /**
   * Matrix inverse (2x2 only)
   */
  static inv(arr: NDArray): NDArray {
    if (arr.shape.length !== 2 || arr.shape[0] !== 2 || arr.shape[1] !== 2) {
      throw new Error('Inverse only implemented for 2x2 matrices');
    }
    
    const [[a, b], [c, d]] = NumPy.toArray(arr) as number[][];
    const det = a * d - b * c;
    
    if (Math.abs(det) < 1e-10) {
      throw new Error('Matrix is singular (determinant is zero)');
    }
    
    const invDet = 1 / det;
    return NumPy.array([
      [d * invDet, -b * invDet],
      [-c * invDet, a * invDet]
    ]);
  }

  /**
   * Eigenvalues (2x2 symmetric only)
   */
  static eig(arr: NDArray): { values: NDArray; vectors: NDArray } {
    if (arr.shape.length !== 2 || arr.shape[0] !== 2 || arr.shape[1] !== 2) {
      throw new Error('Eigenvalues only implemented for 2x2 matrices');
    }
    
    const [[a, b], [c, d]] = NumPy.toArray(arr) as number[][];
    
    // For symmetric matrix (b == c)
    if (Math.abs(b - c) > 1e-10) {
      throw new Error('Eigenvalues only implemented for symmetric matrices');
    }
    
    const trace = a + d;
    const det = a * d - b * b;
    const discriminant = trace * trace - 4 * det;
    
    if (discriminant < 0) {
      throw new Error('Complex eigenvalues not supported');
    }
    
    const sqrtDiscriminant = Math.sqrt(discriminant);
    const lambda1 = (trace + sqrtDiscriminant) / 2;
    const lambda2 = (trace - sqrtDiscriminant) / 2;
    
    // Compute eigenvectors
    let v1, v2;
    if (Math.abs(b) > 1e-10) {
      v1 = [b, lambda1 - a];
      v2 = [b, lambda2 - a];
    } else {
      v1 = [1, 0];
      v2 = [0, 1];
    }
    
    // Normalize eigenvectors
    const norm1 = Math.sqrt(v1[0] * v1[0] + v1[1] * v1[1]);
    const norm2 = Math.sqrt(v2[0] * v2[0] + v2[1] * v2[1]);
    
    return {
      values: NumPy.array([lambda1, lambda2]),
      vectors: NumPy.array([
        [v1[0] / norm1, v2[0] / norm2],
        [v1[1] / norm1, v2[1] / norm2]
      ])
    };
  }
}