import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(request.url);
    const testType = searchParams.get('testType');
    const status = searchParams.get('status');

    const where: any = { walletId: params.id };
    if (testType) where.testType = testType;
    if (status) where.status = status;

    const auditTests = await db.walletAuditTest.findMany({
      where,
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(auditTests);
  } catch (error) {
    console.error('Error fetching audit tests:', error);
    return NextResponse.json(
      { error: 'Failed to fetch audit tests' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const {
      testType,
      testName,
      description,
      result,
      score,
      confidence,
      findings,
      recommendations
    } = body;

    // Validate required fields
    if (!testType || !testName) {
      return NextResponse.json(
        { error: 'Test type and test name are required' },
        { status: 400 }
      );
    }

    // Check if wallet exists
    const wallet = await db.wallet.findUnique({
      where: { id: params.id }
    });

    if (!wallet) {
      return NextResponse.json(
        { error: 'Wallet not found' },
        { status: 404 }
      );
    }

    const auditTest = await db.walletAuditTest.create({
      data: {
        walletId: params.id,
        testType,
        testName,
        description,
        result: result ? JSON.stringify(result) : null,
        score,
        confidence,
        findings: findings ? JSON.stringify(findings) : null,
        recommendations: recommendations ? JSON.stringify(recommendations) : null,
        startedAt: new Date(),
        status: 'running'
      }
    });

    // Simulate test execution (in real implementation, this would be async)
    setTimeout(async () => {
      try {
        const mockResult = {
          verificationStatus: Math.random() > 0.3 ? 'verified' : 'failed',
          confidence: 0.7 + Math.random() * 0.3,
          details: {
            signatureVerified: Math.random() > 0.2,
            knowledgeProof: Math.random() > 0.3,
            possessionVerified: Math.random() > 0.1,
            riskFactors: []
          }
        };

        await db.walletAuditTest.update({
          where: { id: auditTest.id },
          data: {
            status: mockResult.verificationStatus === 'verified' ? 'completed' : 'failed',
            result: JSON.stringify(mockResult),
            score: mockResult.confidence * 100,
            confidence: mockResult.confidence,
            findings: JSON.stringify(mockResult.details),
            completedAt: new Date()
          }
        });
      } catch (error) {
        console.error('Error updating audit test:', error);
      }
    }, 3000);

    return NextResponse.json(auditTest, { status: 201 });
  } catch (error) {
    console.error('Error creating audit test:', error);
    return NextResponse.json(
      { error: 'Failed to create audit test' },
      { status: 500 }
    );
  }
}