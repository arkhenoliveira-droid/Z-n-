'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  MessageCircle, 
  Users, 
  Heart,
  Share2,
  Image,
  Gamepad2,
  Calendar,
  Smile,
  User,
  TrendingUp,
  Bell,
  Search,
  XCircle,
  Plus,
  LogOut,
  LogIn,
  UserPlus,
  UserMinus,
  Send,
  Home,
  BookOpen,
  Activity,
  ArrowDown,
  ArrowLeftRight,
  RefreshCw,
  Hash,
  AtSign,
  Globe,
  Clock,
  Star,
  Award,
  Zap,
  Play,
  Pause,
  Volume2,
  Eye,
  Lock,
  Unlock,
  Settings,
  HelpCircle,
  Info,
  AlertCircle,
  CheckCircle,
  Filter,
  Bookmark,
  Gift,
  Trophy,
  Target,
  ChevronRight,
  ChevronLeft,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  RotateCcw,
  RotateCw,
  Maximize,
  Minimize,
  Copy,
  Edit,
  Trash2,
  Save,
  Folder,
  FolderOpen,
  Cloud,
  CloudDownload,
  CloudUpload,
  Wifi,
  Download,
  Upload,
  WifiOff,
  Battery,
  BatteryCharging,
  BatteryFull,
  BatteryLow,
  BatteryMedium,
  Plug,
  Unplug,
  Bluetooth,
  BluetoothOff,
  Usb,
  Hdmi,
  Cpu,
  HardDrive,
  Database,
  Server,
  Film,
  Tv,
  Radio,
  Music,
  Mic,
  MicOff,
  VideoOff,
  PhoneCall,
  PhoneMissed,
  PhoneForwarded,
  PhoneIncoming,
  PhoneOutgoing,
  Voicemail,
  Smartphone,
  Tablet,
  Laptop,
  Monitor,
  MonitorSpeaker,
  MonitorSmartphone,
  MonitorUp,
  MonitorDown,
  MonitorCheck,
  MonitorX,
  MonitorDot,
  MonitorStop,
  MonitorPause,
  MonitorRecord,
  MonitorPlay,
  Mail,
  MailOpen,
  MailCheck,
  MailX,
  MailMinus,
  MailPlus,
  MailSearch,
  MailWarning,
  MailQuestion,
  Inbox,
  InboxIcon,
  SendHorizontal,
  SendToBack,
  SendForward,
  Paperclip,
  PaperclipHorizontal,
  PaperclipX,
  PaperclipCheck,
  PaperclipMinus,
  PaperclipPlus,
  Link2,
  Link2Off,
  Unlink,
  Unlink2,
  Link,
  LinkBreak,
  LinkSimple,
  LinkSimpleHorizontal,
  LinkSimpleBreak,
  LinkSimpleX,
  LinkSimplePlus,
  LinkSimpleMinus,
  LinkSimpleCheck,
  HashIcon,
  At,
  Mention,
  MentionOff,
  Mention2,
  Mention2Off,
  Mention3,
  Mention3Off,
  Mention4,
  Mention4Off,
  Mention5,
  Mention5Off,
  Mention6,
  Mention6Off,
  Mention7,
  Mention7Off,
  Mention8,
  Mention8Off,
  Mention9,
  Mention9Off,
  Mention10,
  Mention10Off,
  HomeIcon,
  Compass,
  Map,
  MapPin,
  Navigation,
  Navigation2,
  Navigation2Off,
  NavigationOff,
  Locate,
  LocateFixed,
  LocateOff,
  ZoomIn,
  ZoomOut,
  Zoom,
  Maximize2,
  Minimize2,
  Fullscreen,
  FullscreenExit,
  Key,
  KeyRound,
  Shield,
  ShieldCheck,
  ShieldX,
  ShieldAlert,
  ShieldHalf,
  ShieldBan,
  ShieldClose,
  ShieldPlus,
  ShieldMinus,
  Fingerprint,
  LockKeyhole,
  LockKeyholeOpen,
  UnlockKeyhole,
  LockOpen,
  Unlock,
  EyeOff,
  EyeDropper,
  EyeDropperOff,
  Glasses,
  GlassesOff,
  Contact,
  Contact2,
  Contacts,
  Phone,
  PhoneOff,
  PhoneCall,
  HeartHandshake,
  MessageCircleHeart,
  MessageCircleCode,
  MessageCircleDollar,
  MessageCircleMore,
  MessageCircleReply,
  MessageCircleX,
  PaperPlane,
  Globe3,
  CompassCalibration,
  MapPinned,
  UserCircle,
  UserCog,
  UserX,
  Users2,
  UsersRound,
  UserPlus2,
  HeartHandshake as HeartHandshake2,
  MessageCircleHeart as MessageCircleHeart2,
  MessageCircleCode as MessageCircleCode2,
  MessageCircleDollar as MessageCircleDollar2,
  MessageCircleMore as MessageCircleMore2,
  MessageCircleReply as MessageCircleReply2,
  MessageCircleX as MessageCircleX2,
  ThumbsUp,
  Camera,
  Video,
  FileText,
  Link,
  History,
  Play as PlayIcon,
  Pause as PauseIcon,
  Volume2 as Volume2Icon,
  VolumeX,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  RadioIcon,
  Monitor as MonitorIcon,
  Smartphone as SmartphoneIcon,
  Globe2 as Globe2Icon,
  Wifi as WifiIcon,
  Download as DownloadIcon,
  Upload as UploadIcon,
  MessageSquare,
  Hash as HashIcon2,
  AtSign as AtSignIcon,
  Bell as BellIcon,
  Search as SearchIcon,
  Filter as FilterIcon,
  Bookmark as BookmarkIcon,
  Share as ShareIcon,
  Gift as GiftIcon,
  Trophy as TrophyIcon,
  Target as TargetIcon,
  Eye as EyeIcon,
  Lock as LockIcon,
  Unlock as UnlockIcon,
  Settings as SettingsIcon,
  HelpCircle as HelpCircleIcon,
  Info as InfoIcon,
  AlertCircle as AlertCircleIcon,
  CheckCircle as CheckCircleIcon,
  Plus as PlusIcon,
  Minus as MinusIcon,
  ChevronRight as ChevronRightIcon,
  ChevronLeft as ChevronLeftIcon,
  ArrowUp as ArrowUpIcon,
  ArrowDown as ArrowDownIcon,
  ArrowLeft as ArrowLeftIcon,
  ArrowRight as ArrowRightIcon,
  RotateCcw as RotateCcwIcon,
  RotateCw as RotateCwIcon,
  Maximize as MaximizeIcon,
  Minimize as MinimizeIcon,
  Move as MoveIcon,
  Copy as CopyIcon,
  Scissors as ScissorsIcon,
  Edit as EditIcon,
  Trash2 as Trash2Icon,
  Save as SaveIcon,
  Folder as FolderIcon,
  FolderOpen as FolderOpenIcon,
  HardDrive as HardDriveIcon,
  Database as DatabaseIcon,
  Server as ServerIcon,
  Cloud as CloudIcon,
  CloudDownload as CloudDownloadIcon,
  CloudUpload as CloudUploadIcon,
  CloudOff as CloudOffIcon,
  WifiOff as WifiOffIcon,
  Battery as BatteryIcon,
  BatteryCharging as BatteryChargingIcon,
  BatteryFull as BatteryFullIcon,
  BatteryLow as BatteryLowIcon,
  BatteryMedium as BatteryMediumIcon,
  Plug as PlugIcon,
  Unplug as UnplugIcon,
  Bluetooth as BluetoothIcon,
  BluetoothOff as BluetoothOffIcon,
  Usb as UsbIcon,
  Hdmi as HdmiIcon,
  Cpu as CpuIcon,
  MemoryStick,
  SdCard,
  Dvd,
  Disc,
  Film as FilmIcon,
  Tv as TvIcon,
  Radio as RadioIcon2,
  Music as MusicIcon,
  Mic as MicIcon,
  MicOff as MicOffIcon,
  VideoOff as VideoOffIcon,
  PhoneCall as PhoneCallIcon,
  PhoneMissed as PhoneMissedIcon,
  PhoneForwarded as PhoneForwardedIcon,
  PhoneIncoming as PhoneIncomingIcon,
  PhoneOutgoing as PhoneOutgoingIcon,
  Voicemail as VoicemailIcon,
  Smartphone as SmartphoneIcon2,
  SmartphoneNfc,
  SmartphoneCharging,
  Tablet,
  TabletSmartphone,
  Laptop,
  Laptop2,
  Monitor as MonitorIcon2,
  MonitorSpeaker,
  MonitorSmartphone,
  MonitorUp,
  MonitorDown,
  MonitorCheck,
  MonitorX,
  MonitorDot,
  MonitorStop,
  MonitorPause,
  MonitorRecord,
  MonitorPlay,
  Mails,
  MailOpen as MailOpenIcon,
  MailCheck as MailCheckIcon,
  MailX as MailXIcon,
  MailMinus as MailMinusIcon,
  MailPlus as MailPlusIcon,
  MailSearch as MailSearchIcon,
  MailWarning as MailWarningIcon,
  MailQuestion as MailQuestionIcon,
  Mail as MailIcon,
  Inbox as InboxIcon,
  InboxIcon as InboxIcon2,
  SendHorizontal as SendHorizontalIcon,
  SendToBack as SendToBackIcon,
  SendForward as SendForwardIcon,
  Paperclip as PaperclipIcon,
  PaperclipHorizontal as PaperclipHorizontalIcon,
  PaperclipX as PaperclipXIcon,
  PaperclipCheck as PaperclipCheckIcon,
  PaperclipMinus as PaperclipMinusIcon,
  PaperclipPlus as PaperclipPlusIcon,
  Link2 as Link2Icon,
  Link2Off as Link2OffIcon,
  Unlink as UnlinkIcon,
  Unlink2 as Unlink2Icon,
  Link as LinkIcon,
  LinkBreak as LinkBreakIcon,
  LinkSimple as LinkSimpleIcon,
  LinkSimpleHorizontal as LinkSimpleHorizontalIcon,
  LinkSimpleBreak as LinkSimpleBreakIcon,
  LinkSimpleX as LinkSimpleXIcon,
  LinkSimplePlus as LinkSimplePlusIcon,
  LinkSimpleMinus as LinkSimpleMinusIcon,
  LinkSimpleCheck as LinkSimpleCheckIcon,
  Hash as HashIcon3,
  AtSign as AtSignIcon2,
  At as AtIcon,
  Mention as MentionIcon,
  MentionOff as MentionOffIcon,
  Mention2 as Mention2Icon,
  Mention2Off as Mention2OffIcon,
  Mention3 as Mention3Icon,
  Mention3Off as Mention3OffIcon,
  Mention4 as Mention4Icon,
  Mention4Off as Mention4OffIcon,
  Mention5 as Mention5Icon,
  Mention5Off as Mention5OffIcon,
  Mention6 as Mention6Icon,
  Mention6Off as Mention6OffIcon,
  Mention7 as Mention7Icon,
  Mention7Off as Mention7OffIcon,
  Mention8 as Mention8Icon,
  Mention8Off as Mention8OffIcon,
  Mention9 as Mention9Icon,
  Mention9Off as Mention9OffIcon,
  Mention10 as Mention10Icon,
  Mention10Off as Mention10OffIcon,
  BookOpen as BookOpenIcon,
  Activity as ActivityIcon,
  ArrowDown as ArrowDownIcon
} from 'lucide-react';

// Interfaces para a rede social coerente
interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  avatar: string;
  bio: string;
  joinDate: string;
  friends: string[];
  communities: string[];
  posts: string[];
  status: 'online' | 'offline' | 'away' | 'busy';
  theme: 'msn' | 'orkut' | 'modern';
  privacy: 'public' | 'friends' | 'private';
}

interface Post {
  id: string;
  authorId: string;
  content: string;
  timestamp: string;
  likes: string[];
  comments: Comment[];
  shares: number;
  type: 'text' | 'image' | 'memory' | 'educational';
  tags: string[];
  communityId?: string;
}

interface Comment {
  id: string;
  authorId: string;
  content: string;
  timestamp: string;
  likes: string[];
  replies: Comment[];
}

interface Community {
  id: string;
  name: string;
  description: string;
  creatorId: string;
  members: string[];
  posts: string[];
  tags: string[];
  theme: 'msn' | 'orkut' | 'mixed';
  isPrivate: boolean;
  created: string;
}

interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  status: 'sent' | 'delivered' | 'read';
  type: 'text' | 'image' | 'file';
}

interface Notification {
  id: string;
  userId: string;
  type: 'like' | 'comment' | 'friend' | 'message' | 'community';
  content: string;
  timestamp: string;
  read: boolean;
  actionUrl?: string;
}

export default function CoherentSocialNetwork() {
  // Estados do usuário
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [showLogin, setShowLogin] = useState<boolean>(false);
  const [showRegister, setShowRegister] = useState<boolean>(false);
  
  // Estados de conteúdo
  const [posts, setPosts] = useState<Post[]>([]);
  const [communities, setCommunities] = useState<Community[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  
  // Estados de UI
  const [newPost, setNewPost] = useState<string>('');
  const [activeTab, setActiveTab] = useState<string>('feed');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTheme, setSelectedTheme] = useState<'msn' | 'orkut' | 'modern'>('modern');
  const [onlineUsers, setOnlineUsers] = useState<number>(0);
  
  // Dados mockados iniciais
  const mockUsers: User[] = [
    {
      id: '1',
      name: 'Ana Silva',
      username: 'anasilva',
      email: 'ana@example.com',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ana',
      bio: 'Apaixonada por tecnologia e nostalgia digital',
      joinDate: '2024-01-15',
      friends: ['2', '3'],
      communities: ['1', '2'],
      posts: ['1', '2'],
      status: 'online',
      theme: 'msn',
      privacy: 'public'
    },
    {
      id: '2',
      name: 'Carlos Santos',
      username: 'carlossantos',
      email: 'carlos@example.com',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=carlos',
      bio: 'Desenvolvedor e entusiasta de redes sociais',
      joinDate: '2024-01-20',
      friends: ['1', '3'],
      communities: ['1', '3'],
      posts: ['3', '4'],
      status: 'online',
      theme: 'orkut',
      privacy: 'public'
    },
    {
      id: '3',
      name: 'Mariana Costa',
      username: 'marianacosta',
      email: 'mariana@example.com',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mariana',
      bio: 'Designer gráfica e amante de memes',
      joinDate: '2024-02-01',
      friends: ['1', '2'],
      communities: ['2', '3'],
      posts: ['5'],
      status: 'away',
      theme: 'modern',
      privacy: 'friends'
    }
  ];

  const mockCommunities: Community[] = [
    {
      id: '1',
      name: 'Nostalgia MSN',
      description: 'Comunidade para quem sente falta do MSN Messenger',
      creatorId: '1',
      members: ['1', '2', '3'],
      posts: ['1', '3'],
      tags: ['msn', 'nostalgia', 'mensageria'],
      theme: 'msn',
      isPrivate: false,
      created: '2024-01-15'
    },
    {
      id: '2',
      name: 'Lembranças do Orkut',
      description: 'Revivendo os melhores momentos do Orkut',
      creatorId: '2',
      members: ['1', '3'],
      posts: ['2'],
      tags: ['orkut', 'comunidades', 'recados'],
      theme: 'orkut',
      isPrivate: false,
      created: '2024-01-20'
    },
    {
      id: '3',
      name: 'Evolução Digital',
      description: 'Discussões sobre a evolução das redes sociais',
      creatorId: '3',
      members: ['2', '3'],
      posts: ['4', '5'],
      tags: ['tecnologia', 'redes sociais', 'evolução'],
      theme: 'mixed',
      isPrivate: false,
      created: '2024-02-01'
    }
  ];

  const mockPosts: Post[] = [
    {
      id: '1',
      authorId: '1',
      content: 'Alguém mais sente falta do som de notificação do MSN? 🎵 Essa era a trilha sonora da minha adolescência!',
      timestamp: '2024-03-15T14:30:00Z',
      likes: ['2', '3'],
      comments: [
        {
          id: '1',
          authorId: '2',
          content: 'Sim! Era o melhor som do mundo! 🔥',
          timestamp: '2024-03-15T14:35:00Z',
          likes: ['1'],
          replies: []
        }
      ],
      shares: 5,
      type: 'memory',
      tags: ['msn', 'nostalgia'],
      communityId: '1'
    },
    {
      id: '2',
      authorId: '2',
      content: 'Lembrando quando passávamos horas no Orkut deixando recados e entrando em comunidades... Tempos bons! ✨',
      timestamp: '2024-03-15T16:20:00Z',
      likes: ['1', '3'],
      comments: [],
      shares: 3,
      type: 'memory',
      tags: ['orkut', 'saudade'],
      communityId: '2'
    },
    {
      id: '3',
      authorId: '1',
      content: '📚 Artigo: A evolução dos mensageiros instantâneos - Do MSN ao WhatsApp. Uma análise completa de como a comunicação digital mudou!',
      timestamp: '2024-03-15T18:45:00Z',
      likes: ['2'],
      comments: [],
      shares: 8,
      type: 'educational',
      tags: ['educação', 'tecnologia', 'história'],
      communityId: '1'
    }
  ];

  // Inicialização
  useEffect(() => {
    setPosts(mockPosts);
    setCommunities(mockCommunities);
    setOnlineUsers(mockUsers.filter(u => u.status === 'online').length);
    
    // Simular notificações
    const mockNotifications: Notification[] = [
      {
        id: '1',
        userId: '1',
        type: 'like',
        content: 'Carlos curtiu seu post sobre o MSN',
        timestamp: '2024-03-15T14:35:00Z',
        read: false
      },
      {
        id: '2',
        userId: '1',
        type: 'friend',
        content: 'Mariana aceitou sua solicitação de amizade',
        timestamp: '2024-03-15T16:00:00Z',
        read: false
      }
    ];
    setNotifications(mockNotifications);
  }, []);

  // Funções de autenticação
  const login = (email: string, password: string) => {
    const user = mockUsers.find(u => u.email === email);
    if (user) {
      setCurrentUser(user);
      setIsLoggedIn(true);
      setShowLogin(false);
      return true;
    }
    return false;
  };

  const register = (userData: Partial<User>) => {
    const newUser: User = {
      id: Date.now().toString(),
      name: userData.name || '',
      username: userData.username || '',
      email: userData.email || '',
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${userData.username}`,
      bio: userData.bio || '',
      joinDate: new Date().toISOString(),
      friends: [],
      communities: [],
      posts: [],
      status: 'online',
      theme: 'modern',
      privacy: 'public'
    };
    setCurrentUser(newUser);
    setIsLoggedIn(true);
    setShowRegister(false);
  };

  const logout = () => {
    setCurrentUser(null);
    setIsLoggedIn(false);
    setActiveTab('feed');
  };

  // Funções de postagem
  const createPost = (content: string, type: Post['type'] = 'text') => {
    if (!currentUser || !content.trim()) return;

    const newPostObj: Post = {
      id: Date.now().toString(),
      authorId: currentUser.id,
      content: content.trim(),
      timestamp: new Date().toISOString(),
      likes: [],
      comments: [],
      shares: 0,
      type,
      tags: []
    };

    setPosts([newPostObj, ...posts]);
    setNewPost('');
  };

  const likePost = (postId: string) => {
    if (!currentUser) return;
    
    setPosts(posts.map(post => {
      if (post.id === postId) {
        const likes = post.likes.includes(currentUser.id) 
          ? post.likes.filter(id => id !== currentUser.id)
          : [...post.likes, currentUser.id];
        return { ...post, likes };
      }
      return post;
    }));
  };

  const addComment = (postId: string, content: string) => {
    if (!currentUser || !content.trim()) return;

    const newComment: Comment = {
      id: Date.now().toString(),
      authorId: currentUser.id,
      content: content.trim(),
      timestamp: new Date().toISOString(),
      likes: [],
      replies: []
    };

    setPosts(posts.map(post => {
      if (post.id === postId) {
        return { ...post, comments: [...post.comments, newComment] };
      }
      return post;
    }));
  };

  // Funções de comunidade
  const joinCommunity = (communityId: string) => {
    if (!currentUser) return;

    setCommunities(communities.map(community => {
      if (community.id === communityId && !community.members.includes(currentUser.id)) {
        return { ...community, members: [...community.members, currentUser.id] };
      }
      return community;
    }));

    if (currentUser) {
      setCurrentUser({
        ...currentUser,
        communities: [...currentUser.communities, communityId]
      });
    }
  };

  const leaveCommunity = (communityId: string) => {
    if (!currentUser) return;

    setCommunities(communities.map(community => {
      if (community.id === communityId) {
        return { ...community, members: community.members.filter(id => id !== currentUser.id) };
      }
      return community;
    }));

    if (currentUser) {
      setCurrentUser({
        ...currentUser,
        communities: currentUser.communities.filter(id => id !== communityId)
      });
    }
  };

  // Funções utilitárias
  const getUserById = (id: string) => {
    return mockUsers.find(user => user.id === id);
  };

  const getCommunityById = (id: string) => {
    return communities.find(community => community.id === id);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Agora';
    if (diffInHours < 24) return `${diffInHours}h atrás`;
    if (diffInHours < 48) return 'Ontem';
    return date.toLocaleDateString('pt-BR');
  };

  const getThemeColors = (theme: 'msn' | 'orkut' | 'modern') => {
    switch (theme) {
      case 'msn':
        return {
          primary: 'bg-blue-600',
          secondary: 'bg-blue-100',
          text: 'text-blue-600',
          border: 'border-blue-200'
        };
      case 'orkut':
        return {
          primary: 'bg-red-600',
          secondary: 'bg-red-100',
          text: 'text-red-600',
          border: 'border-red-200'
        };
      default:
        return {
          primary: 'bg-purple-600',
          secondary: 'bg-purple-100',
          text: 'text-purple-600',
          border: 'border-purple-200'
        };
    }
  };

  const themeColors = getThemeColors(selectedTheme);

  // Renderização condicional
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-red-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <MessageCircle className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-red-600 bg-clip-text text-transparent">
                RetroSocial
              </h1>
              <Users className="h-8 w-8 text-red-600" />
            </div>
            <CardDescription>
              A primeira rede social coerente - Onde nostalgia encontra conexão
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {showLogin ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Email</label>
                  <Input type="email" placeholder="seu@email.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Senha</label>
                  <Input type="password" placeholder="••••••••" />
                </div>
                <Button className="w-full" onClick={() => login('ana@example.com', 'password')}>
                  <LogIn className="h-4 w-4 mr-2" />
                  Entrar
                </Button>
                <Button variant="outline" className="w-full" onClick={() => setShowLogin(false)}>
                  Cancelar
                </Button>
              </div>
            ) : showRegister ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Nome</label>
                  <Input placeholder="Seu nome" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Username</label>
                  <Input placeholder="@seuusername" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Email</label>
                  <Input type="email" placeholder="seu@email.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Senha</label>
                  <Input type="password" placeholder="••••••••" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Bio</label>
                  <Textarea placeholder="Conte um pouco sobre você..." />
                </div>
                <Button className="w-full" onClick={() => register({ name: 'Novo Usuário', username: 'novousuario', email: 'novo@example.com', bio: 'Usuário novo na plataforma' })}>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Cadastrar
                </Button>
                <Button variant="outline" className="w-full" onClick={() => setShowRegister(false)}>
                  Cancelar
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <Button className="w-full" onClick={() => setShowLogin(true)}>
                  <LogIn className="h-4 w-4 mr-2" />
                  Entrar
                </Button>
                <Button variant="outline" className="w-full" onClick={() => setShowRegister(true)}>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Criar Conta
                </Button>
                <div className="text-center text-sm text-muted-foreground">
                  <p>Experimente a primeira rede social coerente!</p>
                  <p className="mt-2">🎵 MSN + ❤️ Orkut = 🚀 RetroSocial</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className={`sticky top-0 z-50 ${themeColors.primary} text-white shadow-lg`}>
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MessageCircle className="h-8 w-8 animate-pulse" />
              <h1 className="text-2xl font-bold">RetroSocial</h1>
              <Users className="h-8 w-8 animate-pulse" />
            </div>
            
            <div className="flex items-center gap-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Buscar..."
                  className="pl-10 w-64 bg-white/20 border-white/30 text-white placeholder:text-white/70"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              {/* Theme Selector */}
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant={selectedTheme === 'msn' ? 'default' : 'outline'}
                  className={`$selectedTheme === 'msn' ? 'bg-blue-500' : 'bg-white/20 border-white/30'}`}
                  onClick={() => setSelectedTheme('msn')}
                >
                  MSN
                </Button>
                <Button
                  size="sm"
                  variant={selectedTheme === 'orkut' ? 'default' : 'outline'}
                  className={`$selectedTheme === 'orkut' ? 'bg-red-500' : 'bg-white/20 border-white/30'}`}
                  onClick={() => setSelectedTheme('orkut')}
                >
                  Orkut
                </Button>
                <Button
                  size="sm"
                  variant={selectedTheme === 'modern' ? 'default' : 'outline'}
                  className={`$selectedTheme === 'modern' ? 'bg-purple-500' : 'bg-white/20 border-white/30'}`}
                  onClick={() => setSelectedTheme('modern')}
                >
                  Moderno
                </Button>
              </div>
              
              {/* Notifications */}
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-5 w-5" />
                {notifications.filter(n => !n.read).length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {notifications.filter(n => !n.read).length}
                  </span>
                )}
              </Button>
              
              {/* User Menu */}
              <div className="flex items-center gap-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={currentUser?.avatar} />
                  <AvatarFallback>{currentUser?.name?.[0]}</AvatarFallback>
                </Avatar>
                <div className="text-sm">
                  <div className="font-medium">{currentUser?.name}</div>
                  <div className="text-xs opacity-75">@{currentUser?.username}</div>
                </div>
                <Button variant="ghost" size="sm" onClick={logout}>
                  <LogOut className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* User Profile Card */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={currentUser?.avatar} />
                    <AvatarFallback>{currentUser?.name?.[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-lg">{currentUser?.name}</CardTitle>
                    <CardDescription>@{currentUser?.username}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">{currentUser?.bio}</p>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-lg font-bold">{currentUser?.friends.length}</div>
                    <div className="text-xs text-muted-foreground">Amigos</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold">{currentUser?.communities.length}</div>
                    <div className="text-xs text-muted-foreground">Comunidades</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold">{posts.filter(p => p.authorId === currentUser?.id).length}</div>
                    <div className="text-xs text-muted-foreground">Posts</div>
                  </div>
                </div>
                <div className="mt-4">
                  <Badge variant="outline" className={`mr-2 ${themeColors.text}`}>
                    Tema: {selectedTheme === 'msn' ? 'MSN' : selectedTheme === 'orkut' ? 'Orkut' : 'Moderno'}
                  </Badge>
                  <Badge variant="outline">
                    {onlineUsers} online
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Communities */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Minhas Comunidades
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {communities.filter(c => currentUser?.communities.includes(c.id)).map(community => (
                    <div key={community.id} className="flex items-center gap-2 p-2 rounded hover:bg-gray-50">
                      <div className={`w-3 h-3 rounded-full ${
                        community.theme === 'msn' ? 'bg-blue-500' : 
                        community.theme === 'orkut' ? 'bg-red-500' : 'bg-purple-500'
                      }`} />
                      <div className="flex-1">
                        <div className="font-medium text-sm">{community.name}</div>
                        <div className="text-xs text-muted-foreground">{community.members.length} membros</div>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => leaveCommunity(community.id)}>
                        <XCircle className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <Plus className="h-4 w-4 mr-2" />
                  Explorar Comunidades
                </Button>
              </CardContent>
            </Card>

            {/* Online Friends */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Amigos Online
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {mockUsers.filter(u => u.status === 'online' && u.id !== currentUser?.id).map(user => (
                    <div key={user.id} className="flex items-center gap-2 p-2 rounded hover:bg-gray-50">
                      <div className="relative">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={user.avatar} />
                          <AvatarFallback>{user.name[0]}</AvatarFallback>
                        </Avatar>
                        <div className="absolute bottom-0 right-0 w-2 h-2 bg-green-500 rounded-full border-2 border-white" />
                      </div>
                      <div>
                        <div className="font-medium text-sm">{user.name}</div>
                        <div className="text-xs text-muted-foreground">@{user.username}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Feed */}
          <div className="lg:col-span-2">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="feed">
                  <Home className="h-4 w-4 mr-2" />
                  Feed
                </TabsTrigger>
                <TabsTrigger value="communities">
                  <Users className="h-4 w-4 mr-2" />
                  Comunidades
                </TabsTrigger>
                <TabsTrigger value="educational">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Educativo
                </TabsTrigger>
                <TabsTrigger value="messages">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Mensagens
                </TabsTrigger>
              </TabsList>

              {/* Feed Tab */}
              <TabsContent value="feed" className="space-y-6">
                {/* Create Post */}
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={currentUser?.avatar} />
                        <AvatarFallback>{currentUser?.name?.[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <Textarea
                          placeholder="O que você está pensando? Compartilhe uma memória, conhecimento ou apenas um olá!"
                          value={newPost}
                          onChange={(e) => setNewPost(e.target.value)}
                          className="mb-3"
                        />
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Button variant="ghost" size="sm">
                              <Image className="h-4 w-4" alt="Ícone de imagem" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Smile className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Calendar className="h-4 w-4" />
                            </Button>
                          </div>
                          <Button onClick={() => createPost(newPost)} disabled={!newPost.trim()}>
                            <Send className="h-4 w-4 mr-2" />
                            Publicar
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Posts Feed */}
                <div className="space-y-4">
                  {posts.map(post => {
                    const author = getUserById(post.authorId);
                    const community = post.communityId ? getCommunityById(post.communityId) : null;
                    
                    return (
                      <Card key={post.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={author?.avatar} />
                              <AvatarFallback>{author?.name?.[0]}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium">{author?.name}</span>
                                <span className="text-muted-foreground">@{author?.username}</span>
                                <span className="text-muted-foreground">•</span>
                                <span className="text-muted-foreground text-sm">{formatDate(post.timestamp)}</span>
                              </div>
                              {community && (
                                <div className="flex items-center gap-1 mb-2">
                                  <span className="text-muted-foreground">em</span>
                                  <Badge variant="outline" className={`text-xs ${
                                    community.theme === 'msn' ? 'border-blue-200 text-blue-600' :
                                    community.theme === 'orkut' ? 'border-red-200 text-red-600' :
                                    'border-purple-200 text-purple-600'
                                  }`}>
                                    {community.name}
                                  </Badge>
                                </div>
                              )}
                              <p className="mb-3">{post.content}</p>
                              
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className={`flex items-center gap-1 ${post.likes.includes(currentUser?.id || '') ? 'text-red-500' : ''}`}
                                  onClick={() => likePost(post.id)}
                                >
                                  <Heart className={`h-4 w-4 ${post.likes.includes(currentUser?.id || '') ? 'fill-current' : ''}`} />
                                  {post.likes.length > 0 && post.likes.length}
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="flex items-center gap-1"
                                >
                                  <MessageCircle className="h-4 w-4" />
                                  {post.comments.length > 0 && post.comments.length}
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="flex items-center gap-1"
                                >
                                  <Share2 className="h-4 w-4" />
                                  {post.shares > 0 && post.shares}
                                </Button>
                              </div>
                              
                              {/* Comments */}
                              {post.comments.length > 0 && (
                                <div className="mt-4 pt-4 border-t">
                                  {post.comments.map(comment => {
                                    const commentAuthor = getUserById(comment.authorId);
                                    return (
                                      <div key={comment.id} className="flex items-start gap-2 mb-3">
                                        <Avatar className="h-6 w-6">
                                          <AvatarImage src={commentAuthor?.avatar} />
                                          <AvatarFallback>{commentAuthor?.name?.[0]}</AvatarFallback>
                                        </Avatar>
                                        <div className="flex-1">
                                          <div className="flex items-center gap-2 mb-1">
                                            <span className="font-medium text-sm">{commentAuthor?.name}</span>
                                            <span className="text-muted-foreground text-xs">{formatDate(comment.timestamp)}</span>
                                          </div>
                                          <p className="text-sm">{comment.content}</p>
                                        </div>
                                      </div>
                                    );
                                  })}
                                  <div className="flex items-start gap-2">
                                    <Avatar className="h-6 w-6">
                                      <AvatarImage src={currentUser?.avatar} />
                                      <AvatarFallback>{currentUser?.name?.[0]}</AvatarFallback>
                                    </Avatar>
                                    <div className="flex-1">
                                      <Input
                                        placeholder="Escreva um comentário..."
                                        className="text-sm"
                                        onKeyPress={(e) => {
                                          if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                                            addComment(post.id, e.currentTarget.value);
                                            e.currentTarget.value = '';
                                          }
                                        }}
                                      />
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>

              {/* Communities Tab */}
              <TabsContent value="communities" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {communities.map(community => (
                    <Card key={community.id} className="hover:shadow-md transition-shadow">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className={`w-4 h-4 rounded-full ${
                              community.theme === 'msn' ? 'bg-blue-500' : 
                              community.theme === 'orkut' ? 'bg-red-500' : 'bg-purple-500'
                            }`} />
                            <CardTitle className="text-lg">{community.name}</CardTitle>
                          </div>
                          {currentUser?.communities.includes(community.id) ? (
                            <Button variant="outline" size="sm" onClick={() => leaveCommunity(community.id)}>
                              <UserMinus className="h-4 w-4 mr-1" />
                              Sair
                            </Button>
                          ) : (
                            <Button size="sm" onClick={() => joinCommunity(community.id)}>
                              <UserPlus className="h-4 w-4 mr-1" />
                              Entrar
                            </Button>
                          )}
                        </div>
                        <CardDescription>{community.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Membros</span>
                            <span className="font-medium">{community.members.length}</span>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Posts</span>
                            <span className="font-medium">{community.posts.length}</span>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {community.tags.map(tag => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                #{tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* Educational Tab */}
              <TabsContent value="educational" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5" />
                      Conteúdo Educativo
                    </CardTitle>
                    <CardDescription>
                      Aprenda sobre a história e evolução das redes sociais
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card className="hover:shadow-md transition-shadow cursor-pointer">
                        <CardHeader>
                          <CardTitle className="text-lg">História do MSN Messenger</CardTitle>
                          <CardDescription>A evolução do mensageiro instantâneo</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-3">
                            Descubra como o MSN Messenger revolucionou a comunicação online e influenciou as plataformas modernas.
                          </p>
                          <Button variant="outline" size="sm">
                            <BookOpen className="h-4 w-4 mr-2" />
                            Ler Artigo
                          </Button>
                        </CardContent>
                      </Card>
                      
                      <Card className="hover:shadow-md transition-shadow cursor-pointer">
                        <CardHeader>
                          <CardTitle className="text-lg">Era do Orkut</CardTitle>
                          <CardDescription>O fenômeno social no Brasil</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-3">
                            Conheça a história do Orkut e seu impacto cultural na sociedade brasileira.
                          </p>
                          <Button variant="outline" size="sm">
                            <BookOpen className="h-4 w-4 mr-2" />
                            Ler Artigo
                          </Button>
                        </CardContent>
                      </Card>
                      
                      <Card className="hover:shadow-md transition-shadow cursor-pointer">
                        <CardHeader>
                          <CardTitle className="text-lg">Evolução Tecnológica</CardTitle>
                          <CardDescription>Do MSN às redes sociais modernas</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-3">
                            Compare os recursos e evolução das plataformas de comunicação ao longo dos anos.
                          </p>
                          <Button variant="outline" size="sm">
                            <BookOpen className="h-4 w-4 mr-2" />
                            Ver Comparação
                          </Button>
                        </CardContent>
                      </Card>
                      
                      <Card className="hover:shadow-md transition-shadow cursor-pointer">
                        <CardHeader>
                          <CardTitle className="text-lg">Quiz Interativo</CardTitle>
                          <CardDescription>Teste seus conhecimentos</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-3">
                            Responda perguntas sobre MSN Messenger e Orkut para testar seu conhecimento.
                          </p>
                          <Button variant="outline" size="sm">
                            <Gamepad2 className="h-4 w-4 mr-2" />
                            Começar Quiz
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Messages Tab */}
              <TabsContent value="messages" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MessageCircle className="h-5 w-5" />
                      Mensagens
                    </CardTitle>
                    <CardDescription>
                      Conversas com seus amigos
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockUsers.filter(u => u.id !== currentUser?.id).map(user => (
                        <div key={user.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 cursor-pointer">
                          <div className="relative">
                            <Avatar className="h-12 w-12">
                              <AvatarImage src={user.avatar} />
                              <AvatarFallback>{user.name[0]}</AvatarFallback>
                            </Avatar>
                            <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${
                              user.status === 'online' ? 'bg-green-500' :
                              user.status === 'away' ? 'bg-yellow-500' :
                              user.status === 'busy' ? 'bg-red-500' : 'bg-gray-500'
                            }`} />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <span className="font-medium">{user.name}</span>
                              <span className="text-xs text-muted-foreground">2h atrás</span>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {user.status === 'online' ? 'Online' :
                               user.status === 'away' ? 'Ausente' :
                               user.status === 'busy' ? 'Ocupado' : 'Offline'}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Trending Topics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Em Alta
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-sm">#MSN</div>
                      <div className="text-xs text-muted-foreground">1.2k posts</div>
                    </div>
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-sm">#Orkut</div>
                      <div className="text-xs text-muted-foreground">856 posts</div>
                    </div>
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-sm">#Nostalgia</div>
                      <div className="text-xs text-muted-foreground">642 posts</div>
                    </div>
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-sm">#Tecnologia</div>
                      <div className="text-xs text-muted-foreground">523 posts</div>
                    </div>
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Suggestions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserPlus className="h-5 w-5" />
                  Sugestões de Amizade
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockUsers.filter(u => u.id !== currentUser?.id && !currentUser?.friends.includes(u.id)).map(user => (
                    <div key={user.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={user.avatar} />
                          <AvatarFallback>{user.name[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium text-sm">{user.name}</div>
                          <div className="text-xs text-muted-foreground">@{user.username}</div>
                        </div>
                      </div>
                      <Button size="sm">
                        <UserPlus className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Active Now */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Ativos Agora
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {mockUsers.filter(u => u.status === 'online' && u.id !== currentUser?.id).map(user => (
                    <div key={user.id} className="flex items-center gap-2">
                      <div className="relative">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={user.avatar} />
                          <AvatarFallback>{user.name[0]}</AvatarFallback>
                        </Avatar>
                        <div className="absolute bottom-0 right-0 w-2 h-2 bg-green-500 rounded-full border-2 border-white" />
                      </div>
                      <span className="text-sm">{user.name}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}