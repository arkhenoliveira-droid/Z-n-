'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  FileText, 
  Download, 
  Eye, 
  Plus, 
  CheckCircle, 
  XCircle, 
  Clock,
  AlertTriangle,
  BarChart3,
  TrendingUp,
  Users,
  Activity,
  Zap,
  Calendar,
  User,
  Shield,
  Target
} from 'lucide-react';

interface AuditReport {
  id: string;
  title: string;
  description?: string;
  type: string;
  period: string;
  status: string;
  summary?: string;
  score?: number;
  confidence?: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  publishedAt?: string;
  walletTests: WalletAuditTest[];
}

interface WalletAuditTest {
  id: string;
  testType: string;
  testName: string;
  status: string;
  score?: number;
  confidence?: number;
  wallet: {
    id: string;
    address: string;
    type: string;
    name?: string;
  };
}

export default function AuditReportSystem() {
  const [reports, setReports] = useState<AuditReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState<AuditReport | null>(null);
  const [showCreateReport, setShowCreateReport] = useState(false);
  const [newReport, setNewReport] = useState({
    title: '',
    description: '',
    type: '',
    period: '',
    summary: '',
    createdBy: 'System Auditor'
  });
  const [filters, setFilters] = useState({
    type: '',
    period: '',
    status: ''
  });

  useEffect(() => {
    fetchReports();
  }, [filters]);

  const fetchReports = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });

      const response = await fetch(`/api/audit-reports?${params}`);
      if (response.ok) {
        const data = await response.json();
        setReports(data.reports);
      }
    } catch (error) {
      console.error('Error fetching reports:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateReport = async () => {
    try {
      const response = await fetch('/api/audit-reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newReport)
      });

      if (response.ok) {
        setShowCreateReport(false);
        setNewReport({
          title: '',
          description: '',
          type: '',
          period: '',
          summary: '',
          createdBy: 'System Auditor'
        });
        fetchReports();
      }
    } catch (error) {
      console.error('Error creating report:', error);
    }
  };

  const generate2024AnnualReport = async () => {
    try {
      const response = await fetch('/api/audit-reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: '2024 Annual Wallet Ownership Audit Report',
          description: 'Comprehensive annual audit of wallet ownership verification and security testing',
          type: 'wallet_ownership',
          period: '2024_annual',
          summary: 'This report presents the findings from the 2024 comprehensive audit of wallet ownership verification systems, including security assessments, compliance checks, and risk analysis across all monitored wallets.',
          createdBy: 'Chief Audit Officer',
          score: 87.5,
          confidence: 0.92
        })
      });

      if (response.ok) {
        fetchReports();
      }
    } catch (error) {
      console.error('Error generating annual report:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'published': return 'bg-green-500';
      case 'draft': return 'bg-gray-500';
      case 'in_progress': return 'bg-blue-500';
      case 'failed': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const reportTypes = ['wallet_ownership', 'security', 'compliance', 'risk_assessment'];
  const periods = ['2024_Q1', '2024_Q2', '2024_Q3', '2024_Q4', '2024_annual'];

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Audit Report System</h1>
          <p className="text-gray-600">Generate and manage comprehensive audit reports for wallet ownership testing</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={generate2024AnnualReport} className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Generate 2024 Annual Report
          </Button>
          <Button onClick={() => setShowCreateReport(true)} className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Create Report
          </Button>
        </div>
      </div>

      {/* Create Report Modal */}
      {showCreateReport && (
        <Card>
          <CardHeader>
            <CardTitle>Create New Audit Report</CardTitle>
            <CardDescription>Configure a new audit report for wallet ownership testing</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="title">Report Title</Label>
                <Input
                  id="title"
                  value={newReport.title}
                  onChange={(e) => setNewReport({...newReport, title: e.target.value})}
                  placeholder="Enter report title"
                />
              </div>
              <div>
                <Label htmlFor="type">Report Type</Label>
                <Select value={newReport.type} onValueChange={(value) => setNewReport({...newReport, type: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {reportTypes.map(type => (
                      <SelectItem key={type} value={type}>{type.replace('_', ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="period">Period</Label>
                <Select value={newReport.period} onValueChange={(value) => setNewReport({...newReport, period: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select period" />
                  </SelectTrigger>
                  <SelectContent>
                    {periods.map(period => (
                      <SelectItem key={period} value={period}>{period}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="createdBy">Created By</Label>
                <Input
                  id="createdBy"
                  value={newReport.createdBy}
                  onChange={(e) => setNewReport({...newReport, createdBy: e.target.value})}
                  placeholder="Auditor name"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={newReport.description}
                onChange={(e) => setNewReport({...newReport, description: e.target.value})}
                placeholder="Report description"
              />
            </div>
            <div>
              <Label htmlFor="summary">Executive Summary</Label>
              <Textarea
                id="summary"
                value={newReport.summary}
                onChange={(e) => setNewReport({...newReport, summary: e.target.value})}
                placeholder="Executive summary"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleCreateReport}>Create Report</Button>
              <Button variant="outline" onClick={() => setShowCreateReport(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="filterType">Filter by Type</Label>
              <Select value={filters.type} onValueChange={(value) => setFilters({...filters, type: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All types</SelectItem>
                  {reportTypes.map(type => (
                    <SelectItem key={type} value={type}>{type.replace('_', ' ')}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filterPeriod">Filter by Period</Label>
              <Select value={filters.period} onValueChange={(value) => setFilters({...filters, period: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="All periods" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All periods</SelectItem>
                  {periods.map(period => (
                    <SelectItem key={period} value={period}>{period}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filterStatus">Filter by Status</Label>
              <Select value={filters.status} onValueChange={(value) => setFilters({...filters, status: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All statuses</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="published">Published</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Reports Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full text-center py-8">Loading reports...</div>
        ) : (
          reports.map((report) => (
            <Card 
              key={report.id} 
              className={`cursor-pointer transition-all hover:shadow-lg ${
                selectedReport?.id === report.id ? 'ring-2 ring-blue-500' : ''
              }`}
              onClick={() => setSelectedReport(report)}
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{report.title}</CardTitle>
                  <Badge className={`${getStatusColor(report.status)} text-white`}>
                    {report.status.replace('_', ' ')}
                  </Badge>
                </div>
                <CardDescription>{report.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {report.period}
                    </span>
                    <span className="flex items-center gap-1">
                      <User className="w-4 h-4" />
                      {report.createdBy}
                    </span>
                  </div>
                  
                  {report.score && (
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">Audit Score</span>
                        <span className={`text-sm font-bold ${getScoreColor(report.score)}`}>
                          {report.score}/100
                        </span>
                      </div>
                      <Progress value={report.score} className="h-2" />
                    </div>
                  )}
                  
                  {report.confidence && (
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">Confidence</span>
                        <span className="text-sm font-bold text-blue-600">
                          {(report.confidence * 100).toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={report.confidence * 100} className="h-2" />
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <span>{report.walletTests.length} tests</span>
                    <span>{new Date(report.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Selected Report Details */}
      {selectedReport && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>{selectedReport.title}</CardTitle>
                <CardDescription>{selectedReport.description}</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Export PDF
                </Button>
                <Button variant="outline" size="sm">
                  <Eye className="w-4 h-4 mr-2" />
                  View Details
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="overview" className="w-full">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="tests">Test Results</TabsTrigger>
                <TabsTrigger value="findings">Findings</TabsTrigger>
                <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-gray-600">Overall Score</p>
                          <p className={`text-2xl font-bold ${getScoreColor(selectedReport.score || 0)}`}>
                            {selectedReport.score || 'N/A'}
                          </p>
                        </div>
                        <Target className="w-8 h-8 text-blue-500" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-gray-600">Confidence</p>
                          <p className="text-2xl font-bold text-blue-600">
                            {selectedReport.confidence ? `${(selectedReport.confidence * 100).toFixed(1)}%` : 'N/A'}
                          </p>
                        </div>
                        <Shield className="w-8 h-8 text-green-500" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-gray-600">Tests Run</p>
                          <p className="text-2xl font-bold">{selectedReport.walletTests.length}</p>
                        </div>
                        <Activity className="w-8 h-8 text-purple-500" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-gray-600">Status</p>
                          <Badge className={`${getStatusColor(selectedReport.status)} text-white`}>
                            {selectedReport.status.replace('_', ' ')}
                          </Badge>
                        </div>
                        <Zap className="w-8 h-8 text-yellow-500" />
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {selectedReport.summary && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Executive Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700">{selectedReport.summary}</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
              
              <TabsContent value="tests" className="space-y-4">
                <div className="grid gap-4">
                  {selectedReport.walletTests.map((test) => (
                    <Card key={test.id}>
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium">{test.testName}</h4>
                            <p className="text-sm text-gray-600">{test.testType.replace('_', ' ')} • {test.wallet.name || test.wallet.address}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            {test.score && (
                              <Badge variant="outline">
                                Score: {test.score}/100
                              </Badge>
                            )}
                            <Badge className={`${getStatusColor(test.status)} text-white`}>
                              {test.status}
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="findings" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Key Findings</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Alert>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        Detailed findings will be populated when the audit report is finalized. 
                        This section will include security vulnerabilities, compliance issues, and risk assessments.
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="recommendations" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Recommendations</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Alert>
                      <CheckCircle className="h-4 w-4" />
                      <AlertDescription>
                        Actionable recommendations will be provided based on audit findings. 
                        This will include security improvements, compliance measures, and risk mitigation strategies.
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  );
}