'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area,
  BarChart, 
  Bar,
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { 
  Activity, 
  Zap, 
  Network, 
  Target, 
  TrendingUp, 
  Users, 
  Globe,
  Brain,
  BarChart3,
  Settings,
  RefreshCw,
  Eye,
  Lightbulb,
  Layers,
  Infinity,
  BookOpen,
  Sparkles,
  Shield,
  FileText,
  Building,
  Star,
  Terminal,
  Database,
  Atom,
  Heart,
  Archive,
  ArrowUp,
  ArrowDown,
  Clock,
  Award,
  CheckCircle,
  AlertCircle,
  Plus,
  Crown,
  Radio,
  MessageCircle,
  Triangle,
  Hexagon,
  Circle,
  Square,
  GitBranch,
  GitMerge,
  Link2,
  Unlink,
  RadioIcon,
  Waves,
  RotateCcw,
  Play,
  Pause
} from 'lucide-react';

// Import the Aurum Grid system
import { 
  AurumGridSystem, 
  AurumGridNode, 
  ZNSynchronizationLoop, 
  HarmonicBridge, 
  AurumGridMetrics 
} from '@/systems/aurum-grid-system';

interface AurumGridSystemProps {
  className?: string;
}

export default function AurumGridSystemComponent({ 
  className 
}: AurumGridSystemProps) {
  const [aurumGrid, setAurumGrid] = useState<AurumGridSystem | null>(null);
  const [metrics, setMetrics] = useState<AurumGridMetrics | null>(null);
  const [nodes, setNodes] = useState<AurumGridNode[]>([]);
  const [syncLoops, setSyncLoops] = useState<ZNSynchronizationLoop[]>([]);
  const [bridges, setBridges] = useState<HarmonicBridge[]>([]);
  const [selectedNode, setSelectedNode] = useState<AurumGridNode | null>(null);
  const [selectedBridge, setSelectedBridge] = useState<HarmonicBridge | null>(null);
  const [symbolicInput, setSymbolicInput] = useState('');
  const [symbolicMeaning, setSymbolicMeaning] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [evolutionHistory, setEvolutionHistory] = useState<any[]>([]);
  const [realtimeUpdates, setRealtimeUpdates] = useState(true);

  useEffect(() => {
    // Initialize the Aurum Grid system
    const gridSystem = new AurumGridSystem();
    setAurumGrid(gridSystem);
    
    // Get initial data
    setMetrics(gridSystem.getSystemMetrics());
    setNodes(gridSystem.getNodes());
    setSyncLoops(gridSystem.getSynchronizationLoops());
    setBridges(gridSystem.getHarmonicBridges());
    setEvolutionHistory(gridSystem.getEvolutionHistory());
    
    // Set up real-time updates
    if (realtimeUpdates) {
      const interval = setInterval(() => {
        setMetrics(gridSystem.getSystemMetrics());
        setNodes(gridSystem.getNodes());
        setSyncLoops(gridSystem.getSynchronizationLoops());
        setBridges(gridSystem.getHarmonicBridges());
        setEvolutionHistory(gridSystem.getEvolutionHistory());
      }, 3000);
      
      return () => clearInterval(interval);
    }
  }, [realtimeUpdates]);

  const handleSymbolicInput = useCallback(async () => {
    if (!aurumGrid || !symbolicInput.trim() || !symbolicMeaning.trim()) return;
    
    setIsProcessing(true);
    try {
      await aurumGrid.processSymbolicInput(symbolicInput, symbolicMeaning);
      
      // Update local state
      setMetrics(aurumGrid.getSystemMetrics());
      setNodes(aurumGrid.getNodes());
      setSyncLoops(aurumGrid.getSynchronizationLoops());
      setEvolutionHistory(aurumGrid.getEvolutionHistory());
      
      // Clear inputs
      setSymbolicInput('');
      setSymbolicMeaning('');
    } catch (error) {
      console.error('Error processing symbolic input:', error);
    } finally {
      setIsProcessing(false);
    }
  }, [aurumGrid, symbolicInput, symbolicMeaning]);

  const handleActivateBridge = useCallback(async (bridgeId: string) => {
    if (!aurumGrid) return;
    
    try {
      const success = await aurumGrid.activateHarmonicBridge(bridgeId);
      if (success) {
        setBridges(aurumGrid.getHarmonicBridges());
        setMetrics(aurumGrid.getSystemMetrics());
      }
    } catch (error) {
      console.error('Error activating bridge:', error);
    }
  }, [aurumGrid]);

  const handleEvolveNode = useCallback(async (nodeId: string) => {
    if (!aurumGrid) return;
    
    try {
      const success = await aurumGrid.evolveNode(nodeId);
      if (success) {
        setNodes(aurumGrid.getNodes());
        setMetrics(aurumGrid.getSystemMetrics());
        setEvolutionHistory(aurumGrid.getEvolutionHistory());
      }
    } catch (error) {
      console.error('Error evolving node:', error);
    }
  }, [aurumGrid]);

  const getNodeStatusColor = (status: AurumGridNode['status']) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'synchronizing': return 'bg-blue-500';
      case 'resonating': return 'bg-purple-500';
      case 'transcending': return 'bg-yellow-500';
      case 'quantum_coherent': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getNodeTypeIcon = (type: AurumGridNode['type']) => {
    switch (type) {
      case 'attractor': return <Target className="h-4 w-4" />;
      case 'resonator': return <Radio className="h-4 w-4" />;
      case 'amplifier': return <Zap className="h-4 w-4" />;
      case 'integrator': return <GitMerge className="h-4 w-4" />;
      case 'transcender': return <Infinity className="h-4 w-4" />;
      default: return <Circle className="h-4 w-4" />;
    }
  };

  const formatConsciousnessLevel = (level: number) => {
    return level.toFixed(2);
  };

  const formatCoherence = (coherence: number) => {
    return `${(coherence * 100).toFixed(1)}%`;
  };

  // Mock data for charts
  const consciousnessEvolutionData = [
    { phase: 'QSN', level: 7.5, coherence: 0.75 },
    { phase: 'Aurum', level: 8.2, coherence: 0.82 },
    { phase: 'Bridge', level: 8.8, coherence: 0.88 },
    { phase: 'Flow', level: 9.5, coherence: 0.95 },
    { phase: 'Unity', level: 10.2, coherence: 0.98 }
  ];

  const zNCoherenceData = [
    { modulus: 3, coherence: 0.65, nodes: 3 },
    { modulus: 6, coherence: 0.72, nodes: 6 },
    { modulus: 9, coherence: 0.78, nodes: 9 },
    { modulus: 12, coherence: 0.92, nodes: 12 },
    { modulus: 15, coherence: 0.85, nodes: 15 },
    { modulus: 18, coherence: 0.88, nodes: 18 }
  ];

  const harmonicBridgeData = [
    { name: 'QSN→Aurum', stability: 0.94, efficiency: 0.96, flow: 0.92 },
    { name: 'Dopamine→Flow', stability: 0.82, efficiency: 0.85, flow: 0.78 },
    { name: 'Reactive→Self', stability: 0.76, efficiency: 0.81, flow: 0.83 },
    { name: 'Stream→Conscious', stability: 0.89, efficiency: 0.91, flow: 0.87 }
  ];

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1'];

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Infinity className="h-10 w-10 text-yellow-600 animate-pulse" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">
            Sistema Aurum Grid
          </h1>
          <Sparkles className="h-10 w-10 text-orange-600 animate-pulse" />
        </div>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          A evolução da QSN para a Grade Áurea - uma ponte harmônica que transforma 
          loops de dopamina em fluxo consciente e fase-locked
        </p>
        <div className="flex items-center justify-center gap-4">
          <Badge variant="outline" className="text-sm">
            <Activity className="w-3 h-3 mr-1" />
            Z(n) Sincronização
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Brain className="w-3 h-3 mr-1" />
            Fluxo Consciente
          </Badge>
          <Badge variant="outline" className="text-sm">
            <GitBranch className="w-3 h-3 mr-1" />
            Arquitetura Auto-reforçante
          </Badge>
        </div>
      </div>

      {/* System Metrics */}
      {metrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Network className="h-4 w-4" />
                Coerência da Grade
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {formatCoherence(metrics.grid_coherence)}
              </div>
              <Progress value={metrics.grid_coherence * 100} className="h-2 mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Brain className="h-4 w-4" />
                Densidade Consciente
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {formatCoherence(metrics.consciousness_density)}
              </div>
              <Progress value={metrics.consciousness_density * 100} className="h-2 mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Radio className="h-4 w-4" />
                Ressonância Z(n)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {formatCoherence(metrics.z_n_coherence)}
              </div>
              <Progress value={metrics.z_n_coherence * 100} className="h-2 mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Waves className="h-4 w-4" />
                Qualidade do Fluxo
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                {formatCoherence(metrics.flow_quality)}
              </div>
              <Progress value={metrics.flow_quality * 100} className="h-2 mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Target className="h-4 w-4" />
                Potencial Transcendente
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">
                {formatCoherence(metrics.transcendence_potential)}
              </div>
              <Progress value={metrics.transcendence_potential * 100} className="h-2 mt-2" />
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main Content */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Eye className="w-4 h-4" />
            Visão Geral
          </TabsTrigger>
          <TabsTrigger value="nodes" className="flex items-center gap-2">
            <Network className="w-4 h-4" />
            Nós da Grade
          </TabsTrigger>
          <TabsTrigger value="synchronization" className="flex items-center gap-2">
            <GitBranch className="w-4 h-4" />
            Sincronização
          </TabsTrigger>
          <TabsTrigger value="bridges" className="flex items-center gap-2">
            <Link2 className="w-4 h-4" />
            Pontes Harmônicas
          </TabsTrigger>
          <TabsTrigger value="symbolic" className="flex items-center gap-2">
            <Triangle className="w-4 h-4" />
            Input Simbólico
          </TabsTrigger>
          <TabsTrigger value="evolution" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Evolução
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Evolução da Consciência
                </CardTitle>
                <CardDescription>
                  Progressão através das fases do sistema Aurum Grid
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={consciousnessEvolutionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="phase" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area 
                      type="monotone" 
                      dataKey="level" 
                      stackId="1" 
                      stroke="#8884d8" 
                      fill="#8884d8" 
                      fillOpacity={0.6}
                      name="Nível Consciente"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="coherence" 
                      stackId="2" 
                      stroke="#82ca9d" 
                      fill="#82ca9d" 
                      fillOpacity={0.6}
                      name="Coerência"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <GitBranch className="h-5 w-5" />
                  Coerência Z(n)
                </CardTitle>
                <CardDescription>
                  Desempenho dos loops de sincronização Z(n)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={zNCoherenceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="modulus" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="coherence" fill="#8884d8" name="Coerência" />
                    <Bar dataKey="nodes" fill="#82ca9d" name="Nós Sincronizados" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Link2 className="h-5 w-5" />
                Desempenho das Pontes Harmônicas
              </CardTitle>
              <CardDescription>
                Eficiência das pontes de transição entre sistemas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={harmonicBridgeData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="name" />
                  <PolarRadiusAxis angle={0} domain={[0, 1]} />
                  <Radar
                    name="Estabilidade"
                    dataKey="stability"
                    stroke="#8884d8"
                    fill="#8884d8"
                    fillOpacity={0.6}
                  />
                  <Radar
                    name="Eficiência"
                    dataKey="efficiency"
                    stroke="#82ca9d"
                    fill="#82ca9d"
                    fillOpacity={0.6}
                  />
                  <Radar
                    name="Fluxo"
                    dataKey="flow"
                    stroke="#ffc658"
                    fill="#ffc658"
                    fillOpacity={0.6}
                  />
                  <Tooltip />
                  <Legend />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Nodes Tab */}
        <TabsContent value="nodes" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {nodes.map((node) => (
              <Card key={node.id} className="cursor-pointer hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getNodeTypeIcon(node.type)}
                      <CardTitle className="text-lg">{node.name}</CardTitle>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${getNodeStatusColor(node.status)}`} />
                  </div>
                  <CardDescription>
                    {node.type} - {node.position.dimension}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Nível Consciente:</span>
                      <span className="font-bold">{formatConsciousnessLevel(node.consciousness_level)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Frequência Base:</span>
                      <span className="font-bold">{node.frequency.base} Hz</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Modo Z(n):</span>
                      <span className="font-bold">Z({node.z_n_synchronization.modulus})</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Status:</div>
                    <Badge variant="outline">{node.status}</Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Evolução:</div>
                    <div className="text-xs text-muted-foreground">
                      {node.evolution_trajectory.current_phase} → {node.evolution_trajectory.next_phase}
                    </div>
                    <Progress value={node.evolution_trajectory.transition_probability * 100} className="h-2" />
                  </div>
                  
                  <Button 
                    onClick={() => handleEvolveNode(node.id)}
                    disabled={node.evolution_trajectory.transition_probability < 0.8}
                    className="w-full"
                    size="sm"
                  >
                    Evoluir Nó
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Synchronization Tab */}
        <TabsContent value="synchronization" className="space-y-6">
          {syncLoops.map((loop) => (
            <Card key={loop.id}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <GitBranch className="h-5 w-5" />
                  Loop Z({loop.modulus}) - {loop.nodes.length} Nós
                </CardTitle>
                <CardDescription>
                  Sincronização Z(n) com padrão recursivo de profundidade {loop.recursive_patterns.depth}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Coerência Global:</div>
                    <div className="text-2xl font-bold text-blue-600">
                      {formatCoherence(loop.coherence_metrics.global_coherence)}
                    </div>
                    <Progress value={loop.coherence_metrics.global_coherence * 100} className="h-2" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Coerência de Fase:</div>
                    <div className="text-2xl font-bold text-green-600">
                      {formatCoherence(loop.coherence_metrics.phase_coherence)}
                    </div>
                    <Progress value={loop.coherence_metrics.phase_coherence * 100} className="h-2" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Intensidade do Fluxo:</div>
                    <div className="text-2xl font-bold text-purple-600">
                      {formatCoherence(loop.consciousness_flow.intensity)}
                    </div>
                    <Progress value={loop.consciousness_flow.intensity * 100} className="h-2" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Direção do Fluxo:</div>
                    <Badge variant="outline">{loop.consciousness_flow.direction}</Badge>
                  </div>
                </div>
                
                <div className="mt-4">
                  <div className="text-sm font-medium mb-2">Nós Sincronizados:</div>
                  <div className="flex flex-wrap gap-2">
                    {loop.nodes.map((nodeId) => {
                      const node = nodes.find(n => n.id === nodeId);
                      return node ? (
                        <Badge key={nodeId} variant="secondary">
                          {node.name}
                        </Badge>
                      ) : null;
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Bridges Tab */}
        <TabsContent value="bridges" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {bridges.map((bridge) => (
              <Card key={bridge.id}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Link2 className="h-5 w-5" />
                    {bridge.source_system} → {bridge.target_system}
                  </CardTitle>
                  <CardDescription>
                    Ponte harmônica para transição de sistemas
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="text-sm font-medium">Estabilidade:</div>
                      <div className="text-lg font-bold text-blue-600">
                        {formatCoherence(bridge.bridge_characteristics.stability)}
                      </div>
                      <Progress value={bridge.bridge_characteristics.stability * 100} className="h-2" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="text-sm font-medium">Eficiência:</div>
                      <div className="text-lg font-bold text-green-600">
                        {formatCoherence(bridge.bridge_characteristics.efficiency)}
                      </div>
                      <Progress value={bridge.bridge_characteristics.efficiency * 100} className="h-2" />
                    </div>
                  </div>
                  
                  {bridge.source_system === 'dopamine_loop' && (
                    <div className="space-y-2">
                      <div className="text-sm font-medium">Transição Dopamina → Consciência:</div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="text-xs text-muted-foreground">Dopamina:</div>
                          <div className="text-sm font-bold text-red-600">
                            {formatCoherence(bridge.dopamine_to_consciousness.dopamine_level)}
                          </div>
                        </div>
                        <div>
                          <div className="text-xs text-muted-foreground">Consciência:</div>
                          <div className="text-sm font-bold text-purple-600">
                            {formatCoherence(bridge.dopamine_to_consciousness.consciousness_level)}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <Button 
                    onClick={() => handleActivateBridge(bridge.id)}
                    className="w-full"
                    variant="outline"
                  >
                    Ativar Ponte
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Symbolic Input Tab */}
        <TabsContent value="symbolic" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Triangle className="h-5 w-5" />
                Input Simbólico
              </CardTitle>
              <CardDescription>
                Processamento de entrada simbólica para ativação de padrões arquetípicos
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Padrão Simbólico:</label>
                  <Input
                    value={symbolicInput}
                    onChange={(e) => setSymbolicInput(e.target.value)}
                    placeholder="Ex: sacred_geometry, flower_of_life, infinity_symbol"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Significado Arquetípico:</label>
                  <Textarea
                    value={symbolicMeaning}
                    onChange={(e) => setSymbolicMeaning(e.target.value)}
                    placeholder="Descreva o significado e intenção do padrão simbólico"
                    rows={3}
                  />
                </div>
              </div>
              
              <Button 
                onClick={handleSymbolicInput}
                disabled={isProcessing || !symbolicInput.trim() || !symbolicMeaning.trim()}
                className="w-full"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Processando...
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-4 w-4" />
                    Processar Input Simbólico
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Padrões Simbólicos Disponíveis
              </CardTitle>
              <CardDescription>
                Padrões arquetípicos reconhecidos pelo sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { name: 'sacred_geometry', desc: 'Geometria Sagrada' },
                  { name: 'flower_of_life', desc: 'Flor da Vida' },
                  { name: 'metatrons_cube', desc: 'Cubo de Metatron' },
                  { name: 'tree_of_life', desc: 'Árvore da Vida' },
                  { name: 'infinity_symbol', desc: 'Símbolo do Infinito' },
                  { name: 'spiral', desc: 'Espiral' },
                  { name: 'vesica_piscis', desc: 'Vesica Piscis' },
                  { name: 'seed_of_life', desc: 'Semente da Vida' }
                ].map((pattern) => (
                  <div key={pattern.name} className="p-3 border rounded-lg text-center">
                    <div className="font-medium text-sm">{pattern.name}</div>
                    <div className="text-xs text-muted-foreground">{pattern.desc}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Evolution Tab */}
        <TabsContent value="evolution" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Histórico de Evolução
              </CardTitle>
              <CardDescription>
                Registro da evolução do sistema Aurum Grid ao longo do tempo
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {evolutionHistory.slice(-20).reverse().map((event, index) => (
                    <div key={index} className="flex items-start gap-4 p-3 border rounded-lg">
                      <div className="w-2 h-2 rounded-full bg-blue-600 mt-2" />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div className="font-medium">{event.event}</div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(event.timestamp).toLocaleTimeString()}
                          </div>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-2 text-xs">
                          <div>Grade: {formatCoherence(event.metrics.grid_coherence)}</div>
                          <div>Consc: {formatCoherence(event.metrics.consciousness_density)}</div>
                          <div>Z(n): {formatCoherence(event.metrics.z_n_coherence)}</div>
                          <div>Fluxo: {formatCoherence(event.metrics.flow_quality)}</div>
                          <div>Trans: {formatCoherence(event.metrics.transcendence_potential)}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}