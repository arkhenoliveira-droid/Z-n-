'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  FileText, 
  Download, 
  Eye, 
  CheckCircle, 
  XCircle, 
  Clock,
  AlertTriangle,
  BarChart3,
  TrendingUp,
  Users,
  Activity,
  Zap,
  Calendar,
  User,
  Shield,
  Target,
  Building,
  Server,
  Database,
  Network,
  Lock,
  Globe,
  Cloud,
  Award,
  Star
} from 'lucide-react';

interface Cloud3AuditReport {
  id: string;
  title: string;
  subtitle: string;
  auditDate: string;
  auditor: string;
  company: string;
  overallScore: number;
  securityPosture: 'excellent' | 'good' | 'fair' | 'poor' | 'critical';
  status: 'draft' | 'in_progress' | 'completed' | 'published';
  executiveSummary: string;
  categories: AuditCategory[];
  findings: AuditFinding[];
  recommendations: AuditRecommendation[];
  compliance: ComplianceStatus;
  riskAssessment: RiskAssessment;
  metadata: {
    duration: string;
    scope: string;
    methodology: string;
    teamSize: number;
    toolsUsed: string[];
  };
}

interface AuditCategory {
  name: string;
  score: number;
  status: 'pass' | 'warning' | 'fail' | 'critical';
  description: string;
  checks: AuditCheck[];
  icon: React.ReactNode;
}

interface AuditCheck {
  name: string;
  description: string;
  result: 'pass' | 'fail' | 'warning' | 'not_tested';
  severity: 'low' | 'medium' | 'high' | 'critical';
  details?: string;
  evidence?: string;
}

interface AuditFinding {
  id: string;
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: string;
  impact: string;
  likelihood: string;
  riskScore: number;
  evidence: string;
  recommendations: string[];
  status: 'open' | 'in_progress' | 'resolved' | 'accepted';
}

interface AuditRecommendation {
  id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  category: string;
  effort: 'low' | 'medium' | 'high';
  timeline: string;
  impact: string;
  status: 'pending' | 'in_progress' | 'completed';
}

interface ComplianceStatus {
  overall: 'compliant' | 'partial' | 'non_compliant';
  frameworks: ComplianceFramework[];
}

interface ComplianceFramework {
  name: string;
  version: string;
  status: 'compliant' | 'partial' | 'non_compliant';
  score: number;
  findings: string[];
}

interface RiskAssessment {
  overallRisk: 'low' | 'medium' | 'high' | 'critical';
  risks: RiskItem[];
  mitigation: MitigationStrategy[];
}

interface RiskItem {
  id: string;
  category: string;
  description: string;
  likelihood: 'low' | 'medium' | 'high' | 'very_high';
  impact: 'low' | 'medium' | 'high' | 'critical';
  riskScore: number;
  currentControls: string[];
  recommendations: string[];
}

interface MitigationStrategy {
  riskId: string;
  strategy: string;
  timeline: string;
  responsibility: string;
  status: 'planned' | 'in_progress' | 'completed';
}

export default function Cloud3VenturesAudit() {
  const [auditReport, setAuditReport] = useState<Cloud3AuditReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  useEffect(() => {
    generateAuditReport();
  }, []);

  const generateAuditReport = async () => {
    setLoading(true);
    
    // Simulate API call to generate audit report
    setTimeout(() => {
      const report: Cloud3AuditReport = {
        id: 'cloud3-audit-2025-08-20',
        title: 'Cloud3 Ventures Security Audit Report',
        subtitle: 'Comprehensive Security Assessment and Compliance Review',
        auditDate: '2025-08-20',
        auditor: 'CyberSec Audit Team',
        company: 'Cloud3 Ventures',
        overallScore: 87.5,
        securityPosture: 'good',
        status: 'completed',
        executiveSummary: 'Cloud3 Ventures demonstrates a strong security posture with well-implemented controls across most critical areas. The audit revealed good practices in access management, data protection, and network security. However, opportunities for improvement were identified in monitoring capabilities, incident response procedures, and third-party risk management. Overall, the organization shows maturity in security practices and commitment to continuous improvement.',
        categories: [
          {
            name: 'Access Control',
            score: 92,
            status: 'pass',
            description: 'Identity and access management controls',
            checks: [
              { name: 'MFA Implementation', description: 'Multi-factor authentication across all critical systems', result: 'pass', severity: 'high' },
              { name: 'Least Privilege', description: 'Principle of least privilege enforcement', result: 'pass', severity: 'high' },
              { name: 'Access Reviews', description: 'Regular access rights reviews', result: 'warning', severity: 'medium', details: 'Some delays in quarterly reviews' },
              { name: 'Account Lifecycle', description: 'User account provisioning and deprovisioning', result: 'pass', severity: 'medium' }
            ],
            icon: <Lock className="w-5 h-5" />
          },
          {
            name: 'Data Protection',
            score: 89,
            status: 'pass',
            description: 'Data encryption and protection mechanisms',
            checks: [
              { name: 'Encryption at Rest', description: 'Data encryption in storage systems', result: 'pass', severity: 'critical' },
              { name: 'Encryption in Transit', description: 'Data encryption during transmission', result: 'pass', severity: 'critical' },
              { name: 'Data Classification', description: 'Data classification and handling procedures', result: 'pass', severity: 'high' },
              { name: 'Backup Security', description: 'Secure backup and recovery processes', result: 'warning', severity: 'medium', details: 'Backup encryption needs improvement' }
            ],
            icon: <Database className="w-5 h-5" />
          },
          {
            name: 'Network Security',
            score: 85,
            status: 'pass',
            description: 'Network infrastructure and perimeter security',
            checks: [
              { name: 'Firewall Configuration', description: 'Firewall rules and segmentation', result: 'pass', severity: 'high' },
              { name: 'IDS/IPS', description: 'Intrusion detection/prevention systems', result: 'pass', severity: 'high' },
              { name: 'Network Monitoring', description: 'Network traffic monitoring and analysis', result: 'warning', severity: 'medium', details: 'Limited visibility in some network segments' },
              { name: 'VPN Security', description: 'Remote access security controls', result: 'pass', severity: 'medium' }
            ],
            icon: <Network className="w-5 h-5" />
          },
          {
            name: 'Cloud Security',
            score: 88,
            status: 'pass',
            description: 'Cloud infrastructure and service security',
            checks: [
              { name: 'Cloud Configuration', description: 'Secure cloud service configuration', result: 'pass', severity: 'high' },
              { name: 'Identity Management', description: 'Cloud identity and access management', result: 'pass', severity: 'high' },
              { name: 'Data Residency', description: 'Data residency and sovereignty compliance', result: 'pass', severity: 'medium' },
              { name: 'Cloud Monitoring', description: 'Cloud security monitoring and logging', result: 'warning', severity: 'medium', details: 'Some cloud services lack comprehensive logging' }
            ],
            icon: <Cloud className="w-5 h-5" />
          },
          {
            name: 'Incident Response',
            score: 76,
            status: 'warning',
            description: 'Security incident response capabilities',
            checks: [
              { name: 'IR Plan', description: 'Incident response plan and procedures', result: 'pass', severity: 'high' },
              { name: 'IR Team', description: 'Incident response team structure and training', result: 'warning', severity: 'medium', details: 'Team training needs refresh' },
              { name: 'Detection Capabilities', description: 'Security incident detection mechanisms', result: 'warning', severity: 'high', details: 'Some detection rules need optimization' },
              { name: 'Communication Plan', description: 'Stakeholder communication procedures', result: 'pass', severity: 'medium' }
            ],
            icon: <AlertTriangle className="w-5 h-5" />
          },
          {
            name: 'Compliance',
            score: 91,
            status: 'pass',
            description: 'Regulatory compliance and certification status',
            checks: [
              { name: 'SOC 2', description: 'SOC 2 Type II compliance', result: 'pass', severity: 'high' },
              { name: 'ISO 27001', description: 'ISO 27001 certification status', result: 'pass', severity: 'high' },
              { name: 'GDPR', description: 'GDPR compliance measures', result: 'pass', severity: 'high' },
              { name: 'Industry Standards', description: 'Industry-specific compliance requirements', result: 'pass', severity: 'medium' }
            ],
            icon: <Award className="w-5 h-5" />
          }
        ],
        findings: [
          {
            id: 'F001',
            title: 'Insufficient Security Monitoring',
            description: 'Limited visibility into certain network segments and cloud services',
            severity: 'medium',
            category: 'Network Security',
            impact: 'Reduced ability to detect and respond to security incidents',
            likelihood: 'medium',
            riskScore: 6.5,
            evidence: 'Network monitoring logs show gaps in coverage for certain subnets',
            recommendations: ['Implement comprehensive network monitoring', 'Enhance cloud service logging', 'Deploy SIEM solution'],
            status: 'open'
          },
          {
            id: 'F002',
            title: 'Incident Response Team Training',
            description: 'Incident response team requires updated training and simulations',
            severity: 'medium',
            category: 'Incident Response',
            impact: 'Delayed or ineffective incident response',
            likelihood: 'medium',
            riskScore: 6.0,
            evidence: 'Last training session conducted 18 months ago',
            recommendations: ['Schedule quarterly IR team training', 'Conduct tabletop exercises', 'Update IR procedures'],
            status: 'in_progress'
          },
          {
            id: 'F003',
            title: 'Third-Party Risk Management',
            description: 'Insufficient assessment of third-party vendor security',
            severity: 'high',
            category: 'Compliance',
            impact: 'Potential supply chain security breaches',
            likelihood: 'medium',
            riskScore: 7.5,
            evidence: '30% of critical vendors lack recent security assessments',
            recommendations: ['Implement vendor risk management program', 'Conduct regular security assessments', 'Update vendor contracts'],
            status: 'open'
          }
        ],
        recommendations: [
          {
            id: 'R001',
            title: 'Deploy SIEM Solution',
            description: 'Implement Security Information and Event Management system for comprehensive monitoring',
            priority: 'high',
            category: 'Network Security',
            effort: 'high',
            timeline: '3-6 months',
            impact: 'Significant improvement in threat detection and response capabilities',
            status: 'pending'
          },
          {
            id: 'R002',
            title: 'Enhance Incident Response Program',
            description: 'Update incident response procedures and conduct regular team training',
            priority: 'medium',
            category: 'Incident Response',
            effort: 'medium',
            timeline: '1-2 months',
            impact: 'Improved incident response effectiveness and reduced response time',
            status: 'in_progress'
          },
          {
            id: 'R003',
            title: 'Implement Vendor Risk Management',
            description: 'Establish comprehensive third-party risk management program',
            priority: 'high',
            category: 'Compliance',
            effort: 'high',
            timeline: '4-8 months',
            impact: 'Reduced supply chain risk and improved compliance posture',
            status: 'pending'
          }
        ],
        compliance: {
          overall: 'partial',
          frameworks: [
            {
              name: 'SOC 2 Type II',
              version: '2017',
              status: 'compliant',
              score: 95,
              findings: []
            },
            {
              name: 'ISO 27001',
              version: '2013',
              status: 'compliant',
              score: 92,
              findings: []
            },
            {
              name: 'GDPR',
              version: '2018',
              status: 'partial',
              score: 88,
              findings: ['Some data processing records need improvement', 'Data retention policies require updates']
            },
            {
              name: 'NIST CSF',
              version: '1.1',
              status: 'partial',
              score: 85,
              findings: ['Recovery function needs enhancement', 'Supply chain risk management requires improvement']
            }
          ]
        },
        riskAssessment: {
          overallRisk: 'medium',
          risks: [
            {
              id: 'R001',
              category: 'Operational',
              description: 'Insufficient security monitoring capabilities',
              likelihood: 'medium',
              impact: 'medium',
              riskScore: 6.5,
              currentControls: ['Basic network monitoring', 'Log management'],
              recommendations: ['Deploy SIEM solution', 'Enhance monitoring coverage']
            },
            {
              id: 'R002',
              category: 'Compliance',
              description: 'Third-party vendor security risks',
              likelihood: 'medium',
              impact: 'high',
              riskScore: 7.5,
              currentControls: ['Basic vendor due diligence'],
              recommendations: ['Implement vendor risk management program', 'Regular security assessments']
            },
            {
              id: 'R003',
              category: 'Technical',
              description: 'Incident response capability gaps',
              likelihood: 'medium',
              impact: 'medium',
              riskScore: 6.0,
              currentControls: ['Incident response plan', 'Basic IR team'],
              recommendations: ['Update IR procedures', 'Regular team training and exercises']
            }
          ],
          mitigation: [
            {
              riskId: 'R001',
              strategy: 'Deploy comprehensive SIEM solution',
              timeline: '3-6 months',
              responsibility: 'CISO',
              status: 'planned'
            },
            {
              riskId: 'R002',
              strategy: 'Implement vendor risk management program',
              timeline: '4-8 months',
              responsibility: 'CRO',
              status: 'planned'
            },
            {
              riskId: 'R003',
              strategy: 'Enhance incident response capabilities',
              timeline: '1-2 months',
              responsibility: 'CISO',
              status: 'in_progress'
            }
          ]
        },
        metadata: {
          duration: '2 weeks',
          scope: 'Entire organization infrastructure and processes',
          methodology: 'NIST Cybersecurity Framework, ISO 27001, SOC 2',
          teamSize: 4,
          toolsUsed: ['Nessus', 'Burp Suite', 'Splunk', 'AWS Config', 'Azure Security Center']
        }
      };

      setAuditReport(report);
      setLoading(false);
    }, 2000);
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass': return 'bg-green-500';
      case 'warning': return 'bg-yellow-500';
      case 'fail': return 'bg-red-500';
      case 'critical': return 'bg-red-700';
      case 'compliant': return 'bg-green-500';
      case 'partial': return 'bg-yellow-500';
      case 'non_compliant': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-blue-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-orange-600';
      case 'critical': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-lg">Generating Cloud3 Ventures Audit Report...</p>
        </div>
      </div>
    );
  }

  if (!auditReport) {
    return (
      <div className="container mx-auto p-6">
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Failed to generate audit report. Please try again.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-2">
          <Building className="h-8 w-8 text-blue-600" />
          <h1 className="text-3xl font-bold">{auditReport.title}</h1>
        </div>
        <p className="text-xl text-gray-600">{auditReport.subtitle}</p>
        <div className="flex items-center justify-center gap-4 text-sm text-gray-500">
          <span className="flex items-center gap-1">
            <Calendar className="w-4 h-4" />
            {auditReport.auditDate}
          </span>
          <span className="flex items-center gap-1">
            <User className="w-4 h-4" />
            {auditReport.auditor}
          </span>
          <span className="flex items-center gap-1">
            <Building className="w-4 h-4" />
            {auditReport.company}
          </span>
        </div>
      </div>

      {/* Overall Score */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Star className="w-5 h-5" />
              Overall Security Posture
            </span>
            <Badge className={`${getStatusColor(auditReport.securityPosture)} text-white`}>
              {auditReport.securityPosture.toUpperCase()}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className={`text-4xl font-bold ${getScoreColor(auditReport.overallScore)}`}>
                {auditReport.overallScore}/100
              </div>
              <p className="text-sm text-gray-600">Overall Score</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {auditReport.categories.filter(c => c.status === 'pass').length}/{auditReport.categories.length}
              </div>
              <p className="text-sm text-gray-600">Categories Passed</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {auditReport.recommendations.filter(r => r.status === 'completed').length}/{auditReport.recommendations.length}
              </div>
              <p className="text-sm text-gray-600">Recommendations Complete</p>
            </div>
          </div>
          <div className="mt-6">
            <Progress value={auditReport.overallScore} className="h-3" />
          </div>
        </CardContent>
      </Card>

      {/* Executive Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Executive Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 leading-relaxed">{auditReport.executiveSummary}</p>
        </CardContent>
      </Card>

      {/* Main Dashboard */}
      <Tabs defaultValue="categories" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="findings">Findings</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          <TabsTrigger value="compliance">Compliance</TabsTrigger>
          <TabsTrigger value="risk">Risk Assessment</TabsTrigger>
        </TabsList>

        {/* Categories Tab */}
        <TabsContent value="categories" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {auditReport.categories.map((category) => (
              <Card 
                key={category.name}
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  selectedCategory === category.name ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => setSelectedCategory(selectedCategory === category.name ? null : category.name)}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {category.icon}
                      <CardTitle className="text-lg">{category.name}</CardTitle>
                    </div>
                    <Badge className={`${getStatusColor(category.status)} text-white`}>
                      {category.status}
                    </Badge>
                  </div>
                  <CardDescription>{category.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Score</span>
                      <span className={`text-sm font-bold ${getScoreColor(category.score)}`}>
                        {category.score}/100
                      </span>
                    </div>
                    <Progress value={category.score} className="h-2" />
                    <div className="text-xs text-gray-600">
                      {category.checks.filter(c => c.result === 'pass').length}/{category.checks.length} checks passed
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Selected Category Details */}
          {selectedCategory && (
            <Card>
              <CardHeader>
                <CardTitle>{selectedCategory} - Detailed Results</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {auditReport.categories
                    .find(c => c.name === selectedCategory)
                    ?.checks.map((check, index) => (
                      <div key={index} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium">{check.name}</h4>
                          <div className="flex items-center gap-2">
                            <Badge className={`${getStatusColor(check.result)} text-white`}>
                              {check.result}
                            </Badge>
                            <Badge className={`${getStatusColor(check.severity)} text-white`}>
                              {check.severity}
                            </Badge>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{check.description}</p>
                        {check.details && (
                          <p className="text-sm text-yellow-600">{check.details}</p>
                        )}
                        {check.evidence && (
                          <p className="text-sm text-blue-600 mt-1">Evidence: {check.evidence}</p>
                        )}
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Findings Tab */}
        <TabsContent value="findings" className="space-y-6">
          <div className="grid gap-4">
            {auditReport.findings.map((finding) => (
              <Card key={finding.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="font-semibold text-lg">{finding.title}</h4>
                      <p className="text-sm text-gray-600">{finding.category}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={`${getStatusColor(finding.severity)} text-white`}>
                        {finding.severity}
                      </Badge>
                      <Badge className={`${getStatusColor(finding.status)} text-white`}>
                        {finding.status}
                      </Badge>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-4">{finding.description}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <span className="text-sm font-medium text-gray-600">Impact:</span>
                      <p className="text-sm">{finding.impact}</p>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-gray-600">Likelihood:</span>
                      <p className="text-sm">{finding.likelihood}</p>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-gray-600">Risk Score:</span>
                      <p className={`text-sm font-bold ${getSeverityColor(finding.severity)}`}>
                        {finding.riskScore}/10
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <span className="text-sm font-medium">Evidence:</span>
                    <p className="text-sm text-gray-700">{finding.evidence}</p>
                  </div>
                  
                  <div className="space-y-2 mt-4">
                    <span className="text-sm font-medium">Recommendations:</span>
                    <ul className="text-sm text-gray-700 list-disc list-inside">
                      {finding.recommendations.map((rec, index) => (
                        <li key={index}>{rec}</li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Recommendations Tab */}
        <TabsContent value="recommendations" className="space-y-6">
          <div className="grid gap-4">
            {auditReport.recommendations.map((recommendation) => (
              <Card key={recommendation.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="font-semibold text-lg">{recommendation.title}</h4>
                      <p className="text-sm text-gray-600">{recommendation.category}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={`${getStatusColor(recommendation.priority)} text-white`}>
                        {recommendation.priority}
                      </Badge>
                      <Badge className={`${getStatusColor(recommendation.status)} text-white`}>
                        {recommendation.status}
                      </Badge>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-4">{recommendation.description}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <span className="text-sm font-medium text-gray-600">Effort:</span>
                      <p className="text-sm">{recommendation.effort}</p>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-gray-600">Timeline:</span>
                      <p className="text-sm">{recommendation.timeline}</p>
                    </div>
                    <div className="md:col-span-2">
                      <span className="text-sm font-medium text-gray-600">Expected Impact:</span>
                      <p className="text-sm">{recommendation.impact}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Compliance Tab */}
        <TabsContent value="compliance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Compliance Status</span>
                <Badge className={`${getStatusColor(auditReport.compliance.overall)} text-white`}>
                  {auditReport.compliance.overall.toUpperCase()}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {auditReport.compliance.frameworks.map((framework) => (
                  <Card key={framework.name}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{framework.name}</CardTitle>
                        <Badge className={`${getStatusColor(framework.status)} text-white`}>
                          {framework.status}
                        </Badge>
                      </div>
                      <CardDescription>Version {framework.version}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">Compliance Score</span>
                          <span className={`text-sm font-bold ${getScoreColor(framework.score)}`}>
                            {framework.score}/100
                          </span>
                        </div>
                        <Progress value={framework.score} className="h-2" />
                        
                        {framework.findings.length > 0 && (
                          <div className="space-y-2">
                            <span className="text-sm font-medium">Findings:</span>
                            <ul className="text-sm text-gray-700 list-disc list-inside">
                              {framework.findings.map((finding, index) => (
                                <li key={index}>{finding}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Risk Assessment Tab */}
        <TabsContent value="risk" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Overall Risk Assessment</span>
                <Badge className={`${getStatusColor(auditReport.riskAssessment.overallRisk)} text-white`}>
                  {auditReport.riskAssessment.overallRisk.toUpperCase()} RISK
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {auditReport.riskAssessment.risks.map((risk) => (
                  <Card key={risk.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h4 className="font-semibold">{risk.description}</h4>
                          <p className="text-sm text-gray-600">{risk.category}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={`${getStatusColor(risk.likelihood)} text-white`}>
                            {risk.likelihood}
                          </Badge>
                          <Badge className={`${getStatusColor(risk.impact)} text-white`}>
                            {risk.impact}
                          </Badge>
                          <span className={`text-sm font-bold ${getSeverityColor(risk.impact)}`}>
                            {risk.riskScore}/10
                          </span>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <span className="text-sm font-medium">Current Controls:</span>
                          <ul className="text-sm text-gray-700 list-disc list-inside">
                            {risk.currentControls.map((control, index) => (
                              <li key={index}>{control}</li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <span className="text-sm font-medium">Recommendations:</span>
                          <ul className="text-sm text-gray-700 list-disc list-inside">
                            {risk.recommendations.map((rec, index) => (
                              <li key={index}>{rec}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Mitigation Strategies */}
          <Card>
            <CardHeader>
              <CardTitle>Mitigation Strategies</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {auditReport.riskAssessment.mitigation.map((mitigation) => (
                  <div key={mitigation.riskId} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{mitigation.strategy}</h4>
                      <Badge className={`${getStatusColor(mitigation.status)} text-white`}>
                        {mitigation.status}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Timeline:</span>
                        <p>{mitigation.timeline}</p>
                      </div>
                      <div>
                        <span className="font-medium">Responsibility:</span>
                        <p>{mitigation.responsibility}</p>
                      </div>
                      <div>
                        <span className="font-medium">Risk ID:</span>
                        <p>{mitigation.riskId}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Export Options */}
      <Card>
        <CardHeader>
          <CardTitle>Export Report</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Button className="flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export PDF
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Export JSON
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              View Details
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}