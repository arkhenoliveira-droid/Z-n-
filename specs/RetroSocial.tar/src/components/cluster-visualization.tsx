'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Activity, 
  Zap, 
  Network, 
  Target, 
  TrendingUp, 
  Users, 
  Globe,
  Brain,
  Radio,
  BarChart3,
  Settings,
  RefreshCw,
  Eye,
  Lightbulb,
  Layers,
  Infinity,
  Plus,
  Trash2,
  Scale,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingDown,
  TrendingUp,
  Maximize,
  Minimize,
  Download,
  Share2,
  Filter,
  Calendar,
  MapPin,
  Thermometer,
  Battery,
  Wifi,
  Cpu,
  HardDrive
} from 'lucide-react';

import { DynamicCluster, ClusterAnalytics, OptimizationResult } from '@/systems/dynamic-cluster-creation';

interface ClusterVisualizationProps {
  clusters: DynamicCluster[];
  selectedCluster: DynamicCluster | null;
  analytics: ClusterAnalytics | null;
  onSelectCluster: (cluster: DynamicCluster) => void;
  onRefresh: () => void;
}

interface ClusterNode {
  id: string;
  x: number;
  y: number;
  size: number;
  color: string;
  connections: string[];
  coherence: number;
  type: string;
  status: string;
}

interface VisualizationConfig {
  layout: 'force' | 'circular' | 'hierarchical' | 'grid';
  showConnections: boolean;
  showLabels: boolean;
  animationSpeed: number;
  colorScheme: 'coherence' | 'type' | 'status' | 'performance';
  nodeSize: 'fixed' | 'dynamic' | 'coherence-based';
}

export default function ClusterVisualization({ 
  clusters, 
  selectedCluster, 
  analytics, 
  onSelectCluster, 
  onRefresh 
}: ClusterVisualizationProps) {
  const [config, setConfig] = useState<VisualizationConfig>({
    layout: 'force',
    showConnections: true,
    showLabels: true,
    animationSpeed: 1.0,
    colorScheme: 'coherence',
    nodeSize: 'coherence-based'
  });

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [selectedTimeframe, setSelectedTimeframe] = useState<'1h' | '6h' | '24h' | '7d'>('1h');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Generate visualization data
  const generateVisualizationData = (): ClusterNode[] => {
    if (!selectedCluster) return [];

    const nodes: ClusterNode[] = [];
    const nodeCount = selectedCluster.nodes.length;
    const centerX = 400;
    const centerY = 300;
    const radius = 200;

    selectedCluster.nodes.forEach((nodeId, index) => {
      let x, y;
      
      switch (config.layout) {
        case 'circular':
          const angle = (index / nodeCount) * 2 * Math.PI;
          x = centerX + radius * Math.cos(angle);
          y = centerY + radius * Math.sin(angle);
          break;
        case 'grid':
          const cols = Math.ceil(Math.sqrt(nodeCount));
          const row = Math.floor(index / cols);
          const col = index % cols;
          x = 100 + col * 150;
          y = 100 + row * 150;
          break;
        case 'hierarchical':
          x = centerX + (index % 3 - 1) * 150;
          y = 100 + Math.floor(index / 3) * 100;
          break;
        default: // force
          x = centerX + (Math.random() - 0.5) * radius * 2;
          y = centerY + (Math.random() - 0.5) * radius * 2;
          break;
      }

      const coherence = 0.5 + Math.random() * 0.5;
      const color = getNodeColor(coherence, config.colorScheme);
      const size = getNodeSize(coherence, config.nodeSize);

      nodes.push({
        id: nodeId,
        x,
        y,
        size,
        color,
        connections: selectedCluster.nodes.filter((_, i) => i !== index && Math.random() > 0.7),
        coherence,
        type: getNodeTypes()[index % getNodeTypes().length],
        status: getNodeStatuses()[index % getNodeStatuses().length]
      });
    });

    return nodes;
  };

  const getNodeColor = (coherence: number, scheme: string): string => {
    switch (scheme) {
      case 'coherence':
        if (coherence > 0.8) return '#10b981'; // green
        if (coherence > 0.6) return '#3b82f6'; // blue
        if (coherence > 0.4) return '#f59e0b'; // yellow
        return '#ef4444'; // red
      case 'type':
        const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];
        return colors[Math.floor(Math.random() * colors.length)];
      case 'status':
        return '#3b82f6'; // blue for active
      case 'performance':
        if (coherence > 0.8) return '#10b981';
        if (coherence > 0.6) return '#3b82f6';
        return '#f59e0b';
      default:
        return '#6b7280';
    }
  };

  const getNodeSize = (coherence: number, sizeType: string): number => {
    switch (sizeType) {
      case 'fixed':
        return 20;
      case 'dynamic':
        return 15 + Math.random() * 20;
      case 'coherence-based':
        return 10 + coherence * 30;
      default:
        return 20;
    }
  };

  const getNodeTypes = (): string[] => {
    return ['quantum', 'classical', 'hybrid', 'neural', 'biological'];
  };

  const getNodeStatuses = (): string[] => {
    return ['active', 'idle', 'processing', 'optimizing', 'standby'];
  };

  // Draw visualization
  const drawVisualization = () => {
    const canvas = canvasRef.current;
    if (!canvas || !selectedCluster) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const nodes = generateVisualizationData();

    // Draw connections
    if (config.showConnections) {
      ctx.strokeStyle = 'rgba(107, 114, 128, 0.3)';
      ctx.lineWidth = 1;
      
      nodes.forEach(node => {
        node.connections.forEach(connectionId => {
          const connectedNode = nodes.find(n => n.id === connectionId);
          if (connectedNode) {
            ctx.beginPath();
            ctx.moveTo(node.x, node.y);
            ctx.lineTo(connectedNode.x, connectedNode.y);
            ctx.stroke();
          }
        });
      });
    }

    // Draw nodes
    nodes.forEach(node => {
      ctx.fillStyle = node.color;
      ctx.beginPath();
      ctx.arc(node.x, node.y, node.size, 0, 2 * Math.PI);
      ctx.fill();

      // Draw node border
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Draw labels
      if (config.showLabels) {
        ctx.fillStyle = '#374151';
        ctx.font = '12px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(node.id.slice(-4), node.x, node.y + node.size + 15);
      }
    });
  };

  useEffect(() => {
    drawVisualization();
  }, [selectedCluster, config]);

  const handleConfigChange = (key: keyof VisualizationConfig, value: any) => {
    setConfig(prev => ({ ...prev, [key]: value }));
  };

  const exportVisualization = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = `cluster-visualization-${selectedCluster?.id || 'all'}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  const getClusterHealthScore = (cluster: DynamicCluster): number => {
    const coherence = cluster.coherence_metrics.overall_coherence;
    const performance = (cluster.performance_metrics.reliability + cluster.performance_metrics.availability) / 2;
    const stability = cluster.coherence_metrics.stability_factor;
    
    return (coherence + performance + stability) / 3;
  };

  const getClusterEfficiency = (cluster: DynamicCluster): number => {
    return (cluster.performance_metrics.throughput + cluster.performance_metrics.efficiency) / 2;
  };

  return (
    <div className={`space-y-6 ${isFullscreen ? 'fixed inset-0 bg-white z-50 p-6' : ''}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Cluster Visualization & Monitoring</h2>
          <p className="text-muted-foreground">
            {selectedCluster ? `Visualizing ${selectedCluster.name}` : 'Select a cluster to visualize'}
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" onClick={onRefresh}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button variant="outline" size="sm" onClick={() => setIsFullscreen(!isFullscreen)}>
            {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          </Button>
          <Button variant="outline" size="sm" onClick={exportVisualization}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Configuration Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Visualization Configuration</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <div>
              <label className="text-sm font-medium">Layout</label>
              <select 
                value={config.layout}
                onChange={(e) => handleConfigChange('layout', e.target.value)}
                className="w-full mt-1 px-2 py-1 border rounded text-sm"
              >
                <option value="force">Force</option>
                <option value="circular">Circular</option>
                <option value="hierarchical">Hierarchical</option>
                <option value="grid">Grid</option>
              </select>
            </div>
            
            <div>
              <label className="text-sm font-medium">Color Scheme</label>
              <select 
                value={config.colorScheme}
                onChange={(e) => handleConfigChange('colorScheme', e.target.value)}
                className="w-full mt-1 px-2 py-1 border rounded text-sm"
              >
                <option value="coherence">Coherence</option>
                <option value="type">Type</option>
                <option value="status">Status</option>
                <option value="performance">Performance</option>
              </select>
            </div>
            
            <div>
              <label className="text-sm font-medium">Node Size</label>
              <select 
                value={config.nodeSize}
                onChange={(e) => handleConfigChange('nodeSize', e.target.value)}
                className="w-full mt-1 px-2 py-1 border rounded text-sm"
              >
                <option value="fixed">Fixed</option>
                <option value="dynamic">Dynamic</option>
                <option value="coherence-based">Coherence-based</option>
              </select>
            </div>
            
            <div className="flex items-center space-x-2">
              <input 
                type="checkbox"
                checked={config.showConnections}
                onChange={(e) => handleConfigChange('showConnections', e.target.checked)}
                className="rounded"
              />
              <label className="text-sm">Show Connections</label>
            </div>
            
            <div className="flex items-center space-x-2">
              <input 
                type="checkbox"
                checked={config.showLabels}
                onChange={(e) => handleConfigChange('showLabels', e.target.checked)}
                className="rounded"
              />
              <label className="text-sm">Show Labels</label>
            </div>
            
            <div>
              <label className="text-sm font-medium">Timeframe</label>
              <select 
                value={selectedTimeframe}
                onChange={(e) => setSelectedTimeframe(e.target.value as any)}
                className="w-full mt-1 px-2 py-1 border rounded text-sm"
              >
                <option value="1h">1 Hour</option>
                <option value="6h">6 Hours</option>
                <option value="24h">24 Hours</option>
                <option value="7d">7 Days</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Visualization Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Visualization Canvas */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Cluster Topology</CardTitle>
              <CardDescription>
                {selectedCluster ? `${selectedCluster.nodes.length} nodes • ${selectedCluster.cluster_type}` : 'No cluster selected'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <canvas 
                  ref={canvasRef}
                  width={800}
                  height={600}
                  className="border rounded-lg w-full"
                />
                {!selectedCluster && (
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-50 rounded-lg">
                    <div className="text-center">
                      <Network className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                      <p className="text-gray-600">Select a cluster to visualize</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Metrics Panel */}
        <div className="space-y-4">
          {/* Cluster Health */}
          {selectedCluster && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Cluster Health</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Health Score</span>
                  <span className="text-lg font-bold text-green-600">
                    {(getClusterHealthScore(selectedCluster) * 100).toFixed(1)}%
                  </span>
                </div>
                <Progress value={getClusterHealthScore(selectedCluster) * 100} />
                
                <div className="flex items-center justify-between">
                  <span className="text-sm">Efficiency</span>
                  <span className="text-lg font-bold text-blue-600">
                    {(getClusterEfficiency(selectedCluster) * 100).toFixed(1)}%
                  </span>
                </div>
                <Progress value={getClusterEfficiency(selectedCluster) * 100} />
                
                <div className="flex items-center justify-between">
                  <span className="text-sm">Coherence</span>
                  <span className="text-lg font-bold text-purple-600">
                    {(selectedCluster.coherence_metrics.overall_coherence * 100).toFixed(1)}%
                  </span>
                </div>
                <Progress value={selectedCluster.coherence_metrics.overall_coherence * 100} />
              </CardContent>
            </Card>
          )}

          {/* Resource Utilization */}
          {selectedCluster && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Resource Utilization</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Cpu className="w-4 h-4 text-blue-500" />
                    <span className="text-sm">CPU</span>
                  </div>
                  <span className="text-sm font-medium">65%</span>
                </div>
                <Progress value={65} className="h-1" />
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <HardDrive className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Memory</span>
                  </div>
                  <span className="text-sm font-medium">48%</span>
                </div>
                <Progress value={48} className="h-1" />
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Wifi className="w-4 h-4 text-purple-500" />
                    <span className="text-sm">Network</span>
                  </div>
                  <span className="text-sm font-medium">72%</span>
                </div>
                <Progress value={72} className="h-1" />
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Battery className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm">Quantum</span>
                  </div>
                  <span className="text-sm font-medium">38%</span>
                </div>
                <Progress value={38} className="h-1" />
              </CardContent>
            </Card>
          )}

          {/* Performance Metrics */}
          {selectedCluster && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Throughput</span>
                  <span className="text-sm font-medium">
                    {selectedCluster.performance_metrics.throughput.toFixed(2)} ops/s
                  </span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm">Latency</span>
                  <span className="text-sm font-medium">
                    {selectedCluster.performance_metrics.latency.toFixed(2)} ms
                  </span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm">Reliability</span>
                  <span className="text-sm font-medium text-green-600">
                    {(selectedCluster.performance_metrics.reliability * 100).toFixed(1)}%
                  </span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm">Error Rate</span>
                  <span className="text-sm font-medium text-red-600">
                    {(selectedCluster.performance_metrics.error_rate * 100).toFixed(2)}%
                  </span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm">Availability</span>
                  <span className="text-sm font-medium text-blue-600">
                    {(selectedCluster.performance_metrics.availability * 100).toFixed(1)}%
                  </span>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Cluster List */}
      <Card>
        <CardHeader>
          <CardTitle>Active Clusters</CardTitle>
          <CardDescription>Overview of all active clusters with key metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {clusters.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Network className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No active clusters</p>
              </div>
            ) : (
              clusters.map((cluster) => (
                <div 
                  key={cluster.id}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    selectedCluster?.id === cluster.id ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => onSelectCluster(cluster)}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">{cluster.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {cluster.nodes.length} nodes • {cluster.cluster_type.replace('_', ' ')}
                      </p>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="text-sm font-medium">
                          {(cluster.coherence_metrics.overall_coherence * 100).toFixed(1)}%
                        </div>
                        <div className="text-xs text-muted-foreground">Coherence</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">
                          {getClusterHealthScore(cluster) > 0.8 ? 'Good' : getClusterHealthScore(cluster) > 0.6 ? 'Fair' : 'Poor'}
                        </div>
                        <div className="text-xs text-muted-foreground">Health</div>
                      </div>
                      <div className={`w-3 h-3 rounded-full ${
                        cluster.status === 'stable' ? 'bg-green-500' :
                        cluster.status === 'optimizing' ? 'bg-blue-500' :
                        cluster.status === 'adapting' ? 'bg-yellow-500' : 'bg-gray-500'
                      }`} />
                    </div>
                  </div>
                  
                  <div className="mt-3 grid grid-cols-3 gap-4">
                    <div>
                      <div className="text-xs text-muted-foreground">Efficiency</div>
                      <Progress value={getClusterEfficiency(cluster) * 100} className="h-1 mt-1" />
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">Quantum Correlation</div>
                      <Progress value={cluster.coherence_metrics.quantum_correlation * 100} className="h-1 mt-1" />
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">Emergence</div>
                      <Progress value={cluster.coherence_metrics.emergence_level * 100} className="h-1 mt-1" />
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Analytics Panel */}
      {analytics && (
        <Card>
          <CardHeader>
            <CardTitle>Advanced Analytics</CardTitle>
            <CardDescription>Detailed insights and recommendations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">{analytics.efficiency_score.toFixed(2)}</div>
                <div className="text-sm text-muted-foreground">Efficiency Score</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">{analytics.adaptation_events}</div>
                <div className="text-sm text-muted-foreground">Adaptation Events</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">
                  {Math.floor(analytics.uptime / 3600000)}h
                </div>
                <div className="text-sm text-muted-foreground">Uptime</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600">{analytics.recommendations.length}</div>
                <div className="text-sm text-muted-foreground">Recommendations</div>
              </div>
            </div>
            
            {analytics.recommendations.length > 0 && (
              <div className="mt-6">
                <h4 className="font-medium mb-3">Recommendations</h4>
                <div className="space-y-2">
                  {analytics.recommendations.map((recommendation, index) => (
                    <div key={index} className="flex items-start space-x-2 p-2 bg-muted rounded">
                      <Lightbulb className="w-4 h-4 text-yellow-500 mt-0.5" />
                      <span className="text-sm">{recommendation}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}