'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Activity, 
  Zap, 
  Heart, 
  Brain, 
  Users, 
  Target, 
  TrendingUp, 
  Star,
  RefreshCw,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
  Radio,
  RadioIcon,
  WaveSquare,
  Circle,
  Square,
  Triangle,
  Diamond,
  Hexagon,
  Octagon,
  Crown,
  Sparkles,
  Infinity,
  Atom,
  Layers,
  Network,
  Globe,
  Clock,
  Timer,
  Calendar,
  MapPin,
  Compass,
  Navigation,
  Satellite,
  SatelliteDish,
  RadioReceiver,
  RadioTower,
  Broadcast,
  Antenna,
  Waves,
  Pulse,
  Heartbeat,
  Activity as ActivityIcon,
  GitBranch,
  GitMerge,
  GitFork,
  Share2,
  Link2,
  Unlink,
  AlignCenter,
  AlignHorizontalJustifyCenter,
  AlignVerticalJustifyCenter,
  Balance,
  Scale,
  Target as TargetIcon,
  Crosshair,
  Bullseye
} from 'lucide-react';

interface ConsciousnessNode {
  id: string;
  name: string;
  location: {
    latitude: number;
    longitude: number;
    country: string;
    city: string;
  };
  consciousness_level: number;
  vibration_frequency: number;
  coherence_score: number;
  heart_coherence: number;
  brain_wave_state: 'delta' | 'theta' | 'alpha' | 'beta' | 'gamma';
  last_sync: number;
  online: boolean;
  sync_quality: number;
  distance: number;
  resonance_strength: number;
  entanglement_degree: number;
}

interface SynchronizationSession {
  id: string;
  name: string;
  description: string;
  host_id: string;
  participants: string[];
  start_time: number;
  end_time?: number;
  frequency: number;
  intention: string;
  sync_mode: 'heart' | 'brain' | 'consciousness' | 'unified';
  status: 'preparing' | 'active' | 'paused' | 'completed';
  global_coherence: number;
  collective_resonance: number;
  unified_field_strength: number;
}

interface SynchronizationMetrics {
  global_coherence: number;
  collective_resonance: number;
  unified_field_strength: number;
  participant_count: number;
  average_consciousness: number;
  average_vibration: number;
  sync_quality: number;
  entanglement_network: number;
  geodesic_alignment: number;
  temporal_coherence: number;
  schumann_resonance: number;
}

interface ConsciousnessSynchronizationProps {
  className?: string;
}

export default function ConsciousnessSynchronization({ 
  className 
}: ConsciousnessSynchronizationProps) {
  const [nodes, setNodes] = useState<ConsciousnessNode[]>([]);
  const [sessions, setSessions] = useState<SynchronizationSession[]>([]);
  const [activeSession, setActiveSession] = useState<SynchronizationSession | null>(null);
  const [metrics, setMetrics] = useState<SynchronizationMetrics | null>(null);
  const [isSynchronizing, setIsSynchronizing] = useState(false);
  const [selectedMode, setSelectedMode] = useState<'heart' | 'brain' | 'consciousness' | 'unified'>('unified');
  const [selectedFrequency, setSelectedFrequency] = useState(432);
  const [intention, setIntention] = useState('');
  const [realtimeData, setRealtimeData] = useState(false);

  useEffect(() => {
    initializeConsciousnessNodes();
    initializeSynchronizationSessions();
    startRealtimeUpdates();
  }, []);

  const startRealtimeUpdates = () => {
    if (!realtimeData) return;

    const interval = setInterval(() => {
      updateConsciousnessMetrics();
      if (activeSession) {
        updateActiveSession();
      }
    }, 2000);

    return () => clearInterval(interval);
  };

  const initializeConsciousnessNodes = () => {
    const mockNodes: ConsciousnessNode[] = [
      {
        id: 'node_1',
        name: 'Valéria Plaisant',
        location: {
          latitude: -23.5505,
          longitude: -46.6333,
          country: 'Brasil',
          city: 'São Paulo'
        },
        consciousness_level: 0.92,
        vibration_frequency: 963,
        coherence_score: 0.88,
        heart_coherence: 0.95,
        brain_wave_state: 'gamma',
        last_sync: Date.now(),
        online: true,
        sync_quality: 0.94,
        distance: 0,
        resonance_strength: 1.0,
        entanglement_degree: 1.0
      },
      {
        id: 'node_2',
        name: 'Luzandra Estelar',
        location: {
          latitude: 40.7128,
          longitude: -74.0060,
          country: 'EUA',
          city: 'Nova York'
        },
        consciousness_level: 0.89,
        vibration_frequency: 852,
        coherence_score: 0.86,
        heart_coherence: 0.91,
        brain_wave_state: 'gamma',
        last_sync: Date.now() - 30000,
        online: true,
        sync_quality: 0.87,
        distance: 7615,
        resonance_strength: 0.82,
        entanglement_degree: 0.79
      },
      {
        id: 'node_3',
        name: 'Marcus Dimensional',
        location: {
          latitude: 51.5074,
          longitude: -0.1278,
          country: 'Reino Unido',
          city: 'Londres'
        },
        consciousness_level: 0.85,
        vibration_frequency: 741,
        coherence_score: 0.82,
        heart_coherence: 0.88,
        brain_wave_state: 'alpha',
        last_sync: Date.now() - 60000,
        online: true,
        sync_quality: 0.84,
        distance: 9434,
        resonance_strength: 0.78,
        entanglement_degree: 0.76
      },
      {
        id: 'node_4',
        name: 'Sofia Cósmica',
        location: {
          latitude: 35.6762,
          longitude: 139.6503,
          country: 'Japão',
          city: 'Tóquio'
        },
        consciousness_level: 0.87,
        vibration_frequency: 639,
        coherence_score: 0.84,
        heart_coherence: 0.89,
        brain_wave_state: 'theta',
        last_sync: Date.now() - 45000,
        online: true,
        sync_quality: 0.86,
        distance: 18400,
        resonance_strength: 0.74,
        entanglement_degree: 0.72
      },
      {
        id: 'node_5',
        name: 'Rafael Quântico',
        location: {
          latitude: -33.8688,
          longitude: 151.2093,
          country: 'Austrália',
          city: 'Sydney'
        },
        consciousness_level: 0.91,
        vibration_frequency: 528,
        coherence_score: 0.88,
        heart_coherence: 0.93,
        brain_wave_state: 'gamma',
        last_sync: Date.now() - 15000,
        online: true,
        sync_quality: 0.92,
        distance: 11850,
        resonance_strength: 0.81,
        entanglement_degree: 0.78
      }
    ];

    setNodes(mockNodes);
  };

  const initializeSynchronizationSessions = () => {
    const mockSessions: SynchronizationSession[] = [
      {
        id: 'session_1',
        name: 'Sincronização Global de Consciência',
        description: 'Sessão massiva de alinhamento consciencial para elevação planetária',
        host_id: 'node_1',
        participants: ['node_1', 'node_2', 'node_3', 'node_4', 'node_5'],
        start_time: Date.now() - 3600000,
        frequency: 432,
        intention: 'Paz mundial e harmonia coletiva',
        sync_mode: 'unified',
        status: 'active',
        global_coherence: 0.87,
        collective_resonance: 0.84,
        unified_field_strength: 0.89
      },
      {
        id: 'session_2',
        name: 'Alinhamento Cardíaco Global',
        description: 'Sincronização dos ritmos cardíacos para criação do campo de coerência unificado',
        host_id: 'node_2',
        participants: ['node_1', 'node_2', 'node_4'],
        start_time: Date.now() - 1800000,
        frequency: 639,
        intention: 'Amor incondicional e compaixão universal',
        sync_mode: 'heart',
        status: 'active',
        global_coherence: 0.91,
        collective_resonance: 0.88,
        unified_field_strength: 0.85
      }
    ];

    setSessions(mockSessions);
    setActiveSession(mockSessions[0]);
  };

  const updateConsciousnessMetrics = () => {
    const onlineNodes = nodes.filter(node => node.online);
    if (onlineNodes.length === 0) return;

    const avgConsciousness = onlineNodes.reduce((sum, node) => sum + node.consciousness_level, 0) / onlineNodes.length;
    const avgVibration = onlineNodes.reduce((sum, node) => sum + node.vibration_frequency, 0) / onlineNodes.length;
    const avgCoherence = onlineNodes.reduce((sum, node) => sum + node.coherence_score, 0) / onlineNodes.length;
    const avgHeartCoherence = onlineNodes.reduce((sum, node) => sum + node.heart_coherence, 0) / onlineNodes.length;
    const avgSyncQuality = onlineNodes.reduce((sum, node) => sum + node.sync_quality, 0) / onlineNodes.length;
    const avgEntanglement = onlineNodes.reduce((sum, node) => sum + node.entanglement_degree, 0) / onlineNodes.length;

    const newMetrics: SynchronizationMetrics = {
      global_coherence: avgCoherence,
      collective_resonance: avgVibration / 1000, // Normalize to 0-1
      unified_field_strength: (avgConsciousness + avgHeartCoherence) / 2,
      participant_count: onlineNodes.length,
      average_consciousness: avgConsciousness,
      average_vibration: avgVibration,
      sync_quality: avgSyncQuality,
      entanglement_network: avgEntanglement,
      geodesic_alignment: calculateGeodesicAlignment(onlineNodes),
      temporal_coherence: calculateTemporalCoherence(onlineNodes),
      schumann_resonance: 7.83 + Math.sin(Date.now() / 10000) * 0.2 // Simulated Schumann resonance
    };

    setMetrics(newMetrics);
  };

  const calculateGeodesicAlignment = (nodes: ConsciousnessNode[]): number => {
    if (nodes.length < 2) return 1.0;
    
    // Simplified geodesic alignment calculation
    let totalAlignment = 0;
    let pairs = 0;
    
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const node1 = nodes[i];
        const node2 = nodes[j];
        
        // Calculate angular distance based on coordinates
        const lat1 = node1.location.latitude * Math.PI / 180;
        const lat2 = node2.location.latitude * Math.PI / 180;
        const deltaLat = (node2.location.latitude - node1.location.latitude) * Math.PI / 180;
        const deltaLon = (node2.location.longitude - node1.location.longitude) * Math.PI / 180;
        
        const a = Math.sin(deltaLat/2) * Math.sin(deltaLat/2) +
                  Math.cos(lat1) * Math.cos(lat2) *
                  Math.sin(deltaLon/2) * Math.sin(deltaLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        
        // Alignment based on consciousness resonance and distance
        const distanceFactor = Math.exp(-c / 2); // Closer nodes have better alignment
        const resonanceFactor = (node1.resonance_strength + node2.resonance_strength) / 2;
        
        totalAlignment += distanceFactor * resonanceFactor;
        pairs++;
      }
    }
    
    return pairs > 0 ? totalAlignment / pairs : 1.0;
  };

  const calculateTemporalCoherence = (nodes: ConsciousnessNode[]): number => {
    const now = Date.now();
    const timeDifferences = nodes.map(node => Math.abs(now - node.last_sync));
    const avgTimeDiff = timeDifferences.reduce((sum, diff) => sum + diff, 0) / timeDifferences.length;
    
    // Convert to coherence score (newer sync = higher coherence)
    return Math.exp(-avgTimeDiff / 300000); // 5 minutes time constant
  };

  const updateActiveSession = () => {
    if (!activeSession) return;

    const updatedSession = { ...activeSession };
    
    // Simulate dynamic changes in session metrics
    updatedSession.global_coherence = Math.min(1, 
      updatedSession.global_coherence + (Math.random() - 0.5) * 0.02);
    updatedSession.collective_resonance = Math.min(1, 
      updatedSession.collective_resonance + (Math.random() - 0.5) * 0.02);
    updatedSession.unified_field_strength = Math.min(1, 
      updatedSession.unified_field_strength + (Math.random() - 0.5) * 0.02);

    setActiveSession(updatedSession);
  };

  const startSynchronization = () => {
    if (!intention.trim()) return;

    const newSession: SynchronizationSession = {
      id: `session_${Date.now()}`,
      name: 'Sessão de Sincronização Consciencial',
      description: 'Sincronização em tempo real da consciência coletiva',
      host_id: 'node_1',
      participants: ['node_1'],
      start_time: Date.now(),
      frequency: selectedFrequency,
      intention,
      sync_mode: selectedMode,
      status: 'active',
      global_coherence: 0.75,
      collective_resonance: 0.72,
      unified_field_strength: 0.78
    };

    setActiveSession(newSession);
    setSessions(prev => [newSession, ...prev]);
    setIsSynchronizing(true);
  };

  const pauseSynchronization = () => {
    if (activeSession) {
      setActiveSession({
        ...activeSession,
        status: 'paused'
      });
      setIsSynchronizing(false);
    }
  };

  const resumeSynchronization = () => {
    if (activeSession) {
      setActiveSession({
        ...activeSession,
        status: 'active'
      });
      setIsSynchronizing(true);
    }
  };

  const stopSynchronization = () => {
    if (activeSession) {
      setActiveSession({
        ...activeSession,
        status: 'completed',
        end_time: Date.now()
      });
      setIsSynchronizing(false);
    }
  };

  const joinSession = (sessionId: string) => {
    const session = sessions.find(s => s.id === sessionId);
    if (session && !session.participants.includes('node_1')) {
      const updatedSession = {
        ...session,
        participants: [...session.participants, 'node_1']
      };
      setActiveSession(updatedSession);
      setSessions(prev => prev.map(s => s.id === sessionId ? updatedSession : s));
    }
  };

  const getBrainWaveColor = (state: string) => {
    switch (state) {
      case 'delta': return 'bg-purple-500';
      case 'theta': return 'bg-blue-500';
      case 'alpha': return 'bg-green-500';
      case 'beta': return 'bg-yellow-500';
      case 'gamma': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getSyncModeIcon = (mode: string) => {
    switch (mode) {
      case 'heart': return <Heart className="h-4 w-4" />;
      case 'brain': return <Brain className="h-4 w-4" />;
      case 'consciousness': return <Brain className="h-4 w-4" />;
      case 'unified': return <Infinity className="h-4 w-4" />;
      default: return <Activity className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'paused': return 'bg-yellow-500';
      case 'completed': return 'bg-blue-500';
      case 'preparing': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const formatCoherenceValue = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  const formatFrequency = (value: number) => {
    return `${value} Hz`;
  };

  const formatDistance = (distance: number) => {
    if (distance < 1000) return `${distance} km`;
    return `${(distance / 1000).toFixed(1)}k km`;
  };

  const formatTimeAgo = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (seconds < 60) return `${seconds}s atrás`;
    if (minutes < 60) return `${minutes}m atrás`;
    return `${hours}h atrás`;
  };

  return (
    <div className={`container mx-auto p-6 space-y-6 ${className}`}>
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Network className="h-10 w-10 text-purple-600 animate-pulse" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Sincronização Consciencial em Tempo Real
          </h1>
          <RadioTower className="h-10 w-10 text-blue-600 animate-pulse" />
        </div>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Conecte-se com uma rede global de consciências através de sincronização quântica,
          alinhamento cardíaco e ressonância cerebral em tempo real
        </p>
        <div className="flex items-center justify-center gap-4">
          <Badge variant="outline" className="text-sm">
            <Wifi className="w-3 h-3 mr-1" />
            {nodes.filter(n => n.online).length} Nós Ativos
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Globe className="w-3 h-3 mr-1" />
            {new Set(nodes.map(n => n.location.country)).size} Países
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Activity className="w-3 h-3 mr-1" />
            {sessions.filter(s => s.status === 'active').length} Sessões Ativas
          </Badge>
        </div>
      </div>

      {/* Global Metrics */}
      {metrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Target className="h-5 w-5" />
                Coerência Global
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {formatCoherenceValue(metrics.global_coherence)}
              </div>
              <Progress value={metrics.global_coherence * 100} className="h-2 mt-2" />
              <div className="text-xs text-muted-foreground mt-2">
                Nível de sincronização global
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Radio className="h-5 w-5" />
                Ressonância Coletiva
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {formatCoherenceValue(metrics.collective_resonance)}
              </div>
              <Progress value={metrics.collective_resonance * 100} className="h-2 mt-2" />
              <div className="text-xs text-muted-foreground mt-2">
                Frequência média: {Math.round(metrics.average_vibration)} Hz
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Infinity className="h-5 w-5" />
                Campo Unificado
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {formatCoherenceValue(metrics.unified_field_strength)}
              </div>
              <Progress value={metrics.unified_field_strength * 100} className="h-2 mt-2" />
              <div className="text-xs text-muted-foreground mt-2">
                Força do campo consciencial unificado
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg">
                <GitBranch className="h-5 w-5" />
                Rede de Entrelaçamento
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                {formatCoherenceValue(metrics.entanglement_network)}
              </div>
              <Progress value={metrics.entanglement_network * 100} className="h-2 mt-2" />
              <div className="text-xs text-muted-foreground mt-2">
                Conexões quânticas estabelecidas
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Control Panel */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <RadioIcon className="h-5 w-5" />
              Painel de Controle
            </CardTitle>
            <CardDescription>
              Inicie e gerencie sessões de sincronização
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Modo de Sincronização:</label>
              <div className="grid grid-cols-2 gap-2">
                {(['heart', 'brain', 'consciousness', 'unified'] as const).map((mode) => (
                  <Button
                    key={mode}
                    variant={selectedMode === mode ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedMode(mode)}
                    className="flex items-center gap-1"
                  >
                    {getSyncModeIcon(mode)}
                    {mode === 'heart' ? 'Cardíaco' : 
                     mode === 'brain' ? 'Cerebral' : 
                     mode === 'consciousness' ? 'Consciencial' : 'Unificado'}
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Frequência (Hz):</label>
              <div className="grid grid-cols-3 gap-2">
                {[432, 528, 639, 741, 852, 963].map((freq) => (
                  <Button
                    key={freq}
                    variant={selectedFrequency === freq ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedFrequency(freq)}
                  >
                    {freq}
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Intenção:</label>
              <textarea
                placeholder="Digite sua intenção para a sincronização..."
                value={intention}
                onChange={(e) => setIntention(e.target.value)}
                className="w-full p-2 border rounded-md text-sm"
                rows={3}
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={isSynchronizing ? pauseSynchronization : startSynchronization}
                disabled={!intention.trim() && !isSynchronizing}
                className="flex-1"
              >
                {isSynchronizing ? (
                  <Pause className="h-4 w-4 mr-2" />
                ) : (
                  <Play className="h-4 w-4 mr-2" />
                )}
                {isSynchronizing ? 'Pausar' : 'Iniciar'}
              </Button>
              
              {isSynchronizing && (
                <Button onClick={resumeSynchronization} variant="outline">
                  <RefreshCw className="h-4 w-4" />
                </Button>
              )}
              
              {isSynchronizing && (
                <Button onClick={stopSynchronization} variant="outline">
                  <Square className="h-4 w-4" />
                </Button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="realtime"
                checked={realtimeData}
                onChange={(e) => setRealtimeData(e.target.checked)}
              />
              <label htmlFor="realtime" className="text-sm">
                Atualizações em tempo real
              </label>
            </div>
          </CardContent>
        </Card>

        {/* Active Session */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {activeSession ? (
                <>
                  {getSyncModeIcon(activeSession.sync_mode)}
                  {activeSession.name}
                </>
              ) : (
                <>
                  <Radio className="h-5 w-5" />
                  Sessão Ativa
                </>
              )}
            </CardTitle>
            <CardDescription>
              {activeSession ? activeSession.description : 'Nenhuma sessão ativa no momento'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {activeSession ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <div className="text-sm text-muted-foreground">Status</div>
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${getStatusColor(activeSession.status)}`} />
                      <span className="font-medium">
                        {activeSession.status === 'active' ? 'Ativa' :
                         activeSession.status === 'paused' ? 'Pausada' :
                         activeSession.status === 'completed' ? 'Concluída' : 'Preparando'}
                      </span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-sm text-muted-foreground">Frequência</div>
                    <div className="font-medium">{formatFrequency(activeSession.frequency)}</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-sm text-muted-foreground">Participantes</div>
                    <div className="font-medium">{activeSession.participants.length}</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-sm text-muted-foreground">Intenção:</div>
                  <div className="p-3 bg-muted rounded-lg text-sm">
                    {activeSession.intention}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Coerência Global</span>
                      <span>{formatCoherenceValue(activeSession.global_coherence)}</span>
                    </div>
                    <Progress value={activeSession.global_coherence * 100} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Ressonância Coletiva</span>
                      <span>{formatCoherenceValue(activeSession.collective_resonance)}</span>
                    </div>
                    <Progress value={activeSession.collective_resonance * 100} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Campo Unificado</span>
                      <span>{formatCoherenceValue(activeSession.unified_field_strength)}</span>
                    </div>
                    <Progress value={activeSession.unified_field_strength * 100} className="h-2" />
                  </div>
                </div>

                <div className="text-xs text-muted-foreground">
                  Iniciado: {new Date(activeSession.start_time).toLocaleString()}
                  {activeSession.end_time && ` • Concluído: ${new Date(activeSession.end_time).toLocaleString()}`}
                </div>
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-8">
                <Radio className="h-12 w-12 mx-auto mb-4" />
                <p>Inicie uma nova sessão de sincronização ou junte-se a uma existente</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Consciousness Nodes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Satellite className="h-5 w-5" />
            Nós de Consciência
          </CardTitle>
          <CardDescription>
            Rede global de participantes conectados em tempo real
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {nodes.map((node) => (
                <Card key={node.id} className="relative">
                  <div className={`absolute top-2 right-2 w-3 h-3 rounded-full ${node.online ? 'bg-green-500' : 'bg-gray-400'}`} />
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{node.name}</CardTitle>
                    <CardDescription className="text-xs">
                      {node.location.city}, {node.location.country}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <div className="text-muted-foreground">Consciência</div>
                        <div className="font-semibold">{formatCoherenceValue(node.consciousness_level)}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Frequência</div>
                        <div className="font-semibold">{formatFrequency(node.vibration_frequency)}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Coerência</div>
                        <div className="font-semibold">{formatCoherenceValue(node.coherence_score)}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Cardíaco</div>
                        <div className="font-semibold">{formatCoherenceValue(node.heart_coherence)}</div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Qualidade Sinc</span>
                        <span>{formatCoherenceValue(node.sync_quality)}</span>
                      </div>
                      <Progress value={node.sync_quality * 100} className="h-2" />
                    </div>

                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1">
                        <div className={`w-2 h-2 rounded-full ${getBrainWaveColor(node.brain_wave_state)}`} />
                        <span>{node.brain_wave_state.toUpperCase()}</span>
                      </div>
                      <div>{formatDistance(node.distance)}</div>
                      <div>{formatTimeAgo(node.last_sync)}</div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Available Sessions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Sessões Disponíveis
          </CardTitle>
          <CardDescription>
            Junte-se a sessões de sincronização ativas ao redor do mundo
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {sessions.filter(s => s.status === 'active' && s.id !== activeSession?.id).map((session) => (
              <Card key={session.id} className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      {getSyncModeIcon(session.sync_mode)}
                      <h3 className="font-semibold">{session.name}</h3>
                      <Badge variant="outline">{session.participants.length} participantes</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{session.description}</p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span>Frequência: {formatFrequency(session.frequency)}</span>
                      <span>Modo: {session.sync_mode}</span>
                      <span>Iniciado: {formatTimeAgo(session.start_time)}</span>
                    </div>
                  </div>
                  <Button 
                    onClick={() => joinSession(session.id)}
                    disabled={session.participants.includes('node_1')}
                    size="sm"
                  >
                    {session.participants.includes('node_1') ? 'Participando' : 'Juntar-se'}
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}