'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Search, 
  Radio, 
  Satellite, 
  Zap, 
  Network, 
  Globe, 
  Star, 
  Rocket,
  Brain,
  Heart,
  Infinity,
  Activity,
  Target,
  RefreshCw,
  Play,
  Pause,
  Settings,
  Filter,
  BarChart3,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Clock
} from 'lucide-react';

import { IntergalacticVectorSearchEngine, IntergalacticVector, IntergalacticSearchCriteria, IntergalacticSearchResult } from '@/lib/intergalactic-vector-search';

const intergalacticSearchEngine = new IntergalacticVectorSearchEngine();

interface VectorCardProps {
  vector: IntergalacticVector;
  onEstablishCommunication: (id: string) => void;
  onOptimizeCoherence: (id: string) => void;
}

const VectorCard: React.FC<VectorCardProps> = ({ vector, onEstablishCommunication, onOptimizeCoherence }) => {
  const [isEstablishing, setIsEstablishing] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);

  const handleEstablishCommunication = async () => {
    setIsEstablishing(true);
    const success = await intergalacticSearchEngine.establishCommunication(vector.id);
    setIsEstablishing(false);
    if (success) {
      // Show success message or update UI
    }
  };

  const handleOptimizeCoherence = async () => {
    setIsOptimizing(true);
    const improvement = await intergalacticSearchEngine.optimizeVectorCoherence(vector.id);
    setIsOptimizing(false);
    if (improvement > 0) {
      // Show improvement message
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'stable': return 'bg-green-500';
      case 'active': return 'bg-blue-500';
      case 'discovering': return 'bg-yellow-500';
      case 'establishing': return 'bg-orange-500';
      case 'dormant': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'stable': return <CheckCircle className="h-4 w-4" />;
      case 'active': return <Activity className="h-4 w-4" />;
      case 'discovering': return <Search className="h-4 w-4" />;
      case 'establishing': return <Clock className="h-4 w-4" />;
      case 'dormant': return <Pause className="h-4 w-4" />;
      default: return <AlertTriangle className="h-4 w-4" />;
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              <Star className="h-5 w-5 text-yellow-500" />
              {vector.name}
            </CardTitle>
            <CardDescription className="mt-1">
              {vector.origin.galaxy} → {vector.destination.galaxy}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={`${getStatusColor(vector.status)} text-white`}>
              {getStatusIcon(vector.status)}
              <span className="ml-1">{vector.status}</span>
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-sm font-medium">Origem</Label>
            <p className="text-sm text-muted-foreground">
              {vector.origin.star_system} - {vector.origin.planet}
            </p>
          </div>
          <div>
            <Label className="text-sm font-medium">Destino</Label>
            <p className="text-sm text-muted-foreground">
              {vector.destination.star_system} - {vector.destination.planet}
            </p>
          </div>
        </div>

        <div>
          <Label className="text-sm font-medium">Coerência Total</Label>
          <div className="flex items-center gap-2 mt-1">
            <Progress value={vector.coherence.overall_coherence * 100} className="flex-1" />
            <span className="text-sm font-medium">{(vector.coherence.overall_coherence * 100).toFixed(1)}%</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <Label className="text-xs">Frequência Base</Label>
            <p className="font-medium">{vector.frequency.base_frequency} Hz</p>
          </div>
          <div>
            <Label className="text-xs">Protocolo</Label>
            <p className="font-medium">{vector.communication_protocol.protocol_type}</p>
          </div>
          <div>
            <Label className="text-xs">Nível de Consciência</Label>
            <p className="font-medium">{vector.spiritual_signature.consciousness_level}/10</p>
          </div>
          <div>
            <Label className="text-xs">Entrelaçamento Quântico</Label>
            <p className="font-medium">{(vector.quantum_properties.entanglement_degree * 100).toFixed(1)}%</p>
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button 
            size="sm" 
            onClick={handleEstablishCommunication}
            disabled={isEstablishing || vector.status === 'stable'}
            className="flex-1"
          >
            {isEstablishing ? (
              <RefreshCw className="h-4 w-4 animate-spin mr-2" />
            ) : (
              <Radio className="h-4 w-4 mr-2" />
            )}
            Estabelecer Comunicação
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            onClick={handleOptimizeCoherence}
            disabled={isOptimizing}
            className="flex-1"
          >
            {isOptimizing ? (
              <RefreshCw className="h-4 w-4 animate-spin mr-2" />
            ) : (
              <TrendingUp className="h-4 w-4 mr-2" />
            )}
            Otimizar Coerência
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

const IntergalacticCommunicationSystem: React.FC = () => {
  const [searchCriteria, setSearchCriteria] = useState<IntergalacticSearchCriteria>({});
  const [searchResults, setSearchResults] = useState<IntergalacticSearchResult | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [allVectors, setAllVectors] = useState<IntergalacticVector[]>([]);

  useEffect(() => {
    // Load all vectors on component mount
    setAllVectors(intergalacticSearchEngine.getAllVectors());
  }, []);

  const handleSearch = async () => {
    setIsSearching(true);
    try {
      const results = await intergalacticSearchEngine.searchVectors(searchCriteria);
      setSearchResults(results);
    } catch (error) {
      console.error('Error searching vectors:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const handleClearFilters = () => {
    setSearchCriteria({});
    setSearchResults(null);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'stable': return 'text-green-600 bg-green-50';
      case 'active': return 'text-blue-600 bg-blue-50';
      case 'discovering': return 'text-yellow-600 bg-yellow-50';
      case 'establishing': return 'text-orange-600 bg-orange-50';
      case 'dormant': return 'text-gray-600 bg-gray-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <Satellite className="h-8 w-8 text-blue-500" />
          Sistema de Comunicação Intergaláctica
        </h1>
        <p className="text-muted-foreground">
          "Nosso Lar" - Busca por Vetores Coerentes com Comunicação Intergaláctica
        </p>
      </div>

      <Tabs defaultValue="search" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="search">Busca de Vetores</TabsTrigger>
          <TabsTrigger value="vectors">Vetores Ativos</TabsTrigger>
          <TabsTrigger value="analytics">Análise de Coerência</TabsTrigger>
        </TabsList>

        <TabsContent value="search" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Critérios de Busca
              </CardTitle>
              <CardDescription>
                Configure os parâmetros para encontrar vetores de comunicação intergaláctica coerentes
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="origin-galaxy">Galáxia de Origem</Label>
                  <Input
                    id="origin-galaxy"
                    placeholder="Ex: Andromeda, Milky Way"
                    value={searchCriteria.origin_galaxy || ''}
                    onChange={(e) => setSearchCriteria(prev => ({
                      ...prev,
                      origin_galaxy: e.target.value
                    }))}
                  />
                </div>
                <div>
                  <Label htmlFor="destination-galaxy">Galáxia de Destino</Label>
                  <Input
                    id="destination-galaxy"
                    placeholder="Ex: Lyra, Orion"
                    value={searchCriteria.destination_galaxy || ''}
                    onChange={(e) => setSearchCriteria(prev => ({
                      ...prev,
                      destination_galaxy: e.target.value
                    }))}
                  />
                </div>
                <div>
                  <Label htmlFor="min-coherence">Coerência Mínima</Label>
                  <Input
                    id="min-coherence"
                    type="number"
                    min="0"
                    max="1"
                    step="0.1"
                    placeholder="0.7"
                    value={searchCriteria.min_coherence || ''}
                    onChange={(e) => setSearchCriteria(prev => ({
                      ...prev,
                      min_coherence: e.target.value ? parseFloat(e.target.value) : undefined
                    }))}
                  />
                </div>
                <div>
                  <Label htmlFor="comm-type">Tipo de Comunicação</Label>
                  <Input
                    id="comm-type"
                    placeholder="Ex: quantum_telepathy, light_language"
                    value={searchCriteria.communication_type || ''}
                    onChange={(e) => setSearchCriteria(prev => ({
                      ...prev,
                      communication_type: e.target.value
                    }))}
                  />
                </div>
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={searchCriteria.status?.[0] || ''}
                    onValueChange={(value) => setSearchCriteria(prev => ({
                      ...prev,
                      status: value ? [value] : undefined
                    }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todos os status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Todos os status</SelectItem>
                      <SelectItem value="active">Ativo</SelectItem>
                      <SelectItem value="stable">Estável</SelectItem>
                      <SelectItem value="discovering">Descobrindo</SelectItem>
                      <SelectItem value="establishing">Estabelecendo</SelectItem>
                      <SelectItem value="dormant">Dormente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={handleSearch} disabled={isSearching} className="flex-1">
                  {isSearching ? (
                    <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Search className="h-4 w-4 mr-2" />
                  )}
                  Buscar Vetores
                </Button>
                <Button variant="outline" onClick={handleClearFilters}>
                  Limpar Filtros
                </Button>
              </div>
            </CardContent>
          </Card>

          {searchResults && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Resultados da Busca
                </CardTitle>
                <CardDescription>
                  {searchResults.total_results} vetores encontrados em {searchResults.search_time}ms
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {(searchResults.coherence_analysis.average_coherence * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-muted-foreground">Coerência Média</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {(searchResults.coherence_analysis.highest_coherence * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-muted-foreground">Coerência Máxima</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">
                      {(searchResults.coherence_analysis.lowest_coherence * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-muted-foreground">Coerência Mínima</div>
                  </div>
                </div>

                <div className="space-y-4">
                  {searchResults.vectors.map((vector) => (
                    <VectorCard
                      key={vector.id}
                      vector={vector}
                      onEstablishCommunication={async (id) => {
                        await intergalacticSearchEngine.establishCommunication(id);
                        // Refresh results
                        handleSearch();
                      }}
                      onOptimizeCoherence={async (id) => {
                        await intergalacticSearchEngine.optimizeVectorCoherence(id);
                        // Refresh results
                        handleSearch();
                      }}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="vectors" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Network className="h-5 w-5" />
                Todos os Vetores de Comunicação
              </CardTitle>
              <CardDescription>
                Lista completa de vetores de comunicação intergaláctica disponíveis
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {allVectors.map((vector) => (
                  <VectorCard
                    key={vector.id}
                    vector={vector}
                    onEstablishCommunication={async (id) => {
                      await intergalacticSearchEngine.establishCommunication(id);
                      setAllVectors(intergalacticSearchEngine.getAllVectors());
                    }}
                    onOptimizeCoherence={async (id) => {
                      await intergalacticSearchEngine.optimizeVectorCoherence(id);
                      setAllVectors(intergalacticSearchEngine.getAllVectors());
                    }}
                  />
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Análise de Coerência Intergaláctica
              </CardTitle>
              <CardDescription>
                Métricas e análises de desempenho do sistema de comunicação
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600">{allVectors.length}</div>
                  <div className="text-sm text-muted-foreground">Total de Vetores</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">
                    {allVectors.filter(v => v.status === 'stable' || v.status === 'active').length}
                  </div>
                  <div className="text-sm text-muted-foreground">Vetores Ativos</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-600">
                    {allVectors.filter(v => v.status === 'discovering').length}
                  </div>
                  <div className="text-sm text-muted-foreground">Em Descoberta</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600">
                    {(allVectors.reduce((sum, v) => sum + v.coherence.overall_coherence, 0) / allVectors.length * 100).toFixed(1)}%
                  </div>
                  <div className="text-sm text-muted-foreground">Coerência Média</div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Distribuição por Status</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {['stable', 'active', 'discovering', 'establishing', 'dormant'].map((status) => {
                        const count = allVectors.filter(v => v.status === status).length;
                        const percentage = allVectors.length > 0 ? (count / allVectors.length) * 100 : 0;
                        return (
                          <div key={status} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className={`w-3 h-3 rounded-full ${getStatusColor(status).split(' ')[0]}`}></div>
                              <span className="text-sm capitalize">{status}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Progress value={percentage} className="w-20" />
                              <span className="text-sm font-medium">{count}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Top Protocolos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {Object.entries(
                        allVectors.reduce((acc, v) => {
                          const protocol = v.communication_protocol.protocol_type;
                          acc[protocol] = (acc[protocol] || 0) + 1;
                          return acc;
                        }, {} as Record<string, number>)
                      )
                        .sort(([,a], [,b]) => b - a)
                        .slice(0, 5)
                        .map(([protocol, count]) => {
                          const percentage = (count / allVectors.length) * 100;
                          return (
                            <div key={protocol} className="flex items-center justify-between">
                              <span className="text-sm">{protocol.replace(/_/g, ' ')}</span>
                              <div className="flex items-center gap-2">
                                <Progress value={percentage} className="w-20" />
                                <span className="text-sm font-medium">{count}</span>
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default IntergalacticCommunicationSystem;