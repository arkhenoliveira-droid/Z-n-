'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Eye, 
  Lightbulb, 
  TrendingUp, 
  RefreshCw, 
  Play, 
  Pause, 
  BarChart3, 
  Target,
  Zap,
  Brain,
  Radio,
  Activity,
  Clock,
  CheckCircle,
  AlertCircle,
  XCircle,
  Search,
  Filter,
  Download,
  Trash2,
  Wifi,
  WifiOff
} from 'lucide-react';
import useInvestigationSocket from '@/hooks/useInvestigationSocket';
import InvestigationAnalytics from '@/components/investigation-analytics';

interface Investigation {
  id: string;
  title: string;
  description?: string;
  type: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  parameters?: any;
  results?: any;
  insightsData?: any[];
  coherenceScore?: number;
  confidenceLevel?: number;
  createdAt: string;
  updatedAt: string;
  insightObjects?: InvestigationInsight[];
}

interface InvestigationInsight {
  id: string;
  type: string;
  title: string;
  description: string;
  data?: any;
  relevanceScore?: number;
  confidence?: number;
  createdAt: string;
}

interface RealityPattern {
  id: string;
  name: string;
  description?: string;
  patternType: string;
  frequency?: number;
  amplitude?: number;
  phase?: number;
  coherence?: number;
  stability?: number;
  metadata?: any;
  discoveredAt: string;
  lastObserved: string;
}

interface InvestigationToolsProps {
  onInvestigationComplete?: (results: any) => void;
}

export default function InvestigationTools({ onInvestigationComplete }: InvestigationToolsProps) {
  const [investigations, setInvestigations] = useState<Investigation[]>([]);
  const [patterns, setPatterns] = useState<RealityPattern[]>([]);
  const [selectedInvestigation, setSelectedInvestigation] = useState<Investigation | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [realtimeProgress, setRealtimeProgress] = useState<{[key: string]: number}>({});
  const [realtimeMessages, setRealtimeMessages] = useState<{[key: string]: string}>({});
  
  // Form state
  const [newInvestigation, setNewInvestigation] = useState({
    title: '',
    description: '',
    type: 'reality_coherence',
    parameters: '{}'
  });

  // Filter state
  const [filters, setFilters] = useState({
    type: '',
    status: '',
    minCoherence: ''
  });

  // Real-time socket connection
  const { isConnected, joinInvestigation, leaveInvestigation, lastMessage } = useInvestigationSocket({
    onInvestigationUpdate: (update) => {
      if (update.investigationId) {
        // Update investigation in real-time
        setInvestigations(prev => prev.map(inv => 
          inv.id === update.investigationId ? { ...inv, ...update } : inv
        ));
      }
    },
    onInvestigationProgress: (progress, message) => {
      if (selectedInvestigation) {
        setRealtimeProgress(prev => ({ ...prev, [selectedInvestigation.id]: progress }));
        setRealtimeMessages(prev => ({ ...prev, [selectedInvestigation.id]: message }));
      }
    },
    onInvestigationComplete: (results) => {
      if (selectedInvestigation) {
        loadInvestigations(); // Refresh the list
        onInvestigationComplete?.(results);
      }
    },
    onInvestigationError: (error) => {
      console.error('Investigation error:', error);
      if (selectedInvestigation) {
        setRealtimeMessages(prev => ({ ...prev, [selectedInvestigation.id]: error }));
      }
    }
  });

  useEffect(() => {
    loadInvestigations();
    loadPatterns();
  }, []);

  useEffect(() => {
    if (selectedInvestigation) {
      joinInvestigation(selectedInvestigation.id);
      return () => {
        leaveInvestigation(selectedInvestigation.id);
      };
    }
  }, [selectedInvestigation, joinInvestigation, leaveInvestigation]);

  const loadInvestigations = async () => {
    try {
      const params = new URLSearchParams();
      if (filters.type) params.append('type', filters.type);
      if (filters.status) params.append('status', filters.status);
      
      const response = await fetch(`/api/investigations?${params}`);
      if (response.ok) {
        const data = await response.json();
        setInvestigations(data);
      }
    } catch (error) {
      console.error('Error loading investigations:', error);
    }
  };

  const loadPatterns = async () => {
    try {
      const params = new URLSearchParams();
      if (filters.type) params.append('type', filters.type);
      if (filters.minCoherence) params.append('minCoherence', filters.minCoherence);
      
      const response = await fetch(`/api/reality-patterns?${params}`);
      if (response.ok) {
        const data = await response.json();
        setPatterns(data);
      }
    } catch (error) {
      console.error('Error loading patterns:', error);
    }
  };

  const createInvestigation = async () => {
    if (!newInvestigation.title.trim()) return;

    setIsCreating(true);
    try {
      const parameters = JSON.parse(newInvestigation.parameters);
      const response = await fetch('/api/investigations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newInvestigation.title,
          description: newInvestigation.description,
          type: newInvestigation.type,
          parameters
        })
      });

      if (response.ok) {
        const data = await response.json();
        setNewInvestigation({
          title: '',
          description: '',
          type: 'reality_coherence',
          parameters: '{}'
        });
        loadInvestigations();
      }
    } catch (error) {
      console.error('Error creating investigation:', error);
    } finally {
      setIsCreating(false);
    }
  };

  const deleteInvestigation = async (id: string) => {
    try {
      const response = await fetch(`/api/investigations/${id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        loadInvestigations();
        if (selectedInvestigation?.id === id) {
          setSelectedInvestigation(null);
        }
      }
    } catch (error) {
      console.error('Error deleting investigation:', error);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'in_progress':
        return <RefreshCw className="w-4 h-4 text-blue-500 animate-spin" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <AlertCircle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'in_progress':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'failed':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'reality_coherence':
        return <Brain className="w-4 h-4" />;
      case 'pattern_analysis':
        return <BarChart3 className="w-4 h-4" />;
      case 'quantum_investigation':
        return <Zap className="w-4 h-4" />;
      default:
        return <Search className="w-4 h-4" />;
    }
  };

  const getCoherenceColor = (score: number) => {
    if (score >= 0.8) return 'text-green-600';
    if (score >= 0.6) return 'text-yellow-600';
    return 'text-red-600';
  };

  const exportInvestigationData = (investigation: Investigation) => {
    const data = {
      investigation: {
        title: investigation.title,
        description: investigation.description,
        type: investigation.type,
        status: investigation.status,
        coherenceScore: investigation.coherenceScore,
        confidenceLevel: investigation.confidenceLevel,
        createdAt: investigation.createdAt,
        updatedAt: investigation.updatedAt
      },
      results: investigation.results,
      insights: investigation.insightsData,
      parameters: investigation.parameters
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `investigation_${investigation.id}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Eye className="w-5 h-5 mr-2 text-blue-600" />
            Investigation Tools
          </CardTitle>
          <CardDescription>Advanced reality coherence analysis and pattern investigation</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              {isConnected ? (
                <><Wifi className="w-4 h-4 text-green-500" /><span className="text-sm text-green-600">Real-time connected</span></>
              ) : (
                <><WifiOff className="w-4 h-4 text-red-500" /><span className="text-sm text-red-600">Real-time disconnected</span></>
              )}
            </div>
          </div>
          <Tabs defaultValue="investigations" className="space-y-4">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="investigations">Investigations</TabsTrigger>
              <TabsTrigger value="create">Create New</TabsTrigger>
              <TabsTrigger value="patterns">Reality Patterns</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            {/* Investigations Tab */}
            <TabsContent value="investigations" className="space-y-4">
              {/* Filters */}
              <div className="flex flex-wrap gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4" />
                  <span className="text-sm font-medium">Filters:</span>
                </div>
                <Select value={filters.type} onValueChange={(value) => setFilters({...filters, type: value})}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Types</SelectItem>
                    <SelectItem value="reality_coherence">Reality Coherence</SelectItem>
                    <SelectItem value="pattern_analysis">Pattern Analysis</SelectItem>
                    <SelectItem value="quantum_investigation">Quantum Investigation</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={filters.status} onValueChange={(value) => setFilters({...filters, status: value})}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={loadInvestigations} size="sm">
                  <RefreshCw className="w-4 h-4 mr-1" />
                  Apply
                </Button>
              </div>

              {/* Investigations List */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
                {investigations.map((investigation) => (
                  <Card key={investigation.id} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {getTypeIcon(investigation.type)}
                          <CardTitle className="text-sm">{investigation.title}</CardTitle>
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(investigation.status)}
                          <Badge variant="outline" className={getStatusColor(investigation.status)}>
                            {investigation.status.replace('_', ' ')}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <CardDescription className="text-xs mb-2">
                        {investigation.description || 'No description'}
                      </CardDescription>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{new Date(investigation.createdAt).toLocaleDateString()}</span>
                        <div className="flex items-center gap-2">
                          {investigation.coherenceScore && (
                            <span className={getCoherenceColor(investigation.coherenceScore)}>
                              {(investigation.coherenceScore * 100).toFixed(0)}%
                            </span>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setSelectedInvestigation(investigation)}
                          >
                            <Eye className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => exportInvestigationData(investigation)}
                          >
                            <Download className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => deleteInvestigation(investigation.id)}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Selected Investigation Details */}
              {selectedInvestigation && (
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2">
                        {getTypeIcon(selectedInvestigation.type)}
                        {selectedInvestigation.title}
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(selectedInvestigation.status)}
                        <Badge className={getStatusColor(selectedInvestigation.status)}>
                          {selectedInvestigation.status.replace('_', ' ')}
                        </Badge>
                      </div>
                    </div>
                    <CardDescription>{selectedInvestigation.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Real-time Progress */}
                    {selectedInvestigation.status === 'in_progress' && (
                      <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-blue-800">Real-time Progress</span>
                          <Badge className="bg-blue-100 text-blue-800 border-blue-300">
                            Live
                          </Badge>
                        </div>
                        {realtimeProgress[selectedInvestigation.id] !== undefined && (
                          <div className="mb-2">
                            <Progress value={realtimeProgress[selectedInvestigation.id]} className="h-2" />
                            <div className="text-xs text-blue-600 mt-1">
                              {realtimeProgress[selectedInvestigation.id].toFixed(0)}% Complete
                            </div>
                          </div>
                        )}
                        {realtimeMessages[selectedInvestigation.id] && (
                          <div className="text-xs text-blue-700 bg-blue-100 p-2 rounded">
                            {realtimeMessages[selectedInvestigation.id]}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Metrics */}
                    <div className="grid grid-cols-2 gap-4">
                      {selectedInvestigation.coherenceScore && (
                        <div>
                          <Label className="text-xs">Coherence Score</Label>
                          <div className="flex items-center gap-2">
                            <Progress value={selectedInvestigation.coherenceScore * 100} className="flex-1" />
                            <span className={`text-sm font-medium ${getCoherenceColor(selectedInvestigation.coherenceScore)}`}>
                              {(selectedInvestigation.coherenceScore * 100).toFixed(0)}%
                            </span>
                          </div>
                        </div>
                      )}
                      {selectedInvestigation.confidenceLevel && (
                        <div>
                          <Label className="text-xs">Confidence Level</Label>
                          <div className="flex items-center gap-2">
                            <Progress value={selectedInvestigation.confidenceLevel * 100} className="flex-1" />
                            <span className="text-sm font-medium text-blue-600">
                              {(selectedInvestigation.confidenceLevel * 100).toFixed(0)}%
                            </span>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Results */}
                    {selectedInvestigation.results && (
                      <div>
                        <Label className="text-sm font-medium">Results</Label>
                        <div className="mt-2 p-3 bg-gray-50 rounded-md max-h-32 overflow-y-auto">
                          <pre className="text-xs whitespace-pre-wrap">
                            {JSON.stringify(selectedInvestigation.results, null, 2)}
                          </pre>
                        </div>
                      </div>
                    )}

                    {/* Insights */}
                    {selectedInvestigation.insightObjects && selectedInvestigation.insightObjects.length > 0 && (
                      <div>
                        <Label className="text-sm font-medium">Insights</Label>
                        <div className="mt-2 space-y-2 max-h-40 overflow-y-auto">
                          {selectedInvestigation.insightObjects.map((insight) => (
                            <div key={insight.id} className="p-2 bg-blue-50 rounded-md">
                              <div className="flex items-center justify-between">
                                <span className="text-sm font-medium">{insight.title}</span>
                                <Badge variant="outline" className="text-xs">
                                  {insight.type.replace('_', ' ')}
                                </Badge>
                              </div>
                              <p className="text-xs text-gray-600 mt-1">{insight.description}</p>
                              {insight.relevanceScore && (
                                <div className="flex items-center gap-2 mt-1">
                                  <span className="text-xs">Relevance:</span>
                                  <Progress value={insight.relevanceScore * 100} className="flex-1 h-1" />
                                  <span className="text-xs">{(insight.relevanceScore * 100).toFixed(0)}%</span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Create New Investigation Tab */}
            <TabsContent value="create" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>New Investigation</CardTitle>
                    <CardDescription>Create a new reality coherence investigation</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="title">Title</Label>
                      <Input
                        id="title"
                        value={newInvestigation.title}
                        onChange={(e) => setNewInvestigation({...newInvestigation, title: e.target.value})}
                        placeholder="Enter investigation title"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={newInvestigation.description}
                        onChange={(e) => setNewInvestigation({...newInvestigation, description: e.target.value})}
                        placeholder="Describe the investigation objectives"
                        rows={3}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="type">Investigation Type</Label>
                      <Select value={newInvestigation.type} onValueChange={(value) => setNewInvestigation({...newInvestigation, type: value})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="reality_coherence">Reality Coherence Analysis</SelectItem>
                          <SelectItem value="pattern_analysis">Pattern Analysis</SelectItem>
                          <SelectItem value="quantum_investigation">Quantum Investigation</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="parameters">Parameters (JSON)</Label>
                      <Textarea
                        id="parameters"
                        value={newInvestigation.parameters}
                        onChange={(e) => setNewInvestigation({...newInvestigation, parameters: e.target.value})}
                        placeholder='{"key": "value"}'
                        rows={4}
                      />
                    </div>
                    
                    <Button 
                      onClick={createInvestigation} 
                      disabled={isCreating || !newInvestigation.title.trim()}
                      className="w-full"
                    >
                      {isCreating ? (
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Play className="w-4 h-4 mr-2" />
                      )}
                      {isCreating ? 'Creating...' : 'Start Investigation'}
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Investigation Types</CardTitle>
                    <CardDescription>Learn about different investigation types</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Brain className="w-4 h-4 text-blue-600" />
                        <span className="font-medium">Reality Coherence</span>
                      </div>
                      <p className="text-sm text-gray-600">
                        Analyzes coherence patterns across reality dimensions, quantum correlations, and consciousness alignment.
                      </p>
                    </div>
                    
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <BarChart3 className="w-4 h-4 text-green-600" />
                        <span className="font-medium">Pattern Analysis</span>
                      </div>
                      <p className="text-sm text-gray-600">
                        Examines complex patterns, frequency analysis, temporal correlations, and emergent properties.
                      </p>
                    </div>
                    
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Zap className="w-4 h-4 text-purple-600" />
                        <span className="font-medium">Quantum Investigation</span>
                      </div>
                      <p className="text-sm text-gray-600">
                        Investigates quantum coherence, entanglement, superposition states, and field interactions.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Reality Patterns Tab */}
            <TabsContent value="patterns" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
                {patterns.map((pattern) => (
                  <Card key={pattern.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-sm">{pattern.name}</CardTitle>
                        <Badge variant="outline">{pattern.patternType}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <CardDescription className="text-xs mb-2">
                        {pattern.description || 'No description'}
                      </CardDescription>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        {pattern.frequency && (
                          <div>
                            <span className="text-gray-500">Frequency:</span>
                            <span className="ml-1">{pattern.frequency.toFixed(2)}</span>
                          </div>
                        )}
                        {pattern.amplitude && (
                          <div>
                            <span className="text-gray-500">Amplitude:</span>
                            <span className="ml-1">{pattern.amplitude.toFixed(2)}</span>
                          </div>
                        )}
                        {pattern.coherence && (
                          <div>
                            <span className="text-gray-500">Coherence:</span>
                            <span className={`ml-1 ${getCoherenceColor(pattern.coherence)}`}>
                              {(pattern.coherence * 100).toFixed(0)}%
                            </span>
                          </div>
                        )}
                        {pattern.stability && (
                          <div>
                            <span className="text-gray-500">Stability:</span>
                            <span className="ml-1">{(pattern.stability * 100).toFixed(0)}%</span>
                          </div>
                        )}
                      </div>
                      <div className="mt-2 text-xs text-gray-500">
                        Discovered: {new Date(pattern.discoveredAt).toLocaleDateString()}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics" className="space-y-4">
              <InvestigationAnalytics investigations={investigations} patterns={patterns} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}