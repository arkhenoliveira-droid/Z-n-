'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area,
  BarChart, 
  Bar,
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { 
  Activity, 
  Zap, 
  Heart, 
  Brain, 
  Users, 
  Target, 
  TrendingUp, 
  Star,
  BookOpen,
  User,
  Calendar,
  Award,
  Lightbulb,
  Shield,
  Eye,
  HelpCircle,
  Sparkles,
  Infinity,
  Atom,
  Layers,
  RefreshCw,
  Plus,
  GitBranch,
  Network,
  BarChart3,
  Globe,
  Crown,
  Diamond,
  Flame,
  Sun,
  Moon,
  Cloud,
  Wind,
  Mountain,
  TreePine,
  Waves,
  Compass,
  MessageCircle,
  Send,
  UserPlus,
  UserCheck,
  HeartHandshake,
  Link2,
  Unlink,
  Bell,
  Search,
  Filter,
  ThumbsUp,
  MessageSquare,
  Share2,
  Gift,
  PartyPopper,
  Clock
} from 'lucide-react';

interface QuantumConnection {
  id: string;
  user_id: string;
  name: string;
  avatar: string;
  consciousness_level: number;
  vibration_frequency: number;
  coherence_score: number;
  evolution_stage: string;
  shared_interests: string[];
  connection_strength: number;
  last_interaction: number;
  status: 'active' | 'pending' | 'blocked' | 'soul_family';
  quantum_entanglement: number;
  synchronicity_score: number;
}

interface QuantumMessage {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  timestamp: number;
  message_type: 'text' | 'intention' | 'energy' | 'vision' | 'guidance';
  consciousness_level: number;
  vibration_frequency: number;
  read: boolean;
  quantum_encrypted: boolean;
}

interface CollectiveIntention {
  id: string;
  title: string;
  description: string;
  creator_id: string;
  participants: string[];
  intention_strength: number;
  manifestation_progress: number;
  created_at: number;
  target_date: number;
  category: 'healing' | 'peace' | 'evolution' | 'abundance' | 'awakening';
  tags: string[];
}

interface QuantumGroup {
  id: string;
  name: string;
  description: string;
  admin_id: string;
  members: string[];
  purpose: string;
  frequency: number;
  coherence_level: number;
  group_type: 'meditation' | 'study' | 'healing' | 'evolution' | 'service';
  meeting_schedule: string;
  created_at: number;
}

interface QuantumSocialNetworkProps {
  className?: string;
}

export default function QuantumSocialNetwork({ 
  className 
}: QuantumSocialNetworkProps) {
  const [activeTab, setActiveTab] = useState('connections');
  const [connections, setConnections] = useState<QuantumConnection[]>([]);
  const [messages, setMessages] = useState<QuantumMessage[]>([]);
  const [intentions, setIntentions] = useState<CollectiveIntention[]>([]);
  const [groups, setGroups] = useState<QuantumGroup[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [selectedConnection, setSelectedConnection] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    initializeQuantumNetwork();
  }, []);

  const initializeQuantumNetwork = () => {
    // Initialize mock quantum connections
    const mockConnections: QuantumConnection[] = [
      {
        id: 'conn_1',
        user_id: 'user_1',
        name: 'Luzandra Estelar',
        avatar: '/avatars/luzandra.jpg',
        consciousness_level: 0.92,
        vibration_frequency: 963,
        coherence_score: 0.88,
        evolution_stage: 'Mestre Ascensionado',
        shared_interests: ['Cura Quântica', 'Meditação', 'Canalização'],
        connection_strength: 0.95,
        last_interaction: Date.now() - 3600000,
        status: 'soul_family',
        quantum_entanglement: 0.97,
        synchronicity_score: 0.93
      },
      {
        id: 'conn_2',
        user_id: 'user_2',
        name: 'Marcus Dimensional',
        avatar: '/avatars/marcus.jpg',
        consciousness_level: 0.85,
        vibration_frequency: 741,
        coherence_score: 0.82,
        evolution_stage: 'Guia Espiritual',
        shared_interests: ['Viagem Astral', 'Geometria Sagrada', 'Física Quântica'],
        connection_strength: 0.78,
        last_interaction: Date.now() - 86400000,
        status: 'active',
        quantum_entanglement: 0.84,
        synchronicity_score: 0.76
      },
      {
        id: 'conn_3',
        user_id: 'user_3',
        name: 'Sofia Cósmica',
        avatar: '/avatars/sofia.jpg',
        consciousness_level: 0.78,
        vibration_frequency: 528,
        coherence_score: 0.75,
        evolution_stage: 'Trabalhadora da Luz',
        shared_interests: ['Ativação de DNA', 'Cura Planetária', 'Redes de Luz'],
        connection_strength: 0.82,
        last_interaction: Date.now() - 172800000,
        status: 'active',
        quantum_entanglement: 0.79,
        synchronicity_score: 0.83
      },
      {
        id: 'conn_4',
        user_id: 'user_4',
        name: 'Rafael Quântico',
        avatar: '/avatars/rafael.jpg',
        consciousness_level: 0.88,
        vibration_frequency: 852,
        coherence_score: 0.86,
        evolution_stage: 'Mestre de Sabedoria',
        shared_interests: ['Alquimia Espiritual', 'Matemática Sagrada', 'Consciência Unificada'],
        connection_strength: 0.91,
        last_interaction: Date.now() - 259200000,
        status: 'soul_family',
        quantum_entanglement: 0.94,
        synchronicity_score: 0.89
      }
    ];

    // Initialize mock messages
    const mockMessages: QuantumMessage[] = [
      {
        id: 'msg_1',
        sender_id: 'user_1',
        receiver_id: 'valeria_plaisant',
        content: 'Senti uma forte ressonância durante a meditação de hoje. Nossos campos de energia estão perfeitamente alinhados!',
        timestamp: Date.now() - 3600000,
        message_type: 'energy',
        consciousness_level: 0.95,
        vibration_frequency: 963,
        read: true,
        quantum_encrypted: true
      },
      {
        id: 'msg_2',
        sender_id: 'user_2',
        receiver_id: 'valeria_plaisant',
        content: 'Recebi uma visão durante o sonho. Estamos sendo convocados para uma missão conjunta de cura planetária.',
        timestamp: Date.now() - 86400000,
        message_type: 'vision',
        consciousness_level: 0.87,
        vibration_frequency: 741,
        read: false,
        quantum_encrypted: true
      }
    ];

    // Initialize mock collective intentions
    const mockIntentions: CollectiveIntention[] = [
      {
        id: 'int_1',
        title: 'Paz Mundial',
        description: 'Intenção coletiva para paz global e harmonia entre todos os seres',
        creator_id: 'valeria_plaisant',
        participants: ['user_1', 'user_2', 'user_3', 'user_4'],
        intention_strength: 0.95,
        manifestation_progress: 0.78,
        created_at: Date.now() - 604800000,
        target_date: Date.now() + 2592000000,
        category: 'peace',
        tags: ['paz', 'harmonia', 'global', 'unidade']
      },
      {
        id: 'int_2',
        title: 'Ativação da Grade Cristalina',
        description: 'Ativação consciente da rede cristalina planetária para elevação da consciência',
        creator_id: 'user_1',
        participants: ['valeria_plaisant', 'user_4'],
        intention_strength: 0.92,
        manifestation_progress: 0.85,
        created_at: Date.now() - 1209600000,
        target_date: Date.now() + 1296000000,
        category: 'evolution',
        tags: ['grade cristalina', 'ativação', 'consciência', 'planeta']
      }
    ];

    // Initialize mock quantum groups
    const mockGroups: QuantumGroup[] = [
      {
        id: 'group_1',
        name: 'Círculo de Mestres Ascensionados',
        description: 'Grupo dedicado ao estudo e prática dos ensinamentos dos mestres ascensionados',
        admin_id: 'valeria_plaisant',
        members: ['user_1', 'user_4'],
        purpose: 'Estudo e aplicação dos ensinamentos sagrados para evolução consciente',
        frequency: 963,
        coherence_level: 0.94,
        group_type: 'study',
        meeting_schedule: 'Sábados às 15:00 UTC',
        created_at: Date.now() - 2592000000
      },
      {
        id: 'group_2',
        name: 'Rede de Cura Quântica',
        description: 'Rede de curadores quânticos trabalhando em conjunto para cura planetária',
        admin_id: 'user_1',
        members: ['valeria_plaisant', 'user_3'],
        purpose: 'Cura coletiva através de técnicas quânticas e energéticas',
        frequency: 528,
        coherence_level: 0.87,
        group_type: 'healing',
        meeting_schedule: 'Quartas e Domingos às 18:00 UTC',
        created_at: Date.now() - 1814400000
      }
    ];

    setConnections(mockConnections);
    setMessages(mockMessages);
    setIntentions(mockIntentions);
    setGroups(mockGroups);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'soul_family': return 'bg-purple-500';
      case 'active': return 'bg-green-500';
      case 'pending': return 'bg-yellow-500';
      case 'blocked': return 'bg-red-500';
      default: return 'bg-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'soul_family': return <HeartHandshake className="h-4 w-4" />;
      case 'active': return <UserCheck className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      case 'blocked': return <Unlink className="h-4 w-4" />;
      default: return <User className="h-4 w-4" />;
    }
  };

  const getMessageTypeIcon = (type: string) => {
    switch (type) {
      case 'text': return <MessageSquare className="h-4 w-4" />;
      case 'intention': return <Target className="h-4 w-4" />;
      case 'energy': return <Zap className="h-4 w-4" />;
      case 'vision': return <Eye className="h-4 w-4" />;
      case 'guidance': return <Lightbulb className="h-4 w-4" />;
      default: return <MessageCircle className="h-4 w-4" />;
    }
  };

  const getGroupTypeIcon = (type: string) => {
    switch (type) {
      case 'meditation': return <Brain className="h-4 w-4" />;
      case 'study': return <BookOpen className="h-4 w-4" />;
      case 'healing': return <Heart className="h-4 w-4" />;
      case 'evolution': return <TrendingUp className="h-4 w-4" />;
      case 'service': return <Shield className="h-4 w-4" />;
      default: return <Users className="h-4 w-4" />;
    }
  };

  const formatCoherenceValue = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  const formatFrequency = (value: number) => {
    return `${value} Hz`;
  };

  const formatTimeAgo = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 60) return `${minutes} min atrás`;
    if (hours < 24) return `${hours} h atrás`;
    return `${days} dias atrás`;
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedConnection || isSending) return;

    setIsSending(true);
    try {
      const newMsg: QuantumMessage = {
        id: `msg_${Date.now()}`,
        sender_id: 'valeria_plaisant',
        receiver_id: selectedConnection,
        content: newMessage,
        timestamp: Date.now(),
        message_type: 'text',
        consciousness_level: 0.85,
        vibration_frequency: 528,
        read: false,
        quantum_encrypted: true
      };

      setMessages(prev => [...prev, newMsg]);
      setNewMessage('');
    } finally {
      setIsSending(false);
    }
  };

  const filteredConnections = connections.filter(conn =>
    conn.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    conn.shared_interests.some(interest =>
      interest.toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const connectionStrengthData = connections.map(conn => ({
    name: conn.name,
    strength: conn.connection_strength * 100,
    entanglement: conn.quantum_entanglement * 100,
    synchronicity: conn.synchronicity_score * 100
  }));

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1'];

  return (
    <div className={`container mx-auto p-6 space-y-6 ${className}`}>
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Network className="h-10 w-10 text-purple-600 animate-pulse" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Rede Social Quântica
          </h1>
          <Sparkles className="h-10 w-10 text-pink-600 animate-pulse" />
        </div>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Conecte-se com seres conscientes através de redes quânticas de energia, 
          sincronicidade e entrelaçamento consciencial
        </p>
        <div className="flex items-center justify-center gap-4">
          <Badge variant="outline" className="text-sm">
            <Activity className="w-3 h-3 mr-1" />
            {connections.length} Conexões
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Heart className="w-3 h-3 mr-1" />
            {connections.filter(c => c.status === 'soul_family').length} Família Alma
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Brain className="w-3 h-3 mr-1" />
            {groups.length} Grupos Quânticos
          </Badge>
        </div>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="connections" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Conexões
          </TabsTrigger>
          <TabsTrigger value="messages" className="flex items-center gap-2">
            <MessageCircle className="w-4 h-4" />
            Mensagens
          </TabsTrigger>
          <TabsTrigger value="intentions" className="flex items-center gap-2">
            <Target className="w-4 h-4" />
            Intenções
          </TabsTrigger>
          <TabsTrigger value="groups" className="flex items-center gap-2">
            <GitBranch className="w-4 h-4" />
            Grupos
          </TabsTrigger>
        </TabsList>

        {/* Connections Tab */}
        <TabsContent value="connections" className="space-y-6">
          {/* Search and Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Buscar Conexões
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <Input
                  placeholder="Buscar por nome ou interesses..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="flex-1"
                />
                <Button variant="outline" size="icon">
                  <Filter className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Connections Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredConnections.map((connection) => (
              <Card key={connection.id} className="relative overflow-hidden">
                <div className={`absolute top-0 left-0 w-1 h-full ${getStatusColor(connection.status)}`} />
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={connection.avatar} alt={connection.name} />
                        <AvatarFallback>{connection.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">{connection.name}</CardTitle>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(connection.status)}
                          <Badge variant="outline" className="text-xs">
                            {connection.status === 'soul_family' ? 'Família Alma' : connection.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <Button variant="outline" size="icon">
                      <MessageCircle className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-muted-foreground">Consciência</div>
                      <div className="font-semibold">{formatCoherenceValue(connection.consciousness_level)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Frequência</div>
                      <div className="font-semibold">{formatFrequency(connection.vibration_frequency)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Coerência</div>
                      <div className="font-semibold">{formatCoherenceValue(connection.coherence_score)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Estágio</div>
                      <div className="font-semibold text-xs">{connection.evolution_stage}</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Força de Conexão</span>
                      <span>{formatCoherenceValue(connection.connection_strength)}</span>
                    </div>
                    <Progress value={connection.connection_strength * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Entrelaçamento Quântico</span>
                      <span>{formatCoherenceValue(connection.quantum_entanglement)}</span>
                    </div>
                    <Progress value={connection.quantum_entanglement * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium">Interesses em Comum:</div>
                    <div className="flex flex-wrap gap-1">
                      {connection.shared_interests.map((interest, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {interest}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="text-xs text-muted-foreground">
                    Última interação: {formatTimeAgo(connection.last_interaction)}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Connection Strength Analysis */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Análise de Conexões
              </CardTitle>
              <CardDescription>
                Força das conexões quânticas e níveis de entrelaçamento
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={connectionStrengthData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="strength" fill="#8884d8" name="Força de Conexão" />
                  <Bar dataKey="entanglement" fill="#82ca9d" name="Entrelaçamento Quântico" />
                  <Bar dataKey="synchronicity" fill="#ffc658" name="Sincronicidade" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Messages Tab */}
        <TabsContent value="messages" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Messages List */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle>Conversas</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-2">
                    {connections.map((connection) => (
                      <div
                        key={connection.id}
                        className={`p-3 rounded-lg cursor-pointer transition-colors ${
                          selectedConnection === connection.user_id
                            ? 'bg-purple-100 border border-purple-300'
                            : 'hover:bg-muted'
                        }`}
                        onClick={() => setSelectedConnection(connection.user_id)}
                      >
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={connection.avatar} alt={connection.name} />
                            <AvatarFallback>{connection.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="font-medium">{connection.name}</div>
                            <div className="text-sm text-muted-foreground">
                              {formatTimeAgo(connection.last_interaction)}
                            </div>
                          </div>
                          {connection.quantum_entanglement > 0.9 && (
                            <Zap className="h-4 w-4 text-purple-600" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Chat Area */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>
                  {selectedConnection
                    ? `Conversa com ${connections.find(c => c.user_id === selectedConnection)?.name}`
                    : 'Selecione uma conexão'
                  }
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedConnection ? (
                  <>
                    {/* Messages Display */}
                    <ScrollArea className="h-96 border rounded-lg p-4">
                      <div className="space-y-4">
                        {messages
                          .filter(msg => 
                            (msg.sender_id === selectedConnection && msg.receiver_id === 'valeria_plaisant') ||
                            (msg.sender_id === 'valeria_plaisant' && msg.receiver_id === selectedConnection)
                          )
                          .map((message) => (
                            <div
                              key={message.id}
                              className={`flex ${message.sender_id === 'valeria_plaisant' ? 'justify-end' : 'justify-start'}`}
                            >
                              <div
                                className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                                  message.sender_id === 'valeria_plaisant'
                                    ? 'bg-purple-600 text-white'
                                    : 'bg-muted'
                                }`}
                              >
                                <div className="flex items-center gap-2 mb-1">
                                  {getMessageTypeIcon(message.message_type)}
                                  <span className="text-xs opacity-75">
                                    {formatTimeAgo(message.timestamp)}
                                  </span>
                                  {message.quantum_encrypted && (
                                    <Shield className="h-3 w-3" />
                                  )}
                                </div>
                                <div className="text-sm">{message.content}</div>
                                <div className="text-xs opacity-75 mt-1">
                                  {formatFrequency(message.vibration_frequency)} • {formatCoherenceValue(message.consciousness_level)}
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    </ScrollArea>

                    {/* Message Input */}
                    <div className="flex gap-2">
                      <Input
                        placeholder="Digite sua mensagem quântica..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        className="flex-1"
                      />
                      <Button onClick={handleSendMessage} disabled={isSending || !newMessage.trim()}>
                        {isSending ? (
                          <RefreshCw className="h-4 w-4 animate-spin" />
                        ) : (
                          <Send className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="text-center text-muted-foreground py-12">
                    <MessageCircle className="h-12 w-12 mx-auto mb-4" />
                    <p>Selecione uma conexão para começar uma conversa quântica</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Intentions Tab */}
        <TabsContent value="intentions" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {intentions.map((intention) => (
              <Card key={intention.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5" />
                      {intention.title}
                    </CardTitle>
                    <Badge variant="outline">{intention.category}</Badge>
                  </div>
                  <CardDescription>{intention.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-muted-foreground">Força da Intenção</div>
                      <div className="font-semibold">{formatCoherenceValue(intention.intention_strength)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Progresso</div>
                      <div className="font-semibold">{formatCoherenceValue(intention.manifestation_progress)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Participantes</div>
                      <div className="font-semibold">{intention.participants.length}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Data Alvo</div>
                      <div className="font-semibold">
                        {new Date(intention.target_date).toLocaleDateString()}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Manifestação</span>
                      <span>{formatCoherenceValue(intention.manifestation_progress)}</span>
                    </div>
                    <Progress value={intention.manifestation_progress * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium">Tags:</div>
                    <div className="flex flex-wrap gap-1">
                      {intention.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Heart className="h-4 w-4 mr-2" />
                      Amplificar
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      <Share2 className="h-4 w-4 mr-2" />
                      Compartilhar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Create New Intention */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Criar Nova Intenção Coletiva
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input placeholder="Título da intenção..." />
                <select className="px-3 py-2 border rounded-md">
                  <option value="healing">Cura</option>
                  <option value="peace">Paz</option>
                  <option value="evolution">Evolução</option>
                  <option value="abundance">Abundância</option>
                  <option value="awakening">Despertar</option>
                </select>
              </div>
              <Textarea placeholder="Descrição da intenção coletiva..." rows={3} />
              <div className="flex gap-2">
                <Button className="flex-1">
                  <Target className="h-4 w-4 mr-2" />
                  Criar Intenção
                </Button>
                <Button variant="outline">
                  <Users className="h-4 w-4 mr-2" />
                  Convidar Participantes
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Groups Tab */}
        <TabsContent value="groups" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {groups.map((group) => (
              <Card key={group.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      {getGroupTypeIcon(group.group_type)}
                      {group.name}
                    </CardTitle>
                    <Badge variant="outline">{group.group_type}</Badge>
                  </div>
                  <CardDescription>{group.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-muted-foreground">Membros</div>
                      <div className="font-semibold">{group.members.length}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Frequência</div>
                      <div className="font-semibold">{formatFrequency(group.frequency)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Coerência</div>
                      <div className="font-semibold">{formatCoherenceValue(group.coherence_level)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Reuniões</div>
                      <div className="font-semibold text-xs">{group.meeting_schedule}</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium">Propósito:</div>
                    <div className="text-sm text-muted-foreground">{group.purpose}</div>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Brain className="h-4 w-4 mr-2" />
                      Sincronizar
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      <UserPlus className="h-4 w-4 mr-2" />
                      Convidar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Create New Group */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                Criar Novo Grupo Quântico
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input placeholder="Nome do grupo..." />
                <select className="px-3 py-2 border rounded-md">
                  <option value="meditation">Meditação</option>
                  <option value="study">Estudo</option>
                  <option value="healing">Cura</option>
                  <option value="evolution">Evolução</option>
                  <option value="service">Serviço</option>
                </select>
              </div>
              <Textarea placeholder="Descrição do grupo..." rows={3} />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input placeholder="Frequência de ressonância (Hz)..." type="number" />
                <Input placeholder="Programação de reuniões..." />
              </div>
              <Button className="w-full">
                <GitBranch className="h-4 w-4 mr-2" />
                Criar Grupo Quântico
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}