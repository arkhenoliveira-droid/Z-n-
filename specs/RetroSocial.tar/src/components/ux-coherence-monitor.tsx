'use client';

import React from 'react';
import UXCoherenceOptimizerDashboard from '@/components/ux-coherence-optimizer-dashboard';

export default function UXCoherenceMonitor() {
  return <UXCoherenceOptimizerDashboard />;
}