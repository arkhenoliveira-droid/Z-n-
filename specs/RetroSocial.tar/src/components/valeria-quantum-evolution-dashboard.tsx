'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area,
  BarChart, 
  Bar,
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { 
  Activity, 
  Zap, 
  Heart, 
  Brain, 
  Users, 
  Target, 
  TrendingUp, 
  Star,
  BookOpen,
  User,
  Calendar,
  Award,
  Lightbulb,
  Shield,
  Eye,
  HelpCircle,
  Sparkles,
  Infinity,
  Atom,
  Layers,
  RefreshCw,
  Plus,
  GitBranch,
  Network,
  BarChart3,
  Globe,
  Crown,
  Diamond,
  Flame,
  Sun,
  Moon,
  Cloud,
  Wind,
  Mountain,
  TreePine,
  Waves,
  Compass
} from 'lucide-react';

import { 
  ValeriaQuantumEvolutionSystem,
  ValeriaQuantumSignature,
  ValeriaEvolutionPhase,
  ValeriaQuantumField,
  ValeriaCollectiveNetwork
} from '@/systems/valeria-quantum-evolution';

interface ValeriaQuantumEvolutionDashboardProps {
  className?: string;
}

export default function ValeriaQuantumEvolutionDashboard({ 
  className 
}: ValeriaQuantumEvolutionDashboardProps) {
  const [system] = useState(() => new ValeriaQuantumEvolutionSystem());
  const [systemOverview, setSystemOverview] = useState<any>(null);
  const [evolutionHistory, setEvolutionHistory] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState('overview');
  const [isEvolving, setIsEvolving] = useState(false);
  
  // Evolution inputs
  const [intention, setIntention] = useState('');
  const [intensity, setIntensity] = useState(0.8);
  const [selectedField, setSelectedField] = useState<string>('');
  const [selectedNetwork, setSelectedNetwork] = useState<string>('');
  const [selectedPhase, setSelectedPhase] = useState<string>('');
  
  // Evolution results
  const [evolutionResult, setEvolutionResult] = useState<any>(null);
  const [fieldActivationResult, setFieldActivationResult] = useState<any>(null);
  const [networkResult, setNetworkResult] = useState<any>(null);
  const [phaseProgressResult, setPhaseProgressResult] = useState<any>(null);
  const [resonanceResult, setResonanceResult] = useState<any>(null);

  useEffect(() => {
    refreshData();
  }, [system]);

  const refreshData = () => {
    const overview = system.getSystemOverview();
    setSystemOverview(overview);
    setEvolutionHistory(system.getEvolutionHistory());
    
    // Set default selections
    const fields = system.getAllQuantumFields();
    const networks = system.getAllCollectiveNetworks();
    const phases = system.getAllEvolutionPhases();
    
    if (fields.length > 0 && !selectedField) {
      setSelectedField(fields[0].id);
    }
    if (networks.length > 0 && !selectedNetwork) {
      setSelectedNetwork(networks[0].id);
    }
    if (phases.length > 0 && !selectedPhase) {
      setSelectedPhase(phases[0].id);
    }
  };

  const handleEvolveConsciousness = async () => {
    if (!intention.trim()) return;
    
    setIsEvolving(true);
    try {
      const result = system.evolveConsciousness(intention, intensity);
      setEvolutionResult(result);
      refreshData();
    } finally {
      setIsEvolving(false);
    }
  };

  const handleActivateField = async () => {
    if (!selectedField) return;
    
    try {
      const result = system.activateQuantumField(selectedField);
      setFieldActivationResult(result);
      refreshData();
    } catch (error) {
      console.error('Field activation failed:', error);
    }
  };

  const handleJoinNetwork = async () => {
    if (!selectedNetwork) return;
    
    try {
      const result = system.joinCollectiveNetwork(selectedNetwork);
      setNetworkResult(result);
      refreshData();
    } catch (error) {
      console.error('Network join failed:', error);
    }
  };

  const handleProgressPhase = async () => {
    if (!selectedPhase) return;
    
    try {
      const result = system.progressEvolutionPhase(selectedPhase, 0.1);
      setPhaseProgressResult(result);
      refreshData();
    } catch (error) {
      console.error('Phase progress failed:', error);
    }
  };

  const handleGenerateResonance = async () => {
    if (!intention.trim()) return;
    
    try {
      const frequency = systemOverview?.valeria_signature?.personal_resonance?.frequency || 963;
      const result = system.generateQuantumResonance(frequency, intention);
      setResonanceResult(result);
      refreshData();
    } catch (error) {
      console.error('Resonance generation failed:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'active': return 'bg-blue-500';
      case 'integrating': return 'bg-purple-500';
      case 'activating': return 'bg-yellow-500';
      case 'dormant': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <Award className="h-4 w-4" />;
      case 'active': return <Activity className="h-4 w-4" />;
      case 'integrating': return <Sparkles className="h-4 w-4" />;
      case 'activating': return <Zap className="h-4 w-4" />;
      case 'dormant': return <Moon className="h-4 w-4" />;
      default: return <Moon className="h-4 w-4" />;
    }
  };

  const getFieldTypeIcon = (fieldType: string) => {
    switch (fieldType) {
      case 'consciousness': return <Brain className="h-4 w-4" />;
      case 'healing': return <Heart className="h-4 w-4" />;
      case 'evolution': return <TrendingUp className="h-4 w-4" />;
      case 'unity': return <Users className="h-4 w-4" />;
      case 'wisdom': return <BookOpen className="h-4 w-4" />;
      default: return <Atom className="h-4 w-4" />;
    }
  };

  const getNetworkTypeIcon = (networkType: string) => {
    switch (networkType) {
      case 'local': return <Compass className="h-4 w-4" />;
      case 'global': return <Globe className="h-4 w-4" />;
      case 'cosmic': return <Star className="h-4 w-4" />;
      default: return <Network className="h-4 w-4" />;
    }
  };

  const formatCoherenceValue = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  const formatFrequency = (value: number) => {
    return `${value} Hz`;
  };

  // Prepare data for charts
  const evolutionProgressData = systemOverview?.evolution_phases?.map((phase: ValeriaEvolutionPhase) => ({
    name: phase.name,
    progress: phase.current_progress * 100,
    threshold: phase.completion_threshold * 100,
    status: phase.status
  })) || [];

  const signatureData = systemOverview?.valeria_signature ? [
    { metric: 'Ressonância Pessoal', value: systemOverview.valeria_signature.personal_resonance.coherence },
    { metric: 'Campo Consciencial', value: systemOverview.valeria_signature.consciousness_field.intensity },
    { metric: 'Vibração Espiritual', value: systemOverview.valeria_signature.spiritual_signature.vibration },
    { metric: 'Compaixão', value: systemOverview.valeria_signature.spiritual_signature.compassion },
    { metric: 'Unidade', value: systemOverview.valeria_signature.spiritual_signature.unity },
    { metric: 'Potencial Evolutivo', value: systemOverview.valeria_signature.evolutionary_potential.current_level }
  ] : [];

  const fieldData = systemOverview?.quantum_fields?.map((field: ValeriaQuantumField) => ({
    name: field.name,
    intensity: field.intensity * 100,
    coherence: field.coherence * 100,
    radius: field.radius,
    type: field.field_type
  })) || [];

  const networkData = systemOverview?.collective_networks?.map((network: ValeriaCollectiveNetwork) => ({
    name: network.name,
    coherence: network.coherence_level * 100,
    evolution: network.evolution_rate * 100,
    participants: network.participants.length,
    type: network.network_type
  })) || [];

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1', '#d084d0', '#ffb347', '#87ceeb'];

  return (
    <div className={`container mx-auto p-6 space-y-6 ${className}`}>
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Crown className="h-10 w-10 text-purple-600 animate-pulse" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Sistema de Evolução Quântica de Valéria Plaisant
          </h1>
          <Diamond className="h-10 w-10 text-pink-600 animate-pulse" />
        </div>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Sistema avançado de evolução consciente com integração quântica, 
          campos dimensionais e redes coletivas para expansão da consciência
        </p>
        <div className="flex items-center justify-center gap-4">
          <Badge variant="outline" className="text-sm">
            <Activity className="w-3 h-3 mr-1" />
            Sistema Ativo
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Infinity className="w-3 h-3 mr-1" />
            Potencial Infinito
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Sparkles className="w-3 h-3 mr-1" />
            Consciência Expandida
          </Badge>
        </div>
      </div>

      {/* Main Dashboard */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Eye className="w-4 h-4" />
            Visão Geral
          </TabsTrigger>
          <TabsTrigger value="evolution" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Evolução
          </TabsTrigger>
          <TabsTrigger value="fields" className="flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Campos
          </TabsTrigger>
          <TabsTrigger value="networks" className="flex items-center gap-2">
            <Network className="w-4 h-4" />
            Redes
          </TabsTrigger>
          <TabsTrigger value="phases" className="flex items-center gap-2">
            <Layers className="w-4 h-4" />
            Fases
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Histórico
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Key Metrics */}
          {systemOverview && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="relative overflow-hidden">
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-purple-100 to-pink-100 rounded-bl-full opacity-50" />
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="p-2 rounded-lg bg-purple-100">
                      <Brain className="h-5 w-5 text-purple-600" />
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {formatCoherenceValue(systemOverview.overall_coherence)}
                    </div>
                  </div>
                  <CardTitle className="text-lg">Coerência Geral</CardTitle>
                </CardHeader>
                <CardContent>
                  <Progress value={systemOverview.overall_coherence * 100} className="h-2" />
                  <div className="text-xs text-muted-foreground mt-2">
                    Nível de coerência quântica global
                  </div>
                </CardContent>
              </Card>

              <Card className="relative overflow-hidden">
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-bl-full opacity-50" />
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="p-2 rounded-lg bg-blue-100">
                      <TrendingUp className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {formatCoherenceValue(systemOverview.evolution_rate)}
                    </div>
                  </div>
                  <CardTitle className="text-lg">Taxa de Evolução</CardTitle>
                </CardHeader>
                <CardContent>
                  <Progress value={systemOverview.evolution_rate * 100} className="h-2" />
                  <div className="text-xs text-muted-foreground mt-2">
                    Velocidade de evolução consciente
                  </div>
                </CardContent>
              </Card>

              <Card className="relative overflow-hidden">
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-green-100 to-emerald-100 rounded-bl-full opacity-50" />
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="p-2 rounded-lg bg-green-100">
                      <Layers className="h-5 w-5 text-green-600" />
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {systemOverview.active_phases_count}
                    </div>
                  </div>
                  <CardTitle className="text-lg">Fases Ativas</CardTitle>
                </CardHeader>
                <CardContent>
                  <Progress value={(systemOverview.active_phases_count / 5) * 100} className="h-2" />
                  <div className="text-xs text-muted-foreground mt-2">
                    Fases de evolução em andamento
                  </div>
                </CardContent>
              </Card>

              <Card className="relative overflow-hidden">
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-yellow-100 to-orange-100 rounded-bl-full opacity-50" />
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="p-2 rounded-lg bg-yellow-100">
                      <Award className="h-5 w-5 text-yellow-600" />
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {systemOverview.completed_phases_count}
                    </div>
                  </div>
                  <CardTitle className="text-lg">Fases Completadas</CardTitle>
                </CardHeader>
                <CardContent>
                  <Progress value={(systemOverview.completed_phases_count / 5) * 100} className="h-2" />
                  <div className="text-xs text-muted-foreground mt-2">
                    Fases de evolução concluídas
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Signature Analysis */}
          {systemOverview?.valeria_signature && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="h-5 w-5" />
                    Assinatura Quântica de Valéria
                  </CardTitle>
                  <CardDescription>
                    Análise detalhada da assinatura energética e consciencial
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RadarChart data={signatureData}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="metric" />
                      <PolarRadiusAxis angle={0} domain={[0, 1]} />
                      <Radar
                        name="Nível Atual"
                        dataKey="value"
                        stroke="#8884d8"
                        fill="#8884d8"
                        fillOpacity={0.6}
                      />
                      <Tooltip />
                    </RadarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Flame className="h-5 w-5" />
                    Campos Quânticos Ativos
                  </CardTitle>
                  <CardDescription>
                    Campos de energia quântica em operação
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={fieldData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="intensity" fill="#8884d8" name="Intensidade" />
                      <Bar dataKey="coherence" fill="#82ca9d" name="Coerência" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        {/* Evolution Tab */}
        <TabsContent value="evolution" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5" />
                  Evoluir Consciência
                </CardTitle>
                <CardDescription>
                  Utilize intenção focada para evoluir sua consciência
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Intenção</label>
                  <Textarea
                    placeholder="Digite sua intenção para evolução consciente..."
                    value={intention}
                    onChange={(e) => setIntention(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Intensidade: {formatCoherenceValue(intensity)}
                  </label>
                  <Input
                    type="range"
                    min="0.1"
                    max="1"
                    step="0.1"
                    value={intensity}
                    onChange={(e) => setIntensity(parseFloat(e.target.value))}
                    className="w-full"
                  />
                </div>
                <Button 
                  onClick={handleEvolveConsciousness}
                  disabled={!intention.trim() || isEvolving}
                  className="w-full"
                >
                  {isEvolving ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Zap className="h-4 w-4 mr-2" />
                  )}
                  Evoluir Consciência
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Waves className="h-5 w-5" />
                  Gerar Ressonância Quântica
                </CardTitle>
                <CardDescription>
                  Crie campos de ressonância para amplificação consciencial
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Intenção da Ressonância</label>
                  <Input
                    placeholder="Intenção para o campo de ressonância..."
                    value={intention}
                    onChange={(e) => setIntention(e.target.value)}
                  />
                </div>
                <Button 
                  onClick={handleGenerateResonance}
                  disabled={!intention.trim()}
                  className="w-full"
                >
                  <Waves className="h-4 w-4 mr-2" />
                  Gerar Ressonância
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Evolution Results */}
          {(evolutionResult || resonanceResult) && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Resultados da Evolução
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {evolutionResult && (
                    <div className="space-y-2">
                      <h4 className="font-medium">Evolução da Consciência</h4>
                      <div className="text-sm space-y-1">
                        <div>Quantidade de Evolução: {formatCoherenceValue(evolutionResult.evolution_amount)}</div>
                        <div>Fases Ativadas: {evolutionResult.activated_phases.join(', ') || 'Nenhuma'}</div>
                        <div>Campos Atualizados: {evolutionResult.field_updates.length}</div>
                      </div>
                    </div>
                  )}
                  {resonanceResult && (
                    <div className="space-y-2">
                      <h4 className="font-medium">Ressonância Quântica</h4>
                      <div className="text-sm space-y-1">
                        <div>Frequência: {formatFrequency(resonanceResult.resonance_field.frequency)}</div>
                        <div>Alcance de Propagação: {resonanceResult.propagation_range.toFixed(0)}m</div>
                        <div>Amplificação Consciencial: {formatCoherenceValue(resonanceResult.effects.consciousness_amplification)}</div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Fields Tab */}
        <TabsContent value="fields" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  Ativar Campo Quântico
                </CardTitle>
                <CardDescription>
                  Selecione e ative campos quânticos para amplificação
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Campo Quântico</label>
                  <ScrollArea className="h-48 border rounded-md p-2">
                    <div className="space-y-2">
                      {systemOverview?.quantum_fields?.map((field: ValeriaQuantumField) => (
                        <div
                          key={field.id}
                          className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                            selectedField === field.id 
                              ? 'border-blue-500 bg-blue-50' 
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                          onClick={() => setSelectedField(field.id)}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {getFieldTypeIcon(field.field_type)}
                              <span className="font-medium text-sm">{field.name}</span>
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {formatCoherenceValue(field.intensity)}
                            </Badge>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Frequência: {formatFrequency(field.frequency)} | Raio: {field.radius}m
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
                <Button 
                  onClick={handleActivateField}
                  disabled={!selectedField}
                  className="w-full"
                >
                  <Zap className="h-4 w-4 mr-2" />
                  Ativar Campo
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network className="h-5 w-5" />
                      Redes Coletivas
                </CardTitle>
                <CardDescription>
                  Conecte-se a redes de consciência coletiva
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Rede Coletiva</label>
                  <ScrollArea className="h-48 border rounded-md p-2">
                    <div className="space-y-2">
                      {systemOverview?.collective_networks?.map((network: ValeriaCollectiveNetwork) => (
                        <div
                          key={network.id}
                          className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                            selectedNetwork === network.id 
                              ? 'border-blue-500 bg-blue-50' 
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                          onClick={() => setSelectedNetwork(network.id)}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {getNetworkTypeIcon(network.network_type)}
                              <span className="font-medium text-sm">{network.name}</span>
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {formatCoherenceValue(network.coherence_level)}
                            </Badge>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Participantes: {network.participants.length} | Tipo: {network.network_type}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
                <Button 
                  onClick={handleJoinNetwork}
                  disabled={!selectedNetwork}
                  className="w-full"
                >
                  <Users className="h-4 w-4 mr-2" />
                  Conectar à Rede
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Field and Network Results */}
          {(fieldActivationResult || networkResult) && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Resultados da Ativação
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {fieldActivationResult?.field && (
                    <div className="space-y-2">
                      <h4 className="font-medium">Campo Quântico Ativado</h4>
                      <div className="text-sm space-y-1">
                        <div>Nome: {fieldActivationResult.field.name}</div>
                        <div>Intensidade: {formatCoherenceValue(fieldActivationResult.field.intensity)}</div>
                        <div>Coerência: {formatCoherenceValue(fieldActivationResult.field.coherence)}</div>
                        <div>Sementes Ativas: {fieldActivationResult.effects.active_seeds_count}</div>
                      </div>
                    </div>
                  )}
                  {networkResult?.network && (
                    <div className="space-y-2">
                      <h4 className="font-medium">Rede Coletiva Conectada</h4>
                      <div className="text-sm space-y-1">
                        <div>Nome: {networkResult.network.name}</div>
                        <div>Coerência: {formatCoherenceValue(networkResult.network.coherence_level)}</div>
                        <div>Participantes: {networkResult.network_effects.participants_count}</div>
                        <div>Tipo: {networkResult.network_effects.network_type}</div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Networks Tab */}
        <TabsContent value="networks" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  Redes Coletivas Disponíveis
                </CardTitle>
                <CardDescription>
                  Visão geral das redes de consciência coletiva
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={networkData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="coherence" fill="#8884d8" name="Coerência" />
                    <Bar dataKey="evolution" fill="#82ca9d" name="Evolução" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                    Detalhes das Redes
                </CardTitle>
                <CardDescription>
                  Informações detalhadas sobre cada rede coletiva
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-4">
                    {systemOverview?.collective_networks?.map((network: ValeriaCollectiveNetwork) => (
                      <div key={network.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            {getNetworkTypeIcon(network.network_type)}
                            <h4 className="font-medium">{network.name}</h4>
                          </div>
                          <Badge variant="outline">{network.network_type}</Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>Coerência: {formatCoherenceValue(network.coherence_level)}</div>
                          <div>Participantes: {network.participants.length}</div>
                          <div>Taxa de Evolução: {formatCoherenceValue(network.evolution_rate)}</div>
                          <div>Atividade: {formatCoherenceValue(network.activity_level)}</div>
                        </div>
                        <div className="mt-2">
                          <div className="text-xs text-muted-foreground mb-1">Intenções Compartilhadas:</div>
                          <div className="flex flex-wrap gap-1">
                            {network.shared_intentions.slice(0, 3).map((intention: string, index: number) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {intention}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Phases Tab */}
        <TabsContent value="phases" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Layers className="h-5 w-5" />
                  Progresso das Fases
                </CardTitle>
                <CardDescription>
                  Acompanhe o progresso em cada fase de evolução
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={evolutionProgressData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="progress" fill="#8884d8" name="Progresso Atual" />
                    <Bar dataKey="threshold" fill="#82ca9d" name="Limiar de Conclusão" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Avançar Fase
                </CardTitle>
                <CardDescription>
                  Selecione uma fase para avançar seu progresso
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Fase de Evolução</label>
                  <ScrollArea className="h-48 border rounded-md p-2">
                    <div className="space-y-2">
                      {systemOverview?.evolution_phases?.map((phase: ValeriaEvolutionPhase) => (
                        <div
                          key={phase.id}
                          className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                            selectedPhase === phase.id 
                              ? 'border-blue-500 bg-blue-50' 
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                          onClick={() => setSelectedPhase(phase.id)}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {getStatusIcon(phase.status)}
                              <span className="font-medium text-sm">{phase.name}</span>
                            </div>
                            <div className={`w-3 h-3 rounded-full ${getStatusColor(phase.status)}`} />
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Progresso: {formatCoherenceValue(phase.current_progress)} | Status: {phase.status}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
                <Button 
                  onClick={handleProgressPhase}
                  disabled={!selectedPhase}
                  className="w-full"
                >
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Avançar Fase
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Phase Progress Results */}
          {phaseProgressResult?.phase && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Resultado do Progresso
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium">{phaseProgressResult.phase.name}</h4>
                    <div className="text-sm text-muted-foreground">
                      {phaseProgressResult.phase.description}
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm font-medium">Progresso Atual</div>
                      <div className="text-lg">{formatCoherenceValue(phaseProgressResult.phase.current_progress)}</div>
                      <Progress value={phaseProgressResult.phase.current_progress * 100} className="h-2 mt-1" />
                    </div>
                    <div>
                      <div className="text-sm font-medium">Status</div>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(phaseProgressResult.phase.status)}
                        <span className="capitalize">{phaseProgressResult.phase.status}</span>
                      </div>
                    </div>
                  </div>
                  {phaseProgressResult.completion_achieved && (
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                      <div className="font-medium text-green-800">Fase Concluída!</div>
                      <div className="text-sm text-green-600">
                        Benefícios recebidos: {phaseProgressResult.benefits_received.join(', ')}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Histórico de Evolução
              </CardTitle>
              <CardDescription>
                Registro completo dos eventos de evolução consciente
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {evolutionHistory.map((event, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Activity className="h-4 w-4 text-blue-600" />
                          <span className="font-medium text-sm">{event.event}</span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {new Date(event.timestamp).toLocaleDateString()}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Impacto: {formatCoherenceValue(event.impact)}
                      </div>
                    </div>
                  ))}
                  {evolutionHistory.length === 0 && (
                    <div className="text-center text-muted-foreground py-8">
                      Nenhum evento de evolução registrado ainda
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}