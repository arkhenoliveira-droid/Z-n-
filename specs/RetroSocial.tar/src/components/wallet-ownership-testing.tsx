'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Wallet, 
  Shield, 
  Search, 
  Plus, 
  FileText, 
  CheckCircle, 
  XCircle, 
  Clock,
  AlertTriangle,
  BarChart3,
  TrendingUp,
  Users,
  Activity,
  Zap
} from 'lucide-react';

interface Wallet {
  id: string;
  address: string;
  type: string;
  name?: string;
  description?: string;
  owner?: string;
  balance?: number;
  status: string;
  riskLevel: string;
  createdAt: string;
  auditTests: WalletAuditTest[];
  ownershipClaims: WalletOwnershipClaim[];
  transactions: WalletTransaction[];
}

interface WalletAuditTest {
  id: string;
  testType: string;
  testName: string;
  description?: string;
  status: string;
  score?: number;
  confidence?: number;
  startedAt?: string;
  completedAt?: string;
  findings?: any;
  recommendations?: any;
}

interface WalletOwnershipClaim {
  id: string;
  claimant: string;
  verificationMethod: string;
  status: string;
  confidence?: number;
  createdAt: string;
  verifiedAt?: string;
}

interface WalletTransaction {
  id: string;
  hash: string;
  fromAddress: string;
  toAddress: string;
  amount: number;
  currency: string;
  timestamp: string;
  status: string;
  type: string;
}

export default function WalletOwnershipTesting() {
  const [wallets, setWallets] = useState<Wallet[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedWallet, setSelectedWallet] = useState<Wallet | null>(null);
  const [showAddWallet, setShowAddWallet] = useState(false);
  const [newWallet, setNewWallet] = useState({
    address: '',
    type: '',
    name: '',
    description: '',
    owner: '',
    balance: 0
  });
  const [filters, setFilters] = useState({
    type: '',
    status: '',
    riskLevel: ''
  });

  useEffect(() => {
    fetchWallets();
  }, [filters]);

  const fetchWallets = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });

      const response = await fetch(`/api/wallets?${params}`);
      if (response.ok) {
        const data = await response.json();
        setWallets(data.wallets);
      }
    } catch (error) {
      console.error('Error fetching wallets:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddWallet = async () => {
    try {
      const response = await fetch('/api/wallets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newWallet)
      });

      if (response.ok) {
        setShowAddWallet(false);
        setNewWallet({
          address: '',
          type: '',
          name: '',
          description: '',
          owner: '',
          balance: 0
        });
        fetchWallets();
      }
    } catch (error) {
      console.error('Error adding wallet:', error);
    }
  };

  const runAuditTest = async (walletId: string, testType: string) => {
    try {
      const response = await fetch(`/api/wallets/${walletId}/audit-tests`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          testType,
          testName: `${testType} Test`,
          description: `Automated ${testType} verification test`
        })
      });

      if (response.ok) {
        if (selectedWallet?.id === walletId) {
          fetchWalletDetails(walletId);
        }
        fetchWallets();
      }
    } catch (error) {
      console.error('Error running audit test:', error);
    }
  };

  const fetchWalletDetails = async (walletId: string) => {
    try {
      const response = await fetch(`/api/wallets/${walletId}`);
      if (response.ok) {
        const wallet = await response.json();
        setSelectedWallet(wallet);
      }
    } catch (error) {
      console.error('Error fetching wallet details:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'completed': return 'bg-green-500';
      case 'verified': return 'bg-green-500';
      case 'pending': return 'bg-yellow-500';
      case 'running': return 'bg-blue-500';
      case 'failed': return 'bg-red-500';
      case 'rejected': return 'bg-red-500';
      case 'under_review': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'low': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      case 'high': return 'bg-orange-500';
      case 'critical': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const walletTypes = ['ethereum', 'bitcoin', 'polygon', 'binance', 'solana', 'avalanche', 'arbitrum'];
  const testTypes = ['ownership_verification', 'security_scan', 'compliance_check', 'risk_assessment'];

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">2024 Audit - Wallet Ownership Testing</h1>
          <p className="text-gray-600">Comprehensive wallet ownership verification and security audit system</p>
        </div>
        <Button onClick={() => setShowAddWallet(true)} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add Wallet
        </Button>
      </div>

      {/* Add Wallet Modal */}
      {showAddWallet && (
        <Card>
          <CardHeader>
            <CardTitle>Add New Wallet</CardTitle>
            <CardDescription>Enter wallet details for ownership testing</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="address">Wallet Address</Label>
                <Input
                  id="address"
                  value={newWallet.address}
                  onChange={(e) => setNewWallet({...newWallet, address: e.target.value})}
                  placeholder="0x..."
                />
              </div>
              <div>
                <Label htmlFor="type">Wallet Type</Label>
                <Select value={newWallet.type} onValueChange={(value) => setNewWallet({...newWallet, type: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {walletTypes.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={newWallet.name}
                  onChange={(e) => setNewWallet({...newWallet, name: e.target.value})}
                  placeholder="Wallet name"
                />
              </div>
              <div>
                <Label htmlFor="owner">Owner</Label>
                <Input
                  id="owner"
                  value={newWallet.owner}
                  onChange={(e) => setNewWallet({...newWallet, owner: e.target.value})}
                  placeholder="Owner identifier"
                />
              </div>
              <div>
                <Label htmlFor="balance">Balance</Label>
                <Input
                  id="balance"
                  type="number"
                  value={newWallet.balance}
                  onChange={(e) => setNewWallet({...newWallet, balance: parseFloat(e.target.value) || 0})}
                  placeholder="0.00"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={newWallet.description}
                onChange={(e) => setNewWallet({...newWallet, description: e.target.value})}
                placeholder="Wallet description"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleAddWallet}>Add Wallet</Button>
              <Button variant="outline" onClick={() => setShowAddWallet(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="filterType">Filter by Type</Label>
              <Select value={filters.type} onValueChange={(value) => setFilters({...filters, type: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All types</SelectItem>
                  {walletTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filterStatus">Filter by Status</Label>
              <Select value={filters.status} onValueChange={(value) => setFilters({...filters, status: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="compromised">Compromised</SelectItem>
                  <SelectItem value="under_review">Under Review</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filterRisk">Filter by Risk Level</Label>
              <Select value={filters.riskLevel} onValueChange={(value) => setFilters({...filters, riskLevel: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="All risk levels" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All risk levels</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Wallet List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Wallets Under Audit</CardTitle>
              <CardDescription>Wallets currently undergoing ownership verification and security testing</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">Loading wallets...</div>
              ) : (
                <div className="space-y-4">
                  {wallets.map((wallet) => (
                    <div
                      key={wallet.id}
                      className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                        selectedWallet?.id === wallet.id ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                      }`}
                      onClick={() => fetchWalletDetails(wallet.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Wallet className="w-5 h-5" />
                          <div>
                            <div className="font-medium">{wallet.name || wallet.address}</div>
                            <div className="text-sm text-gray-600">{wallet.type} • {wallet.balance} ETH</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={`${getStatusColor(wallet.status)} text-white`}>
                            {wallet.status}
                          </Badge>
                          <Badge className={`${getRiskColor(wallet.riskLevel)} text-white`}>
                            {wallet.riskLevel}
                          </Badge>
                        </div>
                      </div>
                      <div className="mt-2 flex items-center gap-4 text-sm text-gray-600">
                        <span>Tests: {wallet.auditTests.length}</span>
                        <span>Claims: {wallet.ownershipClaims.length}</span>
                        <span>Transactions: {wallet.transactions.length}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Selected Wallet Details */}
        <div>
          {selectedWallet && (
            <Card>
              <CardHeader>
                <CardTitle>Wallet Details</CardTitle>
                <CardDescription>{selectedWallet.address}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Type</Label>
                  <div className="font-medium">{selectedWallet.type}</div>
                </div>
                <div>
                  <Label>Status</Label>
                  <Badge className={`${getStatusColor(selectedWallet.status)} text-white`}>
                    {selectedWallet.status}
                  </Badge>
                </div>
                <div>
                  <Label>Risk Level</Label>
                  <Badge className={`${getRiskColor(selectedWallet.riskLevel)} text-white`}>
                    {selectedWallet.riskLevel}
                  </Badge>
                </div>
                <div>
                  <Label>Balance</Label>
                  <div className="font-medium">{selectedWallet.balance} ETH</div>
                </div>
                <div>
                  <Label>Owner</Label>
                  <div className="font-medium">{selectedWallet.owner || 'Unknown'}</div>
                </div>
                
                <div className="pt-4 border-t">
                  <Label>Run Audit Test</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {testTypes.map(testType => (
                      <Button
                        key={testType}
                        variant="outline"
                        size="sm"
                        onClick={() => runAuditTest(selectedWallet.id, testType)}
                        className="flex items-center gap-1"
                      >
                        <Shield className="w-3 h-3" />
                        {testType.replace('_', ' ')}
                      </Button>
                    ))}
                  </div>
                </div>

                {selectedWallet.auditTests.length > 0 && (
                  <div className="pt-4 border-t">
                    <Label>Recent Tests</Label>
                    <div className="space-y-2 mt-2">
                      {selectedWallet.auditTests.slice(0, 3).map(test => (
                        <div key={test.id} className="flex items-center justify-between text-sm">
                          <span>{test.testName}</span>
                          <Badge className={`${getStatusColor(test.status)} text-white`}>
                            {test.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}