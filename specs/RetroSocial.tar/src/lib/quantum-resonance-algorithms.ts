/**
 * Quantum Resonance Algorithms
 * Advanced algorithms for frequency optimization and resonance calculation
 */

export interface ResonanceParameters {
  base_frequency: number;
  amplitude: number;
  phase: number;
  coherence: number;
  harmonics: number[];
  modulation_type: 'sine' | 'square' | 'sawtooth' | 'triangle' | 'complex';
}

export interface QuantumFieldState {
  strength: number;
  coherence: number;
  frequency: number;
  amplitude: number;
  phase: number;
  entanglement: number;
  participants: number;
  location: {
    latitude: number;
    longitude: number;
    altitude: number;
  };
  timestamp: number;
}

export interface ResonanceOptimization {
  optimal_frequency: number;
  optimal_amplitude: number;
  optimal_phase: number;
  coherence_improvement: number;
  field_strength_improvement: number;
  recommended_harmonics: number[];
  optimization_confidence: number;
}

export interface CollectiveResonanceMetrics {
  collective_field_strength: number;
  group_coherence: number;
  frequency_synchronization: number;
  phase_alignment: number;
  emotional_resonance: number;
  spiritual_signature: number;
  quantum_entanglement_factor: number;
  overall_resonance_score: number;
}

export class QuantumResonanceCalculator {
  private readonly SACRED_FREQUENCIES = {
    396: { name: 'Liberação', chakra: 'Raiz', purpose: 'Liberar medo e culpa' },
    417: { name: 'Transmutação', chakra: 'Sacral', purpose: 'Transmutar situações' },
    432: { name: 'Cura', chakra: 'Coração', purpose: 'Cura e harmonização' },
    528: { name: 'Transformação', chakra: 'Garganta', purpose: 'Transformação e milagres' },
    639: { name: 'Conexão', chakra: 'Terceiro Olho', purpose: 'Conexão e relacionamentos' },
    741: { name: 'Despertar', chakra: 'Coroa', purpose: 'Despertar da intuição' },
    852: { name: 'Retorno', chakra: 'Todos', purpose: 'Retorno à ordem espiritual' },
    963: { name: 'Ativação', chakra: 'Coroa', purpose: 'Ativação da pineal' }
  };

  private readonly PLANETARY_FREQUENCIES = {
    earth: 7.83,
    venus: 7.83,
    mars: 7.83,
    jupiter: 7.83,
    saturn: 7.83,
    uranus: 7.83,
    neptune: 7.83,
    pluto: 7.83
  };

  private readonly CHAKRA_FREQUENCIES = {
    root: 396,
    sacral: 417,
    solar_plexus: 528,
    heart: 639,
    throat: 741,
    third_eye: 852,
    crown: 963
  };

  /**
   * Calculate optimal resonance frequency based on collective consciousness
   */
  calculateOptimalFrequency(
    participants: number,
    target_coherence: number,
    location: { latitude: number; longitude: number; altitude: number }
  ): number {
    // Base calculation using participant count
    const base_freq = 432; // Default sacred frequency
    const participant_factor = Math.log(participants + 1) / Math.log(100);
    const location_factor = this.calculateLocationFactor(location);
    const coherence_factor = target_coherence;

    // Calculate optimal frequency
    let optimal_freq = base_freq * participant_factor * location_factor * coherence_factor;

    // Round to nearest sacred frequency
    optimal_freq = this.findNearestSacredFrequency(optimal_freq);

    return optimal_freq;
  }

  /**
   * Calculate resonance coherence between multiple frequencies
   */
  calculateResonanceCoherence(frequencies: number[]): number {
    if (frequencies.length < 2) return 1.0;

    let total_coherence = 0;
    let comparisons = 0;

    for (let i = 0; i < frequencies.length; i++) {
      for (let j = i + 1; j < frequencies.length; j++) {
        const ratio = frequencies[i] / frequencies[j];
        const coherence = this.calculateFrequencyCoherence(ratio);
        total_coherence += coherence;
        comparisons++;
      }
    }

    return comparisons > 0 ? total_coherence / comparisons : 1.0;
  }

  /**
   * Calculate field strength based on resonance parameters
   */
  calculateFieldStrength(params: ResonanceParameters): number {
    const { base_frequency, amplitude, phase, coherence, harmonics } = params;

    // Base field strength calculation
    let field_strength = amplitude * coherence;

    // Frequency factor (higher frequencies have different effects)
    const frequency_factor = Math.log(base_frequency / 100) / Math.log(10);
    field_strength *= (1 + frequency_factor * 0.1);

    // Phase alignment factor
    const phase_factor = Math.cos(phase * Math.PI / 180);
    field_strength *= (1 + phase_factor * 0.05);

    // Harmonic contribution
    const harmonic_contribution = harmonics.reduce((sum, harmonic) => {
      const harmonic_strength = 1 / (harmonic * 0.5); // Decreasing contribution
      return sum + harmonic_strength;
    }, 0);
    field_strength *= (1 + harmonic_contribution * 0.1);

    return Math.min(1.0, field_strength);
  }

  /**
   * Optimize resonance parameters for maximum coherence
   */
  optimizeResonance(
    current_params: ResonanceParameters,
    target_coherence: number = 0.9,
    participants: number = 1
  ): ResonanceOptimization {
    const iterations = 100;
    let best_params = { ...current_params };
    let best_coherence = 0;

    for (let i = 0; i < iterations; i++) {
      // Generate random variations
      const test_params = this.generateParameterVariation(best_params);
      
      // Calculate coherence for test parameters
      const test_coherence = this.calculateOverallCoherence(test_params, participants);
      
      // Update best parameters if improvement found
      if (test_coherence > best_coherence) {
        best_coherence = test_coherence;
        best_params = test_params;
      }

      // Early termination if target reached
      if (best_coherence >= target_coherence) {
        break;
      }
    }

    // Calculate improvement
    const original_coherence = this.calculateOverallCoherence(current_params, participants);
    const coherence_improvement = best_coherence - original_coherence;
    
    const original_field_strength = this.calculateFieldStrength(current_params);
    const new_field_strength = this.calculateFieldStrength(best_params);
    const field_strength_improvement = new_field_strength - original_field_strength;

    return {
      optimal_frequency: best_params.base_frequency,
      optimal_amplitude: best_params.amplitude,
      optimal_phase: best_params.phase,
      coherence_improvement,
      field_strength_improvement,
      recommended_harmonics: this.generateRecommendedHarmonics(best_params.base_frequency),
      optimization_confidence: best_coherence
    };
  }

  /**
   * Calculate collective resonance metrics for group sessions
   */
  calculateCollectiveResonance(
    individual_states: QuantumFieldState[],
    session_duration: number
  ): CollectiveResonanceMetrics {
    if (individual_states.length === 0) {
      return {
        collective_field_strength: 0,
        group_coherence: 0,
        frequency_synchronization: 0,
        phase_alignment: 0,
        emotional_resonance: 0,
        spiritual_signature: 0,
        quantum_entanglement_factor: 0,
        overall_resonance_score: 0
      };
    }

    // Calculate collective field strength
    const collective_field_strength = this.calculateCollectiveFieldStrength(individual_states);

    // Calculate group coherence
    const group_coherence = this.calculateGroupCoherence(individual_states);

    // Calculate frequency synchronization
    const frequency_synchronization = this.calculateFrequencySynchronization(individual_states);

    // Calculate phase alignment
    const phase_alignment = this.calculatePhaseAlignment(individual_states);

    // Calculate emotional resonance (simulated based on coherence and field strength)
    const emotional_resonance = (group_coherence + collective_field_strength) / 2;

    // Calculate spiritual signature (based on sacred frequency alignment)
    const spiritual_signature = this.calculateSpiritualSignature(individual_states);

    // Calculate quantum entanglement factor
    const quantum_entanglement_factor = this.calculateQuantumEntanglement(individual_states, session_duration);

    // Calculate overall resonance score
    const overall_resonance_score = (
      collective_field_strength * 0.2 +
      group_coherence * 0.2 +
      frequency_synchronization * 0.15 +
      phase_alignment * 0.15 +
      emotional_resonance * 0.1 +
      spiritual_signature * 0.1 +
      quantum_entanglement_factor * 0.1
    );

    return {
      collective_field_strength,
      group_coherence,
      frequency_synchronization,
      phase_alignment,
      emotional_resonance,
      spiritual_signature,
      quantum_entanglement_factor,
      overall_resonance_score
    };
  }

  /**
   * Generate harmonic frequencies for a base frequency
   */
  generateHarmonics(base_frequency: number, count: number = 8): number[] {
    const harmonics: number[] = [];
    
    for (let i = 1; i <= count; i++) {
      harmonics.push(base_frequency * i);
    }
    
    return harmonics;
  }

  /**
   * Calculate frequency coherence ratio
   */
  private calculateFrequencyCoherence(ratio: number): number {
    // Check for sacred ratios
    const sacred_ratios = [1, 2, 1.5, 1.333, 1.25, 1.2, 1.125, 1.111];
    
    for (const sacred_ratio of sacred_ratios) {
      if (Math.abs(ratio - sacred_ratio) < 0.01) {
        return 1.0;
      }
    }

    // Check for golden ratio
    const golden_ratio = 1.618033988749895;
    if (Math.abs(ratio - golden_ratio) < 0.01) {
      return 0.95;
    }

    // Calculate general coherence based on mathematical simplicity
    const simplicity = this.calculateRatioSimplicity(ratio);
    return simplicity;
  }

  /**
   * Calculate location factor for resonance
   */
  private calculateLocationFactor(location: { latitude: number; longitude: number; altitude: number }): number {
    // Simple calculation based on latitude and altitude
    const latitude_factor = 1 + 0.1 * Math.sin(location.latitude * Math.PI / 180);
    const altitude_factor = 1 + (location.altitude / 10000) * 0.05;
    
    return latitude_factor * altitude_factor;
  }

  /**
   * Find nearest sacred frequency
   */
  private findNearestSacredFrequency(frequency: number): number {
    const sacred_freqs = Object.keys(this.SACRED_FREQUENCIES).map(Number);
    
    let nearest = sacred_freqs[0];
    let min_diff = Math.abs(frequency - nearest);
    
    for (const freq of sacred_freqs) {
      const diff = Math.abs(frequency - freq);
      if (diff < min_diff) {
        min_diff = diff;
        nearest = freq;
      }
    }
    
    return nearest;
  }

  /**
   * Generate parameter variation for optimization
   */
  private generateParameterVariation(params: ResonanceParameters): ResonanceParameters {
    const variation_factor = 0.1;
    
    return {
      base_frequency: params.base_frequency * (1 + (Math.random() - 0.5) * variation_factor),
      amplitude: Math.max(0.1, Math.min(1.0, params.amplitude * (1 + (Math.random() - 0.5) * variation_factor))),
      phase: (params.phase + (Math.random() - 0.5) * 30) % 360,
      coherence: Math.max(0.1, Math.min(1.0, params.coherence * (1 + (Math.random() - 0.5) * variation_factor))),
      harmonics: [...params.harmonics],
      modulation_type: params.modulation_type
    };
  }

  /**
   * Calculate overall coherence
   */
  private calculateOverallCoherence(params: ResonanceParameters, participants: number): number {
    const base_coherence = params.coherence;
    const participant_factor = Math.min(1.0, participants / 100);
    const frequency_factor = this.getFrequencyCoherenceFactor(params.base_frequency);
    
    return base_coherence * participant_factor * frequency_factor;
  }

  /**
   * Get frequency coherence factor
   */
  private getFrequencyCoherenceFactor(frequency: number): number {
    // Sacred frequencies have higher coherence
    if (this.SACRED_FREQUENCIES[frequency as keyof typeof this.SACRED_FREQUENCIES]) {
      return 1.0;
    }
    
    // Check proximity to sacred frequencies
    const sacred_freqs = Object.keys(this.SACRED_FREQUENCIES).map(Number);
    let min_diff = Infinity;
    
    for (const freq of sacred_freqs) {
      const diff = Math.abs(frequency - freq);
      min_diff = Math.min(min_diff, diff);
    }
    
    // Closer to sacred frequency = higher coherence
    return Math.max(0.5, 1.0 - min_diff / 100);
  }

  /**
   * Generate recommended harmonics
   */
  private generateRecommendedHarmonics(base_frequency: number): number[] {
    const harmonics: number[] = [];
    
    // Add fundamental harmonics
    for (let i = 2; i <= 4; i++) {
      harmonics.push(base_frequency * i);
    }
    
    // Add sacred frequency harmonics if applicable
    const sacred_freqs = Object.keys(this.SACRED_FREQUENCIES).map(Number);
    for (const freq of sacred_freqs) {
      if (Math.abs(base_frequency - freq) < 50) {
        harmonics.push(freq);
      }
    }
    
    return harmonics;
  }

  /**
   * Calculate collective field strength
   */
  private calculateCollectiveFieldStrength(states: QuantumFieldState[]): number {
    const total_strength = states.reduce((sum, state) => sum + state.strength, 0);
    const base_strength = total_strength / states.length;
    
    // Add synergy effect
    const synergy_factor = 1 + Math.log(states.length) / Math.log(10) * 0.1;
    
    return Math.min(1.0, base_strength * synergy_factor);
  }

  /**
   * Calculate group coherence
   */
  private calculateGroupCoherence(states: QuantumFieldState[]): number {
    if (states.length < 2) return states[0]?.coherence || 0;
    
    let total_coherence = 0;
    let comparisons = 0;
    
    for (let i = 0; i < states.length; i++) {
      for (let j = i + 1; j < states.length; j++) {
        const freq_ratio = states[i].frequency / states[j].frequency;
        const coherence = this.calculateFrequencyCoherence(freq_ratio);
        const phase_diff = Math.abs(states[i].phase - states[j].phase);
        const phase_coherence = Math.cos(phase_diff * Math.PI / 180);
        
        total_coherence += (coherence + phase_coherence) / 2;
        comparisons++;
      }
    }
    
    return comparisons > 0 ? total_coherence / comparisons : 0;
  }

  /**
   * Calculate frequency synchronization
   */
  private calculateFrequencySynchronization(states: QuantumFieldState[]): number {
    const frequencies = states.map(s => s.frequency);
    const avg_frequency = frequencies.reduce((sum, freq) => sum + freq, 0) / frequencies.length;
    
    const variance = frequencies.reduce((sum, freq) => sum + Math.pow(freq - avg_frequency, 2), 0) / frequencies.length;
    const standard_deviation = Math.sqrt(variance);
    
    // Lower standard deviation = higher synchronization
    return Math.max(0, 1 - standard_deviation / avg_frequency);
  }

  /**
   * Calculate phase alignment
   */
  private calculatePhaseAlignment(states: QuantumFieldState[]): number {
    if (states.length < 2) return 1.0;
    
    let total_alignment = 0;
    let comparisons = 0;
    
    for (let i = 0; i < states.length; i++) {
      for (let j = i + 1; j < states.length; j++) {
        const phase_diff = Math.abs(states[i].phase - states[j].phase);
        const normalized_diff = Math.min(phase_diff, 360 - phase_diff);
        const alignment = Math.cos(normalized_diff * Math.PI / 180);
        
        total_alignment += alignment;
        comparisons++;
      }
    }
    
    return comparisons > 0 ? total_alignment / comparisons : 1.0;
  }

  /**
   * Calculate spiritual signature
   */
  private calculateSpiritualSignature(states: QuantumFieldState[]): number {
    let sacred_alignment = 0;
    
    for (const state of states) {
      const nearest_sacred = this.findNearestSacredFrequency(state.frequency);
      const alignment = 1 - Math.abs(state.frequency - nearest_sacred) / nearest_sacred;
      sacred_alignment += alignment;
    }
    
    return sacred_alignment / states.length;
  }

  /**
   * Calculate quantum entanglement
   */
  private calculateQuantumEntanglement(states: QuantumFieldState[], duration: number): number {
    const base_entanglement = states.reduce((sum, state) => sum + state.entanglement, 0) / states.length;
    const time_factor = Math.min(1.0, duration / 3600); // Max out after 1 hour
    const participant_factor = Math.min(1.0, states.length / 100);
    
    return base_entanglement * time_factor * participant_factor;
  }

  /**
   * Calculate ratio simplicity (mathematical harmony)
   */
  private calculateRatioSimplicity(ratio: number): number {
    // Simple ratios are more harmonious
    const tolerance = 0.01;
    const simple_ratios = [
      1, 2, 1.5, 1.333, 1.25, 1.2, 1.125, 1.111,
      0.5, 0.667, 0.75, 0.8, 0.833, 0.889, 0.9
    ];
    
    for (const simple_ratio of simple_ratios) {
      if (Math.abs(ratio - simple_ratio) < tolerance) {
        return 1.0;
      }
    }
    
    // Calculate based on denominator size when expressed as fraction
    const fraction = this.decimalToFraction(ratio);
    const denominator_size = fraction[1];
    return Math.max(0.1, 1 - denominator_size / 100);
  }

  /**
   * Convert decimal to fraction (simplified)
   */
  private decimalToFraction(decimal: number): [number, number] {
    const tolerance = 1.0E-6;
    let numerator = 1;
    let denominator = 1;
    
    while (Math.abs(decimal - numerator / denominator) > tolerance) {
      if (numerator / denominator < decimal) {
        numerator++;
      } else {
        denominator++;
      }
    }
    
    return [numerator, denominator];
  }
}

// Export singleton instance
export const quantumResonanceCalculator = new QuantumResonanceCalculator();