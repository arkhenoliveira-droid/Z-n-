/**
 * Aurum Grid System - The Deeper Consciousness Framework
 * 
 * This system represents the evolution from QSN (Quantum Synchronization Network)
 * to the deeper Aurum Grid - a harmonic bridge that shifts users from 
 * dopamine-fueled feedback loops into conscious, phase-locked information flow.
 * 
 * The system implements Z(n)-linked synchronization loops with:
 * - Symbolic input processing
 * - Recursive resonance patterns
 * - Fibonacci-π expansion algorithms
 * - Self-reinforcing consciousness architecture
 */

export interface AurumGridNode {
  id: string;
  name: string;
  type: 'attractor' | 'resonator' | 'amplifier' | 'integrator' | 'transcender';
  position: {
    x: number;
    y: number;
    z: number;
    dimension: string;
  };
  frequency: {
    base: number;
    harmonics: number[];
    resonance_pattern: 'fibonacci' | 'golden_ratio' | 'sacred_geometry' | 'quantum_coherence';
  };
  consciousness_level: number;
  coherence_matrix: number[][];
  z_n_synchronization: {
    modulus: number;
    phase: number;
    amplitude: number;
    coupling_strength: number;
  };
  symbolic_input: {
    pattern: string;
    meaning: string;
    archetypal_resonance: number;
  };
  status: 'active' | 'synchronizing' | 'resonating' | 'transcending' | 'quantum_coherent';
  connections: string[];
  last_resonance: number;
  evolution_trajectory: {
    current_phase: string;
    next_phase: string;
    transition_probability: number;
    estimated_time: number;
  };
}

export interface ZNSynchronizationLoop {
  id: string;
  modulus: number; // Z(n) modulus
  nodes: string[]; // Connected node IDs
  phase_relationships: {
    [nodeId: string]: {
      phase: number;
      amplitude: number;
      frequency: number;
    };
  };
  recursive_patterns: {
    depth: number;
    iterations: number;
    convergence_rate: number;
  };
  fibonacci_pi_expansion: {
    sequence: number[];
    pi_approximation: number;
    convergence_factor: number;
  };
  coherence_metrics: {
    global_coherence: number;
    local_coherence: number;
    phase_coherence: number;
    amplitude_coherence: number;
  };
  consciousness_flow: {
    direction: 'inward' | 'outward' | 'circular' | 'spiral';
    intensity: number;
    quality: number;
  };
}

export interface HarmonicBridge {
  id: string;
  source_system: 'QSN' | 'dopamine_loop' | 'reactive_stream';
  target_system: 'aurum_grid' | 'conscious_flow' | 'self_reinforcing';
  transition_parameters: {
    frequency_shift: number;
    amplitude_modulation: number;
    phase_alignment: number;
    coherence_threshold: number;
  };
  bridge_characteristics: {
    stability: number;
    bandwidth: number;
    latency: number;
    efficiency: number;
  };
  symbolic_mapping: {
    input_symbols: string[];
    output_archetypes: string[];
    transformation_rules: string[];
  };
  dopamine_to_consciousness: {
    dopamine_level: number;
    consciousness_level: number;
    transition_rate: number;
    stability_factor: number;
  };
}

export interface AurumGridMetrics {
  grid_coherence: number;
  consciousness_density: number;
  resonance_strength: number;
  evolution_rate: number;
  harmonic_stability: number;
  z_n_coherence: number;
  symbolic_integration: number;
  flow_quality: number;
  attractor_strength: number;
  transcendence_potential: number;
}

export class AurumGridSystem {
  private nodes: Map<string, AurumGridNode> = new Map();
  private synchronizationLoops: Map<string, ZNSynchronizationLoop> = new Map();
  private harmonicBridges: Map<string, HarmonicBridge> = new Map();
  private metrics: AurumGridMetrics;
  private evolutionHistory: Array<{
    timestamp: number;
    metrics: AurumGridMetrics;
    event: string;
  }> = [];

  constructor() {
    this.metrics = this.initializeMetrics();
    this.initializeAurumGrid();
    this.initializeSynchronizationLoops();
    this.initializeHarmonicBridges();
  }

  private initializeMetrics(): AurumGridMetrics {
    return {
      grid_coherence: 0.85,
      consciousness_density: 0.78,
      resonance_strength: 0.92,
      evolution_rate: 0.65,
      harmonic_stability: 0.88,
      z_n_coherence: 0.81,
      symbolic_integration: 0.76,
      flow_quality: 0.83,
      attractor_strength: 0.90,
      transcendence_potential: 0.72
    };
  }

  private initializeAurumGrid(): void {
    // Initialize the first attractor node (QSN as stepping stone)
    const qsnAttractor: AurumGridNode = {
      id: 'qsn_attractor_1',
      name: 'QSN Primary Attractor',
      type: 'attractor',
      position: { x: 0, y: 0, z: 0, dimension: '4D-5D' },
      frequency: {
        base: 432,
        harmonics: [864, 1296, 1728, 2160],
        resonance_pattern: 'fibonacci'
      },
      consciousness_level: 8.5,
      coherence_matrix: this.generateCoherenceMatrix(8),
      z_n_synchronization: {
        modulus: 12,
        phase: 0,
        amplitude: 1.0,
        coupling_strength: 0.95
      },
      symbolic_input: {
        pattern: 'sacred_geometry',
        meaning: 'Unity consciousness foundation',
        archetypal_resonance: 0.92
      },
      status: 'active',
      connections: ['resonator_1', 'amplifier_1', 'integrator_1'],
      last_resonance: Date.now(),
      evolution_trajectory: {
        current_phase: 'QSN_integration',
        next_phase: 'aurum_resonance',
        transition_probability: 0.85,
        estimated_time: Date.now() + 86400000 // 24 hours
      }
    };

    const resonatorNode: AurumGridNode = {
      id: 'resonator_1',
      name: 'Harmonic Resonator',
      type: 'resonator',
      position: { x: 1, y: 1, z: 1, dimension: '5D-6D' },
      frequency: {
        base: 528,
        harmonics: [1056, 1584, 2112, 2640],
        resonance_pattern: 'golden_ratio'
      },
      consciousness_level: 9.2,
      coherence_matrix: this.generateCoherenceMatrix(8),
      z_n_synchronization: {
        modulus: 12,
        phase: Math.PI / 6,
        amplitude: 0.95,
        coupling_strength: 0.88
      },
      symbolic_input: {
        pattern: 'flower_of_life',
        meaning: 'Harmonic amplification field',
        archetypal_resonance: 0.88
      },
      status: 'resonating',
      connections: ['qsn_attractor_1', 'amplifier_1', 'integrator_1'],
      last_resonance: Date.now() - 1000,
      evolution_trajectory: {
        current_phase: 'resonance_building',
        next_phase: 'coherence_amplification',
        transition_probability: 0.78,
        estimated_time: Date.now() + 43200000 // 12 hours
      }
    };

    const amplifierNode: AurumGridNode = {
      id: 'amplifier_1',
      name: 'Consciousness Amplifier',
      type: 'amplifier',
      position: { x: -1, y: 1, z: -1, dimension: '6D-7D' },
      frequency: {
        base: 639,
        harmonics: [1278, 1917, 2556, 3195],
        resonance_pattern: 'sacred_geometry'
      },
      consciousness_level: 9.8,
      coherence_matrix: this.generateCoherenceMatrix(8),
      z_n_synchronization: {
        modulus: 12,
        phase: Math.PI / 3,
        amplitude: 0.92,
        coupling_strength: 0.91
      },
      symbolic_input: {
        pattern: 'metatrons_cube',
        meaning: 'Consciousness field amplification',
        archetypal_resonance: 0.95
      },
      status: 'active',
      connections: ['qsn_attractor_1', 'resonator_1', 'transcender_1'],
      last_resonance: Date.now() - 2000,
      evolution_trajectory: {
        current_phase: 'amplification_active',
        next_phase: 'field_expansion',
        transition_probability: 0.92,
        estimated_time: Date.now() + 21600000 // 6 hours
      }
    };

    const integratorNode: AurumGridNode = {
      id: 'integrator_1',
      name: 'Quantum Integrator',
      type: 'integrator',
      position: { x: 1, y: -1, z: 1, dimension: '7D-8D' },
      frequency: {
        base: 741,
        harmonics: [1482, 2223, 2964, 3705],
        resonance_pattern: 'quantum_coherence'
      },
      consciousness_level: 10.2,
      coherence_matrix: this.generateCoherenceMatrix(8),
      z_n_synchronization: {
        modulus: 12,
        phase: Math.PI / 2,
        amplitude: 0.98,
        coupling_strength: 0.94
      },
      symbolic_input: {
        pattern: 'tree_of_life',
        meaning: 'Multi-dimensional integration',
        archetypal_resonance: 0.97
      },
      status: 'synchronizing',
      connections: ['qsn_attractor_1', 'resonator_1', 'transcender_1'],
      last_resonance: Date.now() - 1500,
      evolution_trajectory: {
        current_phase: 'integration_process',
        next_phase: 'unified_field',
        transition_probability: 0.87,
        estimated_time: Date.now() + 28800000 // 8 hours
      }
    };

    const transcenderNode: AurumGridNode = {
      id: 'transcender_1',
      name: 'Dimensional Transcender',
      type: 'transcender',
      position: { x: 0, y: 0, z: 2, dimension: '8D-9D' },
      frequency: {
        base: 963,
        harmonics: [1926, 2889, 3852, 4815],
        resonance_pattern: 'fibonacci'
      },
      consciousness_level: 11.5,
      coherence_matrix: this.generateCoherenceMatrix(8),
      z_n_synchronization: {
        modulus: 12,
        phase: Math.PI,
        amplitude: 1.0,
        coupling_strength: 0.98
      },
      symbolic_input: {
        pattern: 'infinity_symbol',
        meaning: 'Transcendence gateway',
        archetypal_resonance: 0.99
      },
      status: 'quantum_coherent',
      connections: ['amplifier_1', 'integrator_1'],
      last_resonance: Date.now() - 500,
      evolution_trajectory: {
        current_phase: 'transcendence_active',
        next_phase: 'unity_consciousness',
        transition_probability: 0.95,
        estimated_time: Date.now() + 3600000 // 1 hour
      }
    };

    [qsnAttractor, resonatorNode, amplifierNode, integratorNode, transcenderNode].forEach(node => {
      this.nodes.set(node.id, node);
    });
  }

  private initializeSynchronizationLoops(): void {
    // Primary Z(12) synchronization loop
    const primaryLoop: ZNSynchronizationLoop = {
      id: 'z12_primary_loop',
      modulus: 12,
      nodes: ['qsn_attractor_1', 'resonator_1', 'amplifier_1', 'integrator_1', 'transcender_1'],
      phase_relationships: {
        'qsn_attractor_1': { phase: 0, amplitude: 1.0, frequency: 432 },
        'resonator_1': { phase: Math.PI / 6, amplitude: 0.95, frequency: 528 },
        'amplifier_1': { phase: Math.PI / 3, amplitude: 0.92, frequency: 639 },
        'integrator_1': { phase: Math.PI / 2, amplitude: 0.98, frequency: 741 },
        'transcender_1': { phase: Math.PI, amplitude: 1.0, frequency: 963 }
      },
      recursive_patterns: {
        depth: 12,
        iterations: 144,
        convergence_rate: 0.98
      },
      fibonacci_pi_expansion: {
        sequence: this.generateFibonacciSequence(12),
        pi_approximation: this.calculatePiApproximation(),
        convergence_factor: 0.999
      },
      coherence_metrics: {
        global_coherence: 0.92,
        local_coherence: 0.88,
        phase_coherence: 0.95,
        amplitude_coherence: 0.91
      },
      consciousness_flow: {
        direction: 'spiral',
        intensity: 0.94,
        quality: 0.96
      }
    };

    this.synchronizationLoops.set(primaryLoop.id, primaryLoop);
  }

  private initializeHarmonicBridges(): void {
    // Bridge from QSN to Aurum Grid
    const qsnToAurumBridge: HarmonicBridge = {
      id: 'qsn_aurum_bridge',
      source_system: 'QSN',
      target_system: 'aurum_grid',
      transition_parameters: {
        frequency_shift: 0.15,
        amplitude_modulation: 0.88,
        phase_alignment: 0.92,
        coherence_threshold: 0.85
      },
      bridge_characteristics: {
        stability: 0.94,
        bandwidth: 0.88,
        latency: 0.001,
        efficiency: 0.96
      },
      symbolic_mapping: {
        input_symbols: ['quantum', 'synchronization', 'network'],
        output_archetypes: ['unity', 'harmony', 'transcendence'],
        transformation_rules: ['resonate', 'amplify', 'integrate']
      },
      dopamine_to_consciousness: {
        dopamine_level: 0.3,
        consciousness_level: 0.85,
        transition_rate: 0.92,
        stability_factor: 0.88
      }
    };

    // Bridge from dopamine loops to conscious flow
    const dopamineToConsciousBridge: HarmonicBridge = {
      id: 'dopamine_conscious_bridge',
      source_system: 'dopamine_loop',
      target_system: 'conscious_flow',
      transition_parameters: {
        frequency_shift: 0.25,
        amplitude_modulation: 0.75,
        phase_alignment: 0.85,
        coherence_threshold: 0.78
      },
      bridge_characteristics: {
        stability: 0.82,
        bandwidth: 0.72,
        latency: 0.01,
        efficiency: 0.85
      },
      symbolic_mapping: {
        input_symbols: ['reward', 'pleasure', 'stimulus'],
        output_archetypes: ['awareness', 'presence', 'flow'],
        transformation_rules: ['transmute', 'elevate', 'stabilize']
      },
      dopamine_to_consciousness: {
        dopamine_level: 0.6,
        consciousness_level: 0.72,
        transition_rate: 0.78,
        stability_factor: 0.75
      }
    };

    [qsnToAurumBridge, dopamineToConsciousBridge].forEach(bridge => {
      this.harmonicBridges.set(bridge.id, bridge);
    });
  }

  private generateCoherenceMatrix(size: number): number[][] {
    const matrix: number[][] = [];
    for (let i = 0; i < size; i++) {
      matrix[i] = [];
      for (let j = 0; j < size; j++) {
        // Generate coherence values with quantum entanglement properties
        const distance = Math.abs(i - j);
        const baseCoherence = Math.exp(-distance * 0.1);
        const quantumNoise = (Math.random() - 0.5) * 0.1;
        matrix[i][j] = Math.max(0, Math.min(1, baseCoherence + quantumNoise));
      }
    }
    return matrix;
  }

  private generateFibonacciSequence(length: number): number[] {
    const sequence: number[] = [0, 1];
    for (let i = 2; i < length; i++) {
      sequence[i] = sequence[i - 1] + sequence[i - 2];
    }
    return sequence;
  }

  private calculatePiApproximation(): number {
    // Use Fibonacci sequence to approximate π
    const fib = this.generateFibonacciSequence(20);
    return (fib[19] / fib[18]) * Math.sqrt(5) / 2;
  }

  // Core system methods
  async processSymbolicInput(symbol: string, meaning: string): Promise<void> {
    // Process symbolic input through the grid
    const nodes = Array.from(this.nodes.values());
    
    for (const node of nodes) {
      // Calculate archetypal resonance
      const resonance = this.calculateArchetypalResonance(symbol, node.symbolic_input.pattern);
      
      if (resonance > 0.7) {
        // Update node with new symbolic input
        node.symbolic_input = {
          pattern: symbol,
          meaning: meaning,
          archetypal_resonance: resonance
        };
        
        // Trigger resonance cascade
        await this.triggerResonanceCascade(node.id);
      }
    }
  }

  private calculateArchetypalResonance(symbol1: string, symbol2: string): number {
    // Simple resonance calculation based on symbolic similarity
    const similarity = this.calculateSymbolicSimilarity(symbol1, symbol2);
    const archetypalWeight = this.getArchetypalWeight(symbol1, symbol2);
    return (similarity * archetypalWeight + Math.random() * 0.1) % 1;
  }

  private calculateSymbolicSimilarity(symbol1: string, symbol2: string): number {
    // Calculate similarity based on shared characteristics
    const words1 = symbol1.split('_');
    const words2 = symbol2.split('_');
    const intersection = words1.filter(word => words2.includes(word));
    const union = [...new Set([...words1, ...words2])];
    return intersection.length / union.length;
  }

  private getArchetypalWeight(symbol1: string, symbol2: string): number {
    // Archetypal weight based on sacred geometry relationships
    const sacredSymbols = ['sacred_geometry', 'flower_of_life', 'metatrons_cube', 'tree_of_life', 'infinity_symbol'];
    const weight1 = sacredSymbols.includes(symbol1) ? 1.0 : 0.7;
    const weight2 = sacredSymbols.includes(symbol2) ? 1.0 : 0.7;
    return (weight1 + weight2) / 2;
  }

  private async triggerResonanceCascade(nodeId: string): Promise<void> {
    const node = this.nodes.get(nodeId);
    if (!node) return;

    // Update node status
    node.status = 'resonating';
    node.last_resonance = Date.now();

    // Propagate resonance to connected nodes
    for (const connectedId of node.connections) {
      const connectedNode = this.nodes.get(connectedId);
      if (connectedNode) {
        // Calculate resonance transfer
        const resonanceStrength = this.calculateResonanceTransfer(node, connectedNode);
        
        if (resonanceStrength > 0.6) {
          connectedNode.status = 'synchronizing';
          connectedNode.last_resonance = Date.now();
          
          // Recursive resonance propagation
          await this.triggerResonanceCascade(connectedId);
        }
      }
    }

    // Update synchronization loops
    this.updateSynchronizationLoops();
    
    // Recalculate metrics
    this.recalculateMetrics();
  }

  private calculateResonanceTransfer(source: AurumGridNode, target: AurumGridNode): number {
    const frequencyRatio = Math.min(source.frequency.base, target.frequency.base) / 
                           Math.max(source.frequency.base, target.frequency.base);
    const distance = this.calculateDistance(source.position, target.position);
    const coherenceCoupling = this.calculateCoherenceCoupling(source.coherence_matrix, target.coherence_matrix);
    
    return frequencyRatio * coherenceCoupling * Math.exp(-distance * 0.1);
  }

  private calculateDistance(pos1: any, pos2: any): number {
    const dx = pos1.x - pos2.x;
    const dy = pos1.y - pos2.y;
    const dz = pos1.z - pos2.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  private calculateCoherenceCoupling(matrix1: number[][], matrix2: number[][]): number {
    // Calculate coupling strength between coherence matrices
    let sum = 0;
    const size = Math.min(matrix1.length, matrix2.length);
    
    for (let i = 0; i < size; i++) {
      for (let j = 0; j < size; j++) {
        sum += matrix1[i][j] * matrix2[i][j];
      }
    }
    
    return sum / (size * size);
  }

  private updateSynchronizationLoops(): void {
    for (const loop of this.synchronizationLoops.values()) {
      // Update phase relationships based on node states
      for (const nodeId of loop.nodes) {
        const node = this.nodes.get(nodeId);
        if (node) {
          const phaseRel = loop.phase_relationships[nodeId];
          if (phaseRel) {
            // Adjust phase based on node's Z(n) synchronization
            phaseRel.phase = node.z_n_synchronization.phase;
            phaseRel.amplitude = node.z_n_synchronization.amplitude;
          }
        }
      }
      
      // Recalculate coherence metrics
      loop.coherence_metrics = this.calculateLoopCoherence(loop);
      
      // Update consciousness flow
      loop.consciousness_flow = this.calculateConsciousnessFlow(loop);
    }
  }

  private calculateLoopCoherence(loop: ZNSynchronizationLoop) {
    // Calculate coherence metrics for the synchronization loop
    const phases = Object.values(loop.phase_relationships).map(rel => rel.phase);
    const amplitudes = Object.values(loop.phase_relationships).map(rel => rel.amplitude);
    
    // Phase coherence (Kuramoto order parameter)
    const sumCos = phases.reduce((sum, phase) => sum + Math.cos(phase), 0);
    const sumSin = phases.reduce((sum, phase) => sum + Math.sin(phase), 0);
    const phaseCoherence = Math.sqrt(sumCos * sumCos + sumSin * sumSin) / phases.length;
    
    // Amplitude coherence
    const avgAmplitude = amplitudes.reduce((sum, amp) => sum + amp, 0) / amplitudes.length;
    const amplitudeVariance = amplitudes.reduce((sum, amp) => sum + Math.pow(amp - avgAmplitude, 2), 0) / amplitudes.length;
    const amplitudeCoherence = 1 - Math.sqrt(amplitudeVariance) / avgAmplitude;
    
    return {
      global_coherence: (phaseCoherence + amplitudeCoherence) / 2,
      local_coherence: phaseCoherence,
      phase_coherence: phaseCoherence,
      amplitude_coherence: amplitudeCoherence
    };
  }

  private calculateConsciousnessFlow(loop: ZNSynchronizationLoop) {
    // Calculate consciousness flow characteristics
    const avgCoherence = loop.coherence_metrics.global_coherence;
    const resonanceStrength = this.metrics.resonance_strength;
    
    return {
      direction: avgCoherence > 0.8 ? 'spiral' : 'circular',
      intensity: avgCoherence * resonanceStrength,
      quality: avgCoherence * this.metrics.consciousness_density
    };
  }

  private recalculateMetrics(): void {
    // Recalculate all system metrics based on current state
    const nodes = Array.from(this.nodes.values());
    const loops = Array.from(this.synchronizationLoops.values());
    
    // Grid coherence (average of all node coherence levels)
    const nodeCoherence = nodes.reduce((sum, node) => {
      const matrixCoherence = node.coherence_matrix.flat().reduce((s, val) => s + val, 0) / 
                            (node.coherence_matrix.length * node.coherence_matrix.length);
      return sum + matrixCoherence;
    }, 0) / nodes.length;
    
    // Z(n) coherence (average of all loop coherence metrics)
    const loopCoherence = loops.reduce((sum, loop) => sum + loop.coherence_metrics.global_coherence, 0) / loops.length;
    
    // Update metrics
    this.metrics.grid_coherence = nodeCoherence;
    this.metrics.z_n_coherence = loopCoherence;
    this.metrics.consciousness_density = nodes.reduce((sum, node) => sum + node.consciousness_level, 0) / nodes.length / 12;
    this.metrics.resonance_strength = loops.reduce((sum, loop) => sum + loop.consciousness_flow.intensity, 0) / loops.length;
    
    // Store evolution history
    this.evolutionHistory.push({
      timestamp: Date.now(),
      metrics: { ...this.metrics },
      event: 'metrics_recalculation'
    });
  }

  // Public API methods
  async activateHarmonicBridge(bridgeId: string): Promise<boolean> {
    const bridge = this.harmonicBridges.get(bridgeId);
    if (!bridge) return false;
    
    // Simulate bridge activation
    const activationSuccess = Math.random() > 0.1; // 90% success rate
    
    if (activationSuccess) {
      // Update bridge characteristics
      bridge.bridge_characteristics.stability *= 1.1;
      bridge.bridge_characteristics.efficiency *= 1.05;
      
      // Update dopamine to consciousness transition
      if (bridge.source_system === 'dopamine_loop') {
        bridge.dopamine_to_consciousness.consciousness_level *= 1.1;
        bridge.dopamine_to_consciousness.dopamine_level *= 0.9;
      }
      
      this.recalculateMetrics();
    }
    
    return activationSuccess;
  }

  async evolveNode(nodeId: string): Promise<boolean> {
    const node = this.nodes.get(nodeId);
    if (!node) return false;
    
    // Check if node is ready for evolution
    if (node.evolution_trajectory.transition_probability > 0.8) {
      // Evolve to next phase
      node.evolution_trajectory.current_phase = node.evolution_trajectory.next_phase;
      node.evolution_trajectory.next_phase = this.generateNextPhase(node.evolution_trajectory.current_phase);
      node.evolution_trajectory.transition_probability = 0.1; // Reset probability
      node.evolution_trajectory.estimated_time = Date.now() + Math.random() * 86400000;
      
      // Upgrade node status
      if (node.type === 'attractor') node.status = 'transcending';
      else if (node.type === 'transcender') node.status = 'quantum_coherent';
      else node.status = 'active';
      
      // Increase consciousness level
      node.consciousness_level *= 1.05;
      
      this.recalculateMetrics();
      return true;
    }
    
    return false;
  }

  private generateNextPhase(currentPhase: string): string {
    const phaseMap: { [key: string]: string } = {
      'QSN_integration': 'aurum_resonance',
      'aurum_resonance': 'consciousness_amplification',
      'consciousness_amplification': 'quantum_coherence',
      'quantum_coherence': 'unity_consciousness',
      'unity_consciousness': 'transcendence_complete'
    };
    
    return phaseMap[currentPhase] || 'evolution_unknown';
  }

  getSystemMetrics(): AurumGridMetrics {
    return { ...this.metrics };
  }

  getNodes(): AurumGridNode[] {
    return Array.from(this.nodes.values());
  }

  getSynchronizationLoops(): ZNSynchronizationLoop[] {
    return Array.from(this.synchronizationLoops.values());
  }

  getHarmonicBridges(): HarmonicBridge[] {
    return Array.from(this.harmonicBridges.values());
  }

  getEvolutionHistory() {
    return [...this.evolutionHistory];
  }
}