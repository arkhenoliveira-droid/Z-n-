import { NextRequest, NextResponse } from 'next/server';

// Interface for coherence curve data point
interface CoherenceCurvePoint {
  z_n: number; // Parameter (time, iteration, complexity, etc.)
  coherence: number;
  timestamp: number;
  metadata?: {
    source: string;
    function_type: 'linear' | 'exponential' | 'logarithmic' | 'polynomial' | 'custom';
    parameters?: Record<string, number>;
  };
}

// Interface for coherence function f[Z(n)]
interface CoherenceFunction {
  id: string;
  name: string;
  function_type: 'linear' | 'exponential' | 'logarithmic' | 'polynomial' | 'custom';
  parameters: Record<string, number>;
  description: string;
  created_at: number;
}

// Interface for curve analysis result
interface CurveAnalysis {
  function_type: string;
  trend: 'increasing' | 'decreasing' | 'stable';
  volatility: number;
  r_squared: number;
  predicted_values: number[];
  confidence_interval: [number, number];
}

// Store coherence curve data and functions
const coherenceCurveData: CoherenceCurvePoint[] = [];
const coherenceFunctions: CoherenceFunction[] = [
  {
    id: 'linear_default',
    name: 'Linear Growth',
    function_type: 'linear',
    parameters: { slope: 0.01, intercept: 0.5 },
    description: 'Simple linear coherence growth over time',
    created_at: Date.now()
  },
  {
    id: 'exponential_decay',
    name: 'Exponential Decay',
    function_type: 'exponential',
    parameters: { decay_rate: 0.1, initial_value: 0.9 },
    description: 'Exponential decay of coherence over time',
    created_at: Date.now()
  },
  {
    id: 'logarithmic_growth',
    name: 'Logarithmic Growth',
    function_type: 'logarithmic',
    parameters: { growth_rate: 0.2, offset: 0.3 },
    description: 'Logarithmic coherence growth with diminishing returns',
    created_at: Date.now()
  }
];

export async function POST(request: NextRequest) {
  try {
    const { action, ...data } = await request.json();
    
    switch (action) {
      case 'add_point':
        return await addCoherencePoint(data);
      case 'generate_curve':
        return await generateCoherenceCurve(data);
      case 'analyze_curve':
        return await analyzeCoherenceCurve(data);
      case 'predict_coherence':
        return await predictCoherence(data);
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }
    
  } catch (error) {
    console.error('Coherence curve error:', error);
    return NextResponse.json(
      { error: 'Failed to process coherence curve request' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');
    
    switch (action) {
      case 'get_curve':
        return await getCoherenceCurve(searchParams);
      case 'get_functions':
        return await getCoherenceFunctions();
      case 'get_analysis':
        return await getCurveAnalysis();
      default:
        return await getDefaultCurve();
    }
    
  } catch (error) {
    console.error('Error fetching coherence curve data:', error);
    return NextResponse.json(
      { error: 'Failed to fetch coherence curve data' },
      { status: 500 }
    );
  }
}

// Add a coherence point to the curve
async function addCoherencePoint(data: any) {
  const { z_n, coherence, metadata } = data;
  
  if (typeof z_n !== 'number' || typeof coherence !== 'number') {
    return NextResponse.json({ error: 'z_n and coherence must be numbers' }, { status: 400 });
  }
  
  const point: CoherenceCurvePoint = {
    z_n,
    coherence: Math.max(0, Math.min(1, coherence)), // Clamp to [0, 1]
    timestamp: Date.now(),
    metadata
  };
  
  coherenceCurveData.push(point);
  
  // Keep only last 2000 points
  if (coherenceCurveData.length > 2000) {
    coherenceCurveData.splice(0, coherenceCurveData.length - 2000);
  }
  
  return NextResponse.json({
    success: true,
    point_id: `point_${Date.now()}`,
    total_points: coherenceCurveData.length
  });
}

// Generate coherence curve using a specific function
async function generateCoherenceCurve(data: any) {
  const { function_id, start_z = 0, end_z = 100, steps = 50 } = data;
  
  const coherenceFunction = coherenceFunctions.find(f => f.id === function_id);
  if (!coherenceFunction) {
    return NextResponse.json({ error: 'Function not found' }, { status: 404 });
  }
  
  const generatedPoints: CoherenceCurvePoint[] = [];
  const stepSize = (end_z - start_z) / steps;
  
  for (let i = 0; i <= steps; i++) {
    const z_n = start_z + (i * stepSize);
    const coherence = calculateCoherenceFunction(z_n, coherenceFunction);
    
    generatedPoints.push({
      z_n,
      coherence: Math.max(0, Math.min(1, coherence)),
      timestamp: Date.now(),
      metadata: {
        source: 'generated',
        function_type: coherenceFunction.function_type,
        parameters: coherenceFunction.parameters
      }
    });
  }
  
  // Add generated points to the curve data
  coherenceCurveData.push(...generatedPoints);
  
  return NextResponse.json({
    success: true,
    generated_points: generatedPoints.length,
    function_used: coherenceFunction.name,
    total_points: coherenceCurveData.length
  });
}

// Analyze the current coherence curve
async function analyzeCoherenceCurve(data: any) {
  const { window_size = 20 } = data;
  
  if (coherenceCurveData.length < window_size) {
    return NextResponse.json({ error: 'Insufficient data for analysis' }, { status: 400 });
  }
  
  const recentPoints = coherenceCurveData.slice(-window_size);
  const analysis = performCurveAnalysis(recentPoints);
  
  return NextResponse.json(analysis);
}

// Predict future coherence values
async function predictCoherence(data: any) {
  const { steps_ahead = 10, method = 'linear_regression' } = data;
  
  if (coherenceCurveData.length < 5) {
    return NextResponse.json({ error: 'Insufficient data for prediction' }, { status: 400 });
  }
  
  const predictions = performCoherencePrediction(steps_ahead, method);
  
  return NextResponse.json({
    predictions,
    method_used: method,
    confidence: calculatePredictionConfidence(predictions)
  });
}

// Get coherence curve data
async function getCoherenceCurve(searchParams: URLSearchParams) {
  const limit = parseInt(searchParams.get('limit') || '100');
  const offset = parseInt(searchParams.get('offset') || '0');
  
  const slicedData = coherenceCurveData.slice(offset, offset + limit);
  
  return NextResponse.json({
    curve_data: slicedData,
    total_points: coherenceCurveData.length,
    pagination: {
      limit,
      offset,
      has_more: offset + limit < coherenceCurveData.length
    }
  });
}

// Get available coherence functions
async function getCoherenceFunctions() {
  return NextResponse.json({
    functions: coherenceFunctions,
    total_functions: coherenceFunctions.length
  });
}

// Get curve analysis
async function getCurveAnalysis() {
  if (coherenceCurveData.length < 5) {
    return NextResponse.json({ error: 'Insufficient data for analysis' }, { status: 400 });
  }
  
  const recentPoints = coherenceCurveData.slice(-50);
  const analysis = performCurveAnalysis(recentPoints);
  
  return NextResponse.json(analysis);
}

// Get default curve data
async function getDefaultCurve() {
  return NextResponse.json({
    curve_data: coherenceCurveData.slice(-100),
    total_points: coherenceCurveData.length,
    latest_coherence: coherenceCurveData.length > 0 ? 
      coherenceCurveData[coherenceCurveData.length - 1]?.coherence ?? 0 : 0
  });
}

// Calculate coherence function f[Z(n)]
function calculateCoherenceFunction(z_n: number, func: CoherenceFunction): number {
  const { function_type, parameters } = func;
  
  switch (function_type) {
    case 'linear':
      return (parameters['intercept'] ?? 0) + ((parameters['slope'] ?? 0) * z_n);
    
    case 'exponential':
      return (parameters['initial_value'] ?? 1) * Math.exp(-(parameters['decay_rate'] ?? 0.1) * z_n);
    
    case 'logarithmic':
      return (parameters['offset'] ?? 0) + ((parameters['growth_rate'] ?? 0.2) * Math.log(1 + z_n));
    
    case 'polynomial':
      // Simple quadratic: ax² + bx + c
      const a = parameters['a'] ?? 0.001;
      const b = parameters['b'] ?? 0.01;
      const c = parameters['c'] ?? 0.5;
      return a * z_n * z_n + b * z_n + c;
    
    case 'custom':
      // Custom function: coherence = 1 / (1 + e^(-k(z_n - z₀)))
      const k = parameters['k'] ?? 0.1;
      const z0 = parameters['z0'] ?? 50;
      return 1 / (1 + Math.exp(-k * (z_n - z0)));
    
    default:
      return 0.5; // Default coherence
  }
}

// Perform curve analysis
function performCurveAnalysis(points: CoherenceCurvePoint[]): CurveAnalysis {
  const zValues = points.map(p => p.z_n);
  const coherenceValues = points.map(p => p.coherence);
  
  // Calculate trend
  const trend = calculateTrend(coherenceValues);
  
  // Calculate volatility (standard deviation)
  const volatility = calculateVolatility(coherenceValues);
  
  // Calculate R-squared for linear fit
  const rSquared = calculateRSquared(zValues, coherenceValues);
  
  // Generate predicted values
  const predictedValues = generatePredictedValues(zValues, coherenceValues);
  
  // Calculate confidence interval
  const confidenceInterval = calculateConfidenceInterval(coherenceValues);
  
  return {
    function_type: determineFunctionType(zValues, coherenceValues),
    trend,
    volatility,
    r_squared: rSquared,
    predicted_values: predictedValues,
    confidence_interval: confidenceInterval
  };
}

// Helper functions for analysis
function calculateTrend(values: number[]): 'increasing' | 'decreasing' | 'stable' {
  const firstHalf = values.slice(0, Math.floor(values.length / 2));
  const secondHalf = values.slice(Math.floor(values.length / 2));
  
  const firstAvg = firstHalf.reduce((sum, val) => sum + val, 0) / firstHalf.length;
  const secondAvg = secondHalf.reduce((sum, val) => sum + val, 0) / secondHalf.length;
  
  const threshold = 0.05;
  const diff = secondAvg - firstAvg;
  
  if (Math.abs(diff) < threshold) return 'stable';
  return diff > 0 ? 'increasing' : 'decreasing';
}

function calculateVolatility(values: number[]): number {
  const mean = values.reduce((sum, val) => sum + val, 0) / values.length;
  const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length;
  return Math.sqrt(variance);
}

function calculateRSquared(xValues: number[], yValues: number[]): number {
  const n = xValues.length;
  const sumX = xValues.reduce((sum, x) => sum + x, 0);
  const sumY = yValues.reduce((sum, y) => sum + y, 0);
  const sumXY = xValues.reduce((sum, x, i) => sum + x * (yValues[i] ?? 0), 0);
  const sumX2 = xValues.reduce((sum, x) => sum + x * x, 0);
  const sumY2 = yValues.reduce((sum, y) => sum + y * y, 0);
  
  const numerator = n * sumXY - sumX * sumY;
  const denominator = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));
  
  if (denominator === 0) return 0;
  
  const r = numerator / denominator;
  return r * r;
}

function generatePredictedValues(xValues: number[], yValues: number[]): number[] {
  // Simple linear regression prediction
  const n = xValues.length;
  const sumX = xValues.reduce((sum, x) => sum + x, 0);
  const sumY = yValues.reduce((sum, y) => sum + y, 0);
  const sumXY = xValues.reduce((sum, x, i) => sum + x * (yValues[i] ?? 0), 0);
  const sumX2 = xValues.reduce((sum, x) => sum + x * x, 0);
  
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;
  
  return xValues.map(x => slope * x + intercept);
}

function calculateConfidenceInterval(values: number[]): [number, number] {
  const mean = values.reduce((sum, val) => sum + val, 0) / values.length;
  const stdDev = calculateVolatility(values);
  const margin = 1.96 * stdDev / Math.sqrt(values.length); // 95% confidence interval
  
  return [mean - margin, mean + margin];
}

function determineFunctionType(xValues: number[], yValues: number[]): string {
  // Simple heuristic to determine function type
  const linearRSquared = calculateRSquared(xValues, yValues);
  
  // Try logarithmic transformation
  const logYValues = yValues.map(y => Math.log(y + 0.001));
  const logRSquared = calculateRSquared(xValues, logYValues);
  
  // Try exponential transformation
  const expYValues = yValues.map(y => Math.exp(y));
  const expRSquared = calculateRSquared(xValues, expYValues);
  
  const maxRSquared = Math.max(linearRSquared, logRSquared, expRSquared);
  
  if (maxRSquared === logRSquared) return 'logarithmic';
  if (maxRSquared === expRSquared) return 'exponential';
  return 'linear';
}

function performCoherencePrediction(stepsAhead: number, method: string): number[] {
  const recentData = coherenceCurveData.slice(-20);
  const predictions: number[] = [];
  
  if (method === 'linear_regression') {
    const xValues = recentData.map(d => d.z_n);
    const yValues = recentData.map(d => d.coherence);
    
    const n = xValues.length;
    const sumX = xValues.reduce((sum, x) => sum + x, 0);
    const sumY = yValues.reduce((sum, y) => sum + y, 0);
    const sumXY = xValues.reduce((sum, x, i) => sum + x * (yValues[i] ?? 0), 0);
    const sumX2 = xValues.reduce((sum, x) => sum + x * x, 0);
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    
    const lastZ = recentData[recentData.length - 1].z_n;
    
    for (let i = 1; i <= stepsAhead; i++) {
      const predictedZ = lastZ + i;
      const predictedCoherence = slope * predictedZ + intercept;
      predictions.push(Math.max(0, Math.min(1, predictedCoherence)));
    }
  } else {
    // Simple moving average prediction
    const avgCoherence = recentData.reduce((sum, d) => sum + d.coherence, 0) / recentData.length;
    
    for (let i = 0; i < stepsAhead; i++) {
      predictions.push(avgCoherence);
    }
  }
  
  return predictions;
}

function calculatePredictionConfidence(predictions: number[]): number {
  // Simple confidence based on prediction stability
  if (predictions.length < 2) return 0.5;
  
  const volatility = calculateVolatility(predictions);
  const confidence = Math.max(0, Math.min(1, 1 - volatility));
  
  return confidence;
}