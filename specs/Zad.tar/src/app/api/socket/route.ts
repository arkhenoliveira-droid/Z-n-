import { NextRequest, NextResponse } from 'next/server';
import { Server as ServerIO } from 'socket.io';
import { Server as NetServer } from 'http';
import ZAI from 'z-ai-web-dev-sdk';

// Global state for real-time processing
const globalState = {
  coherenceHistory: [] as Array<{ timestamp: number; coherence: number; source: string }>,
  vectorCount: 0,
  analysisCount: 0,
  lastUpdateTime: Date.now(),
  isProcessing: false,
  dataProcessor: null as any
};

// Real-time data processor
class RealTimeDataProcessor {
  private io: ServerIO;
  private zai: ZAI | null = null;
  private processingInterval: NodeJS.Timeout | null = null;

  constructor(io: ServerIO) {
    this.io = io;
    this.initialize();
  }

  private async initialize() {
    try {
      this.zai = await ZAI.create();
      this.startProcessing();
      console.log('Real-time data processor initialized');
    } catch (error) {
      console.error('Failed to initialize real-time processor:', error);
    }
  }

  private startProcessing() {
    // Process data every 5 seconds
    this.processingInterval = setInterval(async () => {
      if (!globalState.isProcessing) {
        await this.processBatchData();
      }
    }, 5000);

    // Generate synthetic coherence data for demonstration
    this.generateSyntheticData();
  }

  private async processBatchData() {
    globalState.isProcessing = true;
    
    try {
      // Process any pending analyses or vector updates
      const updates: any[] = [];

      // Generate coherence trend analysis
      if (globalState.coherenceHistory.length > 10) {
        const recentData = globalState.coherenceHistory.slice(-10);
        const trendAnalysis = this.analyzeCoherenceTrend(recentData);
        
        updates.push({
          type: 'coherence_update',
          data: {
            timestamp: Date.now(),
            coherence_score: trendAnalysis.currentCoherence,
            source: 'trend_analysis',
            metadata: {
              trend: trendAnalysis.trend,
              volatility: trendAnalysis.volatility,
              average: trendAnalysis.average
            }
          }
        });
      }

      // Broadcast updates to all connected clients
      if (updates.length > 0) {
        this.io.emit('system_update', updates);
      }

    } catch (error) {
      console.error('Error processing batch data:', error);
    } finally {
      globalState.isProcessing = false;
    }
  }

  private generateSyntheticData() {
    // Generate synthetic coherence data for demonstration
    setInterval(() => {
      const baseCoherence = 0.7;
      const variation = (Math.random() - 0.5) * 0.2;
      const coherence = Math.max(0, Math.min(1, baseCoherence + variation));
      
      const update = {
        type: 'coherence_update',
        data: {
          timestamp: Date.now(),
          coherence_score: coherence,
          source: 'synthetic_generator'
        }
      };

      globalState.coherenceHistory.push({
        timestamp: update.data.timestamp,
        coherence: update.data.coherence_score,
        source: update.data.source
      });

      // Keep only last 1000 entries
      if (globalState.coherenceHistory.length > 1000) {
        globalState.coherenceHistory = globalState.coherenceHistory.slice(-1000);
      }

      this.io.emit('system_update', [update]);
    }, 2000);
  }

  private analyzeCoherenceTrend(data: Array<{ timestamp: number; coherence: number; source: string }>) {
    const coherences = data.map(d => d.coherence);
    const average = coherences.reduce((sum, c) => sum + c, 0) / coherences.length;
    
    // Calculate trend
    const firstHalf = coherences.slice(0, Math.floor(coherences.length / 2));
    const secondHalf = coherences.slice(Math.floor(coherences.length / 2));
    const firstAvg = firstHalf.reduce((sum, c) => sum + c, 0) / firstHalf.length;
    const secondAvg = secondHalf.reduce((sum, c) => sum + c, 0) / secondHalf.length;
    
    let trend: 'increasing' | 'decreasing' | 'stable' = 'stable';
    if (secondAvg > firstAvg + 0.05) trend = 'increasing';
    else if (secondAvg < firstAvg - 0.05) trend = 'decreasing';
    
    // Calculate volatility (standard deviation)
    const variance = coherences.reduce((sum, c) => sum + Math.pow(c - average, 2), 0) / coherences.length;
    const volatility = Math.sqrt(variance);
    
    return {
      currentCoherence: coherences[coherences.length - 1],
      average,
      trend,
      volatility
    };
  }

  public async processZeitgeistAnalysis(prompt: string): Promise<any> {
    if (!this.zai) {
      throw new Error('ZAI not initialized');
    }

    const startTime = Date.now();
    
    try {
      const completion = await this.zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are a sophisticated AI assistant that analyzes and synthesizes information about current trends, cultural phenomena, and the collective consciousness (Zeitgeist). Provide coherent, well-structured insights that capture the essence of the topic in relation to contemporary reality.'
          },
          {
            role: 'user',
            content: `Analyze the following topic in the context of current Zeitgeist: ${prompt}`
          }
        ],
        model: 'grok-4',
        max_tokens: 1000,
        temperature: 0.7
      });

      const responseText = completion.choices[0]?.message?.content || '';
      
      // Generate embedding for coherence calculation
      const embeddingResponse = await this.zai.embeddings.create({
        input: responseText,
        model: 'text-embedding-3-large'
      });
      
      const embedding = embeddingResponse.data[0]?.embedding || [];
      const coherence_score = this.calculateCoherenceScore(embedding);
      
      const processingTime = Date.now() - startTime;
      
      const analysisData = {
        analysis_id: `analysis_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        prompt,
        response: responseText,
        coherence_score,
        processing_time,
        timestamp: Date.now()
      };

      // Update global state
      globalState.analysisCount++;
      
      // Broadcast to clients
      this.io.emit('system_update', [{
        type: 'analysis_update',
        data: analysisData
      }]);

      return analysisData;
      
    } catch (error) {
      console.error('Error processing Zeitgeist analysis:', error);
      throw error;
    }
  }

  private calculateCoherenceScore(embedding: number[]): number {
    if (!embedding || embedding.length === 0) return 0;
    
    const magnitude = Math.sqrt(embedding.reduce((sum, val) => sum + val * val, 0));
    const mean = embedding.reduce((sum, val) => sum + val, 0) / embedding.length;
    const variance = embedding.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / embedding.length;
    
    const normalizedVariance = Math.min(1, variance / 0.1);
    const coherenceScore = (magnitude / 10) * (1 - normalizedVariance) * 0.8 + 0.2;
    
    return Math.min(1, Math.max(0, coherenceScore));
  }

  public getSystemStats() {
    return {
      coherence_history_length: globalState.coherenceHistory.length,
      vector_count: globalState.vectorCount,
      analysis_count: globalState.analysisCount,
      last_update_time: globalState.lastUpdateTime,
      is_processing: globalState.isProcessing,
      current_coherence: globalState.coherenceHistory.length > 0 
        ? globalState.coherenceHistory[globalState.coherenceHistory.length - 1].coherence 
        : 0
    };
  }

  public shutdown() {
    if (this.processingInterval) {
      clearInterval(this.processingInterval);
    }
  }
}

// This route handles WebSocket connections for real-time updates
export async function GET(request: NextRequest) {
  try {
    // This is a simple health check for the WebSocket endpoint
    return NextResponse.json({
      message: 'WebSocket endpoint is available',
      status: 'active',
      timestamp: Date.now()
    });
  } catch (error) {
    console.error('WebSocket route error:', error);
    return NextResponse.json(
      { error: 'Failed to access WebSocket endpoint' },
      { status: 500 }
    );
  }
}

// Initialize Socket.IO server (this would be called from the main server)
function initializeSocketIO(server: NetServer) {
  const io = new ServerIO(server, {
    path: '/api/socket',
    addTrailingSlash: false,
    cors: {
      origin: '*',
      methods: ['GET', 'POST']
    }
  });

  // Initialize real-time data processor
  const dataProcessor = new RealTimeDataProcessor(io);
  globalState.dataProcessor = dataProcessor;

  // Handle client connections
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);

    // Send current system stats to new client
    socket.emit('system_stats', dataProcessor.getSystemStats());

    // Handle client requests for Zeitgeist analysis
    socket.on('request_analysis', async (data: { prompt: string }) => {
      try {
        const analysis = await dataProcessor.processZeitgeistAnalysis(data.prompt);
        socket.emit('analysis_result', analysis);
      } catch (error) {
        socket.emit('analysis_error', { error: 'Failed to process analysis' });
      }
    });

    // Handle requests for system stats
    socket.on('request_stats', () => {
      socket.emit('system_stats', dataProcessor.getSystemStats());
    });

    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
    });
  });

  return io;
}

// Export for external use
export type { RealTimeDataProcessor };