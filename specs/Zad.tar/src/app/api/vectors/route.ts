import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// Interface for coherent vector
interface CoherentVector {
  id: string;
  data: number[];
  timestamp: number;
  source: string;
  coherence_score: number;
  metadata: {
    type: 'text' | 'image' | 'multimodal';
    description?: string;
    tags?: string[];
  };
}

// Interface for vector similarity result
interface VectorSimilarity {
  vector_id: string;
  similarity_score: number;
  coherence_score: number;
  timestamp: number;
  metadata: CoherentVector['metadata'];
}

// Store vectors in memory (in production, use a vector database)
const vectorStore: CoherentVector[] = [];

export async function POST(request: NextRequest) {
  try {
    const { 
      data, 
      source = 'user_input', 
      metadata = { type: 'text' as const },
      calculateCoherence = true 
    } = await request.json();
    
    if (!data || !Array.isArray(data)) {
      return NextResponse.json({ error: 'Vector data is required and must be an array' }, { status: 400 });
    }

    // Calculate coherence score if requested
    let coherence_score = 0;
    if (calculateCoherence) {
      coherence_score = calculateVectorCoherence(data);
    }

    // Create coherent vector
    const vector: CoherentVector = {
      id: `vector_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      data,
      timestamp: Date.now(),
      source,
      coherence_score,
      metadata
    };
    
    vectorStore.push(vector);
    
    // Keep only last 5000 vectors in memory
    if (vectorStore.length > 5000) {
      vectorStore.splice(0, vectorStore.length - 5000);
    }
    
    return NextResponse.json({
      success: true,
      vector_id: vector.id,
      coherence_score: vector.coherence_score,
      total_vectors: vectorStore.length
    });
    
  } catch (error) {
    console.error('Error creating coherent vector:', error);
    return NextResponse.json(
      { error: 'Failed to create coherent vector' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');
    
    if (action === 'search') {
      const queryVector = searchParams.get('query');
      const limit = parseInt(searchParams.get('limit') || '10');
      
      if (!queryVector) {
        return NextResponse.json({ error: 'Query vector is required for search' }, { status: 400 });
      }
      
      const queryData = JSON.parse(queryVector);
      const similarities = findSimilarVectors(queryData, limit);
      
      return NextResponse.json({
        results: similarities,
        query_coherence: calculateVectorCoherence(queryData)
      });
    }
    
    if (action === 'stats') {
      const stats = calculateVectorStats();
      return NextResponse.json(stats);
    }
    
    // Return all vectors (with pagination)
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    
    const paginatedVectors = vectorStore.slice(startIndex, endIndex);
    
    return NextResponse.json({
      vectors: paginatedVectors,
      pagination: {
        current_page: page,
        per_page: limit,
        total_vectors: vectorStore.length,
        total_pages: Math.ceil(vectorStore.length / limit)
      }
    });
    
  } catch (error) {
    console.error('Error fetching vectors:', error);
    return NextResponse.json(
      { error: 'Failed to fetch vectors' },
      { status: 500 }
    );
  }
}

// Helper function to calculate vector coherence
function calculateVectorCoherence(vector: number[]): number {
  if (!vector || vector.length === 0) return 0;
  
  // Calculate magnitude (L2 norm)
  const magnitude = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0));
  
  // Calculate variance as a measure of coherence
  const mean = vector.reduce((sum, val) => sum + val, 0) / vector.length;
  const variance = vector.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / vector.length;
  
  // Calculate skewness and kurtosis for additional coherence measures
  const skewness = calculateSkewness(vector, mean, Math.sqrt(variance));
  const kurtosis = calculateKurtosis(vector, mean, variance);
  
  // Normalize measures to [0, 1] range
  const normalizedMagnitude = Math.min(1, magnitude / 10);
  const normalizedVariance = Math.min(1, variance / 0.1);
  const normalizedSkewness = Math.min(1, Math.abs(skewness) / 2);
  const normalizedKurtosis = Math.min(1, Math.abs(kurtosis - 3) / 5);
  
  // Combine measures for coherence score (lower variance, skewness, and kurtosis = higher coherence)
  const coherenceScore = (
    normalizedMagnitude * 0.3 +
    (1 - normalizedVariance) * 0.4 +
    (1 - normalizedSkewness) * 0.15 +
    (1 - normalizedKurtosis) * 0.15
  );
  
  return Math.min(1, Math.max(0, coherenceScore));
}

// Helper function to calculate skewness
function calculateSkewness(vector: number[], mean: number, stdDev: number): number {
  if (stdDev === 0) return 0;
  
  const n = vector.length;
  const skewness = vector.reduce((sum, val) => {
    return sum + Math.pow((val - mean) / stdDev, 3);
  }, 0) / n;
  
  return skewness;
}

// Helper function to calculate kurtosis
function calculateKurtosis(vector: number[], mean: number, variance: number): number {
  if (variance === 0) return 0;
  
  const n = vector.length;
  const kurtosis = vector.reduce((sum, val) => {
    return sum + Math.pow((val - mean), 4);
  }, 0) / (n * variance * variance);
  
  return kurtosis;
}

// Helper function to find similar vectors
function findSimilarVectors(queryVector: number[], limit: number): VectorSimilarity[] {
  const similarities: VectorSimilarity[] = [];
  
  for (const vector of vectorStore) {
    const similarity = calculateCosineSimilarity(queryVector, vector.data);
    
    similarities.push({
      vector_id: vector.id,
      similarity_score: similarity,
      coherence_score: vector.coherence_score,
      timestamp: vector.timestamp,
      metadata: vector.metadata
    });
  }
  
  // Sort by similarity score and return top results
  similarities.sort((a, b) => b.similarity_score - a.similarity_score);
  return similarities.slice(0, limit);
}

// Helper function to calculate cosine similarity
function calculateCosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) return 0;
  
  const dotProduct = vecA.reduce((sum, a, i) => sum + a * vecB[i], 0);
  const magnitudeA = Math.sqrt(vecA.reduce((sum, a) => sum + a * a, 0));
  const magnitudeB = Math.sqrt(vecB.reduce((sum, b) => sum + b * b, 0));
  
  if (magnitudeA === 0 || magnitudeB === 0) return 0;
  
  return dotProduct / (magnitudeA * magnitudeB);
}

// Helper function to calculate vector statistics
function calculateVectorStats() {
  if (vectorStore.length === 0) {
    return {
      total_vectors: 0,
      average_coherence: 0,
      coherence_distribution: { low: 0, medium: 0, high: 0 },
      source_distribution: {},
      type_distribution: {}
    };
  }
  
  const totalCoherence = vectorStore.reduce((sum, v) => sum + v.coherence_score, 0);
  const averageCoherence = totalCoherence / vectorStore.length;
  
  const coherenceDistribution = {
    low: vectorStore.filter(v => v.coherence_score < 0.33).length,
    medium: vectorStore.filter(v => v.coherence_score >= 0.33 && v.coherence_score < 0.66).length,
    high: vectorStore.filter(v => v.coherence_score >= 0.66).length
  };
  
  const sourceDistribution: Record<string, number> = {};
  const typeDistribution: Record<string, number> = {};
  
  vectorStore.forEach(vector => {
    sourceDistribution[vector.source] = (sourceDistribution[vector.source] || 0) + 1;
    typeDistribution[vector.metadata.type] = (typeDistribution[vector.metadata.type] || 0) + 1;
  });
  
  return {
    total_vectors: vectorStore.length,
    average_coherence: averageCoherence,
    coherence_distribution: coherenceDistribution,
    source_distribution: sourceDistribution,
    type_distribution: typeDistribution
  };
}