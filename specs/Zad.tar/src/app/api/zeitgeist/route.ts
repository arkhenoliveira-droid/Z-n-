import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// Interface for coherence vector
interface CoherenceVector {
  id: string;
  data: number[];
  timestamp: number;
  source: string;
  coherence_score: number;
}

// Interface for Zeitgeist analysis response
interface ZeitgeistAnalysis {
  id: string;
  prompt: string;
  response: string;
  embedding: number[];
  coherence_score: number;
  timestamp: number;
  metadata: {
    model: string;
    processing_time: number;
    source_confidence: number;
  };
}

// Interface for coherence curve data point
interface CoherenceCurvePoint {
  z_n: number; // Parameter (time, iteration, etc.)
  coherence: number;
  timestamp: number;
}

// Store coherence vectors in memory (in production, use a database)
const coherenceVectors: CoherenceVector[] = [];
const coherenceCurve: CoherenceCurvePoint[] = [];

export async function POST(request: NextRequest) {
  try {
    const { prompt, searchParameters = {} } = await request.json();
    
    if (!prompt) {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create();
    
    const startTime = Date.now();
    
    // Generate response using Grok
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a sophisticated AI assistant that analyzes and synthesizes information about current trends, cultural phenomena, and the collective consciousness (Zeitgeist). Provide coherent, well-structured insights that capture the essence of the topic in relation to contemporary reality.'
        },
        {
          role: 'user',
          content: `Analyze the following topic in the context of current Zeitgeist: ${prompt}`
        }
      ],
      model: 'grok-4',
      max_tokens: 1000,
      temperature: 0.7
    });

    const responseText = completion.choices[0]?.message?.content || '';
    
    // Generate embedding for the response
    const embeddingResponse = await zai.embeddings.create({
      input: responseText,
      model: 'text-embedding-3-large'
    });
    
    const embedding = embeddingResponse.data[0]?.embedding || [];
    
    // Calculate coherence score based on embedding properties
    const coherence_score = calculateCoherenceScore(embedding);
    
    // Store coherence vector
    const vector: CoherenceVector = {
      id: `vector_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      data: embedding,
      timestamp: Date.now(),
      source: 'zeitgeist_analysis',
      coherence_score
    };
    
    coherenceVectors.push(vector);
    
    // Update coherence curve
    const curvePoint: CoherenceCurvePoint = {
      z_n: coherenceCurve.length + 1, // Using iteration count as Z(n)
      coherence: coherence_score,
      timestamp: Date.now()
    };
    
    coherenceCurve.push(curvePoint);
    
    // Keep only last 1000 points in memory
    if (coherenceCurve.length > 1000) {
      coherenceCurve.splice(0, coherenceCurve.length - 1000);
    }
    
    const processingTime = Date.now() - startTime;
    
    const analysis: ZeitgeistAnalysis = {
      id: `analysis_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      prompt,
      response: responseText,
      embedding,
      coherence_score,
      timestamp: Date.now(),
      metadata: {
        model: 'grok-4',
        processing_time: processingTime,
        source_confidence: Math.min(0.95, 0.7 + (coherence_score * 0.25))
      }
    };
    
    return NextResponse.json(analysis);
    
  } catch (error) {
    console.error('Zeitgeist analysis error:', error);
    return NextResponse.json(
      { error: 'Failed to analyze Zeitgeist data' },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    // Return current coherence curve data
    return NextResponse.json({
      coherence_curve: coherenceCurve,
      total_vectors: coherenceVectors.length,
      latest_coherence: coherenceCurve.length > 0 ? coherenceCurve[coherenceCurve.length - 1].coherence : 0,
      average_coherence: coherenceCurve.length > 0 
        ? coherenceCurve.reduce((sum, point) => sum + point.coherence, 0) / coherenceCurve.length 
        : 0
    });
  } catch (error) {
    console.error('Error fetching coherence data:', error);
    return NextResponse.json(
      { error: 'Failed to fetch coherence data' },
      { status: 500 }
    );
  }
}

// Helper function to calculate coherence score
function calculateCoherenceScore(embedding: number[]): number {
  if (!embedding || embedding.length === 0) return 0;
  
  // Calculate magnitude (L2 norm)
  const magnitude = Math.sqrt(embedding.reduce((sum, val) => sum + val * val, 0));
  
  // Calculate variance as a measure of coherence
  const mean = embedding.reduce((sum, val) => sum + val, 0) / embedding.length;
  const variance = embedding.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / embedding.length;
  
  // Normalize variance to [0, 1] range (lower variance = higher coherence)
  const normalizedVariance = Math.min(1, variance / 0.1);
  
  // Combine magnitude and variance for coherence score
  const coherenceScore = (magnitude / 10) * (1 - normalizedVariance) * 0.8 + 0.2;
  
  return Math.min(1, Math.max(0, coherenceScore));
}