'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter } from 'recharts';
import { 
  Brain, 
  Zap, 
  Network, 
  Target, 
  TrendingUp, 
  Activity,
  RefreshCw,
  BarChart3,
  Settings,
  Play,
  Pause,
  AlertCircle,
  CheckCircle
} from 'lucide-react';

// Interfaces for our data
interface ZeitgeistAnalysis {
  id: string;
  prompt: string;
  response: string;
  embedding: number[];
  coherence_score: number;
  timestamp: number;
  metadata: {
    model: string;
    processing_time: number;
    source_confidence: number;
  };
}

interface CoherenceCurvePoint {
  z_n: number;
  coherence: number;
  timestamp: number;
}

interface VectorStats {
  total_vectors: number;
  average_coherence: number;
  coherence_distribution: { low: number; medium: number; high: number };
  source_distribution: Record<string, number>;
  type_distribution: Record<string, number>;
}

interface CurveAnalysis {
  function_type: string;
  trend: 'increasing' | 'decreasing' | 'stable';
  volatility: number;
  r_squared: number;
  predicted_values: number[];
  confidence_interval: [number, number];
}

export default function ZeitgeistDashboard() {
  const [prompt, setPrompt] = useState('');
  const [analysis, setAnalysis] = useState<ZeitgeistAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [coherenceCurve, setCoherenceCurve] = useState<CoherenceCurvePoint[]>([]);
  const [vectorStats, setVectorStats] = useState<VectorStats | null>(null);
  const [curveAnalysis, setCurveAnalysis] = useState<CurveAnalysis | null>(null);
  const [isRealTime, setIsRealTime] = useState(false);
  const [realTimeInterval, setRealTimeInterval] = useState<NodeJS.Timeout | null>(null);

  // Fetch initial data
  useEffect(() => {
    fetchCoherenceData();
    fetchVectorStats();
    fetchCurveAnalysis();
  }, []);

  // Handle real-time updates
  useEffect(() => {
    if (isRealTime) {
      const interval = setInterval(() => {
        fetchCoherenceData();
        fetchVectorStats();
      }, 5000);
      setRealTimeInterval(interval);
    } else if (realTimeInterval) {
      clearInterval(realTimeInterval);
      setRealTimeInterval(null);
    }

    return () => {
      if (realTimeInterval) {
        clearInterval(realTimeInterval);
      }
    };
  }, [isRealTime]);

  const fetchCoherenceData = async () => {
    try {
      const response = await fetch('/api/zeitgeist');
      const data = await response.json();
      setCoherenceCurve(data.coherence_curve || []);
    } catch (error) {
      console.error('Error fetching coherence data:', error);
    }
  };

  const fetchVectorStats = async () => {
    try {
      const response = await fetch('/api/vectors?action=stats');
      const data = await response.json();
      setVectorStats(data);
    } catch (error) {
      console.error('Error fetching vector stats:', error);
    }
  };

  const fetchCurveAnalysis = async () => {
    try {
      const response = await fetch('/api/coherence-curve?action=get_analysis');
      const data = await response.json();
      setCurveAnalysis(data);
    } catch (error) {
      console.error('Error fetching curve analysis:', error);
    }
  };

  const handleAnalyze = async () => {
    if (!prompt.trim()) return;

    setIsAnalyzing(true);
    try {
      const response = await fetch('/api/zeitgeist', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt }),
      });

      const data: ZeitgeistAnalysis = await response.json();
      setAnalysis(data);
      
      // Refresh data after analysis
      await fetchCoherenceData();
      await fetchVectorStats();
      await fetchCurveAnalysis();
    } catch (error) {
      console.error('Error analyzing prompt:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getCoherenceColor = (score: number) => {
    if (score >= 0.7) return 'text-green-600';
    if (score >= 0.4) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getCoherenceBadge = (score: number) => {
    if (score >= 0.7) return 'default';
    if (score >= 0.4) return 'secondary';
    return 'destructive';
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'increasing': return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'decreasing': return <TrendingUp className="h-4 w-4 text-red-600 rotate-180" />;
      default: return <Target className="h-4 w-4 text-blue-600" />;
    }
  };

  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString();
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Zeitgeist Analysis Dashboard</h1>
          <p className="text-muted-foreground">
            Monitor coherence patterns and analyze collective consciousness through AI
          </p>
        </div>
        <div className="flex space-x-2">
          <Button
            onClick={() => setIsRealTime(!isRealTime)}
            variant={isRealTime ? "default" : "outline"}
          >
            {isRealTime ? <Pause className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}
            {isRealTime ? 'Stop Real-time' : 'Start Real-time'}
          </Button>
          <Button onClick={fetchCoherenceData} variant="outline">
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
        </div>
      </div>

      <Tabs defaultValue="analysis" className="space-y-4">
        <TabsList>
          <TabsTrigger value="analysis">Zeitgeist Analysis</TabsTrigger>
          <TabsTrigger value="coherence">Coherence Curve</TabsTrigger>
          <TabsTrigger value="vectors">Coherent Vectors</TabsTrigger>
          <TabsTrigger value="insights">System Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="analysis" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="h-5 w-5" />
                <span>Zeitgeist Analysis</span>
              </CardTitle>
              <CardDescription>
                Enter a topic to analyze its current cultural significance and coherence patterns
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-2">
                <Textarea
                  placeholder="Enter a topic or question to analyze in the context of current Zeitgeist..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="flex-1"
                  rows={3}
                />
                <Button
                  onClick={handleAnalyze}
                  disabled={isAnalyzing || !prompt.trim()}
                  className="self-end"
                >
                  {isAnalyzing ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Zap className="mr-2 h-4 w-4" />}
                  {isAnalyzing ? 'Analyzing...' : 'Analyze'}
                </Button>
              </div>

              {analysis && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Badge variant={getCoherenceBadge(analysis.coherence_score)}>
                        Coherence: {(analysis.coherence_score * 100).toFixed(1)}%
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        {formatTimestamp(analysis.timestamp)}
                      </span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Processing time: {analysis.metadata.processing_time}ms
                    </div>
                  </div>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Analysis Result</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="whitespace-pre-wrap">{analysis.response}</p>
                    </CardContent>
                  </Card>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="coherence" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Current Coherence</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {coherenceCurve.length > 0 
                    ? `${(coherenceCurve[coherenceCurve.length - 1].coherence * 100).toFixed(1)}%`
                    : '0%'
                  }
                </div>
                <p className="text-xs text-muted-foreground">
                  Latest measurement
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Average Coherence</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {coherenceCurve.length > 0
                    ? `${(coherenceCurve.reduce((sum, point) => sum + point.coherence, 0) / coherenceCurve.length * 100).toFixed(1)}%`
                    : '0%'
                  }
                </div>
                <p className="text-xs text-muted-foreground">
                  Overall average
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Data Points</CardTitle>
                <Network className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{coherenceCurve.length}</div>
                <p className="text-xs text-muted-foreground">
                  Total measurements
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Coherence Curve f[Z(n)]</CardTitle>
              <CardDescription>
                Evolution of coherence over time/iterations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={coherenceCurve.slice(-100)}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="z_n" 
                    label={{ value: 'Z(n) Parameter', position: 'insideBottom', offset: -10 }}
                  />
                  <YAxis 
                    domain={[0, 1]}
                    label={{ value: 'Coherence', angle: -90, position: 'insideLeft' }}
                  />
                  <Tooltip 
                    formatter={(value: number) => [`${(value * 100).toFixed(1)}%`, 'Coherence']}
                    labelFormatter={(label) => `Z(n) = ${label}`}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="coherence" 
                    stroke="#8884d8" 
                    strokeWidth={2}
                    dot={{ r: 2 }}
                    name="Coherence"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {curveAnalysis && (
            <Card>
              <CardHeader>
                <CardTitle>Curve Analysis</CardTitle>
                <CardDescription>
                  Statistical analysis of coherence patterns
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex items-center justify-between">
                    <span>Function Type:</span>
                    <Badge variant="outline">{curveAnalysis.function_type}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Trend:</span>
                    <div className="flex items-center space-x-2">
                      {getTrendIcon(curveAnalysis.trend)}
                      <Badge variant="outline">{curveAnalysis.trend}</Badge>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Volatility:</span>
                    <span className={getCoherenceColor(1 - curveAnalysis.volatility)}>
                      {(curveAnalysis.volatility * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>R-squared:</span>
                    <span className={getCoherenceColor(curveAnalysis.r_squared)}>
                      {(curveAnalysis.r_squared * 100).toFixed(1)}%
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="vectors" className="space-y-4">
          {vectorStats && (
            <>
              <div className="grid gap-4 md:grid-cols-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Vectors</CardTitle>
                    <Network className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{vectorStats.total_vectors}</div>
                    <p className="text-xs text-muted-foreground">
                      Coherent vectors stored
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Avg Coherence</CardTitle>
                    <Activity className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className={`text-2xl font-bold ${getCoherenceColor(vectorStats.average_coherence)}`}>
                      {(vectorStats.average_coherence * 100).toFixed(1)}%
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Average coherence score
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">High Coherence</CardTitle>
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600">
                      {vectorStats.coherence_distribution.high}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Vectors with ≥66% coherence
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Low Coherence</CardTitle>
                    <AlertCircle className="h-4 w-4 text-red-600" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-red-600">
                      {vectorStats.coherence_distribution.low}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Vectors with &lt;33% coherence
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Coherence Distribution</CardTitle>
                    <CardDescription>
                      Distribution of coherence scores across all vectors
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>High Coherence (≥66%)</span>
                        <span>{vectorStats.coherence_distribution.high}</span>
                      </div>
                      <Progress 
                        value={(vectorStats.coherence_distribution.high / vectorStats.total_vectors) * 100} 
                        className="h-2"
                      />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Medium Coherence (33-66%)</span>
                        <span>{vectorStats.coherence_distribution.medium}</span>
                      </div>
                      <Progress 
                        value={(vectorStats.coherence_distribution.medium / vectorStats.total_vectors) * 100} 
                        className="h-2"
                      />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Low Coherence (&lt;33%)</span>
                        <span>{vectorStats.coherence_distribution.low}</span>
                      </div>
                      <Progress 
                        value={(vectorStats.coherence_distribution.low / vectorStats.total_vectors) * 100} 
                        className="h-2"
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Source Distribution</CardTitle>
                    <CardDescription>
                      Distribution of vector sources
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {Object.entries(vectorStats.source_distribution).map(([source, count]) => (
                        <div key={source} className="flex justify-between">
                          <span className="capitalize">{source}</span>
                          <Badge variant="outline">{count}</Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>System Status</CardTitle>
                <CardDescription>
                  Current system health and performance
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Real-time Updates:</span>
                  <Badge variant={isRealTime ? "default" : "secondary"}>
                    {isRealTime ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>API Status:</span>
                  <Badge variant="default">Operational</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Data Processing:</span>
                  <Badge variant="default">Normal</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Memory Usage:</span>
                  <Badge variant="outline">Optimal</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Coherence Insights</CardTitle>
                <CardDescription>
                  Key observations about coherence patterns
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm space-y-2">
                  <p>• Coherence scores indicate the alignment of AI responses with expected patterns</p>
                  <p>• The curve f[Z(n)] shows how coherence evolves over time/iterations</p>
                  <p>• Higher coherence suggests better pattern recognition and synthesis</p>
                  <p>• Real-time monitoring helps identify trends and anomalies</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Technical Implementation</CardTitle>
              <CardDescription>
                How the system works under the hood
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <h4 className="font-semibold mb-2">Zeitgeist Analysis</h4>
                  <p className="text-sm text-muted-foreground">
                    Uses Grok API to analyze topics in the context of current cultural trends and collective consciousness. 
                    Generates embeddings and calculates coherence scores based on vector properties.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Coherent Vectors</h4>
                  <p className="text-sm text-muted-foreground">
                    Stores and manages high-dimensional vector representations with coherence scoring. 
                    Supports similarity search and statistical analysis of vector distributions.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Coherence Curve</h4>
                  <p className="text-sm text-muted-foreground">
                    Implements f[Z(n)] function to model coherence evolution. 
                    Supports multiple function types (linear, exponential, logarithmic) and provides predictive analysis.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Real-time Processing</h4>
                  <p className="text-sm text-muted-foreground">
                    Continuous monitoring and analysis with automatic updates. 
                    Provides live insights into coherence patterns and system performance.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}