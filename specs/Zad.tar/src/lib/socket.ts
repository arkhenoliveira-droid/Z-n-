import { Server } from 'socket.io';

export const setupSocket = (io: Server) => {
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    // Handle investigation updates
    socket.on('join-investigation', (investigationId: string) => {
      socket.join(`investigation-${investigationId}`);
      console.log(`Client ${socket.id} joined investigation ${investigationId}`);
    });

    socket.on('leave-investigation', (investigationId: string) => {
      socket.leave(`investigation-${investigationId}`);
      console.log(`Client ${socket.id} left investigation ${investigationId}`);
    });

    // Handle messages
    socket.on('message', (msg: { text: string; senderId: string }) => {
      // Echo: broadcast message only the client who send the message
      socket.emit('message', {
        text: `Echo: ${msg.text}`,
        senderId: 'system',
        timestamp: new Date().toISOString(),
      });
    });

    // Handle investigation status requests
    socket.on('get-investigation-status', async (investigationId: string) => {
      try {
        // Here you would fetch the investigation status from the database
        // For now, we'll just acknowledge the request
        socket.emit('investigation-status', {
          investigationId,
          status: 'requested',
          timestamp: new Date().toISOString(),
        });
      } catch (error) {
        socket.emit('investigation-error', {
          investigationId,
          error: 'Failed to fetch investigation status',
          timestamp: new Date().toISOString(),
        });
      }
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
    });

    // Send welcome message
    socket.emit('message', {
      text: 'Welcome to Real-time Investigation Server!',
      senderId: 'system',
      timestamp: new Date().toISOString(),
    });
  });
};

// Helper functions to broadcast investigation updates
export const broadcastInvestigationUpdate = (io: Server, investigationId: string, update: any) => {
  io.to(`investigation-${investigationId}`).emit('investigation-update', {
    investigationId,
    ...update,
    timestamp: new Date().toISOString(),
  });
};

export const broadcastInvestigationProgress = (io: Server, investigationId: string, progress: number, message: string) => {
  io.to(`investigation-${investigationId}`).emit('investigation-progress', {
    investigationId,
    progress,
    message,
    timestamp: new Date().toISOString(),
  });
};

export const broadcastInvestigationComplete = (io: Server, investigationId: string, results: any) => {
  io.to(`investigation-${investigationId}`).emit('investigation-complete', {
    investigationId,
    results,
    timestamp: new Date().toISOString(),
  });
};

export const broadcastInvestigationError = (io: Server, investigationId: string, error: string) => {
  io.to(`investigation-${investigationId}`).emit('investigation-error', {
    investigationId,
    error,
    timestamp: new Date().toISOString(),
  });
};