# Deploy Rápido - Sistema de Coerência de Arquivos

## Métodos Rápidos de Deploy

### 1. Deploy Local (Desenvolvimento)

```bash
# Método mais simples
./deploy.sh development

# Ou manualmente
npm install
npm run dev
```

### 2. Deploy Produção (PM2)

```bash
# Método automático
./deploy.sh production

# Ou manualmente
npm run build
pm2 start server.ts --name "coherence-system" --interpreter tsx
```

### 3. Deploy Docker

```bash
# Método automático
./deploy.sh docker

# Ou manualmente
docker-compose up -d --build
```

## Verificação Pós-Deploy

### Health Check
```bash
# Verificar se a aplicação está rodando
curl http://localhost:3000/api/health

# Verificar logs
pm2 logs coherence-system  # Se usando PM2
docker logs coherence-system  # Se usando Docker
```

### Acessar a Aplicação
- URL: http://localhost:3000
- Health Check: http://localhost:3000/api/health
- Socket.IO: ws://localhost:3000/api/socketio

## Solução de Problemas Rápida

### Erro: "Sorry, there was a problem deploying the code"

```bash
# 1. Limpar tudo e reinstalar
rm -rf .next node_modules package-lock.json
npm install
npm run build

# 2. Verificar erros
npm run lint
npx tsc --noEmit

# 3. Testar build
npm run build
```

### Erro: "EADDRINUSE: address already in use"

```bash
# Matar processo na porta 3000
lsof -ti:3000 | xargs kill -9

# Ou usar porta diferente
PORT=3001 npm start
```

### Erro: "Module parse failed"

```bash
# Verificar importações duplicadas
grep -r "import.*FileText" src/

# Corrigir no arquivo page.tsx se necessário
```

## Configurações Mínimas

### Variáveis de Ambiente
```bash
# .env.production
NODE_ENV=production
PORT=3000
HOSTNAME=0.0.0.0
DATABASE_URL="file:./dev.db"
```

### Portas Necessárias
- 3000: Aplicação principal
- 5432: PostgreSQL (opcional)
- 6379: Redis (opcional)
- 80/443: Nginx (opcional)

### Recursos Mínimos
- CPU: 1 core
- RAM: 512MB
- Disco: 1GB

## Comandos Úteis

### PM2
```bash
pm2 list                    # Listar processos
pm2 logs coherence-system    # Ver logs
pm2 restart coherence-system # Reiniciar
pm2 stop coherence-system    # Parar
pm2 monit                   # Monitorar
```

### Docker
```bash
docker-compose up -d         # Iniciar containers
docker-compose down          # Parar containers
docker-compose logs -f       # Ver logs
docker-compose ps            # Ver status
```

### Build
```bash
npm run build               # Build para produção
npm run lint                # Verificar código
npx tsc --noEmit            # Verificar tipos
npm run db:push             # Configurar banco
```

## Próximos Passos

1. **Configurar domínio** - Atualizar server_name no nginx.conf
2. **Configurar SSL** - Adicionar certificados SSL
3. **Configurar backup** - Implementar script de backup automático
4. **Monitoramento** - Configurar monitoramento e alertas
5. **Escala** - Configurar múltiplas instâncias se necessário

## Suporte

- Verificar logs: `pm2 logs` ou `docker logs`
- Health check: `curl http://localhost:3000/api/health`
- Documentação completa: `DEPLOYMENT_GUIDE.md`