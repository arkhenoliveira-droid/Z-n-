# Guia de Solução de Problemas - Sistema de Coerência de Arquivos

## Erro: "Sorry, there was a problem deploying the code"

Este erro geralmente ocorre durante o processo de deploy e pode ter várias causas. Abaixo estão as soluções para diferentes cenários.

### Causas Comuns e Soluções

#### 1. Erros de Build do Projeto

**Sintomas:**
- Build falha com erros de TypeScript
- Erros de módulo não encontrado
- Erros de importação duplicada

**Diagnóstico:**
```bash
# Verificar erros de build
npm run build

# Verificar erros de lint
npm run lint

# Verificar erros de TypeScript
npx tsc --noEmit
```

**Soluções:**

**a) Limpar cache e reinstalar dependências:**
```bash
# Remover cache e dependências
rm -rf .next
rm -rf node_modules
rm package-lock.json

# Reinstalar dependências
npm install

# Build novamente
npm run build
```

**b) Corrigir importações duplicadas:**
```bash
# Encontrar importações duplicadas
grep -r "import.*FileText" src/
grep -r "import.*Heart" src/

# Exemplo de correção (remover duplicatas):
# Antes:
import { Activity, Zap, FileText, Heart, FileText, Archive } from 'lucide-react';
# Depois:
import { Activity, Zap, FileText, Heart, Archive } from 'lucide-react';
```

**c) Verificar disponibilidade de ícones:**
```bash
# Listar ícones disponíveis
npm list lucide-react

# Verificar documentação de ícones
# https://lucide.dev/icons/
```

#### 2. Problemas de Configuração do Servidor

**Sintomas:**
- Erro "EADDRINUSE: address already in use"
- Servidor não inicia
- Timeout de conexão

**Diagnóstico:**
```bash
# Verificar processos na porta 3000
lsof -i :3000
netstat -tulpn | grep :3000

# Testar servidor local
npm run dev
```

**Soluções:**

**a) Liberar porta ocupada:**
```bash
# Matar processo na porta 3000
lsof -ti:3000 | xargs kill -9

# Ou usar porta diferente
PORT=3001 npm start
```

**b) Verificar configuração do servidor:**
```typescript
// server.ts - Verificar configuração
const dev = process.env.NODE_ENV !== 'production';
const currentPort = process.env.PORT || 3000;
const hostname = process.env.HOSTNAME || '0.0.0.0';
```

**c) Configurar variáveis de ambiente:**
```bash
# .env.production
NODE_ENV=production
PORT=3000
HOSTNAME=0.0.0.0
DATABASE_URL="file:./dev.db"
```

#### 3. Problemas de Dependências

**Sintomas:**
- Erros de módulo não encontrado
- Versões incompatíveis
- Dependências faltando

**Diagnóstico:**
```bash
# Verificar dependências
npm list

# Verificar vulnerabilidades
npm audit

# Verificar versões do Node.js
node --version
npm --version
```

**Soluções:**

**a) Atualizar dependências:**
```bash
# Atualizar pacotes
npm update

# Corrigir vulnerabilidades
npm audit fix

# Forçar reinstalação
npm ci --force
```

**b) Verificar compatibilidade de versões:**
```json
// package.json - Verificar versões compatíveis
"dependencies": {
  "next": "15.3.5",
  "react": "^19.0.0",
  "react-dom": "^19.0.0",
  "typescript": "^5"
}
```

#### 4. Problemas de Banco de Dados

**Sintomas:**
- Erros de conexão com banco de dados
- Migrações falhando
- Schema não encontrado

**Diagnóstico:**
```bash
# Verificar configuração do banco
cat .env

# Testar conexão
npm run db:push

# Verificar schema
npx prisma db pull
```

**Soluções:**

**a) Reconfigurar banco de dados:**
```bash
# Resetar banco de dados
npm run db:reset

# Gerar client novamente
npm run db:generate

# Push schema
npm run db:push
```

**b) Verificar arquivo de schema:**
```prisma
// prisma/schema.prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}
```

#### 5. Problemas de Ambiente de Produção

**Sintomas:**
- Aplicação funciona em dev mas não em prod
- Erros de variáveis de ambiente
- Problemas de permissão

**Diagnóstico:**
```bash
# Verificar ambiente
echo $NODE_ENV
echo $PORT

# Verificar permissões
ls -la
whoami
```

**Soluções:**

**a) Configurar ambiente de produção:**
```bash
# Build para produção
NODE_ENV=production npm run build

# Iniciar servidor de produção
NODE_ENV=production npm start
```

**b) Configurar permissões:**
```bash
# Dar permissões de execução
chmod +x server.ts

# Configurar usuário adequado
sudo chown -R user:group /path/to/project
```

### Soluções por Plataforma

#### Linux (Ubuntu/Debian)

```bash
# 1. Instalar dependências do sistema
sudo apt-get update
sudo apt-get install -y build-essential python3

# 2. Limpar cache do projeto
rm -rf .next node_modules package-lock.json

# 3. Reinstalar dependências
npm install

# 4. Build do projeto
npm run build

# 5. Configurar variáveis de ambiente
export NODE_ENV=production
export PORT=3000

# 6. Iniciar servidor
npm start
```

#### Linux (CentOS/RHEL)

```bash
# 1. Instalar dependências
sudo yum groupinstall -y "Development Tools"
sudo yum install -y python3

# 2. Limpar cache
rm -rf .next node_modules package-lock.json

# 3. Reinstalar dependências
npm install

# 4. Build
npm run build

# 5. Configurar firewall
sudo firewall-cmd --permanent --add-port=3000/tcp
sudo firewall-cmd --reload

# 6. Iniciar servidor
npm start
```

#### macOS

```bash
# 1. Atualizar Homebrew
brew update

# 2. Limpar cache
rm -rf .next node_modules package-lock.json

# 3. Reinstalar dependências
npm install

# 4. Build
npm run build

# 5. Configurar variáveis
export NODE_ENV=production
export PORT=3000

# 6. Iniciar servidor
npm start
```

#### Windows (PowerShell)

```powershell
# 1. Limpar cache
Remove-Item -Recurse -Force .next
Remove-Item -Recurse -Force node_modules
Remove-Item package-lock.json

# 2. Reinstalar dependências
npm install

# 3. Build
npm run build

# 4. Configurar variáveis
$env:NODE_ENV = "production"
$env:PORT = "3000"

# 5. Iniciar servidor
npm start
```

### Soluções por Método de Deploy

#### Docker

```bash
# 1. Limpar imagens existentes
docker system prune -a

# 2. Build imagem
docker build -t coherence-system .

# 3. Testar localmente
docker run -p 3000:3000 coherence-system

# 4. Verificar logs
docker logs <container-id>

# 5. Se usar docker-compose
docker-compose down
docker-compose up -d --build
```

#### PM2

```bash
# 1. Parar processos existentes
pm2 stop all
pm2 delete all

# 2. Limpar cache PM2
pm2 flush

# 3. Build projeto
npm run build

# 4. Iniciar com PM2
pm2 start server.ts --name "coherence-system" --interpreter tsx

# 5. Verificar status
pm2 status
pm2 logs coherence-system
```

#### Kubernetes

```bash
# 1. Verificar configuração
kubectl get pods
kubectl get services

# 2. Verificar logs
kubectl logs <pod-name>

# 3. Descrever pod
kubectl describe pod <pod-name>

# 4. Recriar deployment
kubectl rollout restart deployment/coherence-system

# 5. Aplicar configuração
kubectl apply -f k8s-deployment.yaml
```

### Verificação Pós-Conserto

Após aplicar as soluções, verifique se o sistema está funcionando corretamente:

```bash
# 1. Testar build
npm run build

# 2. Testar servidor local
npm run dev &
sleep 5
curl http://localhost:3000/api/health

# 3. Testar em produção
npm start &
sleep 10
curl http://localhost:3000/api/health

# 4. Verificar logs
tail -f server.log
```

### Prevenção Futura

Para evitar erros futuros:

1. **Sempre teste o build antes do deploy:**
   ```bash
   npm run build
   npm run lint
   npm run test
   ```

2. **Use versões fixas de dependências:**
   ```json
   "dependencies": {
     "next": "15.3.5",
     "react": "19.0.0"
   }
   ```

3. **Configure CI/CD adequado:**
   ```yaml
   # .github/workflows/deploy.yml
   name: Deploy
   on: [push]
   jobs:
     test:
       runs-on: ubuntu-latest
       steps:
         - uses: actions/checkout@v2
         - uses: actions/setup-node@v2
         - run: npm ci
         - run: npm run build
         - run: npm test
   ```

4. **Monitore o sistema em produção:**
   ```bash
   # Health checks
   curl http://localhost:3000/api/health
   
   # Logs
   pm2 logs
   docker logs
   ```

5. **Mantenha documentação atualizada:**
   - Atualize este guia com novos problemas e soluções
   - Documente mudanças na configuração
   - Mantenha changelog de atualizações

### Contato e Suporte

Se nenhuma das soluções acima funcionar:

1. **Verifique os logs detalhados:**
   ```bash
   npm start 2>&1 | tee debug.log
   ```

2. **Colete informações do sistema:**
   ```bash
   node --version
   npm --version
   uname -a
   ```

3. **Crie um issue com:**
   - Versão do Node.js e npm
   - Sistema operacional
   - Logs completos do erro
   - Passos reproduzíveis

4. **Comunidade:**
   - GitHub Issues
   - Stack Overflow
   - Discord/Slack do projeto

Este guia será atualizado conforme novos problemas e soluções forem identificados.