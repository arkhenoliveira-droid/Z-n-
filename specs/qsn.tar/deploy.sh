#!/bin/bash

# Script de Deploy Automático - Sistema de Coerência de Arquivos
# Este script facilita o deploy em diferentes ambientes

set -e  # Parar em caso de erro

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funções de log
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar pré-requisitos
check_prerequisites() {
    log_info "Verificando pré-requisitos..."
    
    # Verificar Node.js
    if ! command -v node &> /dev/null; then
        log_error "Node.js não está instalado. Por favor, instale Node.js 18+"
        exit 1
    fi
    
    # Verificar npm
    if ! command -v npm &> /dev/null; then
        log_error "npm não está instalado"
        exit 1
    fi
    
    # Verificar versão do Node.js
    NODE_VERSION=$(node -v | cut -d'.' -f1 | cut -d'v' -f2)
    if [ "$NODE_VERSION" -lt 18 ]; then
        log_error "Node.js versão 18+ é requerida. Versão atual: $(node -v)"
        exit 1
    fi
    
    log_success "Pré-requisitos verificados"
}

# Limpar cache e dependências
clean_project() {
    log_info "Limpando cache e dependências..."
    
    # Parar processos na porta 3000
    log_info "Parando processos na porta 3000..."
    lsof -ti:3000 | xargs kill -9 2>/dev/null || true
    
    # Remover caches com força
    log_info "Removendo caches..."
    rm -rf .next 2>/dev/null || true
    rm -rf node_modules 2>/dev/null || true
    rm -f package-lock.json 2>/dev/null || true
    
    # Forçar remoção se necessário
    if [ -d ".next" ]; then
        log_info "Removendo .next com força..."
        find .next -type f -delete 2>/dev/null || true
        find .next -type d -empty -delete 2>/dev/null || true
        rmdir .next 2>/dev/null || true
    fi
    
    if [ -d "node_modules" ]; then
        log_info "Removendo node_modules com força..."
        find node_modules -type f -delete 2>/dev/null || true
        find node_modules -type d -empty -delete 2>/dev/null || true
        rmdir node_modules 2>/dev/null || true
    fi
    
    log_success "Projeto limpo"
}

# Instalar dependências
install_dependencies() {
    log_info "Instalando dependências..."
    
    npm install
    
    if [ $? -eq 0 ]; then
        log_success "Dependências instaladas"
    else
        log_error "Falha ao instalar dependências"
        exit 1
    fi
}

# Verificar código
validate_code() {
    log_info "Validando código..."
    
    # Verificar lint
    log_info "Executando lint..."
    npm run lint
    
    if [ $? -ne 0 ]; then
        log_warning "Lint encontrou problemas, mas continuando..."
    fi
    
    # Verificar tipos TypeScript
    log_info "Verificando tipos TypeScript..."
    npx tsc --noEmit
    
    if [ $? -ne 0 ]; then
        log_error "Erros de TypeScript encontrados"
        exit 1
    fi
    
    log_success "Código validado"
}

# Build do projeto
build_project() {
    log_info "Build do projeto..."
    
    npm run build
    
    if [ $? -eq 0 ]; then
        log_success "Build concluído com sucesso"
    else
        log_error "Build falhou"
        exit 1
    fi
}

# Configurar banco de dados
setup_database() {
    log_info "Configurando banco de dados..."
    
    # Verificar se Prisma está configurado
    if [ ! -d "prisma" ]; then
        log_warning "Diretório prisma não encontrado, pulando configuração do banco"
        return
    fi
    
    # Gerar Prisma client
    log_info "Gerando Prisma client..."
    npm run db:generate
    
    # Push do schema
    log_info "Aplicando schema do banco de dados..."
    npm run db:push
    
    log_success "Banco de dados configurado"
}

# Deploy baseado no ambiente
deploy_environment() {
    local ENV=$1
    
    case $ENV in
        "development")
            log_info "Deploy em ambiente de desenvolvimento..."
            npm run dev
            ;;
        "production")
            log_info "Deploy em ambiente de produção..."
            
            # Verificar variáveis de ambiente
            if [ ! -f ".env.production" ]; then
                log_warning "Arquivo .env.production não encontrado, usando padrões"
            fi
            
            # Iniciar com PM2 se disponível
            if command -v pm2 &> /dev/null; then
                log_info "Iniciando com PM2..."
                pm2 stop coherence-system 2>/dev/null || true
                pm2 start server.ts --name "coherence-system" --interpreter tsx
                pm2 save
                log_success "Aplicação iniciada com PM2"
            else
                log_info "PM2 não encontrado, iniciando diretamente..."
                NODE_ENV=production npm start
            fi
            ;;
        "docker")
            log_info "Deploy com Docker..."
            
            if [ -f "docker-compose.yml" ]; then
                docker-compose down
                docker-compose up -d --build
                log_success "Containers iniciados"
            else
                log_error "docker-compose.yml não encontrado"
                exit 1
            fi
            ;;
        *)
            log_error "Ambiente desconhecido: $ENV"
            echo "Ambientes disponíveis: development, production, docker"
            exit 1
            ;;
    esac
}

# Função principal
main() {
    local ENV=${1:-development}
    
    echo "================================================"
    echo "  Deploy Automático - Sistema de Coerência de Arquivos"
    echo "================================================"
    echo "Ambiente: $ENV"
    echo "================================================"
    
    # Menu interativo se nenhum ambiente for especificado
    if [ "$ENV" == "development" ] && [ $# -eq 0 ]; then
        echo "Selecione o ambiente de deploy:"
        echo "1) Desenvolvimento"
        echo "2) Produção"
        echo "3) Docker"
        echo "4) Apenas Build"
        echo "5) Sair"
        
        read -p "Opção: " choice
        
        case $choice in
            1) ENV="development" ;;
            2) ENV="production" ;;
            3) ENV="docker" ;;
            4) 
                check_prerequisites
                clean_project
                install_dependencies
                validate_code
                build_project
                setup_database
                log_success "Build concluído!"
                exit 0
                ;;
            5) exit 0 ;;
            *) 
                log_error "Opção inválida"
                exit 1
                ;;
        esac
    fi
    
    # Executar steps de deploy
    check_prerequisites
    
    if [ "$ENV" != "docker" ]; then
        clean_project
        install_dependencies
        validate_code
        build_project
        setup_database
    fi
    
    deploy_environment $ENV
    
    echo "================================================"
    log_success "Deploy concluído com sucesso!"
    echo "Ambiente: $ENV"
    echo "================================================"
    
    # Mostrar informações de acesso
    if [ "$ENV" == "production" ]; then
        echo ""
        echo "Informações de acesso:"
        echo "- URL: http://localhost:3000"
        echo "- Health Check: http://localhost:3000/api/health"
        echo "- Logs: pm2 logs coherence-system"
        echo ""
    fi
}

# Trap para limpeza em caso de interrupção
trap 'log_error "Deploy interrompido"; exit 1' INT TERM

# Executar função principal
main "$@"
