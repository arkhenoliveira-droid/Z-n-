/**
 * Adaptive Coherence Feedback System
 * Provides real-time feedback mechanisms for user interactions
 */

export interface UserInteraction {
  id: string;
  type: string;
  timestamp: number;
  coherence_value: number;
  emotional_response: number;
  cognitive_load: number;
  satisfaction_score: number;
  context: {
    page: string;
    component: string;
    user_state: string;
    environment: string;
  };
}

export interface FeedbackSignal {
  id: string;
  type: 'visual' | 'haptic' | 'auditory' | 'adaptive';
  intensity: number;
  duration: number;
  target_coherence: number;
  adaptation_rate: number;
  message: string;
  priority: number;
}

export interface CoherencePattern {
  id: string;
  pattern_type: string;
  coherence_threshold: number;
  adaptation_strategy: string;
  feedback_signals: FeedbackSignal[];
  success_rate: number;
  learning_coefficient: number;
}

export class AdaptiveCoherenceFeedback {
  private interactionHistory: UserInteraction[] = [];
  private feedbackSignals: Map<string, FeedbackSignal> = new Map();
  private coherencePatterns: Map<string, CoherencePattern> = new Map();
  private userProfiles: Map<string, any> = new Map();
  private adaptationMatrix: number[][] = [];

  constructor() {
    this.initializeFeedbackPatterns();
    this.initializeAdaptationMatrix();
  }

  private initializeFeedbackPatterns(): void {
    // Visual feedback patterns
    const visualPattern: CoherencePattern = {
      id: 'visual_feedback',
      pattern_type: 'visual',
      coherence_threshold: 0.8,
      adaptation_strategy: 'progressive_enhancement',
      feedback_signals: [
        {
          id: 'visual_glow',
          type: 'visual',
          intensity: 0.7,
          duration: 1000,
          target_coherence: 0.85,
          adaptation_rate: 0.1,
          message: 'Visual coherence enhanced',
          priority: 1
        },
        {
          id: 'color_shift',
          type: 'visual',
          intensity: 0.5,
          duration: 800,
          target_coherence: 0.9,
          adaptation_rate: 0.15,
          message: 'Color harmony optimized',
          priority: 2
        }
      ],
      success_rate: 0.85,
      learning_coefficient: 0.12
    };

    // Haptic feedback patterns
    const hapticPattern: CoherencePattern = {
      id: 'haptic_feedback',
      pattern_type: 'haptic',
      coherence_threshold: 0.75,
      adaptation_strategy: 'resonance_matching',
      feedback_signals: [
        {
          id: 'haptic_pulse',
          type: 'haptic',
          intensity: 0.6,
          duration: 200,
          target_coherence: 0.8,
          adaptation_rate: 0.08,
          message: 'Tactile feedback synchronized',
          priority: 3
        }
      ],
      success_rate: 0.78,
      learning_coefficient: 0.09
    };

    // Auditory feedback patterns
    const auditoryPattern: CoherencePattern = {
      id: 'auditory_feedback',
      pattern_type: 'auditory',
      coherence_threshold: 0.82,
      adaptation_strategy: 'frequency_modulation',
      feedback_signals: [
        {
          id: 'auditory_chime',
          type: 'auditory',
          intensity: 0.4,
          duration: 300,
          target_coherence: 0.88,
          adaptation_rate: 0.12,
          message: 'Audio coherence aligned',
          priority: 2
        }
      ],
      success_rate: 0.91,
      learning_coefficient: 0.15
    };

    // Adaptive feedback patterns
    const adaptivePattern: CoherencePattern = {
      id: 'adaptive_feedback',
      pattern_type: 'adaptive',
      coherence_threshold: 0.85,
      adaptation_strategy: 'quantum_adaptation',
      feedback_signals: [
        {
          id: 'adaptive_flow',
          type: 'adaptive',
          intensity: 0.8,
          duration: 1500,
          target_coherence: 0.92,
          adaptation_rate: 0.18,
          message: 'System adapted to user flow',
          priority: 1
        }
      ],
      success_rate: 0.87,
      learning_coefficient: 0.16
    };

    this.coherencePatterns.set('visual', visualPattern);
    this.coherencePatterns.set('haptic', hapticPattern);
    this.coherencePatterns.set('auditory', auditoryPattern);
    this.coherencePatterns.set('adaptive', adaptivePattern);
  }

  private initializeAdaptationMatrix(): void {
    // Initialize adaptation matrix for different interaction types
    const interactionTypes = ['click', 'scroll', 'hover', 'input', 'navigation'];
    const feedbackTypes = ['visual', 'haptic', 'auditory', 'adaptive'];
    
    this.adaptationMatrix = interactionTypes.map(() => 
      feedbackTypes.map(() => Math.random() * 0.5 + 0.5)
    );
  }

  public recordInteraction(interaction: UserInteraction): void {
    this.interactionHistory.push(interaction);
    
    // Keep only recent interactions (last 1000)
    if (this.interactionHistory.length > 1000) {
      this.interactionHistory = this.interactionHistory.slice(-1000);
    }

    // Update user profile
    this.updateUserProfile(interaction);
    
    // Generate feedback signals
    this.generateFeedbackSignals(interaction);
  }

  private updateUserProfile(interaction: UserInteraction): void {
    const userId = interaction.context.user_state;
    if (!this.userProfiles.has(userId)) {
      this.userProfiles.set(userId, {
        interaction_count: 0,
        average_coherence: 0,
        preferred_feedback_type: 'visual',
        adaptation_sensitivity: 0.5,
        learning_rate: 0.1
      });
    }

    const profile = this.userProfiles.get(userId)!;
    profile.interaction_count++;
    profile.average_coherence = (profile.average_coherence * (profile.interaction_count - 1) + interaction.coherence_value) / profile.interaction_count;
    
    // Adapt learning rate based on performance
    if (interaction.coherence_value > profile.average_coherence) {
      profile.learning_rate = Math.min(0.2, profile.learning_rate * 1.05);
    } else {
      profile.learning_rate = Math.max(0.05, profile.learning_rate * 0.95);
    }
  }

  private generateFeedbackSignals(interaction: UserInteraction): void {
    const profile = this.userProfiles.get(interaction.context.user_state);
    if (!profile) return;

    // Calculate required feedback based on coherence deviation
    const coherenceDeviation = Math.abs(interaction.coherence_value - 0.85);
    
    if (coherenceDeviation > 0.1) {
      // Generate feedback signals for each pattern type
      this.coherencePatterns.forEach((pattern, patternType) => {
        if (interaction.coherence_value < pattern.coherence_threshold) {
          const signal = this.createFeedbackSignal(pattern, interaction, profile);
          this.feedbackSignals.set(signal.id, signal);
        }
      });
    }
  }

  private createFeedbackSignal(pattern: CoherencePattern, interaction: UserInteraction, profile: any): FeedbackSignal {
    const baseSignal = pattern.feedback_signals[0]; // Use first signal as base
    
    return {
      id: `signal_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type: baseSignal.type,
      intensity: baseSignal.intensity * (1 + profile.learning_rate),
      duration: baseSignal.duration * (1 - profile.learning_rate * 0.2),
      target_coherence: baseSignal.target_coherence,
      adaptation_rate: baseSignal.adaptation_rate * (1 + profile.learning_rate),
      message: baseSignal.message,
      priority: baseSignal.priority
    };
  }

  public getActiveFeedbackSignals(): FeedbackSignal[] {
    const currentTime = Date.now();
    const activeSignals: FeedbackSignal[] = [];

    this.feedbackSignals.forEach((signal) => {
      // Check if signal is still active (within duration)
      const signalAge = currentTime - parseInt(signal.id.split('_')[1]);
      if (signalAge < signal.duration) {
        activeSignals.push(signal);
      }
    });

    // Clean up old signals
    this.cleanupOldSignals(currentTime);

    return activeSignals.sort((a, b) => a.priority - b.priority);
  }

  private cleanupOldSignals(currentTime: number): void {
    const signalsToRemove: string[] = [];
    
    this.feedbackSignals.forEach((signal, signalId) => {
      const signalAge = currentTime - parseInt(signalId.split('_')[1]);
      if (signalAge > signal.duration * 2) {
        signalsToRemove.push(signalId);
      }
    });

    signalsToRemove.forEach(signalId => {
      this.feedbackSignals.delete(signalId);
    });
  }

  public adaptFeedbackMechanism(interactionType: string, feedbackType: string, success: boolean): void {
    const interactionIndex = ['click', 'scroll', 'hover', 'input', 'navigation'].indexOf(interactionType);
    const feedbackIndex = ['visual', 'haptic', 'auditory', 'adaptive'].indexOf(feedbackType);
    
    if (interactionIndex !== -1 && feedbackIndex !== -1) {
      const adaptationFactor = success ? 1.05 : 0.95;
      this.adaptationMatrix[interactionIndex][feedbackIndex] *= adaptationFactor;
      
      // Keep values in reasonable range
      this.adaptationMatrix[interactionIndex][feedbackIndex] = 
        Math.max(0.1, Math.min(1.0, this.adaptationMatrix[interactionIndex][feedbackIndex]));
    }
  }

  public getOptimalFeedbackType(interactionType: string): string {
    const interactionIndex = ['click', 'scroll', 'hover', 'input', 'navigation'].indexOf(interactionType);
    
    if (interactionIndex === -1) return 'visual';
    
    const feedbackTypes = ['visual', 'haptic', 'auditory', 'adaptive'];
    const scores = this.adaptationMatrix[interactionIndex];
    
    const maxScore = Math.max(...scores);
    const optimalIndex = scores.indexOf(maxScore);
    
    return feedbackTypes[optimalIndex];
  }

  public calculateCoherenceTrend(userId: string): number {
    const userInteractions = this.interactionHistory.filter(
      interaction => interaction.context.user_state === userId
    );
    
    if (userInteractions.length < 2) return 0;
    
    const recentInteractions = userInteractions.slice(-10);
    const coherenceValues = recentInteractions.map(i => i.coherence_value);
    
    // Calculate trend using simple linear regression
    const n = coherenceValues.length;
    const sumX = (n * (n - 1)) / 2;
    const sumY = coherenceValues.reduce((sum, val) => sum + val, 0);
    const sumXY = coherenceValues.reduce((sum, val, index) => sum + (index * val), 0);
    const sumX2 = (n * (n - 1) * (2 * n - 1)) / 6;
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    
    return slope;
  }

  public getUserCoherenceProfile(userId: string): any {
    const profile = this.userProfiles.get(userId);
    if (!profile) return null;

    const userInteractions = this.interactionHistory.filter(
      interaction => interaction.context.user_state === userId
    );

    return {
      ...profile,
      coherence_trend: this.calculateCoherenceTrend(userId),
      interaction_count: userInteractions.length,
      last_interaction: userInteractions.length > 0 ? userInteractions[userInteractions.length - 1].timestamp : null,
      preferred_feedback_patterns: this.getPreferredFeedbackPatterns(userId)
    };
  }

  private getPreferredFeedbackPatterns(userId: string): string[] {
    const userInteractions = this.interactionHistory.filter(
      interaction => interaction.context.user_state === userId
    );

    const patternSuccess: Map<string, { count: number; success: number }> = new Map();

    userInteractions.forEach(interaction => {
      this.coherencePatterns.forEach((pattern, patternType) => {
        if (interaction.coherence_value >= pattern.coherence_threshold) {
          if (!patternSuccess.has(patternType)) {
            patternSuccess.set(patternType, { count: 0, success: 0 });
          }
          const stats = patternSuccess.get(patternType)!;
          stats.count++;
          stats.success++;
        } else {
          if (!patternSuccess.has(patternType)) {
            patternSuccess.set(patternType, { count: 1, success: 0 });
          } else {
            const stats = patternSuccess.get(patternType)!;
            stats.count++;
          }
        }
      });
    });

    return Array.from(patternSuccess.entries())
      .map(([pattern, stats]) => ({
        pattern,
        success_rate: stats.success / stats.count
      }))
      .sort((a, b) => b.success_rate - a.success_rate)
      .slice(0, 3)
      .map(item => item.pattern);
  }

  public getInteractionStatistics(): any {
    const totalInteractions = this.interactionHistory.length;
    const averageCoherence = totalInteractions > 0 
      ? this.interactionHistory.reduce((sum, i) => sum + i.coherence_value, 0) / totalInteractions
      : 0;

    const interactionTypes = ['click', 'scroll', 'hover', 'input', 'navigation'];
    const typeStats: any = {};

    interactionTypes.forEach(type => {
      const typeInteractions = this.interactionHistory.filter(i => i.type === type);
      typeStats[type] = {
        count: typeInteractions.length,
        average_coherence: typeInteractions.length > 0
          ? typeInteractions.reduce((sum, i) => sum + i.coherence_value, 0) / typeInteractions.length
          : 0
      };
    });

    return {
      total_interactions: totalInteractions,
      average_coherence: averageCoherence,
      interaction_types: typeStats,
      active_feedback_signals: this.feedbackSignals.size,
      adaptation_matrix_efficiency: this.calculateAdaptationMatrixEfficiency()
    };
  }

  private calculateAdaptationMatrixEfficiency(): number {
    const flatMatrix = this.adaptationMatrix.flat();
    const average = flatMatrix.reduce((sum, val) => sum + val, 0) / flatMatrix.length;
    return average;
  }

  public reset(): void {
    this.interactionHistory = [];
    this.feedbackSignals.clear();
    this.userProfiles.clear();
    this.initializeAdaptationMatrix();
  }
}