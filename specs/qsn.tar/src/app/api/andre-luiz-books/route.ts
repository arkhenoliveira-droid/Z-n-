import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function GET() {
  try {
    const zai = await ZAI.create();

    // Search for information about André Luiz's books on mediumship
    const searchResult = await zai.functions.invoke("web_search", {
      query: "André Luiz Nos Domínios da Mediunidade Mecanismos da Mediunidade livros espíritas",
      num: 10
    });

    return NextResponse.json({
      success: true,
      data: searchResult,
      message: "Information about André Luiz's books on mediumship"
    });

  } catch (error: any) {
    console.error('Error searching for André Luiz books:', error.message);
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to search for book information',
        details: error.message 
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { question } = await request.json();
    
    if (!question) {
      return NextResponse.json(
        { success: false, error: 'Question is required' },
        { status: 400 }
      );
    }

    const zai = await ZAI.create();

    // Get detailed analysis about the books and their teachings
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: `You are an expert on Spiritist literature, particularly the works of André Luiz (pseudonym of Francisco de Xavier Cândido). 
          
          Focus on providing detailed insights about:
          1. "Nos Domínios da Mediunidade" (In the Realms of Mediumship)
          2. "Mecanismos da Mediunidade" (Mechanisms of Mediumship)
          
          Provide comprehensive analysis of:
          - Key concepts and teachings
          - Spiritual principles explained
          - Practical guidance for mediums
          - Scientific and philosophical perspectives
          - Relevance to modern spiritual understanding
          
          Be thorough, accurate, and provide practical insights that can be applied to spiritual development.`
        },
        {
          role: 'user',
          content: question
        }
      ],
      temperature: 0.7,
      max_tokens: 2000
    });

    const response = completion.choices[0]?.message?.content || 'No response available';

    return NextResponse.json({
      success: true,
      response: response,
      question: question
    });

  } catch (error: any) {
    console.error('Error analyzing André Luiz books:', error.message);
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to analyze book content',
        details: error.message 
      },
      { status: 500 }
    );
  }
}