import { NextRequest, NextResponse } from 'next/server';
import { cloud3AuditFramework } from '@/systems/cloud3-audit-framework';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');

    if (category) {
      const criteria = cloud3AuditFramework.getCriteriaByCategory(category);
      return NextResponse.json({ criteria });
    }

    const allCriteria = cloud3AuditFramework.getCriteria();
    return NextResponse.json({ criteria: allCriteria });
  } catch (error) {
    console.error('Error fetching Cloud3 audit criteria:', error);
    return NextResponse.json(
      { error: 'Failed to fetch Cloud3 audit criteria' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { assessmentResults, auditMetadata } = body;

    if (!assessmentResults || !Array.isArray(assessmentResults)) {
      return NextResponse.json(
        { error: 'Assessment results are required and must be an array' },
        { status: 400 }
      );
    }

    // Calculate overall score
    const overallScore = cloud3AuditFramework.calculateOverallScore(assessmentResults);

    // Generate findings
    const findings = cloud3AuditFramework.generateFindings(assessmentResults);

    // Create audit report
    const auditReport = {
      id: `cloud3-audit-${Date.now()}`,
      title: 'Cloud3 Ventures Security Audit Report',
      auditDate: new Date().toISOString().split('T')[0],
      overallScore,
      status: 'completed',
      criteria: cloud3AuditFramework.getCriteria(),
      findings,
      assessmentResults,
      metadata: {
        ...auditMetadata,
        generatedAt: new Date().toISOString(),
        totalCriteria: cloud3AuditFramework.getCriteria().length,
        totalFindings: findings.length
      }
    };

    return NextResponse.json(auditReport, { status: 201 });
  } catch (error) {
    console.error('Error creating Cloud3 audit report:', error);
    return NextResponse.json(
      { error: 'Failed to create Cloud3 audit report' },
      { status: 500 }
    );
  }
}