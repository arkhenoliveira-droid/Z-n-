import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const investigation = await db.investigation.findUnique({
      where: { id: params.id },
      include: {
        insightObjects: {
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!investigation) {
      return NextResponse.json(
        { error: 'Investigation not found' },
        { status: 404 }
      );
    }

    // Parse JSON fields
    const parsedInvestigation = {
      ...investigation,
      parameters: investigation.parameters ? JSON.parse(investigation.parameters) : null,
      results: investigation.results ? JSON.parse(investigation.results) : null,
      insightsData: investigation.insightsData ? JSON.parse(investigation.insightsData) : null,
      insightObjects: investigation.insightObjects.map(insight => ({
        ...insight,
        data: insight.data ? JSON.parse(insight.data) : null,
      })),
    };

    return NextResponse.json(parsedInvestigation);
  } catch (error) {
    console.error('Error fetching investigation:', error);
    return NextResponse.json(
      { error: 'Failed to fetch investigation' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.investigation.delete({
      where: { id: params.id },
    });

    return NextResponse.json({
      message: 'Investigation deleted successfully',
    });
  } catch (error) {
    console.error('Error deleting investigation:', error);
    return NextResponse.json(
      { error: 'Failed to delete investigation' },
      { status: 500 }
    );
  }
}