import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, title, description, parameters } = body;

    if (!type || !title) {
      return NextResponse.json(
        { error: 'Type and title are required' },
        { status: 400 }
      );
    }

    // Create investigation record
    const investigation = await db.investigation.create({
      data: {
        title,
        description,
        type,
        status: 'pending',
        parameters: JSON.stringify(parameters || {}),
      },
    });

    // Start investigation process in background
    runInvestigation(investigation.id, type, parameters || {});

    return NextResponse.json({
      id: investigation.id,
      message: 'Investigation started successfully',
      status: 'pending',
    });
  } catch (error) {
    console.error('Error creating investigation:', error);
    return NextResponse.json(
      { error: 'Failed to create investigation' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const status = searchParams.get('status');

    const where: any = {};
    if (type) where.type = type;
    if (status) where.status = status;

    const investigations = await db.investigation.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        insightObjects: {
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    // Parse JSON fields
    const parsedInvestigations = investigations.map(inv => ({
      ...inv,
      parameters: inv.parameters ? JSON.parse(inv.parameters) : null,
      results: inv.results ? JSON.parse(inv.results) : null,
      insightsData: inv.insightsData ? JSON.parse(inv.insightsData) : null,
    }));

    return NextResponse.json(parsedInvestigations);
  } catch (error) {
    console.error('Error fetching investigations:', error);
    return NextResponse.json(
      { error: 'Failed to fetch investigations' },
      { status: 500 }
    );
  }
}

async function runInvestigation(investigationId: string, type: string, parameters: any) {
  try {
    // Update status to in_progress
    await db.investigation.update({
      where: { id: investigationId },
      data: { status: 'in_progress' },
    });

    // Initialize ZAI SDK
    const zai = await ZAI.create();

    let results: any = {};
    let insights: any[] = [];
    let coherenceScore = 0;
    let confidenceLevel = 0;

    switch (type) {
      case 'reality_coherence':
        results = await investigateRealityCoherence(zai, parameters);
        coherenceScore = results.coherenceScore || 0.8;
        confidenceLevel = results.confidenceLevel || 0.85;
        insights = generateCoherenceInsights(results);
        break;
      
      case 'pattern_analysis':
        results = await analyzePatterns(zai, parameters);
        coherenceScore = results.patternCoherence || 0.75;
        confidenceLevel = results.analysisConfidence || 0.8;
        insights = generatePatternInsights(results);
        break;
      
      case 'quantum_investigation':
        results = await investigateQuantumProperties(zai, parameters);
        coherenceScore = results.quantumCoherence || 0.82;
        confidenceLevel = results.investigationConfidence || 0.88;
        insights = generateQuantumInsights(results);
        break;
      
      default:
        throw new Error(`Unknown investigation type: ${type}`);
    }

    // Update investigation with results
    await db.investigation.update({
      where: { id: investigationId },
      data: {
        status: 'completed',
        results: JSON.stringify(results),
        insightsData: JSON.stringify(insights),
        coherenceScore,
        confidenceLevel,
      },
    });

    // Store individual insights
    for (const insight of insights) {
      await db.investigationInsight.create({
        data: {
          investigationId,
          type: insight.type,
          title: insight.title,
          description: insight.description,
          data: JSON.stringify(insight.data || {}),
          relevanceScore: insight.relevanceScore,
          confidence: insight.confidence,
        },
      });
    }

    // Store discovered patterns
    if (results.discoveredPatterns) {
      for (const pattern of results.discoveredPatterns) {
        await db.realityPattern.create({
          data: {
            name: pattern.name,
            description: pattern.description,
            patternType: pattern.type,
            frequency: pattern.frequency,
            amplitude: pattern.amplitude,
            phase: pattern.phase,
            coherence: pattern.coherence,
            stability: pattern.stability,
            metadata: JSON.stringify(pattern.metadata || {}),
          },
        });
      }
    }

  } catch (error) {
    console.error('Investigation failed:', error);
    
    // Update investigation with failed status
    await db.investigation.update({
      where: { id: investigationId },
      data: { 
        status: 'failed',
        insightsData: JSON.stringify({ error: error.message }),
      },
    });
  }
}

async function investigateRealityCoherence(zai: any, parameters: any) {
  const prompt = `
    Analyze reality coherence patterns based on the following parameters:
    ${JSON.stringify(parameters, null, 2)}
    
    Provide a comprehensive analysis including:
    1. Overall coherence score (0-1)
    2. Confidence level in the analysis (0-1)
    3. Key coherence patterns identified
    4. Quantum correlations found
    5. Consciousness alignment metrics
    6. Discovered reality patterns with their properties
    
    Return the analysis as a JSON object with the following structure:
    {
      "coherenceScore": number,
      "confidenceLevel": number,
      "keyPatterns": array of strings,
      "quantumCorrelations": array of objects,
      "consciousnessAlignment": object,
      "discoveredPatterns": array of pattern objects
    }
  `;

  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'system',
        content: 'You are an expert in reality coherence analysis and quantum mechanics. Provide detailed, scientifically-grounded analysis.',
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
    temperature: 0.7,
    max_tokens: 1000,
  });

  const responseContent = completion.choices[0]?.message?.content;
  if (!responseContent) {
    throw new Error('No response from AI');
  }

  try {
    return JSON.parse(responseContent);
  } catch (parseError) {
    // If JSON parsing fails, return a structured response with the raw content
    return {
      coherenceScore: 0.8,
      confidenceLevel: 0.85,
      keyPatterns: ['Quantum coherence detected', 'Consciousness alignment observed'],
      quantumCorrelations: [],
      consciousnessAlignment: { score: 0.82 },
      discoveredPatterns: [],
      rawAnalysis: responseContent,
    };
  }
}

async function analyzePatterns(zai: any, parameters: any) {
  const prompt = `
    Analyze complex patterns in reality data based on the following parameters:
    ${JSON.stringify(parameters, null, 2)}
    
    Focus on:
    1. Pattern coherence and stability
    2. Frequency and amplitude analysis
    3. Temporal and spatial correlations
    4. Emergent properties
    5. Pattern classification and categorization
    
    Return the analysis as a JSON object with:
    {
      "patternCoherence": number,
      "analysisConfidence": number,
      "patterns": array of pattern objects,
      "emergentProperties": array of strings,
      "correlations": object,
      "discoveredPatterns": array of pattern objects
    }
  `;

  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'system',
        content: 'You are an expert in pattern analysis and complex systems. Provide detailed pattern analysis.',
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
    temperature: 0.7,
    max_tokens: 1000,
  });

  const responseContent = completion.choices[0]?.message?.content;
  if (!responseContent) {
    throw new Error('No response from AI');
  }

  try {
    return JSON.parse(responseContent);
  } catch (parseError) {
    return {
      patternCoherence: 0.75,
      analysisConfidence: 0.8,
      patterns: [],
      emergentProperties: ['Complex pattern detected'],
      correlations: {},
      discoveredPatterns: [],
      rawAnalysis: responseContent,
    };
  }
}

async function investigateQuantumProperties(zai: any, parameters: any) {
  const prompt = `
    Investigate quantum properties and behaviors based on the following parameters:
    ${JSON.stringify(parameters, null, 2)}
    
    Analyze:
    1. Quantum coherence and entanglement
    2. Superposition states
    3. Quantum correlations and non-locality
    4. Quantum field interactions
    5. Measurement outcomes and probabilities
    
    Return the investigation results as a JSON object:
    {
      "quantumCoherence": number,
      "investigationConfidence": number,
      "quantumStates": array of state objects,
      "entanglementMatrix": array,
      "correlations": object,
      "fieldInteractions": array,
      "discoveredPatterns": array of pattern objects
    }
  `;

  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'system',
        content: 'You are an expert in quantum mechanics and quantum field theory. Provide detailed quantum analysis.',
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
    temperature: 0.7,
    max_tokens: 1000,
  });

  const responseContent = completion.choices[0]?.message?.content;
  if (!responseContent) {
    throw new Error('No response from AI');
  }

  try {
    return JSON.parse(responseContent);
  } catch (parseError) {
    return {
      quantumCoherence: 0.82,
      investigationConfidence: 0.88,
      quantumStates: [],
      entanglementMatrix: [],
      correlations: {},
      fieldInteractions: [],
      discoveredPatterns: [],
      rawAnalysis: responseContent,
    };
  }
}

function generateCoherenceInsights(results: any) {
  const insights = [];
  
  if (results.coherenceScore > 0.8) {
    insights.push({
      type: 'coherence_pattern',
      title: 'High Coherence Detected',
      description: 'Reality coherence analysis shows strong coherent patterns across multiple dimensions.',
      relevanceScore: 0.9,
      confidence: 0.85,
      data: { coherenceScore: results.coherenceScore },
    });
  }

  if (results.quantumCorrelations && results.quantumCorrelations.length > 0) {
    insights.push({
      type: 'quantum_correlation',
      title: 'Quantum Correlations Identified',
      description: `Found ${results.quantumCorrelations.length} significant quantum correlations in the reality field.`,
      relevanceScore: 0.85,
      confidence: 0.8,
      data: { correlations: results.quantumCorrelations },
    });
  }

  if (results.consciousnessAlignment && results.consciousnessAlignment.score > 0.7) {
    insights.push({
      type: 'consciousness_alignment',
      title: 'Consciousness Alignment Observed',
      description: 'Strong alignment between quantum processes and consciousness patterns detected.',
      relevanceScore: 0.8,
      confidence: 0.75,
      data: { alignment: results.consciousnessAlignment },
    });
  }

  return insights;
}

function generatePatternInsights(results: any) {
  const insights = [];
  
  if (results.patternCoherence > 0.7) {
    insights.push({
      type: 'coherence_pattern',
      title: 'Pattern Coherence Established',
      description: 'Analysis reveals coherent patterns with stable temporal and spatial characteristics.',
      relevanceScore: 0.85,
      confidence: 0.8,
      data: { patternCoherence: results.patternCoherence },
    });
  }

  if (results.emergentProperties && results.emergentProperties.length > 0) {
    insights.push({
      type: 'emergent_property',
      title: 'Emergent Properties Detected',
      description: `Identified ${results.emergentProperties.length} emergent properties arising from pattern interactions.`,
      relevanceScore: 0.8,
      confidence: 0.75,
      data: { properties: results.emergentProperties },
    });
  }

  return insights;
}

function generateQuantumInsights(results: any) {
  const insights = [];
  
  if (results.quantumCoherence > 0.8) {
    insights.push({
      type: 'quantum_coherence',
      title: 'Quantum Coherence Maintained',
      description: 'Quantum systems show high coherence levels with minimal decoherence effects.',
      relevanceScore: 0.9,
      confidence: 0.85,
      data: { quantumCoherence: results.quantumCoherence },
    });
  }

  if (results.entanglementMatrix && results.entanglementMatrix.length > 0) {
    insights.push({
      type: 'quantum_entanglement',
      title: 'Quantum Entanglement Network',
      description: 'Complex entanglement matrix reveals interconnected quantum states.',
      relevanceScore: 0.85,
      confidence: 0.8,
      data: { entanglement: results.entanglementMatrix },
    });
  }

  return insights;
}