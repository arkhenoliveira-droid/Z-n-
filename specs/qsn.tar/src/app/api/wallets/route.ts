import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const type = searchParams.get('type');
    const status = searchParams.get('status');
    const riskLevel = searchParams.get('riskLevel');

    const skip = (page - 1) * limit;

    const where: any = {};
    if (type) where.type = type;
    if (status) where.status = status;
    if (riskLevel) where.riskLevel = riskLevel;

    const [wallets, total] = await Promise.all([
      db.wallet.findMany({
        where,
        include: {
          auditTests: {
            orderBy: { createdAt: 'desc' },
            take: 3
          },
          ownershipClaims: {
            where: { status: 'verified' },
            orderBy: { createdAt: 'desc' },
            take: 1
          },
          transactions: {
            orderBy: { timestamp: 'desc' },
            take: 5
          }
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      db.wallet.count({ where })
    ]);

    return NextResponse.json({
      wallets,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Error fetching wallets:', error);
    return NextResponse.json(
      { error: 'Failed to fetch wallets' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      address,
      type,
      name,
      description,
      owner,
      balance,
      status,
      riskLevel,
      metadata
    } = body;

    // Validate required fields
    if (!address || !type) {
      return NextResponse.json(
        { error: 'Address and type are required' },
        { status: 400 }
      );
    }

    // Check if wallet already exists
    const existingWallet = await db.wallet.findUnique({
      where: { address }
    });

    if (existingWallet) {
      return NextResponse.json(
        { error: 'Wallet with this address already exists' },
        { status: 400 }
      );
    }

    const wallet = await db.wallet.create({
      data: {
        address,
        type,
        name,
        description,
        owner,
        balance,
        status: status || 'active',
        riskLevel: riskLevel || 'low',
        metadata: metadata ? JSON.stringify(metadata) : null
      },
      include: {
        auditTests: true,
        ownershipClaims: true,
        transactions: true
      }
    });

    return NextResponse.json(wallet, { status: 201 });
  } catch (error) {
    console.error('Error creating wallet:', error);
    return NextResponse.json(
      { error: 'Failed to create wallet' },
      { status: 500 }
    );
  }
}