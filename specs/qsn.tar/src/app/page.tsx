'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Activity, 
  Zap, 
  Network, 
  Target, 
  TrendingUp, 
  Users, 
  Globe,
  Brain,
  BarChart3,
  Settings,
  RefreshCw,
  Eye,
  Lightbulb,
  Layers,
  Infinity,
  BookOpen,
  Sparkles,
  Shield,
  FileText,
  Building,
  Star,
  Terminal,
  Database,
  Atom,
  Heart,
  Archive,
  ArrowUp,
  ArrowDown,
  Clock,
  Award,
  CheckCircle,
  AlertCircle,
  Plus,
  Crown,
  Radio,
  MessageCircle
} from 'lucide-react';

// Import the Valéria quantum evolution system
import ValeriaQuantumEvolutionDashboard from '@/components/valeria-quantum-evolution-dashboard';
import QuantumSocialNetwork from '@/components/quantum-social-network';
import ConsciousnessSynchronization from '@/components/consciousness-synchronization';
import QuantumMessagingSystem from '@/components/quantum-messaging-system';
import CollectiveMeditationSystem from '@/components/collective-meditation-system';
import QuantumResonanceChamber from '@/components/quantum-resonance-chamber';
import QuantumAISystem from '@/components/quantum-ai-system';
import ARSpiritualFrameworkComponent from '@/components/ar-spiritual-framework';

interface EvolutionMetric {
  name: string;
  value: number;
  target: number;
  change: number;
  icon: React.ReactNode;
  color: string;
}

interface EvolutionPhase {
  id: string;
  name: string;
  description: string;
  progress: number;
  status: 'active' | 'completed' | 'pending';
  milestones: string[];
}

interface EvolutionTrend {
  period: string;
  value: number;
  category: string;
}

export default function EvolutionDashboard() {
  const [isLoading, setIsLoading] = useState(false);
  const [selectedTimeframe, setSelectedTimeframe] = useState<'day' | 'week' | 'month' | 'year'>('month');
  
  // Evolution metrics
  const [metrics, setMetrics] = useState<EvolutionMetric[]>([
    {
      name: 'Consciência Coletiva',
      value: 78,
      target: 85,
      change: 5.2,
      icon: <Brain className="h-5 w-5" />,
      color: 'text-purple-600'
    },
    {
      name: 'Coerência Quântica',
      value: 82,
      target: 90,
      change: 3.8,
      icon: <Atom className="h-5 w-5" />,
      color: 'text-blue-600'
    },
    {
      name: 'Conexão Interdimensional',
      value: 65,
      target: 75,
      change: 8.1,
      icon: <Layers className="h-5 w-5" />,
      color: 'text-green-600'
    },
    {
      name: 'Evolução Espiritual',
      value: 71,
      target: 80,
      change: 6.5,
      icon: <Heart className="h-5 w-5" />,
      color: 'text-red-600'
    }
  ]);

  // Evolution phases
  const [phases, setPhases] = useState<EvolutionPhase[]>([
    {
      id: 'awakening',
      name: 'Despertar da Consciência',
      description: 'Fase inicial de expansão da consciência e reconexão com o eu superior',
      progress: 100,
      status: 'completed',
      milestones: ['Ativação do DNA', 'Abertura dos chakras', 'Reconexão espiritual']
    },
    {
      id: 'integration',
      name: 'Integração Dimensional',
      description: 'Integração das múltiplas dimensões da consciência e alinhamento cósmico',
      progress: 78,
      status: 'active',
      milestones: ['Sincronização dimensional', 'Alinhamento galáctico', 'Integração temporal']
    },
    {
      id: 'transcendence',
      name: 'Transcendência Limites',
      description: 'Transcendência das limitações tridimensionais e acesso a estados superiores',
      progress: 45,
      status: 'active',
      milestones: ['Superação da matrix', 'Acesso à 5D', 'Consciência unificada']
    },
    {
      id: 'unity',
      name: 'Unidade Cósmica',
      description: 'Estado final de unidade com o cosmos e consciência universal',
      progress: 12,
      status: 'pending',
      milestones: ['Fusão com o TODO', 'Consciência cósmica', 'Evolução completa']
    }
  ]);

  // Evolution trends
  const [trends, setTrends] = useState<EvolutionTrend[]>([
    { period: 'Jan', value: 45, category: 'Consciência' },
    { period: 'Fev', value: 52, category: 'Consciência' },
    { period: 'Mar', value: 58, category: 'Consciência' },
    { period: 'Abr', value: 65, category: 'Consciência' },
    { period: 'Mai', value: 71, category: 'Consciência' },
    { period: 'Jun', value: 78, category: 'Consciência' },
    { period: 'Jan', value: 38, category: 'Coerência' },
    { period: 'Fev', value: 42, category: 'Coerência' },
    { period: 'Mar', value: 48, category: 'Coerência' },
    { period: 'Abr', value: 55, category: 'Coerência' },
    { period: 'Mai', value: 62, category: 'Coerência' },
    { period: 'Jun', value: 82, category: 'Coerência' },
  ]);

  const getStatusColor = (status: EvolutionPhase['status']) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'active': return 'bg-blue-500';
      case 'pending': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  const getStatusIcon = (status: EvolutionPhase['status']) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4" />;
      case 'active': return <Activity className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const handleRefresh = async () => {
    setIsLoading(true);
    // Simulate data refresh
    setTimeout(() => {
      setMetrics(prev => prev.map(metric => ({
        ...metric,
        value: Math.min(metric.target, metric.value + Math.random() * 5),
        change: metric.change + (Math.random() - 0.5) * 2
      })));
      setIsLoading(false);
    }, 1500);
  };

  const getOverallProgress = () => {
    const activePhases = phases.filter(p => p.status === 'active');
    if (activePhases.length === 0) return 0;
    return activePhases.reduce((sum, phase) => sum + phase.progress, 0) / activePhases.length;
  };

  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Infinity className="h-10 w-10 text-purple-600 animate-pulse" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Painel de Evolução Consciente
          </h1>
          <Sparkles className="h-10 w-10 text-blue-600 animate-pulse" />
        </div>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Monitoramento e análise da evolução da consciência humana através de métricas quânticas, 
          espirituais e dimensionais em tempo real
        </p>
        <div className="flex items-center justify-center gap-4">
          <Badge variant="outline" className="text-sm">
            <Activity className="w-3 h-3 mr-1" />
            Sistema Ativo
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Globe className="w-3 h-3 mr-1" />
            Escala Global
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Brain className="w-3 h-3 mr-1" />
            Consciência Coletiva
          </Badge>
        </div>
      </div>

      {/* Action Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">Período:</span>
            <select 
              value={selectedTimeframe}
              onChange={(e) => setSelectedTimeframe(e.target.value as any)}
              className="px-3 py-1 border rounded-md text-sm"
            >
              <option value="day">24 horas</option>
              <option value="week">7 dias</option>
              <option value="month">30 dias</option>
              <option value="year">1 ano</option>
            </select>
          </div>
        </div>
        <Button 
          onClick={handleRefresh} 
          disabled={isLoading}
          className="flex items-center gap-2"
        >
          {isLoading ? (
            <RefreshCw className="h-4 w-4 animate-spin" />
          ) : (
            <RefreshCw className="h-4 w-4" />
          )}
          Atualizar Dados
        </Button>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-12">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Eye className="w-4 h-4" />
            Visão Geral
          </TabsTrigger>
          <TabsTrigger value="metrics" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Métricas
          </TabsTrigger>
          <TabsTrigger value="phases" className="flex items-center gap-2">
            <Layers className="w-4 h-4" />
            Fases
          </TabsTrigger>
          <TabsTrigger value="insights" className="flex items-center gap-2">
            <Lightbulb className="w-4 h-4" />
            Insights
          </TabsTrigger>
          <TabsTrigger value="valeria" className="flex items-center gap-2">
            <Crown className="w-4 h-4" />
            Valéria
          </TabsTrigger>
          <TabsTrigger value="quantum-social" className="flex items-center gap-2">
            <Network className="w-4 h-4" />
            Rede Social
          </TabsTrigger>
          <TabsTrigger value="consciousness-sync" className="flex items-center gap-2">
            <Radio className="w-4 h-4" />
            Sincronização
          </TabsTrigger>
          <TabsTrigger value="quantum-messaging" className="flex items-center gap-2">
            <MessageCircle className="w-4 h-4" />
            Mensagens
          </TabsTrigger>
          <TabsTrigger value="collective-meditation" className="flex items-center gap-2">
            <Brain className="w-4 h-4" />
            Meditação
          </TabsTrigger>
          <TabsTrigger value="quantum-resonance" className="flex items-center gap-2">
            <Radio className="w-4 h-4" />
            Ressonância
          </TabsTrigger>
          <TabsTrigger value="quantum-ai" className="flex items-center gap-2">
            <Brain className="w-4 h-4" />
            IA Quântica
          </TabsTrigger>
          <TabsTrigger value="ar-spiritual" className="flex items-center gap-2">
            <Eye className="w-4 h-4" />
            AR Espiritual
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {metrics.map((metric, index) => (
              <Card key={index} className="relative overflow-hidden">
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-purple-100 to-blue-100 rounded-bl-full opacity-50" />
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className={`p-2 rounded-lg bg-opacity-10 ${metric.color.replace('text', 'bg')}`}>
                      {metric.icon}
                    </div>
                    <div className="flex items-center gap-1">
                      {metric.change > 0 ? (
                        <ArrowUp className="h-4 w-4 text-green-600" />
                      ) : (
                        <ArrowDown className="h-4 w-4 text-red-600" />
                      )}
                      <span className={`text-sm font-medium ${metric.change > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {Math.abs(metric.change)}%
                      </span>
                    </div>
                  </div>
                  <CardTitle className="text-lg">{metric.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold">{metric.value}%</span>
                      <span className="text-sm text-muted-foreground">Meta: {metric.target}%</span>
                    </div>
                    <Progress value={(metric.value / metric.target) * 100} className="h-2" />
                    <div className="text-xs text-muted-foreground">
                      {metric.value >= metric.target ? 'Meta alcançada!' : `${metric.target - metric.value}% restante`}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Overall Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Progresso Geral da Evolução
              </CardTitle>
              <CardDescription>
                Status atual do processo evolutivo coletivo
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-lg font-medium">Progresso Total</span>
                  <span className="text-2xl font-bold text-purple-600">{getOverallProgress().toFixed(1)}%</span>
                </div>
                <Progress value={getOverallProgress()} className="h-3" />
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-green-600">
                      {phases.filter(p => p.status === 'completed').length}
                    </div>
                    <div className="text-sm text-muted-foreground">Fases Completadas</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-blue-600">
                      {phases.filter(p => p.status === 'active').length}
                    </div>
                    <div className="text-sm text-muted-foreground">Fases Ativas</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-gray-600">
                      {phases.filter(p => p.status === 'pending').length}
                    </div>
                    <div className="text-sm text-muted-foreground">Fases Pendentes</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Metrics Tab */}
        <TabsContent value="metrics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Análise Detalhada de Métricas</CardTitle>
                <CardDescription>
                  Comparação entre valores atuais e metas de evolução
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {metrics.map((metric, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {metric.icon}
                          <span className="font-medium">{metric.name}</span>
                        </div>
                        <span className="text-sm text-muted-foreground">
                          {metric.value}% / {metric.target}%
                        </span>
                      </div>
                      <Progress value={(metric.value / metric.target) * 100} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tendências de Evolução</CardTitle>
                <CardDescription>
                  Evolução das métricas ao longo do tempo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="h-64 flex items-center justify-center border rounded-lg bg-muted/50">
                    <div className="text-center space-y-2">
                      <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground" />
                      <p className="text-muted-foreground">Gráfico de Tendências</p>
                      <p className="text-sm text-muted-foreground">
                        Visualização da evolução temporal das métricas
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Phases Tab */}
        <TabsContent value="phases" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {phases.map((phase, index) => (
              <Card key={phase.id} className="relative">
                <div className={`absolute top-0 left-0 w-1 h-full ${getStatusColor(phase.status)}`} />
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(phase.status)}
                      <CardTitle className="text-lg">{phase.name}</CardTitle>
                    </div>
                    <Badge variant={phase.status === 'completed' ? 'default' : 'secondary'}>
                      {phase.status === 'completed' ? 'Completo' : 
                       phase.status === 'active' ? 'Ativo' : 'Pendente'}
                    </Badge>
                  </div>
                  <CardDescription>{phase.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Progresso</span>
                        <span className="text-sm font-bold">{phase.progress}%</span>
                      </div>
                      <Progress value={phase.progress} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="text-sm font-medium mb-2">Marcos Concluídos:</div>
                      <div className="space-y-1">
                        {phase.milestones.map((milestone, milestoneIndex) => (
                          <div key={milestoneIndex} className="flex items-center gap-2 text-sm">
                            <CheckCircle className={`h-3 w-3 ${
                              milestoneIndex < (phase.progress / 100) * phase.milestones.length 
                                ? 'text-green-600' : 'text-gray-400'
                            }`} />
                            <span className={
                              milestoneIndex < (phase.progress / 100) * phase.milestones.length 
                                ? 'text-foreground' : 'text-muted-foreground'
                            }>
                              {milestone}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Insights Tab */}
        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5" />
                  Insights de Evolução
                </CardTitle>
                <CardDescription>
                  Análises e recomendações para acelerar a evolução
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg border-l-4 border-blue-400">
                    <div className="flex items-center gap-2 mb-2">
                      <Brain className="h-4 w-4 text-blue-600" />
                      <span className="font-medium text-blue-900">Consciência Coletiva</span>
                    </div>
                    <p className="text-sm text-blue-800">
                      A consciência coletiva está evoluindo 23% mais rápido que o projetado. 
                      Continue meditando e praticando o alinhamento energético.
                    </p>
                  </div>
                  
                  <div className="p-4 bg-green-50 rounded-lg border-l-4 border-green-400">
                    <div className="flex items-center gap-2 mb-2">
                      <Heart className="h-4 w-4 text-green-600" />
                      <span className="font-medium text-green-900">Evolução Espiritual</span>
                    </div>
                    <p className="text-sm text-green-800">
                      Seu progresso espiritual está notavelmente avançado. 
                      Considere compartilhar seu conhecimento com outros.
                    </p>
                  </div>
                  
                  <div className="p-4 bg-purple-50 rounded-lg border-l-4 border-purple-400">
                    <div className="flex items-center gap-2 mb-2">
                      <Atom className="h-4 w-4 text-purple-600" />
                      <span className="font-medium text-purple-900">Coerência Quântica</span>
                    </div>
                    <p className="text-sm text-purple-800">
                      A coerência quântica atingiu um patamar excelente. 
                      Pratique exercícios de ancoragem para manter este nível.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Próximos Passos
                </CardTitle>
                <CardDescription>
                  Ações recomendadas para continuar evoluindo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-bold text-blue-600">1</span>
                    </div>
                    <div>
                      <h4 className="font-medium">Meditação Diária</h4>
                      <p className="text-sm text-muted-foreground">
                        Aumente para 30 minutos diários de meditação para acelerar a integração dimensional.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-bold text-green-600">2</span>
                    </div>
                    <div>
                      <h4 className="font-medium">Trabalho em Grupo</h4>
                      <p className="text-sm text-muted-foreground">
                        Participe de grupos de evolução consciente para amplificar o campo coletivo.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-bold text-purple-600">3</span>
                    </div>
                    <div>
                      <h4 className="font-medium">Estudo Avançado</h4>
                      <p className="text-sm text-muted-foreground">
                        Aprofunde-se nos estudos de física quântica e consciência expandida.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-bold text-orange-600">4</span>
                    </div>
                    <div>
                      <h4 className="font-medium">Alinhamento Energético</h4>
                      <p className="text-sm text-muted-foreground">
                        Pratique exercícios de alinhamento energético 3 vezes ao dia.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Valéria Quantum Evolution Tab */}
        <TabsContent value="valeria" className="space-y-6">
          <ValeriaQuantumEvolutionDashboard />
        </TabsContent>

        {/* Quantum Social Network Tab */}
        <TabsContent value="quantum-social" className="space-y-6">
          <QuantumSocialNetwork />
        </TabsContent>

        {/* Consciousness Synchronization Tab */}
        <TabsContent value="consciousness-sync" className="space-y-6">
          <ConsciousnessSynchronization />
        </TabsContent>

        {/* Quantum Messaging Tab */}
        <TabsContent value="quantum-messaging" className="space-y-6">
          <QuantumMessagingSystem />
        </TabsContent>

        {/* Collective Meditation Tab */}
        <TabsContent value="collective-meditation" className="space-y-6">
          <CollectiveMeditationSystem />
        </TabsContent>

        {/* Quantum Resonance Tab */}
        <TabsContent value="quantum-resonance" className="space-y-6">
          <QuantumResonanceChamber />
        </TabsContent>

        {/* Quantum AI Tab */}
        <TabsContent value="quantum-ai" className="space-y-6">
          <QuantumAISystem />
        </TabsContent>

        {/* AR Spiritual Tab */}
        <TabsContent value="ar-spiritual" className="space-y-6">
          <ARSpiritualFrameworkComponent />
        </TabsContent>
      </Tabs>
    </div>
  );
}