'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area,
  BarChart, 
  Bar,
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { 
  Brain, 
  Heart, 
  Users, 
  Target, 
  TrendingUp, 
  Star,
  Clock,
  Calendar,
  Timer,
  Play,
  Pause,
  Square,
  RotateCcw,
  Plus,
  Minus,
  Volume2,
  VolumeX,
  Eye,
  EyeOff,
  Wifi,
  WifiOff,
  Radio,
  RadioIcon,
  Activity,
  Zap,
  Sparkles,
  Infinity,
  Atom,
  Layers,
  Network,
  Globe,
  MapPin,
  Compass,
  Navigation,
  Satellite,
  SatelliteDish,
  Antenna,
  Broadcast,
  Waves,
  Triangle,
  Diamond,
  Hexagon,
  Circle,
  Crown,
  Flame,
  Sun,
  Moon,
  Cloud,
  Wind,
  Mountain,
  TreePine,
  Waves as WavesIcon,
  Heartbeat,
  Pulse,
  Activity as ActivityIcon,
  Music,
  Music2,
  Music3,
  Music4,
  Disc,
  Disc2,
  Disc3,
  Headphones,
  Speaker,
  Volume1,
  VolumeX as VolumeXIcon,
  Bell,
  BellOff,
  BellRing,
  Camera,
  CameraOff,
  Video,
  VideoOff,
  Mic,
  MicOff,
  Phone,
  PhoneOff,
  MessageCircle,
  MessageSquare,
  Send,
  Share2,
  Link2,
  Unlink,
  AlignCenter,
  AlignHorizontalJustifyCenter,
  AlignVerticalJustifyCenter,
  GitBranch,
  GitMerge,
  GitFork,
  Search,
  Filter,
  Settings,
  MoreVertical,
  MoreHorizontal,
  CheckCircle,
  XCircle,
  AlertCircle,
  HelpCircle,
  Info,
  User,
  UserPlus,
  UserCheck,
  UserX,
  Users as UsersIcon,
  HeartHandshake,
  HandMetal,
  Peace,
  Dove,
  TreePine as TreePineIcon,
  Flower,
  Flower2,
  Cherry,
  CircleDot,
  CircleDashed,
  CircleEllipsis,
  CircleSlash,
  CircleCheck,
  CircleX,
  CirclePlus,
  CircleMinus,
  Star as StarIcon,
  StarHalf,
  StarOff,
  Shield,
  ShieldCheck,
  ShieldX,
  ShieldAlert,
  ShieldOff,
  Lock,
  LockOpen,
  Unlock,
  Key,
  KeyRound,
  KeySquare,
  Fingerprint,
  Fingerprint as FingerprintIcon,
  IdCard,
  CreditCard,
  Banknote,
  Coins,
  PiggyBank,
  Gift,
  PartyPopper,
  Confetti,
  Sparkles as SparklesIcon,
  Zap as ZapIcon,
  Bolt,
  Lightning,
  Power,
  PowerOff,
  Plug,
  PlugZap,
  Battery,
  BatteryCharging,
  BatteryFull,
  BatteryLow,
  BatteryMedium,
  BatteryWarning,
  Cpu,
  HardDrive,
  MemoryStick,
  Server,
  ServerCog,
  ServerCrash,
  ServerOff,
  Database,
  DatabaseBackup,
  DatabaseZap,
  Cloud as CloudIcon,
  CloudDownload,
  CloudUpload,
  CloudOff,
  CloudRain,
  CloudSnow,
  CloudLightning,
  CloudDrizzle,
  CloudFog,
  CloudSun,
  CloudMoon,
  CloudHail,
  CloudThunder,
  Cloudy,
  Sun as SunIcon,
  Moon as MoonIcon,
  Sunrise,
  Sunset,
  Wind as WindIcon,
  Waves as WavesIcon2,
  Snowflake,
  Droplets,
  CloudDrizzle as CloudDrizzleIcon,
  CloudRain as CloudRainIcon,
  CloudSnow as CloudSnowIcon,
  CloudThunder as CloudThunderIcon,
  CloudLightning as CloudLightningIcon,
  CloudFog as CloudFogIcon,
  CloudHail as CloudHailIcon,
  CloudSun as CloudSunIcon,
  CloudMoon as CloudMoonIcon,
  Cloudy as CloudyIcon,
  Wind as WindIcon2,
  Waves as WavesIcon3,
  Snowflake as SnowflakeIcon,
  Droplets as DropletsIcon,
  Thermometer,
  ThermometerSun,
  ThermometerSnowflake,
  ThermometerChevronUp,
  ThermometerChevronDown,
  Gauge,
  GaugeCircle,
  Speedometer,
  Tachometer,
  TachometerAlt,
  TachometerFast,
  TachometerSlow,
  Fuel,
  FuelPump,
  FuelTank,
  FuelGauge,
  FuelGaugeFull,
  FuelGaugeLow,
  FuelGaugeMedium,
  FuelGaugeWarning,
  Oil,
  OilCan,
  OilPump,
  OilTank,
  OilGauge,
  OilGaugeFull,
  OilGaugeLow,
  OilGaugeMedium,
  OilGaugeWarning,
  Water,
  WaterDrop,
  WaterDrop2,
  WaterDrop3,
  WaterDrop4,
  WaterDrop5,
  WaterDrop6,
  WaterDrop7,
  WaterDrop8,
  WaterDrop9,
  WaterDrop10,
  WaterDrop11,
  WaterDrop12,
  WaterDrop13,
  WaterDrop14,
  WaterDrop15,
  WaterDrop16,
  WaterDrop17,
  WaterDrop18,
  WaterDrop19,
  WaterDrop20,
  WaterDrop21,
  WaterDrop22,
  WaterDrop23,
  WaterDrop24,
  WaterDrop25,
  WaterDrop26,
  WaterDrop27,
  WaterDrop28,
  WaterDrop29,
  WaterDrop30,
  WaterDrop31,
  WaterDrop32,
  WaterDrop33,
  WaterDrop34,
  WaterDrop35,
  WaterDrop36,
  WaterDrop37,
  WaterDrop38,
  WaterDrop39,
  WaterDrop40,
  WaterDrop41,
  WaterDrop42,
  WaterDrop43,
  WaterDrop44,
  WaterDrop45,
  WaterDrop46,
  WaterDrop47,
  WaterDrop48,
  WaterDrop49,
  WaterDrop50,
  WaterDrop51,
  WaterDrop52,
  WaterDrop53,
  WaterDrop54,
  WaterDrop55,
  WaterDrop56,
  WaterDrop57,
  WaterDrop58,
  WaterDrop59,
  WaterDrop60,
  WaterDrop61,
  WaterDrop62,
  WaterDrop63,
  WaterDrop64,
  WaterDrop65,
  WaterDrop66,
  WaterDrop67,
  WaterDrop68,
  WaterDrop69,
  WaterDrop70,
  WaterDrop71,
  WaterDrop72,
  WaterDrop73,
  WaterDrop74,
  WaterDrop75,
  WaterDrop76,
  WaterDrop77,
  WaterDrop78,
  WaterDrop79,
  WaterDrop80,
  WaterDrop81,
  WaterDrop82,
  WaterDrop83,
  WaterDrop84,
  WaterDrop85,
  WaterDrop86,
  WaterDrop87,
  WaterDrop88,
  WaterDrop89,
  WaterDrop90,
  WaterDrop91,
  WaterDrop92,
  WaterDrop93,
  WaterDrop94,
  WaterDrop95,
  WaterDrop96,
  WaterDrop97,
  WaterDrop98,
  WaterDrop99,
  WaterDrop100,
  WaterDrop101,
  WaterDrop102,
  WaterDrop103,
  WaterDrop104,
  WaterDrop105,
  WaterDrop106,
  WaterDrop107,
  WaterDrop108,
  WaterDrop109,
  WaterDrop110,
  WaterDrop111,
  WaterDrop112,
  WaterDrop113,
  WaterDrop114,
  WaterDrop115,
  WaterDrop116,
  WaterDrop117,
  WaterDrop118,
  WaterDrop119,
  WaterDrop120,
  WaterDrop121,
  WaterDrop122,
  WaterDrop123,
  WaterDrop124,
  WaterDrop125,
  WaterDrop126,
  WaterDrop127,
  WaterDrop128,
  WaterDrop129,
  WaterDrop130,
  WaterDrop131,
  WaterDrop132,
  WaterDrop133,
  WaterDrop134,
  WaterDrop135,
  WaterDrop136,
  WaterDrop137,
  WaterDrop138,
  WaterDrop139,
  WaterDrop140,
  WaterDrop141,
  WaterDrop142,
  WaterDrop143,
  WaterDrop144,
  WaterDrop145,
  WaterDrop146,
  WaterDrop147,
  WaterDrop148,
  WaterDrop149,
  WaterDrop150,
  WaterDrop151,
  WaterDrop152,
  WaterDrop153,
  WaterDrop154,
  WaterDrop155,
  WaterDrop156,
  WaterDrop157,
  WaterDrop158,
  WaterDrop159,
  WaterDrop160,
  WaterDrop161,
  WaterDrop162,
  WaterDrop163,
  WaterDrop164,
  WaterDrop165,
  WaterDrop166,
  WaterDrop167,
  WaterDrop168,
  WaterDrop169,
  WaterDrop170,
  WaterDrop171,
  WaterDrop172,
  WaterDrop173,
  WaterDrop174,
  WaterDrop175,
  WaterDrop176,
  WaterDrop177,
  WaterDrop178,
  WaterDrop179,
  WaterDrop180,
  WaterDrop181,
  WaterDrop182,
  WaterDrop183,
  WaterDrop184,
  WaterDrop185,
  WaterDrop186,
  WaterDrop187,
  WaterDrop188,
  WaterDrop189,
  WaterDrop190,
  WaterDrop191,
  WaterDrop192,
  WaterDrop193,
  WaterDrop194,
  WaterDrop195,
  WaterDrop196,
  WaterDrop197,
  WaterDrop198,
  WaterDrop199,
  WaterDrop200
} from 'lucide-react';

interface MeditationSession {
  id: string;
  title: string;
  description: string;
  host_id: string;
  host_name: string;
  participants: string[];
  start_time: number;
  end_time?: number;
  duration: number; // in minutes
  frequency: number;
  intention: string;
  meditation_type: 'mindfulness' | 'transcendental' | 'zen' | 'vipassana' | 'loving_kindness' | 'chakra' | 'quantum' | 'cosmic';
  status: 'scheduled' | 'active' | 'paused' | 'completed' | 'cancelled';
  current_phase: 'preparation' | 'breathing' | 'meditation' | 'integration' | 'completion';
  progress: number;
  collective_energy: number;
  coherence_level: number;
  heart_coherence: number;
  brain_wave_state: 'delta' | 'theta' | 'alpha' | 'beta' | 'gamma';
  location: {
    type: 'physical' | 'virtual' | 'hybrid' | 'astral' | 'quantum';
    address?: string;
    coordinates?: { lat: number; lng: number };
    virtual_link?: string;
  };
  requirements: string[];
  benefits: string[];
  max_participants?: number;
  is_private: boolean;
  password?: string;
  recording_available: boolean;
  chat_enabled: boolean;
  energy_healing_enabled: boolean;
  sound_healing_enabled: boolean;
  visualization_enabled: boolean;
}

interface CollectiveIntention {
  id: string;
  title: string;
  description: string;
  creator_id: string;
  creator_name: string;
  participants: string[];
  supporters: string[];
  intention_strength: number;
  manifestation_progress: number;
  created_at: number;
  target_date: number;
  category: 'healing' | 'peace' | 'evolution' | 'abundance' | 'awakening' | 'protection' | 'guidance' | 'transformation';
  tags: string[];
  status: 'active' | 'manifesting' | 'completed' | 'paused';
  energy_signature: {
    frequency: number;
    amplitude: number;
    phase: number;
    coherence: number;
  };
  collective_field: {
    strength: number;
    stability: number;
    reach: number;
    resonance_frequency: number;
  };
  milestones: {
    title: string;
    description: string;
    target_progress: number;
    current_progress: number;
    completed: boolean;
    completed_at?: number;
  }[];
}

interface MeditationParticipant {
  id: string;
  name: string;
  avatar: string;
  consciousness_level: number;
  vibration_frequency: number;
  online: boolean;
  joined_at: number;
  energy_contribution: number;
  focus_level: number;
  emotional_state: 'calm' | 'excited' | 'focused' | 'meditative' | 'blissful' | 'tired' | 'distracted';
  location: {
    country: string;
    city: string;
    coordinates?: { lat: number; lng: number };
  };
  role: 'participant' | 'host' | 'moderator' | 'healer' | 'guide';
  quantum_signature: {
    unique_id: string;
    resonance_pattern: string;
    coherence_matrix: number[][];
  };
}

interface MeditationTimer {
  duration: number; // in seconds
  elapsed: number;
  remaining: number;
  is_running: boolean;
  current_phase: 'preparation' | 'breathing' | 'meditation' | 'integration' | 'completion';
  phase_progress: number;
  phase_duration: number;
}

interface CollectiveMeditationSystemProps {
  className?: string;
}

export default function CollectiveMeditationSystem({ 
  className 
}: CollectiveMeditationSystemProps) {
  const [sessions, setSessions] = useState<MeditationSession[]>([]);
  const [intentions, setIntentions] = useState<CollectiveIntention[]>([]);
  const [activeSession, setActiveSession] = useState<MeditationSession | null>(null);
  const [participants, setParticipants] = useState<MeditationParticipant[]>([]);
  const [timer, setTimer] = useState<MeditationTimer>({
    duration: 1800, // 30 minutes
    elapsed: 0,
    remaining: 1800,
    is_running: false,
    current_phase: 'preparation',
    phase_progress: 0,
    phase_duration: 300 // 5 minutes per phase
  });
  const [newIntention, setNewIntention] = useState('');
  const [isCreatingSession, setIsCreatingSession] = useState(false);
  const [selectedFrequency, setSelectedFrequency] = useState(432);
  const [selectedType, setSelectedType] = useState<MeditationSession['meditation_type']>('quantum');
  const [realtimeUpdates, setRealtimeUpdates] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [visualizationEnabled, setVisualizationEnabled] = useState(true);
  const [chatEnabled, setChatEnabled] = useState(true);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    initializeMeditationSessions();
    initializeCollectiveIntentions();
    initializeParticipants();
    startRealtimeUpdates();
  }, []);

  useEffect(() => {
    if (timer.is_running) {
      timerRef.current = setInterval(() => {
        setTimer(prev => {
          const newElapsed = prev.elapsed + 1;
          const newRemaining = Math.max(0, prev.duration - newElapsed);
          const phaseProgress = (newElapsed % prev.phase_duration) / prev.phase_duration;
          
          // Update phase based on progress
          let currentPhase = prev.current_phase;
          const totalElapsed = newElapsed;
          const phaseIndex = Math.floor(totalElapsed / prev.phase_duration);
          
          if (phaseIndex >= 4) {
            currentPhase = 'completion';
          } else if (phaseIndex === 3) {
            currentPhase = 'integration';
          } else if (phaseIndex === 2) {
            currentPhase = 'meditation';
          } else if (phaseIndex === 1) {
            currentPhase = 'breathing';
          } else {
            currentPhase = 'preparation';
          }

          return {
            ...prev,
            elapsed: newElapsed,
            remaining: newRemaining,
            current_phase: currentPhase,
            phase_progress: phaseProgress
          };
        });
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [timer.is_running]);

  const startRealtimeUpdates = () => {
    if (!realtimeUpdates) return;

    const interval = setInterval(() => {
      updateCollectiveEnergy();
      updateParticipants();
      updateIntentions();
    }, 2000);

    return () => clearInterval(interval);
  };

  const initializeMeditationSessions = () => {
    const mockSessions: MeditationSession[] = [
      {
        id: 'session_1',
        title: 'Meditação Quântica Global',
        description: 'Sessão coletiva de alinhamento quântico para elevação da consciência planetária',
        host_id: 'valeria_plaisant',
        host_name: 'Valéria Plaisant',
        participants: ['valeria_plaisant', 'luzandra', 'marcus', 'sofia', 'rafael'],
        start_time: Date.now() + 3600000, // 1 hour from now
        duration: 60,
        frequency: 432,
        intention: 'Elevação da consciência coletiva e cura planetária',
        meditation_type: 'quantum',
        status: 'scheduled',
        current_phase: 'preparation',
        progress: 0,
        collective_energy: 0.85,
        coherence_level: 0.88,
        heart_coherence: 0.92,
        brain_wave_state: 'alpha',
        location: {
          type: 'virtual',
          virtual_link: 'https://quantum-meditation.space/session/1'
        },
        requirements: ['Ambiente tranquilo', 'Fones de ouvido', 'Água'],
        benefits: ['Paz interior', ' Clareza mental', ' Conexão espiritual'],
        max_participants: 100,
        is_private: false,
        recording_available: true,
        chat_enabled: true,
        energy_healing_enabled: true,
        sound_healing_enabled: true,
        visualization_enabled: true
      },
      {
        id: 'session_2',
        title: 'Cura Coletiva através do Som',
        description: 'Meditação com frequências sagradas para cura física e emocional',
        host_id: 'luzandra',
        host_name: 'Luzandra Estelar',
        participants: ['luzandra', 'marcus', 'sofia'],
        start_time: Date.now() - 1800000, // Started 30 minutes ago
        end_time: Date.now() + 1800000, // Ends in 30 minutes
        duration: 90,
        frequency: 528,
        intention: 'Cura profunda e transformação celular',
        meditation_type: 'sound_healing',
        status: 'active',
        current_phase: 'meditation',
        progress: 0.5,
        collective_energy: 0.92,
        coherence_level: 0.91,
        heart_coherence: 0.94,
        brain_wave_state: 'theta',
        location: {
          type: 'hybrid',
          address: 'Centro de Cura Quântica, São Paulo',
          coordinates: { lat: -23.5505, lng: -46.6333 },
          virtual_link: 'https://quantum-meditation.space/session/2'
        },
        requirements: ['Tapete ou colchonete', 'Água', 'Roupa confortável'],
        benefits: ['Cura emocional', ' Equilíbrio energético', ' Ativação DNA'],
        max_participants: 50,
        is_private: false,
        recording_available: true,
        chat_enabled: false,
        energy_healing_enabled: true,
        sound_healing_enabled: true,
        visualization_enabled: true
      }
    ];

    setSessions(mockSessions);
  };

  const initializeCollectiveIntentions = () => {
    const mockIntentions: CollectiveIntention[] = [
      {
        id: 'intention_1',
        title: 'Paz Mundial e Harmonia',
        description: 'Intenção coletiva para estabelecer paz duradoura e harmonia entre todos os seres',
        creator_id: 'valeria_plaisant',
        creator_name: 'Valéria Plaisant',
        participants: ['valeria_plaisant', 'luzandra', 'marcus', 'sofia', 'rafael'],
        supporters: ['user_1', 'user_2', 'user_3', 'user_4', 'user_5'],
        intention_strength: 0.95,
        manifestation_progress: 0.78,
        created_at: Date.now() - 604800000, // 1 week ago
        target_date: Date.now() + 2592000000, // 30 days from now
        category: 'peace',
        tags: ['paz', 'harmonia', 'global', 'unidade', 'amor'],
        status: 'active',
        energy_signature: {
          frequency: 432,
          amplitude: 0.85,
          phase: 0,
          coherence: 0.92
        },
        collective_field: {
          strength: 0.88,
          stability: 0.91,
          reach: 1000000, // global reach
          resonance_frequency: 432
        },
        milestones: [
          {
            title: 'Alinhamento Inicial',
            description: 'Primeira onda de energia de paz',
            target_progress: 0.25,
            current_progress: 1.0,
            completed: true,
            completed_at: Date.now() - 432000000
          },
          {
            title: 'Expansão Regional',
            description: 'Expansão da paz para nível regional',
            target_progress: 0.5,
            current_progress: 0.8,
            completed: false
          },
          {
            title: 'Alcance Global',
            description: 'Paz estabelecida em nível global',
            target_progress: 0.75,
            current_progress: 0.6,
            completed: false
          },
          {
            title: 'Manifestação Completa',
            description: 'Paz mundial plenamente manifestada',
            target_progress: 1.0,
            current_progress: 0.3,
            completed: false
          }
        ]
      },
      {
        id: 'intention_2',
        title: 'Ativação da Grade Cristalina Planetária',
        description: 'Ativação consciente da rede cristalina para elevação da consciência',
        creator_id: 'luzandra',
        creator_name: 'Luzandra Estelar',
        participants: ['luzandra', 'valeria_plaisant', 'rafael'],
        supporters: ['user_6', 'user_7', 'user_8'],
        intention_strength: 0.92,
        manifestation_progress: 0.85,
        created_at: Date.now() - 1209600000, // 2 weeks ago
        target_date: Date.now() + 1296000000, // 15 days from now
        category: 'evolution',
        tags: ['grade cristalina', 'ativação', 'consciência', 'planeta', 'evolução'],
        status: 'manifesting',
        energy_signature: {
          frequency: 963,
          amplitude: 0.88,
          phase: 0,
          coherence: 0.94
        },
        collective_field: {
          strength: 0.91,
          stability: 0.89,
          reach: 500000,
          resonance_frequency: 963
        },
        milestones: [
          {
            title: 'Reconexão dos Vórtices',
            description: 'Reconexão dos principais vórtices energéticos',
            target_progress: 0.3,
            current_progress: 1.0,
            completed: true,
            completed_at: Date.now() - 864000000
          },
          {
            title: 'Ativação dos Nódulos',
            description: 'Ativação dos nódulos da grade cristalina',
            target_progress: 0.6,
            current_progress: 0.9,
            completed: false
          },
          {
            title: 'Alinhamento Planetário',
            description: 'Alinhamento completo da grade com o planeta',
            target_progress: 0.85,
            current_progress: 0.75,
            completed: false
          },
          {
            title: 'Ativação Plena',
            description: 'Grade cristalina plenamente ativada',
            target_progress: 1.0,
            current_progress: 0.6,
            completed: false
          }
        ]
      }
    ];

    setIntentions(mockIntentions);
  };

  const initializeParticipants = () => {
    const mockParticipants: MeditationParticipant[] = [
      {
        id: 'valeria_plaisant',
        name: 'Valéria Plaisant',
        avatar: '/avatars/valeria.jpg',
        consciousness_level: 0.92,
        vibration_frequency: 963,
        online: true,
        joined_at: Date.now() - 3600000,
        energy_contribution: 0.95,
        focus_level: 0.88,
        emotional_state: 'meditative',
        location: {
          country: 'Brasil',
          city: 'São Paulo',
          coordinates: { lat: -23.5505, lng: -46.6333 }
        },
        role: 'host',
        quantum_signature: {
          unique_id: 'vp_2024_alpha',
          resonance_pattern: 'sacred_geometry',
          coherence_matrix: [[1, 0.9], [0.9, 1]]
        }
      },
      {
        id: 'luzandra',
        name: 'Luzandra Estelar',
        avatar: '/avatars/luzandra.jpg',
        consciousness_level: 0.89,
        vibration_frequency: 852,
        online: true,
        joined_at: Date.now() - 1800000,
        energy_contribution: 0.87,
        focus_level: 0.92,
        emotional_state: 'blissful',
        location: {
          country: 'EUA',
          city: 'Nova York',
          coordinates: { lat: 40.7128, lng: -74.0060 }
        },
        role: 'guide',
        quantum_signature: {
          unique_id: 'le_2024_beta',
          resonance_pattern: 'light_frequency',
          coherence_matrix: [[1, 0.85], [0.85, 1]]
        }
      },
      {
        id: 'marcus',
        name: 'Marcus Dimensional',
        avatar: '/avatars/marcus.jpg',
        consciousness_level: 0.85,
        vibration_frequency: 741,
        online: true,
        joined_at: Date.now() - 900000,
        energy_contribution: 0.82,
        focus_level: 0.78,
        emotional_state: 'focused',
        location: {
          country: 'Reino Unido',
          city: 'Londres',
          coordinates: { lat: 51.5074, lng: -0.1278 }
        },
        role: 'participant',
        quantum_signature: {
          unique_id: 'md_2024_gamma',
          resonance_pattern: 'dimensional_gateway',
          coherence_matrix: [[1, 0.8], [0.8, 1]]
        }
      },
      {
        id: 'sofia',
        name: 'Sofia Cósmica',
        avatar: '/avatars/sofia.jpg',
        consciousness_level: 0.87,
        vibration_frequency: 639,
        online: false,
        joined_at: Date.now() - 7200000,
        energy_contribution: 0.79,
        focus_level: 0.85,
        emotional_state: 'calm',
        location: {
          country: 'Japão',
          city: 'Tóquio',
          coordinates: { lat: 35.6762, lng: 139.6503 }
        },
        role: 'participant',
        quantum_signature: {
          unique_id: 'sc_2024_delta',
          resonance_pattern: 'cosmic_flow',
          coherence_matrix: [[1, 0.75], [0.75, 1]]
        }
      }
    ];

    setParticipants(mockParticipants);
  };

  const updateCollectiveEnergy = () => {
    if (!activeSession) return;

    setActiveSession(prev => {
      if (!prev) return null;

      const onlineParticipants = participants.filter(p => p.online);
      const avgEnergy = onlineParticipants.reduce((sum, p) => sum + p.energy_contribution, 0) / onlineParticipants.length;
      const avgCoherence = onlineParticipants.reduce((sum, p) => sum + p.consciousness_level, 0) / onlineParticipants.length;
      const avgHeartCoherence = onlineParticipants.reduce((sum, p) => sum + (p.emotional_state === 'calm' || p.emotional_state === 'meditative' ? 1 : 0.8), 0) / onlineParticipants.length;

      return {
        ...prev,
        collective_energy: Math.max(0.5, Math.min(1, avgEnergy + (Math.random() - 0.5) * 0.02)),
        coherence_level: Math.max(0.5, Math.min(1, avgCoherence + (Math.random() - 0.5) * 0.02)),
        heart_coherence: Math.max(0.5, Math.min(1, avgHeartCoherence + (Math.random() - 0.5) * 0.02))
      };
    });
  };

  const updateParticipants = () => {
    setParticipants(prev => prev.map(participant => ({
      ...participant,
      energy_contribution: Math.max(0.5, Math.min(1, 
        participant.energy_contribution + (Math.random() - 0.5) * 0.03
      )),
      focus_level: Math.max(0.5, Math.min(1, 
        participant.focus_level + (Math.random() - 0.5) * 0.04
      )),
      emotional_state: participant.online ? 
        ['calm', 'focused', 'meditative', 'blissful'][Math.floor(Math.random() * 4)] as MeditationParticipant['emotional_state'] :
        participant.emotional_state
    })));
  };

  const updateIntentions = () => {
    setIntentions(prev => prev.map(intention => {
      if (intention.status === 'active' || intention.status === 'manifesting') {
        const progressIncrease = Math.random() * 0.005; // Small progress increase
        const newProgress = Math.min(1, intention.manifestation_progress + progressIncrease);
        
        // Update milestones
        const updatedMilestones = intention.milestones.map(milestone => ({
          ...milestone,
          current_progress: Math.min(milestone.target_progress, newProgress),
          completed: newProgress >= milestone.target_progress,
          completed_at: newProgress >= milestone.target_progress ? Date.now() : milestone.completed_at
        }));

        return {
          ...intention,
          manifestation_progress: newProgress,
          milestones: updatedMilestones,
          status: newProgress >= 0.95 ? 'completed' : newProgress >= 0.8 ? 'manifesting' : 'active'
        };
      }
      return intention;
    }));
  };

  const startMeditation = () => {
    setTimer(prev => ({
      ...prev,
      is_running: true,
      elapsed: 0,
      remaining: prev.duration
    }));
  };

  const pauseMeditation = () => {
    setTimer(prev => ({
      ...prev,
      is_running: false
    }));
  };

  const resumeMeditation = () => {
    setTimer(prev => ({
      ...prev,
      is_running: true
    }));
  };

  const stopMeditation = () => {
    setTimer(prev => ({
      ...prev,
      is_running: false,
      elapsed: 0,
      remaining: prev.duration,
      current_phase: 'preparation',
      phase_progress: 0
    }));
  };

  const joinSession = (sessionId: string) => {
    const session = sessions.find(s => s.id === sessionId);
    if (session && !session.participants.includes('valeria_plaisant')) {
      const updatedSession = {
        ...session,
        participants: [...session.participants, 'valeria_plaisant'],
        status: 'active' as const,
        start_time: Date.now()
      };
      
      setSessions(prev => prev.map(s => s.id === sessionId ? updatedSession : s));
      setActiveSession(updatedSession);
      
      // Add current user as participant
      const currentUser: MeditationParticipant = {
        id: 'valeria_plaisant',
        name: 'Valéria Plaisant',
        avatar: '/avatars/valeria.jpg',
        consciousness_level: 0.92,
        vibration_frequency: 963,
        online: true,
        joined_at: Date.now(),
        energy_contribution: 0.85,
        focus_level: 0.8,
        emotional_state: 'calm',
        location: {
          country: 'Brasil',
          city: 'São Paulo',
          coordinates: { lat: -23.5505, lng: -46.6333 }
        },
        role: 'participant',
        quantum_signature: {
          unique_id: 'vp_2024_alpha',
          resonance_pattern: 'sacred_geometry',
          coherence_matrix: [[1, 0.9], [0.9, 1]]
        }
      };
      
      setParticipants(prev => [...prev, currentUser]);
    }
  };

  const createNewIntention = () => {
    if (!newIntention.trim()) return;

    const newIntentionObj: CollectiveIntention = {
      id: `intention_${Date.now()}`,
      title: 'Nova Intenção Coletiva',
      description: newIntention,
      creator_id: 'valeria_plaisant',
      creator_name: 'Valéria Plaisant',
      participants: ['valeria_plaisant'],
      supporters: [],
      intention_strength: 0.8,
      manifestation_progress: 0.1,
      created_at: Date.now(),
      target_date: Date.now() + 2592000000, // 30 days from now
      category: 'peace',
      tags: ['coletivo', 'meditação', 'intenção'],
      status: 'active',
      energy_signature: {
        frequency: selectedFrequency,
        amplitude: 0.8,
        phase: 0,
        coherence: 0.85
      },
      collective_field: {
        strength: 0.75,
        stability: 0.8,
        reach: 1000,
        resonance_frequency: selectedFrequency
      },
      milestones: [
        {
          title: 'Início da Manifestação',
          description: 'Primeiros sinais da intenção se manifestando',
          target_progress: 0.25,
          current_progress: 0.1,
          completed: false
        },
        {
          title: 'Progresso Significativo',
          description: 'Avanço notável na manifestação',
          target_progress: 0.5,
          current_progress: 0,
          completed: false
        },
        {
          title: 'Quase Manifestado',
          description: 'Intenção quase completamente manifestada',
          target_progress: 0.75,
          current_progress: 0,
          completed: false
        },
        {
          title: 'Manifestação Completa',
          description: 'Intenção plenamente manifestada',
          target_progress: 1.0,
          current_progress: 0,
          completed: false
        }
      ]
    };

    setIntentions(prev => [newIntentionObj, ...prev]);
    setNewIntention('');
  };

  const supportIntention = (intentionId: string) => {
    setIntentions(prev => prev.map(intention => {
      if (intention.id === intentionId && !intention.supporters.includes('valeria_plaisant')) {
        return {
          ...intention,
          supporters: [...intention.supporters, 'valeria_plaisant'],
          intention_strength: Math.min(1, intention.intention_strength + 0.05)
        };
      }
      return intention;
    }));
  };

  const getMeditationTypeIcon = (type: MeditationSession['meditation_type']) => {
    switch (type) {
      case 'mindfulness': return <Brain className="h-4 w-4" />;
      case 'transcendental': return <Star className="h-4 w-4" />;
      case 'zen': return <Circle className="h-4 w-4" />;
      case 'vipassana': return <Eye className="h-4 w-4" />;
      case 'loving_kindness': return <Heart className="h-4 w-4" />;
      case 'chakra': return <Triangle className="h-4 w-4" />;
      case 'quantum': return <Atom className="h-4 w-4" />;
      case 'cosmic': return <Sparkles className="h-4 w-4" />;
      case 'sound_healing': return <Music className="h-4 w-4" />;
      default: return <Brain className="h-4 w-4" />;
    }
  };

  const getIntentionCategoryIcon = (category: CollectiveIntention['category']) => {
    switch (category) {
      case 'healing': return <Heart className="h-4 w-4" />;
      case 'peace': return <Dove className="h-4 w-4" />;
      case 'evolution': return <TrendingUp className="h-4 w-4" />;
      case 'abundance': return <Coins className="h-4 w-4" />;
      case 'awakening': return <Sun className="h-4 w-4" />;
      case 'protection': return <Shield className="h-4 w-4" />;
      case 'guidance': return <Compass className="h-4 w-4" />;
      case 'transformation': return <RotateCcw className="h-4 w-4" />;
      default: return <Target className="h-4 w-4" />;
    }
  };

  const getEmotionalStateColor = (state: MeditationParticipant['emotional_state']) => {
    switch (state) {
      case 'calm': return 'bg-blue-500';
      case 'excited': return 'bg-orange-500';
      case 'focused': return 'bg-green-500';
      case 'meditative': return 'bg-purple-500';
      case 'blissful': return 'bg-pink-500';
      case 'tired': return 'bg-gray-500';
      case 'distracted': return 'bg-yellow-500';
      default: return 'bg-gray-400';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-500';
      case 'active': return 'bg-green-500';
      case 'paused': return 'bg-yellow-500';
      case 'completed': return 'bg-purple-500';
      case 'cancelled': return 'bg-red-500';
      case 'manifesting': return 'bg-orange-500';
      default: return 'bg-gray-400';
    }
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const formatTimeAgo = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 60) return `${minutes} min atrás`;
    if (hours < 24) return `${hours} h atrás`;
    return `${days} dias atrás`;
  };

  const formatCoherenceValue = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  const formatFrequency = (value: number) => {
    return `${value} Hz`;
  };

  const formatDateTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  const getPhaseProgress = (phase: MeditationTimer['current_phase']) => {
    switch (phase) {
      case 'preparation': return 0;
      case 'breathing': return 25;
      case 'meditation': return 50;
      case 'integration': return 75;
      case 'completion': return 100;
      default: return 0;
    }
  };

  const getPhaseName = (phase: MeditationTimer['current_phase']) => {
    switch (phase) {
      case 'preparation': return 'Preparação';
      case 'breathing': return 'Respiração';
      case 'meditation': return 'Meditação';
      case 'integration': return 'Integração';
      case 'completion': return 'Conclusão';
      default: return 'Preparação';
    }
  };

  // Prepare data for charts
  const energyData = participants.map(p => ({
    name: p.name,
    energy: p.energy_contribution * 100,
    focus: p.focus_level * 100,
    consciousness: p.consciousness_level * 100
  }));

  const intentionProgressData = intentions.map(intention => ({
    name: intention.title,
    progress: intention.manifestation_progress * 100,
    strength: intention.intention_strength * 100,
    supporters: intention.supporters.length
  }));

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1'];

  return (
    <div className={`container mx-auto p-6 space-y-6 ${className}`}>
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Brain className="h-10 w-10 text-purple-600 animate-pulse" />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Sistema de Meditação Coletiva
          </h1>
          <Heart className="h-10 w-10 text-blue-600 animate-pulse" />
        </div>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Conecte-se com uma comunidade global para meditações coletivas, 
          definição de intenções e elevação da consciência
        </p>
        <div className="flex items-center justify-center gap-4">
          <Badge variant="outline" className="text-sm">
            <Users className="w-3 h-3 mr-1" />
            {participants.filter(p => p.online).length} Participantes Online
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Activity className="w-3 h-3 mr-1" />
            {sessions.filter(s => s.status === 'active').length} Sessões Ativas
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Target className="w-3 h-3 mr-1" />
            {intentions.filter(i => i.status === 'active').length} Intenções Ativas
          </Badge>
        </div>
      </div>

      {/* Active Session Controls */}
      {activeSession && (
        <Card className="border-purple-200 bg-purple-50">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {getMeditationTypeIcon(activeSession.meditation_type)}
                {activeSession.title}
              </div>
              <Badge variant="outline" className="bg-purple-100 text-purple-800">
                Sessão Ativa
              </Badge>
            </CardTitle>
            <CardDescription>{activeSession.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Timer and Controls */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Timer</CardTitle>
                </CardHeader>
                <CardContent className="text-center space-y-4">
                  <div className="text-4xl font-bold text-purple-600">
                    {formatTime(timer.remaining)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {getPhaseName(timer.current_phase)} - {Math.round(timer.phase_progress * 100)}%
                  </div>
                  <Progress value={getPhaseProgress(timer.current_phase) + timer.phase_progress * 25} className="h-2" />
                  <div className="flex gap-2 justify-center">
                    {!timer.is_running ? (
                      <Button onClick={startMeditation} size="sm">
                        <Play className="h-4 w-4 mr-2" />
                        Iniciar
                      </Button>
                    ) : (
                      <Button onClick={pauseMeditation} size="sm">
                        <Pause className="h-4 w-4 mr-2" />
                        Pausar
                      </Button>
                    )}
                    {timer.elapsed > 0 && (
                      <Button onClick={resumeMeditation} size="sm" variant="outline">
                        <RotateCcw className="h-4 w-4 mr-2" />
                        Retomar
                      </Button>
                    )}
                    <Button onClick={stopMeditation} size="sm" variant="outline">
                      <Square className="h-4 w-4 mr-2" />
                      Parar
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Energia Coletiva</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-muted-foreground">Energia</div>
                      <div className="font-semibold">{formatCoherenceValue(activeSession.collective_energy)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Coerência</div>
                      <div className="font-semibold">{formatCoherenceValue(activeSession.coherence_level)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Cardíaco</div>
                      <div className="font-semibold">{formatCoherenceValue(activeSession.heart_coherence)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Participantes</div>
                      <div className="font-semibold">{activeSession.participants.length}</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Progresso Total</span>
                      <span>{formatCoherenceValue(activeSession.progress)}</span>
                    </div>
                    <Progress value={activeSession.progress * 100} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Configurações</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={soundEnabled}
                        onChange={(e) => setSoundEnabled(e.target.checked)}
                      />
                      <Music className="h-4 w-4" />
                      Som Ambiente
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={visualizationEnabled}
                        onChange={(e) => setVisualizationEnabled(e.target.checked)}
                      />
                      <Eye className="h-4 w-4" />
                      Visualização
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={chatEnabled}
                        onChange={(e) => setChatEnabled(e.target.checked)}
                      />
                      <MessageCircle className="h-4 w-4" />
                      Chat do Grupo
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={realtimeUpdates}
                        onChange={(e) => setRealtimeUpdates(e.target.checked)}
                      />
                      <Activity className="h-4 w-4" />
                      Atualizações em Tempo Real
                    </label>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Participants Grid */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Participantes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {participants.filter(p => activeSession.participants.includes(p.id)).map((participant) => (
                    <Card key={participant.id} className="relative">
                      <div className={`absolute top-2 right-2 w-3 h-3 rounded-full ${participant.online ? 'bg-green-500' : 'bg-gray-400'}`} />
                      <CardHeader className="pb-2">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={participant.avatar} alt={participant.name} />
                            <AvatarFallback>{participant.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="text-sm font-medium">{participant.name}</div>
                            <div className="text-xs text-muted-foreground">{participant.role}</div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <div className="text-muted-foreground">Energia</div>
                            <div className="font-semibold">{formatCoherenceValue(participant.energy_contribution)}</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">Foco</div>
                            <div className="font-semibold">{formatCoherenceValue(participant.focus_level)}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${getEmotionalStateColor(participant.emotional_state)}`} />
                          <span className="text-xs">{participant.emotional_state}</span>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {participant.location.city}, {participant.location.country}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </CardContent>
        </Card>
      )}

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Meditation Sessions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              Sessões de Meditação
            </CardTitle>
            <CardDescription>
              Próximas sessões e meditações ativas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              <div className="space-y-4">
                {sessions.map((session) => (
                  <Card key={session.id} className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {getMeditationTypeIcon(session.meditation_type)}
                        <h3 className="font-semibold">{session.title}</h3>
                        <Badge variant="outline">{session.meditation_type}</Badge>
                      </div>
                      <div className={`w-2 h-2 rounded-full ${getStatusColor(session.status)}`} />
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{session.description}</p>
                    <div className="grid grid-cols-2 gap-4 text-xs mb-3">
                      <div>
                        <div className="text-muted-foreground">Host</div>
                        <div>{session.host_name}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Duração</div>
                        <div>{session.duration} min</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Frequência</div>
                        <div>{formatFrequency(session.frequency)}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Participantes</div>
                        <div>{session.participants.length}{session.max_participants && `/${session.max_participants}`}</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-muted-foreground">
                        {session.status === 'scheduled' ? `Início: ${formatDateTime(session.start_time)}` :
                         session.status === 'active' ? `Ativo desde ${formatTimeAgo(session.start_time)}` :
                         session.status === 'completed' ? `Concluído: ${formatDateTime(session.end_time!)}` :
                         'Status desconhecido'}
                      </div>
                      <Button 
                        onClick={() => joinSession(session.id)}
                        disabled={session.participants.includes('valeria_plaisant') || session.status === 'completed'}
                        size="sm"
                      >
                        {session.participants.includes('valeria_plaisant') ? 'Participando' : 'Participar'}
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Collective Intentions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Intenções Coletivas
            </CardTitle>
            <CardDescription>
              Junte-se a intenções coletivas para manifestação
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Create New Intention */}
            <Card className="border-dashed">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="text-sm font-medium">Criar Nova Intenção:</div>
                  <Textarea
                    placeholder="Descreva sua intenção coletiva..."
                    value={newIntention}
                    onChange={(e) => setNewIntention(e.target.value)}
                    rows={3}
                  />
                  <div className="flex gap-2">
                    <select 
                      value={selectedFrequency}
                      onChange={(e) => setSelectedFrequency(Number(e.target.value))}
                      className="px-3 py-2 border rounded-md text-sm"
                    >
                      <option value={432}>432 Hz - Paz</option>
                      <option value={528}>528 Hz - Cura</option>
                      <option value={639}>639 Hz - Conexão</option>
                      <option value={741}>741 Hz - Despertar</option>
                      <option value={852}>852 Hz - Intuição</option>
                      <option value={963}>963 Hz - Espiritual</option>
                    </select>
                    <Button onClick={createNewIntention} disabled={!newIntention.trim()}>
                      <Plus className="h-4 w-4 mr-2" />
                      Criar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Existing Intentions */}
            <ScrollArea className="h-80">
              <div className="space-y-4">
                {intentions.map((intention) => (
                  <Card key={intention.id} className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {getIntentionCategoryIcon(intention.category)}
                        <h3 className="font-semibold">{intention.title}</h3>
                        <Badge variant="outline">{intention.category}</Badge>
                      </div>
                      <div className={`w-2 h-2 rounded-full ${getStatusColor(intention.status)}`} />
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{intention.description}</p>
                    <div className="grid grid-cols-2 gap-4 text-xs mb-3">
                      <div>
                        <div className="text-muted-foreground">Criador</div>
                        <div>{intention.creator_name}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Apoiadores</div>
                        <div>{intention.supporters.length}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Força</div>
                        <div>{formatCoherenceValue(intention.intention_strength)}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Progresso</div>
                        <div>{formatCoherenceValue(intention.manifestation_progress)}</div>
                      </div>
                    </div>
                    <div className="space-y-2 mb-3">
                      <div className="flex items-center justify-between text-sm">
                        <span>Manifestação</span>
                        <span>{formatCoherenceValue(intention.manifestation_progress)}</span>
                      </div>
                      <Progress value={intention.manifestation_progress * 100} className="h-2" />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-muted-foreground">
                        Alvo: {formatDateTime(intention.target_date)}
                      </div>
                      <Button 
                        onClick={() => supportIntention(intention.id)}
                        disabled={intention.supporters.includes('valeria_plaisant')}
                        size="sm"
                        variant="outline"
                      >
                        <Heart className="h-4 w-4 mr-1" />
                        {intention.supporters.includes('valeria_plaisant') ? 'Apoiando' : 'Apoiar'}
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Analytics and Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Participant Energy Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Energia dos Participantes
            </CardTitle>
            <CardDescription>
              Níveis de energia, foco e consciência dos participantes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={energyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="energy" fill="#8884d8" name="Energia" />
                <Bar dataKey="focus" fill="#82ca9d" name="Foco" />
                <Bar dataKey="consciousness" fill="#ffc658" name="Consciência" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Intention Progress Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Progresso das Intenções
            </CardTitle>
            <CardDescription>
              Manifestação e força das intenções coletivas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={intentionProgressData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="progress" stroke="#8884d8" name="Progresso" />
                <Line type="monotone" dataKey="strength" stroke="#82ca9d" name="Força" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}