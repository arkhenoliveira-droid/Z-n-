'use client'

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Brain, 
  Network, 
  Zap, 
  Star, 
  TrendingUp, 
  RefreshCw, 
  Activity,
  Target,
  Layers,
  Radio
} from 'lucide-react'
import { CosmicGrapesArchitect, CosmicCluster, CosmicModule, ArchitecturalCoherence } from '@/systems/cosmic-grapes-architect'

const CosmicGrapesArchitectDashboard: React.FC = () => {
  const [architect] = useState(() => new CosmicGrapesArchitect())
  const [coherence, setCoherence] = useState<ArchitecturalCoherence | null>(null)
  const [clusters, setClusters] = useState<CosmicCluster[]>([])
  const [isOptimizing, setIsOptimizing] = useState(false)
  const [optimizationCycle, setOptimizationCycle] = useState(0)

  useEffect(() => {
    updateDashboard()
  }, [])

  const updateDashboard = () => {
    const newCoherence = architect.calculateArchitecturalCoherence()
    const newClusters = architect.getClusters()
    const newCycle = architect.getOptimizationCycle()
    
    setCoherence(newCoherence)
    setClusters(newClusters)
    setOptimizationCycle(newCycle)
  }

  const handleOptimize = async () => {
    setIsOptimizing(true)
    await new Promise(resolve => setTimeout(resolve, 1500)) // Simular otimização
    
    architect.optimizeArchitecture()
    updateDashboard()
    setIsOptimizing(false)
  }

  const getClusterIcon = (type: string) => {
    switch (type) {
      case 'stellar-formation':
        return <Star className="h-5 w-5" />
      case 'quantum-coherence':
        return <Brain className="h-5 w-5" />
      case 'spiritual-resonance':
        return <Radio className="h-5 w-5" />
      case 'adaptive-intelligence':
        return <Activity className="h-5 w-5" />
      default:
        return <Network className="h-5 w-5" />
    }
  }

  const getClusterColor = (type: string) => {
    switch (type) {
      case 'stellar-formation':
        return 'bg-yellow-500'
      case 'quantum-coherence':
        return 'bg-blue-500'
      case 'spiritual-resonance':
        return 'bg-purple-500'
      case 'adaptive-intelligence':
        return 'bg-green-500'
      default:
        return 'bg-gray-500'
    }
  }

  const getCoherenceColor = (coherence: number) => {
    if (coherence >= 0.9) return 'text-green-600'
    if (coherence >= 0.8) return 'text-yellow-600'
    if (coherence >= 0.7) return 'text-orange-600'
    return 'text-red-600'
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      active: 'default',
      developing: 'secondary',
      stable: 'outline',
      evolving: 'destructive'
    } as const

    const labels = {
      active: 'Ativo',
      developing: 'Desenvolvendo',
      stable: 'Estável',
      evolving: 'Evoluindo'
    }

    return (
      <Badge variant={variants[status as keyof typeof variants] || 'default'}>
        {labels[status as keyof typeof labels] || status}
      </Badge>
    )
  }

  if (!coherence) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Arquitetura Cosmic Grapes</h2>
          <p className="text-muted-foreground">
            Sistema modular baseado em padrões cósmicos de formação estelar
          </p>
        </div>
        <Button 
          onClick={handleOptimize} 
          disabled={isOptimizing}
          className="flex items-center gap-2"
        >
          {isOptimizing ? (
            <RefreshCw className="h-4 w-4 animate-spin" />
          ) : (
            <Zap className="h-4 w-4" />
          )}
          {isOptimizing ? 'Otimizando...' : 'Otimizar Arquitetura'}
        </Button>
      </div>

      {/* Cards Principais */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Coerência Global</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getCoherenceColor(coherence.globalCoherence)}`}>
              {(coherence.globalCoherence * 100).toFixed(1)}%
            </div>
            <Progress value={coherence.globalCoherence * 100} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Clusters Ativos</CardTitle>
            <Layers className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{clusters.length}</div>
            <p className="text-xs text-muted-foreground">
              {clusters.reduce((sum, cluster) => sum + cluster.modules.length, 0)} módulos totais
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Conexões Inter-Cluster</CardTitle>
            <Network className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{coherence.interClusterConnections}</div>
            <p className="text-xs text-muted-foreground">
              Rede de integração
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ciclo de Otimização</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">#{optimizationCycle}</div>
            <p className="text-xs text-muted-foreground">
              Otimizações realizadas
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="clusters" className="space-y-4">
        <TabsList>
          <TabsTrigger value="clusters">Clusters</TabsTrigger>
          <TabsTrigger value="modules">Módulos</TabsTrigger>
          <TabsTrigger value="optimization">Otimização</TabsTrigger>
          <TabsTrigger value="report">Relatório</TabsTrigger>
        </TabsList>

        <TabsContent value="clusters" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {clusters.map((cluster) => (
              <Card key={cluster.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`p-2 rounded-full ${getClusterColor(cluster.type)} text-white`}>
                        {getClusterIcon(cluster.type)}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{cluster.name}</CardTitle>
                        <CardDescription>{cluster.description}</CardDescription>
                      </div>
                    </div>
                    <Badge variant="outline">{cluster.type}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm">
                        <span>Coerência</span>
                        <span className={getCoherenceColor(cluster.coherence)}>
                          {(cluster.coherence * 100).toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={cluster.coherence * 100} className="mt-1" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Módulos:</span>
                        <span className="ml-1 font-medium">{cluster.modules.length}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Conexões:</span>
                        <span className="ml-1 font-medium">{cluster.connections.length}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Energia:</span>
                        <span className="ml-1 font-medium">
                          {(cluster.metadata.energy * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Estabilidade:</span>
                        <span className="ml-1 font-medium">
                          {(cluster.metadata.stability * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>

                    <div>
                      <span className="text-sm text-muted-foreground">Módulos:</span>
                      <div className="mt-2 space-y-2">
                        {cluster.modules.slice(0, 3).map((module) => (
                          <div key={module.id} className="flex items-center justify-between text-sm">
                            <span>{module.name}</span>
                            <div className="flex items-center gap-2">
                              <div className="w-16">
                                <Progress value={module.coherence * 100} className="h-2" />
                              </div>
                              <span className="text-xs text-muted-foreground">
                                {(module.coherence * 100).toFixed(0)}%
                              </span>
                            </div>
                          </div>
                        ))}
                        {cluster.modules.length > 3 && (
                          <div className="text-xs text-muted-foreground">
                            +{cluster.modules.length - 3} mais módulos
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="modules" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Todos os Módulos</CardTitle>
              <CardDescription>
                Visão detalhada de todos os módulos nos clusters
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {clusters.map((cluster) => (
                    <div key={cluster.id} className="space-y-3">
                      <div className="flex items-center gap-2">
                        <div className={`p-1 rounded ${getClusterColor(cluster.type)} text-white`}>
                          {getClusterIcon(cluster.type)}
                        </div>
                        <h4 className="font-semibold">{cluster.name}</h4>
                      </div>
                      <div className="ml-6 space-y-2">
                        {cluster.modules.map((module) => (
                          <Card key={module.id} className="p-3">
                            <div className="flex items-center justify-between">
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-medium">{module.name}</span>
                                  {getStatusBadge(module.status)}
                                </div>
                                <p className="text-sm text-muted-foreground">{module.purpose}</p>
                                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                                  <span>Complexidade: {module.complexity}/10</span>
                                  <span>Dependências: {module.dependencies.length}</span>
                                  <span>Exports: {module.exports.length}</span>
                                </div>
                              </div>
                              <div className="text-right space-y-1">
                                <div className={`text-sm font-medium ${getCoherenceColor(module.coherence)}`}>
                                  {(module.coherence * 100).toFixed(1)}%
                                </div>
                                <Progress value={module.coherence * 100} className="w-20 h-2" />
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="optimization" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sugestões de Otimização</CardTitle>
              <CardDescription>
                Recomendações baseadas na análise de coerência arquitetônica
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {coherence.optimizationSuggestions.length > 0 ? (
                  coherence.optimizationSuggestions.map((suggestion, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 rounded-lg border">
                      <Target className="h-5 w-5 text-blue-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Sugestão #{index + 1}</h4>
                        <p className="text-sm text-muted-foreground">{suggestion}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <Brain className="h-12 w-12 mx-auto text-green-500 mb-4" />
                    <h4 className="font-medium">Arquitetura Otimizada</h4>
                    <p className="text-sm text-muted-foreground">
                      Não há sugestões de otimização no momento
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Métricas de Coerência</CardTitle>
              <CardDescription>
                Análise detalhada da coerência por cluster
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(coherence.clusterCoherence).map(([clusterId, clusterCoherence]) => {
                  const cluster = clusters.find(c => c.id === clusterId)
                  return (
                    <div key={clusterId} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{cluster?.name || 'Cluster Desconhecido'}</span>
                        <span className={`text-sm font-medium ${getCoherenceColor(clusterCoherence)}`}>
                          {(clusterCoherence * 100).toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={clusterCoherence * 100} />
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="report" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Relatório Completo</CardTitle>
              <CardDescription>
                Relatório detalhado da arquitetura Cosmic Grapes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <pre className="text-sm whitespace-pre-wrap bg-muted p-4 rounded-lg">
                  {architect.generateArchitectureReport()}
                </pre>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default CosmicGrapesArchitectDashboard