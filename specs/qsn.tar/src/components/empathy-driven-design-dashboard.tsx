'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Heart, 
  Users, 
  Accessibility, 
  Settings, 
  Eye, 
  Brain, 
  Target,
  Lightbulb,
  BookOpen,
  Palette,
  Keyboard,
  Volume2,
  ZoomIn,
  Moon,
  Sun,
  Monitor,
  User,
  Star,
  CheckCircle,
  AlertCircle,
  Info
} from 'lucide-react';

import { EmpathyDrivenDesignAnalyzer } from '@/systems/empathy-driven-design-analyzer';
import { InclusiveDesignStrategy } from '@/systems/inclusive-design-strategy';

interface UserProfile {
  id: string;
  name: string;
  category: string;
  experience_level: string;
  accessibility_needs: any;
  preferences: any;
}

export default function EmpathyDrivenDesignDashboard() {
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [adaptiveConfig, setAdaptiveConfig] = useState<any>(null);
  const [analysisResults, setAnalysisResults] = useState<any>(null);
  const [userGroups, setUserGroups] = useState<any[]>([]);
  const [currentTheme, setCurrentTheme] = useState<'light' | 'dark' | 'high-contrast'>('light');
  const [fontSize, setFontSize] = useState<'small' | 'medium' | 'large'>('medium');
  const [reducedMotion, setReducedMotion] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  const empathyAnalyzer = new EmpathyDrivenDesignAnalyzer();
  const inclusiveStrategy = new InclusiveDesignStrategy();

  useEffect(() => {
    // Initialize analysis
    const analysis = empathyAnalyzer.analyzeUserNeeds();
    setAnalysisResults(analysis);
    
    const groups = inclusiveStrategy.getAllUserGroups();
    setUserGroups(groups);

    // Set default user
    const profiles = empathyAnalyzer.getUserProfiles();
    setSelectedUser(profiles[0]);
    
    // Generate adaptive config for default user
    const config = inclusiveStrategy.adaptInterfaceForUser(profiles[0]);
    setAdaptiveConfig(config);
  }, []);

  const handleUserSelect = (user: UserProfile) => {
    setSelectedUser(user);
    const config = inclusiveStrategy.adaptInterfaceForUser(user);
    setAdaptiveConfig(config);
  };

  const handleThemeChange = (theme: 'light' | 'dark' | 'high-contrast') => {
    setCurrentTheme(theme);
    // Apply theme to document
    document.documentElement.className = '';
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else if (theme === 'high-contrast') {
      document.documentElement.classList.add('high-contrast');
    }
  };

  const handleFontSizeChange = (size: 'small' | 'medium' | 'large') => {
    setFontSize(size);
    document.documentElement.style.fontSize = size === 'small' ? '14px' : size === 'medium' ? '16px' : '18px';
  };

  const getThemeClasses = () => {
    switch (currentTheme) {
      case 'dark':
        return 'bg-gray-900 text-white';
      case 'high-contrast':
        return 'bg-black text-yellow-300';
      default:
        return 'bg-white text-gray-900';
    }
  };

  const getCardClasses = () => {
    switch (currentTheme) {
      case 'dark':
        return 'bg-gray-800 border-gray-700';
      case 'high-contrast':
        return 'bg-black border-yellow-400';
      default:
        return 'bg-white border-gray-200';
    }
  };

  const renderUserProfile = (profile: UserProfile) => {
    const isSelected = selectedUser?.id === profile.id;
    
    return (
      <Card 
        key={profile.id} 
        className={`cursor-pointer transition-all duration-200 ${
          isSelected ? 'ring-2 ring-blue-500' : ''
        } ${getCardClasses()}`}
        onClick={() => handleUserSelect(profile)}
      >
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center">
              <User className="w-5 h-5 mr-2" />
              {profile.name}
            </CardTitle>
            {isSelected && <CheckCircle className="w-5 h-5 text-green-500" />}
          </div>
          <CardDescription className="flex items-center">
            <Badge variant="outline" className="mr-2">
              {profile.category}
            </Badge>
            <Badge variant="secondary">
              {profile.experience_level}
            </Badge>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center text-sm">
              <Target className="w-4 h-4 mr-2" />
              <span className="font-medium">Preferências:</span>
            </div>
            <div className="text-xs space-y-1 ml-6">
              <div>Complexidade: {profile.preferences.visual_complexity}</div>
              <div>Densidade: {profile.preferences.information_density}</div>
              <div>Interação: {profile.preferences.interaction_style}</div>
            </div>
            
            {Object.values(profile.accessibility_needs).some((need: any) => need) && (
              <div className="flex items-center text-sm mt-2">
                <Accessibility className="w-4 h-4 mr-2 text-orange-500" />
                <span className="font-medium text-orange-500">Necessidades especiais identificadas</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderAdaptiveConfig = () => {
    if (!adaptiveConfig) return null;

    return (
      <Card className={getCardClasses()}>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Settings className="w-5 h-5 mr-2" />
            Configuração Adaptativa
          </CardTitle>
          <CardDescription>
            Interface adaptada para o usuário selecionado
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-medium">Complexidade:</span>
                <Badge variant="outline">{adaptiveConfig.complexity_level}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Densidade:</span>
                <Badge variant="outline">{adaptiveConfig.information_density}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Interação:</span>
                <Badge variant="outline">{adaptiveConfig.interaction_mode}</Badge>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-medium">Estilo Visual:</span>
                <Badge variant="outline">{adaptiveConfig.visual_style}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Acessibilidade:</span>
                <Badge variant="outline">{adaptiveConfig.accessibility_mode}</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderAccessibilityControls = () => {
    return (
      <Card className={getCardClasses()}>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Accessibility className="w-5 h-5 mr-2" />
            Controles de Acessibilidade
          </CardTitle>
          <CardDescription>
            Personalize a interface para suas necessidades
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Tema</label>
                <div className="flex space-x-2">
                  <Button
                    variant={currentTheme === 'light' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => handleThemeChange('light')}
                  >
                    <Sun className="w-4 h-4 mr-1" />
                    Claro
                  </Button>
                  <Button
                    variant={currentTheme === 'dark' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => handleThemeChange('dark')}
                  >
                    <Moon className="w-4 h-4 mr-1" />
                    Escuro
                  </Button>
                  <Button
                    variant={currentTheme === 'high-contrast' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => handleThemeChange('high-contrast')}
                  >
                    <Monitor className="w-4 h-4 mr-1" />
                    Alto Contraste
                  </Button>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Tamanho do Texto</label>
                <div className="flex space-x-2">
                  <Button
                    variant={fontSize === 'small' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => handleFontSizeChange('small')}
                  >
                    A
                  </Button>
                  <Button
                    variant={fontSize === 'medium' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => handleFontSizeChange('medium')}
                  >
                    A
                  </Button>
                  <Button
                    variant={fontSize === 'large' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => handleFontSizeChange('large')}
                  >
                    A
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Animações</label>
                <div className="flex items-center space-x-2">
                  <Button
                    variant={!reducedMotion ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setReducedMotion(false)}
                  >
                    Ativadas
                  </Button>
                  <Button
                    variant={reducedMotion ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setReducedMotion(true)}
                  >
                    Reduzidas
                  </Button>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Ajuda Contextual</label>
                <div className="flex items-center space-x-2">
                  <Button
                    variant={showHelp ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setShowHelp(!showHelp)}
                  >
                    <Info className="w-4 h-4 mr-1" />
                    {showHelp ? 'Ocultar' : 'Mostrar'}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderUserGroups = () => {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {userGroups.map((group, index) => (
          <Card key={index} className={getCardClasses()}>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                {group.group_name}
              </CardTitle>
              <CardDescription>
                Prioridade: <Badge variant="outline">{group.implementation_priority}</Badge>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <h4 className="font-medium text-sm mb-2">Princípios Fundamentais:</h4>
                  <ul className="text-xs space-y-1">
                    {group.core_principles.slice(0, 3).map((principle: string, idx: number) => (
                      <li key={idx} className="flex items-start">
                        <Star className="w-3 h-3 mr-1 mt-0.5 text-yellow-500" />
                        {principle}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-medium text-sm mb-2">Estratégias Chave:</h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-medium">Conteúdo:</span>
                      <span className="ml-1">{group.specific_strategies.content_strategy.length}</span>
                    </div>
                    <div>
                      <span className="font-medium">Interação:</span>
                      <span className="ml-1">{group.specific_strategies.interaction_design.length}</span>
                    </div>
                    <div>
                      <span className="font-medium">Visual:</span>
                      <span className="ml-1">{group.specific_strategies.visual_design.length}</span>
                    </div>
                    <div>
                      <span className="font-medium">Acessibilidade:</span>
                      <span className="ml-1">{group.specific_strategies.accessibility_features.length}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  const renderEmpathyInsights = () => {
    if (!analysisResults) return null;

    return (
      <div className="space-y-4">
        <Card className={getCardClasses()}>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Heart className="w-5 h-5 mr-2" />
              Insights Empáticos
            </CardTitle>
            <CardDescription>
              Análise baseada em {analysisResults.user_profiles.length} perfis de usuários
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <h4 className="font-medium text-sm mb-2">Objetivos Compartilhados:</h4>
                <ul className="text-xs space-y-1">
                  {analysisResults.common_patterns.shared_goals.map((goal: string, idx: number) => (
                    <li key={idx} className="flex items-start">
                      <Target className="w-3 h-3 mr-1 mt-0.5 text-green-500" />
                      {goal}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-sm mb-2">Dificuldades Universais:</h4>
                <ul className="text-xs space-y-1">
                  {analysisResults.common_patterns.universal_pain_points.map((pain: string, idx: number) => (
                    <li key={idx} className="flex items-start">
                      <AlertCircle className="w-3 h-3 mr-1 mt-0.5 text-red-500" />
                      {pain}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-sm mb-2">Necessidades Transversais:</h4>
                <ul className="text-xs space-y-1">
                  {analysisResults.common_patterns.cross_category_needs.slice(0, 3).map((need: string, idx: number) => (
                    <li key={idx} className="flex items-start">
                      <Lightbulb className="w-3 h-3 mr-1 mt-0.5 text-blue-500" />
                      {need}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className={`min-h-screen p-6 ${getThemeClasses()}`}>
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold flex items-center mb-2">
            <Heart className="w-8 h-8 mr-3 text-red-500" />
            Design Orientado por Empatia
          </h1>
          <p className="text-lg opacity-80">
            Criando experiências inclusivas para todos os usuários
          </p>
        </div>

        <Tabs defaultValue="user-profiles" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="user-profiles" className="flex items-center">
              <Users className="w-4 h-4 mr-2" />
              Perfis
            </TabsTrigger>
            <TabsTrigger value="adaptive-interface" className="flex items-center">
              <Settings className="w-4 h-4 mr-2" />
              Interface
            </TabsTrigger>
            <TabsTrigger value="accessibility" className="flex items-center">
              <Accessibility className="w-4 h-4 mr-2" />
              Acessibilidade
            </TabsTrigger>
            <TabsTrigger value="insights" className="flex items-center">
              <Brain className="w-4 h-4 mr-2" />
              Insights
            </TabsTrigger>
          </TabsList>

          <TabsContent value="user-profiles" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {analysisResults?.user_profiles.map(renderUserProfile)}
            </div>
            
            {selectedUser && (
              <Card className={getCardClasses()}>
                <CardHeader>
                  <CardTitle>Detalhes do Perfil Selecionado</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium mb-2">Principais Objetivos:</h4>
                      <ul className="text-sm space-y-1">
                        {selectedUser.primary_goals.map((goal: string, idx: number) => (
                          <li key={idx} className="flex items-start">
                            <Target className="w-4 h-4 mr-2 mt-0.5 text-green-500" />
                            {goal}
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="font-medium mb-2">Principais Dificuldades:</h4>
                      <ul className="text-sm space-y-1">
                        {selectedUser.pain_points.map((pain: string, idx: number) => (
                          <li key={idx} className="flex items-start">
                            <AlertCircle className="w-4 h-4 mr-2 mt-0.5 text-red-500" />
                            {pain}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="adaptive-interface" className="space-y-6">
            {renderAdaptiveConfig()}
            {renderUserGroups()}
          </TabsContent>

          <TabsContent value="accessibility" className="space-y-6">
            {renderAccessibilityControls()}
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            {renderEmpathyInsights()}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}