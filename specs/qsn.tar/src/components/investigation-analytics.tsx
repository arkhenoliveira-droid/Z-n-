'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  BarChart3, 
  TrendingUp, 
  PieChart, 
  Activity, 
  Target, 
  Zap,
  Brain,
  Radio,
  Download,
  RefreshCw,
  Calendar,
  Filter,
  Eye,
  Lightbulb
} from 'lucide-react';

interface AnalyticsData {
  totalInvestigations: number;
  completedInvestigations: number;
  averageCoherence: number;
  averageConfidence: number;
  investigationTypes: {
    type: string;
    count: number;
    avgCoherence: number;
  }[];
  temporalTrends: {
    date: string;
    count: number;
    avgCoherence: number;
  }[];
  topPatterns: {
    name: string;
    type: string;
    coherence: number;
    frequency: number;
  }[];
  performanceMetrics: {
    investigationTime: number;
    successRate: number;
    errorRate: number;
  };
}

interface InvestigationAnalyticsProps {
  investigations?: any[];
  patterns?: any[];
}

export default function InvestigationAnalytics({ investigations = [], patterns = [] }: InvestigationAnalyticsProps) {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedTimeframe, setSelectedTimeframe] = useState<'7d' | '30d' | '90d' | 'all'>('30d');

  useEffect(() => {
    generateAnalytics();
  }, [investigations, patterns, selectedTimeframe]);

  const generateAnalytics = () => {
    setIsLoading(true);
    
    try {
      // Filter investigations based on timeframe
      const filteredInvestigations = filterInvestigationsByTimeframe(investigations);
      
      // Calculate basic metrics
      const totalInvestigations = filteredInvestigations.length;
      const completedInvestigations = filteredInvestigations.filter(inv => inv.status === 'completed').length;
      
      const coherenceScores = filteredInvestigations
        .filter(inv => inv.coherenceScore !== undefined)
        .map(inv => inv.coherenceScore);
      const averageCoherence = coherenceScores.length > 0 
        ? coherenceScores.reduce((sum, score) => sum + score, 0) / coherenceScores.length 
        : 0;

      const confidenceScores = filteredInvestigations
        .filter(inv => inv.confidenceLevel !== undefined)
        .map(inv => inv.confidenceLevel);
      const averageConfidence = confidenceScores.length > 0 
        ? confidenceScores.reduce((sum, score) => sum + score, 0) / confidenceScores.length 
        : 0;

      // Group by investigation type
      const typeGroups = filteredInvestigations.reduce((acc, inv) => {
        if (!acc[inv.type]) {
          acc[inv.type] = { count: 0, totalCoherence: 0, coherenceCount: 0 };
        }
        acc[inv.type].count++;
        if (inv.coherenceScore !== undefined) {
          acc[inv.type].totalCoherence += inv.coherenceScore;
          acc[inv.type].coherenceCount++;
        }
        return acc;
      }, {} as Record<string, { count: number; totalCoherence: number; coherenceCount: number }>);

      const investigationTypes = Object.entries(typeGroups).map(([type, data]) => ({
        type,
        count: data.count,
        avgCoherence: data.coherenceCount > 0 ? data.totalCoherence / data.coherenceCount : 0
      }));

      // Generate temporal trends
      const temporalTrends = generateTemporalTrends(filteredInvestigations);

      // Get top patterns
      const topPatterns = patterns
        .sort((a, b) => (b.coherence || 0) - (a.coherence || 0))
        .slice(0, 10)
        .map(pattern => ({
          name: pattern.name,
          type: pattern.patternType,
          coherence: pattern.coherence || 0,
          frequency: pattern.frequency || 0
        }));

      // Calculate performance metrics
      const performanceMetrics = {
        investigationTime: calculateAverageInvestigationTime(filteredInvestigations),
        successRate: totalInvestigations > 0 ? (completedInvestigations / totalInvestigations) * 100 : 0,
        errorRate: totalInvestigations > 0 ? 
          ((filteredInvestigations.filter(inv => inv.status === 'failed').length / totalInvestigations) * 100) : 0
      };

      setAnalyticsData({
        totalInvestigations,
        completedInvestigations,
        averageCoherence,
        averageConfidence,
        investigationTypes,
        temporalTrends,
        topPatterns,
        performanceMetrics
      });
    } catch (error) {
      console.error('Error generating analytics:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filterInvestigationsByTimeframe = (investigations: any[]) => {
    if (selectedTimeframe === 'all') return investigations;
    
    const now = new Date();
    const cutoffDate = new Date();
    
    switch (selectedTimeframe) {
      case '7d':
        cutoffDate.setDate(now.getDate() - 7);
        break;
      case '30d':
        cutoffDate.setDate(now.getDate() - 30);
        break;
      case '90d':
        cutoffDate.setDate(now.getDate() - 90);
        break;
    }
    
    return investigations.filter(inv => new Date(inv.createdAt) >= cutoffDate);
  };

  const generateTemporalTrends = (investigations: any[]) => {
    const trendData: Record<string, { count: number; totalCoherence: number; coherenceCount: number }> = {};
    
    investigations.forEach(inv => {
      const date = new Date(inv.createdAt).toISOString().split('T')[0];
      if (!trendData[date]) {
        trendData[date] = { count: 0, totalCoherence: 0, coherenceCount: 0 };
      }
      trendData[date].count++;
      if (inv.coherenceScore !== undefined) {
        trendData[date].totalCoherence += inv.coherenceScore;
        trendData[date].coherenceCount++;
      }
    });

    return Object.entries(trendData)
      .map(([date, data]) => ({
        date,
        count: data.count,
        avgCoherence: data.coherenceCount > 0 ? data.totalCoherence / data.coherenceCount : 0
      }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(-30); // Last 30 days
  };

  const calculateAverageInvestigationTime = (investigations: any[]) => {
    const completedInvestigations = investigations.filter(inv => 
      inv.status === 'completed' && inv.createdAt && inv.updatedAt
    );
    
    if (completedInvestigations.length === 0) return 0;
    
    const totalTime = completedInvestigations.reduce((sum, inv) => {
      const start = new Date(inv.createdAt).getTime();
      const end = new Date(inv.updatedAt).getTime();
      return sum + (end - start);
    }, 0);
    
    return totalTime / completedInvestigations.length / 1000 / 60; // Convert to minutes
  };

  const exportAnalyticsReport = () => {
    if (!analyticsData) return;
    
    const report = {
      generatedAt: new Date().toISOString(),
      timeframe: selectedTimeframe,
      analytics: analyticsData,
      rawInvestigations: investigations,
      rawPatterns: patterns
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `investigation-analytics-${selectedTimeframe}-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getCoherenceColor = (score: number) => {
    if (score >= 0.8) return 'text-green-600';
    if (score >= 0.6) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'reality_coherence':
        return <Brain className="w-4 h-4" />;
      case 'pattern_analysis':
        return <BarChart3 className="w-4 h-4" />;
      case 'quantum_investigation':
        return <Zap className="w-4 h-4" />;
      default:
        return <Activity className="w-4 h-4" />;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="w-5 h-5 mr-2 text-blue-600" />
            Investigation Analytics
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 animate-spin text-blue-600" />
        </CardContent>
      </Card>
    );
  }

  if (!analyticsData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="w-5 h-5 mr-2 text-blue-600" />
            Investigation Analytics
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-64">
          <div className="text-center">
            <BarChart3 className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-500">No analytics data available</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <BarChart3 className="w-5 h-5 mr-2 text-blue-600" />
                Investigation Analytics
              </CardTitle>
              <CardDescription>Comprehensive analysis of investigation performance and patterns</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Select value={selectedTimeframe} onValueChange={(value: any) => setSelectedTimeframe(value)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7d">Last 7 days</SelectItem>
                  <SelectItem value="30d">Last 30 days</SelectItem>
                  <SelectItem value="90d">Last 90 days</SelectItem>
                  <SelectItem value="all">All time</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={generateAnalytics} size="sm" variant="outline">
                <RefreshCw className="w-4 h-4 mr-1" />
                Refresh
              </Button>
              <Button onClick={exportAnalyticsReport} size="sm">
                <Download className="w-4 h-4 mr-1" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="investigations">Investigations</TabsTrigger>
          <TabsTrigger value="patterns">Patterns</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Investigations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analyticsData.totalInvestigations}</div>
                <p className="text-xs text-muted-foreground">
                  {analyticsData.completedInvestigations} completed
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Average Coherence</CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${getCoherenceColor(analyticsData.averageCoherence)}`}>
                  {(analyticsData.averageCoherence * 100).toFixed(1)}%
                </div>
                <Progress value={analyticsData.averageCoherence * 100} className="mt-2" />
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Average Confidence</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {(analyticsData.averageConfidence * 100).toFixed(1)}%
                </div>
                <Progress value={analyticsData.averageConfidence * 100} className="mt-2" />
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {analyticsData.performanceMetrics.successRate.toFixed(1)}%
                </div>
                <Progress value={analyticsData.performanceMetrics.successRate} className="mt-2" />
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium">Investigation Types</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analyticsData.investigationTypes.map((item) => (
                    <div key={item.type} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getTypeIcon(item.type)}
                        <span className="text-sm capitalize">{item.type.replace('_', ' ')}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{item.count}</Badge>
                        <span className={`text-xs ${getCoherenceColor(item.avgCoherence)}`}>
                          {(item.avgCoherence * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium">Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Avg. Investigation Time</span>
                    <span className="text-sm font-medium">
                      {analyticsData.performanceMetrics.investigationTime.toFixed(1)} min
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Success Rate</span>
                    <span className="text-sm font-medium text-green-600">
                      {analyticsData.performanceMetrics.successRate.toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Error Rate</span>
                    <span className="text-sm font-medium text-red-600">
                      {analyticsData.performanceMetrics.errorRate.toFixed(1)}%
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Investigations Tab */}
        <TabsContent value="investigations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Investigation Types Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.investigationTypes.map((item) => (
                  <div key={item.type} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getTypeIcon(item.type)}
                        <span className="text-sm font-medium capitalize">
                          {item.type.replace('_', ' ')}
                        </span>
                      </div>
                      <Badge variant="outline">{item.count}</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress value={(item.count / analyticsData.totalInvestigations) * 100} className="flex-1" />
                      <span className="text-xs text-muted-foreground">
                        {((item.count / analyticsData.totalInvestigations) * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span>Avg. Coherence:</span>
                      <span className={getCoherenceColor(item.avgCoherence)}>
                        {(item.avgCoherence * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Patterns Tab */}
        <TabsContent value="patterns" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Top Reality Patterns</CardTitle>
              <CardDescription>Patterns with highest coherence scores</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {analyticsData.topPatterns.map((pattern, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">{pattern.name}</span>
                        <Badge variant="outline" className="text-xs">
                          {pattern.type}
                        </Badge>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        Frequency: {pattern.frequency.toFixed(2)}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`text-sm font-medium ${getCoherenceColor(pattern.coherence)}`}>
                        {(pattern.coherence * 100).toFixed(1)}%
                      </div>
                      <Progress value={pattern.coherence * 100} className="w-20 h-1 mt-1" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Performance Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm">Success Rate</span>
                      <span className="text-sm font-medium text-green-600">
                        {analyticsData.performanceMetrics.successRate.toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={analyticsData.performanceMetrics.successRate} />
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm">Error Rate</span>
                      <span className="text-sm font-medium text-red-600">
                        {analyticsData.performanceMetrics.errorRate.toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={analyticsData.performanceMetrics.errorRate} className="bg-red-100" />
                  </div>
                  
                  <div className="pt-2 border-t">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Average Investigation Time</span>
                      <span className="text-sm font-medium">
                        {analyticsData.performanceMetrics.investigationTime.toFixed(1)} minutes
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quality Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm">Average Coherence</span>
                      <span className={`text-sm font-medium ${getCoherenceColor(analyticsData.averageCoherence)}`}>
                        {(analyticsData.averageCoherence * 100).toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={analyticsData.averageCoherence * 100} />
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm">Average Confidence</span>
                      <span className="text-sm font-medium text-blue-600">
                        {(analyticsData.averageConfidence * 100).toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={analyticsData.averageConfidence * 100} />
                  </div>
                  
                  <div className="pt-2 border-t">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Total Investigations</span>
                      <span className="text-sm font-medium">
                        {analyticsData.totalInvestigations}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}