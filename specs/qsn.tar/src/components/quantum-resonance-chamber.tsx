'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area,
  BarChart, 
  Bar,
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ScatterChart,
  Scatter
} from 'recharts';
import { 
  Activity, 
  Zap, 
  Radio, 
  Waves, 
  Target, 
  TrendingUp, 
  Users, 
  Globe,
  Brain,
  Atom,
  Heart,
  Sparkles,
  Infinity,
  Play,
  Pause,
  RotateCcw,
  Settings,
  Volume2,
  VolumeX,
  Shield,
  Star,
  Triangle,
  Circle,
  Square,
  Hexagon,
  Plus,
  Minus,
  Maximize,
  Minimize,
  CheckCircle,
  Clock,
  History,
  PieChart as PieChartIcon
} from 'lucide-react';

interface ResonanceFrequency {
  id: string;
  name: string;
  frequency: number;
  amplitude: number;
  phase: number;
  coherence: number;
  purpose: string;
  chakra: string;
  effect: string;
  active: boolean;
}

interface ResonanceSession {
  id: string;
  name: string;
  description: string;
  frequencies: string[];
  participants: number;
  duration: number;
  intensity: number;
  status: 'preparing' | 'active' | 'completed' | 'paused';
  start_time?: number;
  end_time?: number;
  collective_field_strength: number;
  resonance_score: number;
}

interface QuantumField {
  strength: number;
  coherence: number;
  frequency: number;
  amplitude: number;
  participants: number;
  location: {
    latitude: number;
    longitude: number;
    altitude: number;
  };
  timestamp: number;
}

interface ResonanceMetrics {
  field_strength: number;
  coherence_level: number;
  frequency_stability: number;
  amplitude_harmony: number;
  collective_resonance: number;
  dimensional_alignment: number;
  spiritual_signature: number;
  quantum_entanglement: number;
}

const QuantumResonanceChamber: React.FC = () => {
  const [activeTab, setActiveTab] = useState('chamber');
  const [isResonating, setIsResonating] = useState(false);
  const [sessionIntensity, setSessionIntensity] = useState(0.7);
  const [selectedFrequency, setSelectedFrequency] = useState('432');
  const [resonanceMetrics, setResonanceMetrics] = useState<ResonanceMetrics>({
    field_strength: 0.65,
    coherence_level: 0.72,
    frequency_stability: 0.68,
    amplitude_harmony: 0.75,
    collective_resonance: 0.70,
    dimensional_alignment: 0.67,
    spiritual_signature: 0.80,
    quantum_entanglement: 0.73
  });

  const [frequencies, setFrequencies] = useState<ResonanceFrequency[]>([
    {
      id: '432',
      name: 'Frequência de Cura',
      frequency: 432,
      amplitude: 0.8,
      phase: 0,
      coherence: 0.85,
      purpose: 'Cura e regeneração celular',
      chakra: 'Coração',
      effect: 'Harmonização emocional e física',
      active: true
    },
    {
      id: '528',
      name: 'Frequência de Transformação',
      frequency: 528,
      amplitude: 0.7,
      phase: 45,
      coherence: 0.78,
      purpose: 'Transformação e milagres',
      chakra: 'Garganta',
      effect: 'Manifestação e transmutação',
      active: false
    },
    {
      id: '639',
      name: 'Frequência de Conexão',
      frequency: 639,
      amplitude: 0.6,
      phase: 90,
      coherence: 0.82,
      purpose: 'Conexão e relacionamentos',
      chakra: 'Terceiro Olho',
      effect: 'Intuição e comunicação espiritual',
      active: false
    },
    {
      id: '741',
      name: 'Frequência de Despertar',
      frequency: 741,
      amplitude: 0.9,
      phase: 180,
      coherence: 0.88,
      purpose: 'Despertar da consciência',
      chakra: 'Coroa',
      effect: 'Expansão da consciência e intuição',
      active: false
    },
    {
      id: '852',
      name: 'Frequência de Retorno',
      frequency: 852,
      amplitude: 0.5,
      phase: 270,
      coherence: 0.75,
      purpose: 'Retorno à ordem espiritual',
      chakra: 'Todos',
      effect: 'Alinhamento espiritual e ordem divina',
      active: false
    },
    {
      id: '963',
      name: 'Frequência de Ativação',
      frequency: 963,
      amplitude: 1.0,
      phase: 360,
      coherence: 0.92,
      purpose: 'Ativação da pineal e luz',
      chakra: 'Coroa',
      effect: 'Ativação da glândula pineal e conexão cósmica',
      active: false
    }
  ]);

  const [sessions, setSessions] = useState<ResonanceSession[]>([
    {
      id: 'global-healing',
      name: 'Cura Global',
      description: 'Sessão coletiva de cura planetária',
      frequencies: ['432', '528'],
      participants: 1247,
      duration: 30,
      intensity: 0.8,
      status: 'active',
      start_time: Date.now() - 900000,
      collective_field_strength: 0.87,
      resonance_score: 0.92
    },
    {
      id: 'consciousness-awakening',
      name: 'Despertar da Consciência',
      description: 'Ativação da consciência coletiva',
      frequencies: ['741', '852', '963'],
      participants: 856,
      duration: 45,
      intensity: 0.9,
      status: 'preparing',
      collective_field_strength: 0.78,
      resonance_score: 0.85
    },
    {
      id: 'harmonic-alignment',
      name: 'Alinhamento Harmônico',
      description: 'Alinhamento energético coletivo',
      frequencies: ['432', '639'],
      participants: 623,
      duration: 20,
      intensity: 0.6,
      status: 'completed',
      start_time: Date.now() - 1800000,
      end_time: Date.now() - 600000,
      collective_field_strength: 0.82,
      resonance_score: 0.88
    }
  ]);

  const [fieldData, setFieldData] = useState<QuantumField[]>([]);
  const [resonanceHistory, setResonanceHistory] = useState<any[]>([]);

  // Generate mock field data
  useEffect(() => {
    const generateFieldData = () => {
      const now = Date.now();
      const newData: QuantumField[] = [];
      
      for (let i = 0; i < 50; i++) {
        newData.push({
          strength: 0.5 + Math.random() * 0.5,
          coherence: 0.6 + Math.random() * 0.4,
          frequency: 400 + Math.random() * 600,
          amplitude: 0.4 + Math.random() * 0.6,
          participants: Math.floor(Math.random() * 2000),
          location: {
            latitude: -90 + Math.random() * 180,
            longitude: -180 + Math.random() * 360,
            altitude: Math.random() * 5000
          },
          timestamp: now - (i * 60000)
        });
      }
      
      setFieldData(newData);
    };

    generateFieldData();
  }, []);

  // Generate resonance history data
  useEffect(() => {
    const generateResonanceHistory = () => {
      const history = [];
      const now = Date.now();
      
      for (let i = 23; i >= 0; i--) {
        history.push({
          hour: `${i}:00`,
          field_strength: 0.4 + Math.random() * 0.4,
          coherence: 0.5 + Math.random() * 0.4,
          participants: Math.floor(Math.random() * 1500),
          resonance_score: 0.6 + Math.random() * 0.3
        });
      }
      
      setResonanceHistory(history);
    };

    generateResonanceHistory();
  }, []);

  // Simulate resonance effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isResonating) {
      interval = setInterval(() => {
        setResonanceMetrics(prev => ({
          field_strength: Math.min(1, prev.field_strength + Math.random() * 0.02),
          coherence_level: Math.min(1, prev.coherence_level + Math.random() * 0.015),
          frequency_stability: Math.min(1, prev.frequency_stability + Math.random() * 0.01),
          amplitude_harmony: Math.min(1, prev.amplitude_harmony + Math.random() * 0.015),
          collective_resonance: Math.min(1, prev.collective_resonance + Math.random() * 0.02),
          dimensional_alignment: Math.min(1, prev.dimensional_alignment + Math.random() * 0.01),
          spiritual_signature: Math.min(1, prev.spiritual_signature + Math.random() * 0.005),
          quantum_entanglement: Math.min(1, prev.quantum_entanglement + Math.random() * 0.01)
        }));
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isResonating]);

  const toggleResonance = () => {
    setIsResonating(!isResonating);
  };

  const startSession = (sessionId: string) => {
    setSessions(prev => prev.map(session => 
      session.id === sessionId 
        ? { ...session, status: 'active' as const, start_time: Date.now() }
        : session
    ));
  };

  const pauseSession = (sessionId: string) => {
    setSessions(prev => prev.map(session => 
      session.id === sessionId 
        ? { ...session, status: 'paused' as const }
        : session
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'preparing': return 'bg-yellow-500';
      case 'completed': return 'bg-blue-500';
      case 'paused': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <Play className="h-4 w-4" />;
      case 'preparing': return <Settings className="h-4 w-4" />;
      case 'completed': return <CheckCircle className="h-4 w-4" />;
      case 'paused': return <Pause className="h-4 w-4" />;
      default: return <Pause className="h-4 w-4" />;
    }
  };

  const getChakraColor = (chakra: string) => {
    switch (chakra) {
      case 'Raiz': return 'bg-red-500';
      case 'Sacral': return 'bg-orange-500';
      case 'Plexo Solar': return 'bg-yellow-500';
      case 'Coração': return 'bg-green-500';
      case 'Garganta': return 'bg-blue-500';
      case 'Terceiro Olho': return 'bg-indigo-500';
      case 'Coroa': return 'bg-purple-500';
      case 'Todos': return 'bg-gradient-to-r from-red-500 to-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const formatFrequency = (freq: number) => {
    return `${freq} Hz`;
  };

  const formatPercentage = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1', '#d084d0'];

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <Sparkles className="h-8 w-8 text-purple-600" />
          Câmara de Ressonância Quântica
        </h1>
        <p className="text-muted-foreground">
          Amplificação da consciência coletiva através de frequências quânticas e ressonância harmônica
        </p>
      </div>

      {/* Main Control Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Radio className="h-5 w-5" />
            Painel de Controle Principal
          </CardTitle>
          <CardDescription>
            Controle central da câmara de ressonância quântica
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Resonance Control */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label className="text-lg font-medium">Ressonância Ativa</Label>
                <Button
                  onClick={toggleResonance}
                  className={`flex items-center gap-2 ${isResonating ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'}`}
                >
                  {isResonating ? (
                    <>
                      <Pause className="h-4 w-4" />
                      Parar Ressonância
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4" />
                      Iniciar Ressonância
                    </>
                  )}
                </Button>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="intensity">Intensidade da Sessão</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="intensity"
                    type="range"
                    min="0.1"
                    max="1"
                    step="0.1"
                    value={sessionIntensity}
                    onChange={(e) => setSessionIntensity(parseFloat(e.target.value))}
                    className="flex-1"
                  />
                  <span className="text-sm font-medium w-12">
                    {(sessionIntensity * 100).toFixed(0)}%
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="frequency">Frequência Principal</Label>
                <Select value={selectedFrequency} onValueChange={setSelectedFrequency}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a frequência" />
                  </SelectTrigger>
                  <SelectContent>
                    {frequencies.map(freq => (
                      <SelectItem key={freq.id} value={freq.id}>
                        {freq.name} ({freq.frequency} Hz)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Current Metrics */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Métricas Atuais</h3>
              <div className="space-y-3">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Força do Campo</span>
                    <span className="text-sm font-bold text-purple-600">
                      {formatPercentage(resonanceMetrics.field_strength)}
                    </span>
                  </div>
                  <Progress value={resonanceMetrics.field_strength * 100} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Coerência</span>
                    <span className="text-sm font-bold text-blue-600">
                      {formatPercentage(resonanceMetrics.coherence_level)}
                    </span>
                  </div>
                  <Progress value={resonanceMetrics.coherence_level * 100} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Ressonância Coletiva</span>
                    <span className="text-sm font-bold text-green-600">
                      {formatPercentage(resonanceMetrics.collective_resonance)}
                    </span>
                  </div>
                  <Progress value={resonanceMetrics.collective_resonance * 100} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Assinatura Espiritual</span>
                    <span className="text-sm font-bold text-yellow-600">
                      {formatPercentage(resonanceMetrics.spiritual_signature)}
                    </span>
                  </div>
                  <Progress value={resonanceMetrics.spiritual_signature * 100} className="h-2" />
                </div>
              </div>
            </div>

            {/* Field Visualization */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Visualização do Campo</h3>
              <div className="h-48 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 rounded-lg relative overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-32 h-32 rounded-full bg-purple-500 opacity-20 animate-pulse"></div>
                  <div className="absolute w-24 h-24 rounded-full bg-blue-500 opacity-30 animate-ping"></div>
                  <div className="absolute w-16 h-16 rounded-full bg-white opacity-40 animate-pulse"></div>
                </div>
                <div className="absolute bottom-2 left-2 text-white text-xs">
                  Campo Quântico Ativo
                </div>
                <div className="absolute top-2 right-2 text-white text-xs">
                  {isResonating ? 'RESONANDO' : 'EM ESPERA'}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="chamber">Câmara</TabsTrigger>
          <TabsTrigger value="frequencies">Frequências</TabsTrigger>
          <TabsTrigger value="sessions">Sessões</TabsTrigger>
          <TabsTrigger value="analytics">Análise</TabsTrigger>
        </TabsList>

        {/* Chamber Tab */}
        <TabsContent value="chamber" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Frequency Spectrum */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Waves className="h-5 w-5" />
                  Espectro de Frequências
                </CardTitle>
                <CardDescription>
                  Análise espectral das frequências ativas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={frequencies}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="frequency" />
                    <YAxis />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey="amplitude" 
                      stackId="1" 
                      stroke="#8884d8" 
                      fill="#8884d8" 
                      fillOpacity={0.6}
                      name="Amplitude"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="coherence" 
                      stackId="2" 
                      stroke="#82ca9d" 
                      fill="#82ca9d" 
                      fillOpacity={0.6}
                      name="Coerência"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Resonance Field */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Campo de Ressonância
                </CardTitle>
                <CardDescription>
                  Força e estabilidade do campo quântico
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RadarChart data={Object.entries(resonanceMetrics).map(([key, value]) => ({
                    metric: key.replace(/_/g, ' '),
                    value: value * 100
                  }))}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="metric" />
                    <PolarRadiusAxis angle={0} domain={[0, 100]} />
                    <Radar
                      name="Métricas de Ressonância"
                      dataKey="value"
                      stroke="#8884d8"
                      fill="#8884d8"
                      fillOpacity={0.6}
                    />
                    <Tooltip />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Global Field Map */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Mapa de Campo Global
              </CardTitle>
              <CardDescription>
                Distribuição geográfica da ressonância quântica
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <ScatterChart data={fieldData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="longitude" />
                  <YAxis dataKey="latitude" />
                  <Tooltip 
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-white p-2 border rounded shadow">
                            <p>Força: {formatPercentage(data.strength)}</p>
                            <p>Coerência: {formatPercentage(data.coherence)}</p>
                            <p>Participantes: {data.participants}</p>
                            <p>Frequência: {data.frequency.toFixed(0)} Hz</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Scatter 
                    dataKey="strength" 
                    fill="#8884d8"
                    fillOpacity={0.6}
                  />
                </ScatterChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Frequencies Tab */}
        <TabsContent value="frequencies" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {frequencies.map((frequency) => (
              <Card key={frequency.id} className={frequency.active ? 'border-purple-500' : ''}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{frequency.name}</CardTitle>
                    <Badge 
                      variant="outline" 
                      className={`${getChakraColor(frequency.chakra)} text-white`}
                    >
                      {frequency.chakra}
                    </Badge>
                  </div>
                  <CardDescription>
                    {formatFrequency(frequency.frequency)}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Amplitude</span>
                      <span className="text-sm font-medium">{formatPercentage(frequency.amplitude)}</span>
                    </div>
                    <Progress value={frequency.amplitude * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Coerência</span>
                      <span className="text-sm font-medium">{formatPercentage(frequency.coherence)}</span>
                    </div>
                    <Progress value={frequency.coherence * 100} className="h-2" />
                  </div>

                  <div className="text-sm space-y-1">
                    <div className="font-medium">Propósito:</div>
                    <div className="text-muted-foreground">{frequency.purpose}</div>
                  </div>

                  <div className="text-sm space-y-1">
                    <div className="font-medium">Efeito:</div>
                    <div className="text-muted-foreground">{frequency.effect}</div>
                  </div>

                  <Button 
                    variant={frequency.active ? "default" : "outline"} 
                    size="sm"
                    className="w-full"
                    onClick={() => {
                      setFrequencies(prev => prev.map(f => 
                        f.id === frequency.id 
                          ? { ...f, active: !f.active }
                          : f
                      ));
                    }}
                  >
                    {frequency.active ? 'Desativar' : 'Ativar'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Sessions Tab */}
        <TabsContent value="sessions" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Active Sessions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Sessões Ativas
                </CardTitle>
                <CardDescription>
                  Sessões de ressonância coletiva em andamento
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sessions.filter(s => s.status === 'active').map((session) => (
                    <div key={session.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{session.name}</h4>
                        <Badge variant="outline" className="bg-green-500 text-white">
                          {getStatusIcon(session.status)}
                          <span className="ml-1">{session.status}</span>
                        </Badge>
                      </div>
                      
                      <p className="text-sm text-muted-foreground">{session.description}</p>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Participantes:</span>
                          <span className="ml-1">{session.participants}</span>
                        </div>
                        <div>
                          <span className="font-medium">Duração:</span>
                          <span className="ml-1">{session.duration} min</span>
                        </div>
                        <div>
                          <span className="font-medium">Intensidade:</span>
                          <span className="ml-1">{formatPercentage(session.intensity)}</span>
                        </div>
                        <div>
                          <span className="font-medium">Ressonância:</span>
                          <span className="ml-1">{formatPercentage(session.resonance_score)}</span>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => pauseSession(session.id)}
                        >
                          Pausar
                        </Button>
                        <Button size="sm" className="flex-1">
                          Participar
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Available Sessions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Sessões Disponíveis
                </CardTitle>
                <CardDescription>
                  Sessões preparadas para início
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sessions.filter(s => s.status === 'preparing').map((session) => (
                    <div key={session.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{session.name}</h4>
                        <Badge variant="outline" className="bg-yellow-500 text-white">
                          {getStatusIcon(session.status)}
                          <span className="ml-1">{session.status}</span>
                        </Badge>
                      </div>
                      
                      <p className="text-sm text-muted-foreground">{session.description}</p>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Duração:</span>
                          <span className="ml-1">{session.duration} min</span>
                        </div>
                        <div>
                          <span className="font-medium">Intensidade:</span>
                          <span className="ml-1">{formatPercentage(session.intensity)}</span>
                        </div>
                      </div>

                      <Button 
                        size="sm" 
                        className="w-full"
                        onClick={() => startSession(session.id)}
                      >
                        Iniciar Sessão
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Session History */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                Histórico de Sessões
              </CardTitle>
              <CardDescription>
                Sessões concluídas recentemente
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {sessions.filter(s => s.status === 'completed').map((session) => (
                  <div key={session.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">{session.name}</h4>
                      <Badge variant="outline" className="bg-blue-500 text-white">
                        {getStatusIcon(session.status)}
                        <span className="ml-1">{session.status}</span>
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Participantes:</span>
                        <span className="ml-1">{session.participants}</span>
                      </div>
                      <div>
                        <span className="font-medium">Duração:</span>
                        <span className="ml-1">{session.duration} min</span>
                      </div>
                      <div>
                        <span className="font-medium">Campo:</span>
                        <span className="ml-1">{formatPercentage(session.collective_field_strength)}</span>
                      </div>
                      <div>
                        <span className="font-medium">Ressonância:</span>
                        <span className="ml-1">{formatPercentage(session.resonance_score)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Resonance History */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Histórico de Ressonância
                </CardTitle>
                <CardDescription>
                  Evolução das métricas de ressonância nas últimas 24 horas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={resonanceHistory}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="hour" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="field_strength" 
                      stroke="#8884d8" 
                      strokeWidth={2}
                      name="Força do Campo"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="coherence" 
                      stroke="#82ca9d" 
                      strokeWidth={2}
                      name="Coerência"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="resonance_score" 
                      stroke="#ffc658" 
                      strokeWidth={2}
                      name="Ressonância"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Participant Analysis */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Análise de Participantes
                </CardTitle>
                <CardDescription>
                  Padrões de participação e engajamento
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={resonanceHistory}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="hour" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar 
                      dataKey="participants" 
                      fill="#8884d8"
                      name="Participantes"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Frequency Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="h-5 w-5" />
                Distribuição de Frequências
              </CardTitle>
              <CardDescription>
                Uso e eficácia das diferentes frequências
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <PieChart>
                  <Pie
                    data={frequencies}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, frequency }) => `${name} (${frequency} Hz)`}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="coherence"
                  >
                    {frequencies.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Performance Metrics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Métricas de Desempenho
              </CardTitle>
              <CardDescription>
                Análise detalhada do desempenho do sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="text-center space-y-2">
                  <div className="text-2xl font-bold text-purple-600">
                    {formatPercentage(resonanceMetrics.field_strength)}
                  </div>
                  <div className="text-sm text-muted-foreground">Força do Campo</div>
                  <div className="text-xs text-green-600">+5.2% hoje</div>
                </div>
                <div className="text-center space-y-2">
                  <div className="text-2xl font-bold text-blue-600">
                    {formatPercentage(resonanceMetrics.coherence_level)}
                  </div>
                  <div className="text-sm text-muted-foreground">Coerência</div>
                  <div className="text-xs text-green-600">+3.8% hoje</div>
                </div>
                <div className="text-center space-y-2">
                  <div className="text-2xl font-bold text-green-600">
                    {sessions.filter(s => s.status === 'active').reduce((sum, s) => sum + s.participants, 0)}
                  </div>
                  <div className="text-sm text-muted-foreground">Participantes Ativos</div>
                  <div className="text-xs text-green-600">+12% hoje</div>
                </div>
                <div className="text-center space-y-2">
                  <div className="text-2xl font-bold text-yellow-600">
                    {sessions.filter(s => s.status === 'active').length}
                  </div>
                  <div className="text-sm text-muted-foreground">Sessões Ativas</div>
                  <div className="text-xs text-green-600">+2 hoje</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default QuantumResonanceChamber;