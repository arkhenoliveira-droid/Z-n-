// Audit Logging System for Wallet Ownership Testing
// Comprehensive logging and audit trail management

export interface AuditLogEntry {
  id: string;
  timestamp: number;
  userId: string;
  action: string;
  resource: string;
  resourceId: string;
  result: 'success' | 'failure' | 'error';
  details: AuditLogDetails;
  ipAddress?: string;
  userAgent?: string;
  sessionId?: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  category: 'wallet_operation' | 'verification' | 'security_scan' | 'compliance' | 'system' | 'admin';
}

export interface AuditLogDetails {
  description: string;
  metadata?: Record<string, any>;
  changes?: Record<string, any>;
  previousState?: any;
  newState?: any;
  error?: string;
  duration?: number;
  relatedResources?: string[];
}

export interface AuditFilter {
  startDate?: Date;
  endDate?: Date;
  userId?: string;
  action?: string;
  resource?: string;
  resourceId?: string;
  result?: 'success' | 'failure' | 'error';
  riskLevel?: 'low' | 'medium' | 'high' | 'critical';
  category?: 'wallet_operation' | 'verification' | 'security_scan' | 'compliance' | 'system' | 'admin';
  sessionId?: string;
  ipAddress?: string;
}

export interface AuditReportConfig {
  title: string;
  description: string;
  period: {
    start: Date;
    end: Date;
  };
  filters: AuditFilter;
  includeDetails: boolean;
  format: 'json' | 'csv' | 'pdf';
  groupBy?: 'day' | 'week' | 'month' | 'user' | 'action' | 'category';
}

export interface AuditSummary {
  totalEntries: number;
  successCount: number;
  failureCount: number;
  errorCount: number;
  riskDistribution: Record<string, number>;
  categoryDistribution: Record<string, number>;
  topActions: Array<{ action: string; count: number }>;
  topUsers: Array<{ userId: string; count: number }>;
  timeDistribution: Record<string, number>;
}

export class AuditLogger {
  private logs: AuditLogEntry[] = [];
  private maxLogEntries = 10000;
  private retentionDays = 365;

  constructor() {
    this.initializeLogger();
  }

  private initializeLogger(): void {
    // Load existing logs from storage (in real implementation, this would load from database)
    this.loadLogsFromStorage();
    
    // Set up periodic cleanup
    setInterval(() => this.cleanupOldLogs(), 24 * 60 * 60 * 1000); // Daily cleanup
  }

  async logAction(
    userId: string,
    action: string,
    resource: string,
    resourceId: string,
    result: 'success' | 'failure' | 'error',
    details: AuditLogDetails,
    options?: {
      ipAddress?: string;
      userAgent?: string;
      sessionId?: string;
      riskLevel?: 'low' | 'medium' | 'high' | 'critical';
      category?: 'wallet_operation' | 'verification' | 'security_scan' | 'compliance' | 'system' | 'admin';
    }
  ): Promise<string> {
    const logEntry: AuditLogEntry = {
      id: this.generateLogId(),
      timestamp: Date.now(),
      userId,
      action,
      resource,
      resourceId,
      result,
      details,
      ipAddress: options?.ipAddress,
      userAgent: options?.userAgent,
      sessionId: options?.sessionId,
      riskLevel: options?.riskLevel || this.calculateRiskLevel(action, result),
      category: options?.category || this.categorizeAction(action, resource)
    };

    // Add to in-memory logs
    this.logs.push(logEntry);

    // Trim logs if necessary
    if (this.logs.length > this.maxLogEntries) {
      this.logs = this.logs.slice(-this.maxLogEntries);
    }

    // Persist to storage (in real implementation, this would save to database)
    await this.persistLog(logEntry);

    // Check for suspicious patterns
    await this.analyzeForSuspiciousPatterns(logEntry);

    return logEntry.id;
  }

  async queryLogs(filter: AuditFilter): Promise<AuditLogEntry[]> {
    let filteredLogs = [...this.logs];

    // Apply filters
    if (filter.startDate) {
      filteredLogs = filteredLogs.filter(log => new Date(log.timestamp) >= filter.startDate!);
    }

    if (filter.endDate) {
      filteredLogs = filteredLogs.filter(log => new Date(log.timestamp) <= filter.endDate!);
    }

    if (filter.userId) {
      filteredLogs = filteredLogs.filter(log => log.userId === filter.userId);
    }

    if (filter.action) {
      filteredLogs = filteredLogs.filter(log => log.action.includes(filter.action!));
    }

    if (filter.resource) {
      filteredLogs = filteredLogs.filter(log => log.resource.includes(filter.resource!));
    }

    if (filter.resourceId) {
      filteredLogs = filteredLogs.filter(log => log.resourceId === filter.resourceId);
    }

    if (filter.result) {
      filteredLogs = filteredLogs.filter(log => log.result === filter.result);
    }

    if (filter.riskLevel) {
      filteredLogs = filteredLogs.filter(log => log.riskLevel === filter.riskLevel);
    }

    if (filter.category) {
      filteredLogs = filteredLogs.filter(log => log.category === filter.category);
    }

    if (filter.sessionId) {
      filteredLogs = filteredLogs.filter(log => log.sessionId === filter.sessionId);
    }

    if (filter.ipAddress) {
      filteredLogs = filteredLogs.filter(log => log.ipAddress === filter.ipAddress);
    }

    // Sort by timestamp (newest first)
    filteredLogs.sort((a, b) => b.timestamp - a.timestamp);

    return filteredLogs;
  }

  async generateAuditSummary(filter: AuditFilter): Promise<AuditSummary> {
    const logs = await this.queryLogs(filter);

    const summary: AuditSummary = {
      totalEntries: logs.length,
      successCount: logs.filter(log => log.result === 'success').length,
      failureCount: logs.filter(log => log.result === 'failure').length,
      errorCount: logs.filter(log => log.result === 'error').length,
      riskDistribution: {},
      categoryDistribution: {},
      topActions: [],
      topUsers: [],
      timeDistribution: {}
    };

    // Calculate risk distribution
    logs.forEach(log => {
      summary.riskDistribution[log.riskLevel] = (summary.riskDistribution[log.riskLevel] || 0) + 1;
    });

    // Calculate category distribution
    logs.forEach(log => {
      summary.categoryDistribution[log.category] = (summary.categoryDistribution[log.category] || 0) + 1;
    });

    // Calculate top actions
    const actionCounts: Record<string, number> = {};
    logs.forEach(log => {
      actionCounts[log.action] = (actionCounts[log.action] || 0) + 1;
    });
    summary.topActions = Object.entries(actionCounts)
      .map(([action, count]) => ({ action, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    // Calculate top users
    const userCounts: Record<string, number> = {};
    logs.forEach(log => {
      userCounts[log.userId] = (userCounts[log.userId] || 0) + 1;
    });
    summary.topUsers = Object.entries(userCounts)
      .map(([userId, count]) => ({ userId, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    // Calculate time distribution
    logs.forEach(log => {
      const date = new Date(log.timestamp);
      const timeKey = date.toISOString().split('T')[0]; // Group by day
      summary.timeDistribution[timeKey] = (summary.timeDistribution[timeKey] || 0) + 1;
    });

    return summary;
  }

  async generateAuditReport(config: AuditReportConfig): Promise<any> {
    const logs = await this.queryLogs(config.filters);
    const summary = await this.generateAuditSummary(config.filters);

    const report = {
      metadata: {
        title: config.title,
        description: config.description,
        generatedAt: new Date().toISOString(),
        period: {
          start: config.period.start.toISOString(),
          end: config.period.end.toISOString()
        },
          format: config.format,
          totalEntries: logs.length
      },
      summary,
      details: config.includeDetails ? logs : undefined,
      groupings: config.groupBy ? this.groupLogs(logs, config.groupBy) : undefined
    };

    // Apply formatting based on requested format
    switch (config.format) {
      case 'json':
        return JSON.stringify(report, null, 2);
      case 'csv':
        return this.generateCSVReport(logs, summary);
      case 'pdf':
        // In real implementation, this would generate a PDF
        return JSON.stringify(report, null, 2);
      default:
        return report;
    }
  }

  private groupLogs(logs: AuditLogEntry[], groupBy: string): Record<string, AuditLogEntry[]> {
    const groups: Record<string, AuditLogEntry[]> = {};

    logs.forEach(log => {
      let key: string;
      
      switch (groupBy) {
        case 'day':
          key = new Date(log.timestamp).toISOString().split('T')[0];
          break;
        case 'week':
          const date = new Date(log.timestamp);
          const weekStart = new Date(date.setDate(date.getDate() - date.getDay()));
          key = weekStart.toISOString().split('T')[0];
          break;
        case 'month':
          key = new Date(log.timestamp).toISOString().substring(0, 7); // YYYY-MM
          break;
        case 'user':
          key = log.userId;
          break;
        case 'action':
          key = log.action;
          break;
        case 'category':
          key = log.category;
          break;
        default:
          key = 'all';
      }

      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(log);
    });

    return groups;
  }

  private generateCSVReport(logs: AuditLogEntry[], summary: AuditSummary): string {
    const headers = [
      'Timestamp',
      'User ID',
      'Action',
      'Resource',
      'Resource ID',
      'Result',
      'Risk Level',
      'Category',
      'Description',
      'IP Address'
    ];

    const rows = logs.map(log => [
      new Date(log.timestamp).toISOString(),
      log.userId,
      log.action,
      log.resource,
      log.resourceId,
      log.result,
      log.riskLevel,
      log.category,
      log.details.description,
      log.ipAddress || ''
    ]);

    return [headers, ...rows].map(row => row.join(',')).join('\n');
  }

  private calculateRiskLevel(action: string, result: 'success' | 'failure' | 'error'): 'low' | 'medium' | 'high' | 'critical' {
    const highRiskActions = [
      'delete_wallet',
      'transfer_ownership',
      'modify_security_settings',
      'override_verification'
    ];

    const mediumRiskActions = [
      'create_wallet',
      'update_wallet',
      'run_verification',
      'export_data'
    ];

    if (result === 'error') return 'high';
    if (result === 'failure' && highRiskActions.includes(action)) return 'critical';
    if (result === 'failure') return 'medium';
    if (highRiskActions.includes(action)) return 'high';
    if (mediumRiskActions.includes(action)) return 'medium';

    return 'low';
  }

  private categorizeAction(action: string, resource: string): 'wallet_operation' | 'verification' | 'security_scan' | 'compliance' | 'system' | 'admin' {
    if (action.includes('verification') || action.includes('claim')) return 'verification';
    if (action.includes('scan') || action.includes('security')) return 'security_scan';
    if (action.includes('compliance') || action.includes('audit')) return 'compliance';
    if (action.includes('admin') || action.includes('system')) return 'admin';
    if (resource.includes('wallet')) return 'wallet_operation';
    return 'system';
  }

  private generateLogId(): string {
    return `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private async persistLog(logEntry: AuditLogEntry): Promise<void> {
    // In real implementation, this would save to database
    // For now, we'll just keep it in memory
    console.log('Audit log persisted:', logEntry.id);
  }

  private loadLogsFromStorage(): void {
    // In real implementation, this would load from database
    // For now, we'll start with empty logs
    console.log('Audit logger initialized');
  }

  private async cleanupOldLogs(): Promise<void> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - this.retentionDays);

    const initialCount = this.logs.length;
    this.logs = this.logs.filter(log => new Date(log.timestamp) > cutoffDate);
    
    const cleanedCount = initialCount - this.logs.length;
    if (cleanedCount > 0) {
      console.log(`Cleaned up ${cleanedCount} old audit log entries`);
    }
  }

  private async analyzeForSuspiciousPatterns(logEntry: AuditLogEntry): Promise<void> {
    // Analyze for suspicious patterns like:
    // - Multiple failed verification attempts
    // - Unusual access patterns
    // - High-risk actions from new locations
    
    const recentLogs = this.logs.filter(log => 
      log.userId === logEntry.userId && 
      log.timestamp > Date.now() - 24 * 60 * 60 * 1000 // Last 24 hours
    );

    // Check for multiple failed attempts
    const failedAttempts = recentLogs.filter(log => log.result === 'failure').length;
    if (failedAttempts > 5) {
      console.warn(`Suspicious activity detected: ${failedAttempts} failed attempts for user ${logEntry.userId}`);
    }

    // Check for high-risk actions
    if (logEntry.riskLevel === 'critical') {
      console.warn(`Critical risk action performed: ${logEntry.action} by user ${logEntry.userId}`);
    }
  }
}

// Export singleton instance
export const auditLogger = new AuditLogger();