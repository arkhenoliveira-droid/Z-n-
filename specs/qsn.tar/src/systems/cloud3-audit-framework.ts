// Cloud3 Ventures Specific Audit Criteria and Assessment Framework
// Specialized audit criteria for cloud services and venture capital security assessment

export interface Cloud3AuditCriteria {
  id: string;
  name: string;
  category: 'infrastructure' | 'security' | 'compliance' | 'operations' | 'business' | 'venture_specific';
  description: string;
  weight: number; // Importance weight for overall scoring
  requirements: AuditRequirement[];
  assessmentMethod: string;
  evidenceRequired: string[];
  scoringMethod: ScoringMethod;
}

export interface AuditRequirement {
  id: string;
  title: string;
  description: string;
  criticality: 'critical' | 'major' | 'minor';
  complianceLevel: 'mandatory' | 'recommended' | 'optional';
  testingProcedures: TestingProcedure[];
  successCriteria: string[];
  failureCriteria: string[];
}

export interface TestingProcedure {
  id: string;
  name: string;
  description: string;
  steps: string[];
  tools: string[];
  expectedResults: string[];
  dependencies: string[];
}

export interface ScoringMethod {
  type: 'binary' | 'weighted' | 'percentage' | 'maturity';
  scale: {
    excellent: number;
    good: number;
    satisfactory: number;
    needs_improvement: number;
    poor: number;
  };
  factors: ScoringFactor[];
}

export interface ScoringFactor {
  name: string;
  description: string;
  weight: number;
  criteria: string[];
}

export interface Cloud3AuditFinding {
  id: string;
  criteriaId: string;
  requirementId: string;
  title: string;
  description: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  likelihood: 'very_high' | 'high' | 'medium' | 'low' | 'rare';
  impact: 'critical' | 'high' | 'medium' | 'low';
  riskScore: number;
  evidence: string[];
  recommendations: string[];
  remediation: RemediationPlan;
}

export interface RemediationPlan {
  priority: 'immediate' | 'high' | 'medium' | 'low';
  timeline: string;
  resources: string[];
  estimatedCost: string;
  responsibleParties: string[];
  verificationMethod: string;
}

export class Cloud3AuditFramework {
  private criteria: Cloud3AuditCriteria[] = [];

  constructor() {
    this.initializeCriteria();
  }

  private initializeCriteria(): void {
    this.criteria = [
      {
        id: 'C3-INF-001',
        name: 'Cloud Infrastructure Security',
        category: 'infrastructure',
        description: 'Security of cloud infrastructure including IaaS, PaaS, and SaaS components',
        weight: 0.25,
        requirements: [
          {
            id: 'C3-INF-001-01',
            title: 'Secure Cloud Configuration',
            description: 'All cloud services must be configured according to security best practices',
            criticality: 'critical',
            complianceLevel: 'mandatory',
            testingProcedures: [
              {
                id: 'TP-C3-INF-001-01-01',
                name: 'Cloud Configuration Review',
                description: 'Review cloud service configurations against security benchmarks',
                steps: [
                  'Extract cloud service configurations',
                  'Compare against CIS benchmarks',
                  'Identify misconfigurations',
                  'Document findings'
                ],
                tools: ['AWS Config', 'Azure Security Center', 'Prowler', 'CloudSploit'],
                expectedResults: ['All configurations meet security benchmarks'],
                dependencies: ['Cloud access credentials', 'Configuration export tools']
              }
            ],
            successCriteria: [
              'No critical misconfigurations found',
              'All high-priority security controls implemented',
              'Configuration drift monitoring in place'
            ],
            failureCriteria: [
              'Critical security misconfigurations present',
              'Missing essential security controls',
              'No configuration monitoring'
            ]
          },
          {
            id: 'C3-INF-001-02',
            title: 'Identity and Access Management',
            description: 'Proper management of identities and access to cloud resources',
            criticality: 'critical',
            complianceLevel: 'mandatory',
            testingProcedures: [
              {
                id: 'TP-C3-INF-001-02-01',
                name: 'IAM Review',
                description: 'Review IAM policies, roles, and permissions',
                steps: [
                  'Extract IAM policies and permissions',
                  'Analyze privilege assignments',
                  'Review access patterns',
                  'Identify excessive permissions'
                ],
                tools: ['AWS IAM', 'Azure AD', 'Okta', 'IAM Access Analyzer'],
                expectedResults: ['Principle of least privilege followed', 'No excessive permissions'],
                dependencies: ['IAM access', 'Permission analysis tools']
              }
            ],
            successCriteria: [
              'MFA implemented for all privileged accounts',
              'Least privilege principle enforced',
              'Regular access reviews conducted'
            ],
            failureCriteria: [
              'Missing MFA for privileged accounts',
              'Excessive permissions detected',
              'No access review process'
            ]
          }
        ],
        assessmentMethod: 'Configuration review, penetration testing, access review',
        evidenceRequired: [
          'Cloud configuration snapshots',
          'IAM policy documentation',
          'Access review reports',
          'Security assessment results'
        ],
        scoringMethod: {
          type: 'weighted',
          scale: {
            excellent: 90,
            good: 80,
            satisfactory: 70,
            needs_improvement: 60,
            poor: 0
          },
          factors: [
            {
              name: 'Configuration Security',
              description: 'Security of cloud service configurations',
              weight: 0.4,
              criteria: ['CIS benchmark compliance', 'Security control implementation']
            },
            {
              name: 'Access Management',
              description: 'Effectiveness of identity and access controls',
              weight: 0.3,
              criteria: ['MFA implementation', 'Least privilege enforcement']
            },
            {
              name: 'Monitoring',
              description: 'Cloud security monitoring capabilities',
              weight: 0.3,
              criteria: ['Logging coverage', 'Alert effectiveness']
            }
          ]
        }
      },
      {
        id: 'C3-SEC-001',
        name: 'Data Security and Privacy',
        category: 'security',
        description: 'Protection of sensitive data and compliance with privacy regulations',
        weight: 0.2,
        requirements: [
          {
            id: 'C3-SEC-001-01',
            title: 'Data Encryption',
            description: 'Encryption of data at rest and in transit',
            criticality: 'critical',
            complianceLevel: 'mandatory',
            testingProcedures: [
              {
                id: 'TP-C3-SEC-001-01-01',
                name: 'Encryption Validation',
                description: 'Validate encryption implementation for sensitive data',
                steps: [
                  'Identify sensitive data locations',
                  'Check encryption status at rest',
                  'Verify encryption in transit',
                  'Test key management processes'
                ],
                tools: ['AWS KMS', 'Azure Key Vault', 'OpenSSL', 'Wireshark'],
                expectedResults: ['All sensitive data properly encrypted', 'Key management secure'],
                dependencies: ['Data classification', 'Encryption tools access']
              }
            ],
            successCriteria: [
              'All sensitive data encrypted at rest',
              'All data transmissions encrypted',
              'Secure key management implemented'
            ],
            failureCriteria: [
              'Unencrypted sensitive data found',
              'Insecure data transmissions',
              'Weak key management'
            ]
          }
        ],
        assessmentMethod: 'Technical testing, configuration review, key management audit',
        evidenceRequired: [
          'Encryption configuration documentation',
          'Key management policies',
          'Data classification schema',
          'Encryption test results'
        ],
        scoringMethod: {
          type: 'percentage',
          scale: {
            excellent: 95,
            good: 85,
            satisfactory: 75,
            needs_improvement: 65,
            poor: 0
          },
          factors: [
            {
              name: 'Encryption Coverage',
              description: 'Percentage of sensitive data properly encrypted',
              weight: 0.5,
              criteria: ['Data at rest encryption', 'Data in transit encryption']
            },
            {
              name: 'Key Management',
              description: 'Security of cryptographic key management',
              weight: 0.3,
              criteria: ['Key rotation', 'Access controls', 'Backup procedures']
            },
            {
              name: 'Algorithm Strength',
              description: 'Strength of encryption algorithms used',
              weight: 0.2,
              criteria: ['Algorithm standards', 'Key length requirements']
            }
          ]
        }
      },
      {
        id: 'C3-COM-001',
        name: 'Regulatory Compliance',
        category: 'compliance',
        description: 'Compliance with relevant regulations and industry standards',
        weight: 0.15,
        requirements: [
          {
            id: 'C3-COM-001-01',
            title: 'SOC 2 Compliance',
            description: 'Compliance with SOC 2 Type II requirements',
            criticality: 'major',
            complianceLevel: 'mandatory',
            testingProcedures: [
              {
                id: 'TP-C3-COM-001-01-01',
                name: 'SOC 2 Controls Assessment',
                description: 'Assess implementation of SOC 2 controls',
                steps: [
                  'Review SOC 2 control documentation',
                  'Test control implementation',
                  'Interview control owners',
                  'Assess control effectiveness'
                ],
                tools: ['SOC 2 reports', 'Control assessment frameworks', 'Interview guides'],
                expectedResults: ['All SOC 2 controls properly implemented and operating effectively'],
                dependencies: ['SOC 2 documentation', 'Access to control owners']
              }
            ],
            successCriteria: [
              'All SOC 2 Trust Services Criteria met',
              'Control documentation complete',
              'Regular control testing performed'
            ],
            failureCriteria: [
              'Missing SOC 2 controls',
              'Ineffective control operation',
              'Incomplete documentation'
            ]
          }
        ],
        assessmentMethod: 'Documentation review, control testing, interviews',
        evidenceRequired: [
          'SOC 2 Type II report',
          'Control documentation',
          'Test results',
          'Management attestations'
        ],
        scoringMethod: {
          type: 'maturity',
          scale: {
            excellent: 100,
            good: 85,
            satisfactory: 70,
            needs_improvement: 55,
            poor: 0
          },
          factors: [
            {
              name: 'Control Implementation',
              description: 'Maturity of control implementation',
              weight: 0.4,
              criteria: ['Control existence', 'Control design', 'Operating effectiveness']
            },
            {
              name: 'Documentation',
              description: 'Quality and completeness of documentation',
              weight: 0.3,
              criteria: ['Policy completeness', 'Procedure documentation', 'Evidence maintenance']
            },
            {
              name: 'Testing',
              description: 'Effectiveness of control testing',
              weight: 0.3,
              criteria: ['Test coverage', 'Test frequency', 'Issue resolution']
            }
          ]
        }
      },
      {
        id: 'C3-OPS-001',
        name: 'Operational Resilience',
        category: 'operations',
        description: 'Ability to maintain operations during disruptions',
        weight: 0.15,
        requirements: [
          {
            id: 'C3-OPS-001-01',
            title: 'Incident Response',
            description: 'Effective incident response capabilities',
            criticality: 'major',
            complianceLevel: 'mandatory',
            testingProcedures: [
              {
                id: 'TP-C3-OPS-001-01-01',
                name: 'Incident Response Testing',
                description: 'Test incident response capabilities through simulations',
                steps: [
                  'Review incident response plan',
                  'Conduct tabletop exercises',
                  'Test communication procedures',
                  'Evaluate response effectiveness'
                ],
                tools: ['Incident response plans', 'Simulation scenarios', 'Communication tools'],
                expectedResults: ['Effective incident detection and response demonstrated'],
                dependencies: ['Incident response plan', 'Team availability']
              }
            ],
            successCriteria: [
              'Documented incident response plan',
              'Trained incident response team',
              'Regular testing conducted',
              'Effective communication procedures'
            ],
            failureCriteria: [
              'Missing incident response plan',
              'Untrained response team',
              'No testing performed',
              'Poor communication procedures'
            ]
          }
        ],
        assessmentMethod: 'Plan review, simulation testing, team interviews',
        evidenceRequired: [
          'Incident response plan',
          'Test exercise results',
          'Training records',
          'Communication logs'
        ],
        scoringMethod: {
          type: 'maturity',
          scale: {
            excellent: 100,
            good: 80,
            satisfactory: 65,
            needs_improvement: 50,
            poor: 0
          },
          factors: [
            {
              name: 'Planning',
              description: 'Quality of incident response planning',
              weight: 0.3,
              criteria: ['Plan completeness', 'Plan maintenance', 'Role definitions']
            },
            {
              name: 'Capabilities',
              description: 'Incident response capabilities and readiness',
              weight: 0.4,
              criteria: ['Team training', 'Tool availability', 'Detection capabilities']
            },
            {
              name: 'Testing',
              description: 'Effectiveness of testing and exercises',
              weight: 0.3,
              criteria: ['Exercise frequency', 'Scenario coverage', 'Lessons learned']
            }
          ]
        }
      },
      {
        id: 'C3-BIZ-001',
        name: 'Business Continuity',
        category: 'business',
        description: 'Ability to maintain critical business functions during disruptions',
        weight: 0.1,
        requirements: [
          {
            id: 'C3-BIZ-001-01',
            title: 'Business Impact Analysis',
            description: 'Comprehensive business impact analysis conducted',
            criticality: 'major',
            complianceLevel: 'recommended',
            testingProcedures: [
              {
                id: 'TP-C3-BIZ-001-01-01',
                name: 'BIA Review',
                description: 'Review business impact analysis documentation and results',
                steps: [
                  'Review BIA methodology',
                  'Assess critical business functions',
                  'Evaluate impact assessments',
                  'Verify recovery objectives'
                ],
                tools: ['BIA documentation', 'Interview guides', 'Assessment templates'],
                expectedResults: ['Comprehensive BIA with accurate impact assessments'],
                dependencies: ['BIA documentation', 'Business stakeholder access']
              }
            ],
            successCriteria: [
              'Comprehensive BIA completed',
              'Critical business functions identified',
              'Recovery objectives established',
              'Regular BIA updates'
            ],
            failureCriteria: [
              'Missing BIA',
              'Incomplete function identification',
              'No recovery objectives',
              'Outdated BIA'
            ]
          }
        ],
        assessmentMethod: 'Documentation review, stakeholder interviews',
        evidenceRequired: [
          'Business impact analysis report',
          'Critical function inventory',
          'Recovery time objectives',
          'Update records'
        ],
        scoringMethod: {
          type: 'percentage',
          scale: {
            excellent: 95,
            good: 80,
            satisfactory: 65,
            needs_improvement: 50,
            poor: 0
          },
          factors: [
            {
              name: 'Analysis Coverage',
              description: 'Completeness of business impact analysis',
              weight: 0.4,
              criteria: ['Function coverage', 'Impact assessment', 'Stakeholder involvement']
            },
            {
              name: 'Recovery Objectives',
              description: 'Quality of recovery time and point objectives',
              weight: 0.3,
              criteria: ['RTO definition', 'RPO definition', 'Objective achievability']
            },
            {
              name: 'Maintenance',
              description: 'Regular maintenance and updates',
              weight: 0.3,
              criteria: ['Update frequency', 'Change integration', 'Review process']
            }
          ]
        }
      },
      {
        id: 'C3-VC-001',
        name: 'Venture Capital Specific',
        category: 'venture_specific',
        description: 'Security considerations specific to venture capital operations',
        weight: 0.15,
        requirements: [
          {
            id: 'C3-VC-001-01',
            title: 'Portfolio Company Security',
            description: 'Security oversight of portfolio companies',
            criticality: 'major',
            complianceLevel: 'recommended',
            testingProcedures: [
              {
                id: 'TP-C3-VC-001-01-01',
                name: 'Portfolio Security Review',
                description: 'Review security practices of portfolio companies',
                steps: [
                  'Review portfolio company security assessments',
                  'Assess security oversight processes',
                  'Evaluate incident response coordination',
                  'Review data sharing practices'
                ],
                tools: ['Security assessment reports', 'Oversight frameworks', 'Interview guides'],
                expectedResults: ['Effective security oversight of portfolio companies demonstrated'],
                dependencies: ['Portfolio company access', 'Assessment documentation']
              }
            ],
            successCriteria: [
              'Portfolio company security assessments',
              'Security oversight framework',
              'Incident coordination procedures',
              'Data sharing agreements'
            ],
            failureCriteria: [
              'No portfolio security oversight',
              'Missing security assessments',
              'No coordination procedures',
              'Inadequate data protection'
            ]
          },
          {
            id: 'C3-VC-001-02',
            title: 'Deal Flow Security',
            description: 'Security of confidential deal flow information',
            criticality: 'critical',
            complianceLevel: 'mandatory',
            testingProcedures: [
              {
                id: 'TP-C3-VC-001-02-01',
                name: 'Deal Flow Security Assessment',
                description: 'Assess security controls for deal flow information',
                steps: [
                  'Review deal flow information classification',
                  'Assess access controls',
                  'Evaluate data sharing practices',
                  'Test incident response procedures'
                ],
                tools: ['Access control systems', 'Data classification tools', 'Security assessment frameworks'],
                expectedResults: ['Adequate protection of confidential deal information'],
                dependencies: ['Deal flow system access', 'Security documentation']
              }
            ],
            successCriteria: [
              'Confidential information classification',
              'Strict access controls',
              'Secure data sharing',
              'Incident response procedures'
            ],
            failureCriteria: [
              'Unprotected confidential information',
              'Weak access controls',
              'Insecure data sharing',
              'No incident response'
            ]
          }
        ],
        assessmentMethod: 'Documentation review, system testing, interviews',
        evidenceRequired: [
          'Portfolio company security assessments',
          'Oversight framework documentation',
          'Deal flow security procedures',
          'Access control logs'
        ],
        scoringMethod: {
          type: 'weighted',
          scale: {
            excellent: 90,
            good: 75,
            satisfactory: 60,
            needs_improvement: 45,
            poor: 0
          },
          factors: [
            {
              name: 'Portfolio Oversight',
              description: 'Effectiveness of portfolio company security oversight',
              weight: 0.6,
              criteria: ['Assessment coverage', 'Oversight framework', 'Improvement tracking']
            },
            {
              name: 'Deal Flow Protection',
              description: 'Security of confidential deal flow information',
              weight: 0.4,
              criteria: ['Information classification', 'Access controls', 'Data protection']
            }
          ]
        }
      }
    ];
  }

  getCriteria(): Cloud3AuditCriteria[] {
    return this.criteria;
  }

  getCriteriaByCategory(category: string): Cloud3AuditCriteria[] {
    return this.criteria.filter(c => c.category === category);
  }

  getCriteriaById(id: string): Cloud3AuditCriteria | undefined {
    return this.criteria.find(c => c.id === id);
  }

  calculateOverallScore(assessmentResults: AssessmentResult[]): number {
    let totalWeightedScore = 0;
    let totalWeight = 0;

    assessmentResults.forEach(result => {
      const criteria = this.getCriteriaById(result.criteriaId);
      if (criteria) {
        const weightedScore = result.score * criteria.weight;
        totalWeightedScore += weightedScore;
        totalWeight += criteria.weight;
      }
    });

    return totalWeight > 0 ? totalWeightedScore / totalWeight : 0;
  }

  generateFindings(assessmentResults: AssessmentResult[]): Cloud3AuditFinding[] {
    const findings: Cloud3AuditFinding[] = [];

    assessmentResults.forEach(result => {
      const criteria = this.getCriteriaById(result.criteriaId);
      if (criteria && result.score < 70) { // Threshold for findings
        const requirement = criteria.requirements.find(r => r.id === result.requirementId);
        if (requirement) {
          findings.push({
            id: `FIND-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
            criteriaId: result.criteriaId,
            requirementId: result.requirementId,
            title: `${criteria.name} - ${requirement.title}`,
            description: result.details || 'Assessment revealed areas for improvement',
            severity: this.calculateSeverity(result.score, requirement.criticality),
            likelihood: this.calculateLikelihood(result.score),
            impact: this.calculateImpact(result.score, requirement.criticality),
            riskScore: this.calculateRiskScore(result.score, requirement.criticality),
            evidence: result.evidence || [],
            recommendations: this.generateRecommendations(criteria, requirement, result.score),
            remediation: this.generateRemediationPlan(result.score, requirement.criticality)
          });
        }
      }
    });

    return findings;
  }

  private calculateSeverity(score: number, criticality: string): 'critical' | 'high' | 'medium' | 'low' {
    if (score < 40) return 'critical';
    if (score < 60) return 'high';
    if (score < 80) return 'medium';
    return 'low';
  }

  private calculateLikelihood(score: number): 'very_high' | 'high' | 'medium' | 'low' | 'rare' {
    if (score < 30) return 'very_high';
    if (score < 50) return 'high';
    if (score < 70) return 'medium';
    if (score < 85) return 'low';
    return 'rare';
  }

  private calculateImpact(score: number, criticality: string): 'critical' | 'high' | 'medium' | 'low' {
    if (criticality === 'critical' && score < 50) return 'critical';
    if (criticality === 'major' && score < 60) return 'high';
    if (score < 70) return 'medium';
    return 'low';
  }

  private calculateRiskScore(score: number, criticality: string): number {
    const baseScore = 100 - score;
    const multiplier = criticality === 'critical' ? 1.5 : criticality === 'major' ? 1.2 : 1.0;
    return Math.min(10, Math.round(baseScore * multiplier / 10));
  }

  private generateRecommendations(criteria: Cloud3AuditCriteria, requirement: AuditRequirement, score: number): string[] {
    const recommendations: string[] = [];

    if (score < 40) {
      recommendations.push('Immediate remediation required', 'Implement emergency controls', 'Escalate to executive leadership');
    } else if (score < 60) {
      recommendations.push('Develop remediation plan', 'Implement temporary controls', 'Schedule regular progress reviews');
    } else if (score < 80) {
      recommendations.push('Optimize existing controls', 'Enhance monitoring capabilities', 'Consider process improvements');
    }

    // Add specific recommendations based on category
    if (criteria.category === 'infrastructure') {
      recommendations.push('Review cloud security configurations', 'Enhance identity and access management');
    } else if (criteria.category === 'security') {
      recommendations.push('Strengthen data protection measures', 'Implement advanced threat detection');
    } else if (criteria.category === 'compliance') {
      recommendations.push('Update compliance documentation', 'Enhance control testing procedures');
    }

    return recommendations;
  }

  private generateRemediationPlan(score: number, criticality: string): RemediationPlan {
    let priority: 'immediate' | 'high' | 'medium' | 'low';
    let timeline: string;
    let estimatedCost: string;

    if (score < 40 || criticality === 'critical') {
      priority = 'immediate';
      timeline = '1-2 weeks';
      estimatedCost = 'High';
    } else if (score < 60) {
      priority = 'high';
      timeline = '1-2 months';
      estimatedCost = 'Medium-High';
    } else if (score < 80) {
      priority = 'medium';
      timeline = '2-3 months';
      estimatedCost = 'Medium';
    } else {
      priority = 'low';
      timeline = '3-6 months';
      estimatedCost = 'Low';
    }

    return {
      priority,
      timeline,
      resources: ['Security team', 'IT operations', 'Management'],
      estimatedCost,
      responsibleParties: ['CISO', 'IT Director', 'Business Owners'],
      verificationMethod: 'Follow-up assessment and testing'
    };
  }
}

export interface AssessmentResult {
  criteriaId: string;
  requirementId: string;
  score: number;
  details?: string;
  evidence?: string[];
  assessor: string;
  assessmentDate: string;
}

// Export singleton instance
export const cloud3AuditFramework = new Cloud3AuditFramework();