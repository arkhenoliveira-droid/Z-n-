/**
 * Contextual Help System
 * 
 * Este sistema fornece ajuda e orientação contextual inteligente que se adapta
 * ao contexto atual do usuário, seu nível de conhecimento e necessidades específicas.
 */

export interface HelpContext {
  current_screen: string;
  current_action: string;
  user_level: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  user_history: string[];
  time_spent_current_session: number;
  interaction_frequency: number;
  frustration_indicators: {
    repeated_actions: number;
    error_count: number;
    help_requests: number;
    time_per_action: number;
  };
  accessibility_needs: {
    screen_reader: boolean;
    high_contrast: boolean;
    simplified_ui: boolean;
    audio_guidance: boolean;
  };
}

export interface HelpContent {
  id: string;
  title: string;
  content: string;
  type: 'tooltip' | 'modal' | 'sidebar' | 'inline' | 'video' | 'interactive';
  context_triggers: string[];
  user_level_restriction?: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  priority: 'low' | 'medium' | 'high' | 'critical';
  category: 'navigation' | 'functionality' | 'concept' | 'troubleshooting' | 'best_practice';
  multimedia: {
    images?: string[];
    videos?: string[];
    diagrams?: string[];
    code_examples?: string[];
  };
  related_help: string[];
  estimated_read_time: number; // segundos
  difficulty: number; // 1-10
  effectiveness_metrics: {
    helpfulness_score: number;
    resolution_rate: number;
    average_time_to_resolution: number;
  };
}

export interface HelpInteraction {
  user_id: string;
  help_id: string;
  interaction_type: 'viewed' | 'completed' | 'dismissed' | 'rated' | 'followed';
  timestamp: number;
  context: HelpContext;
  feedback?: {
    rating: number; // 1-5
    helpful: boolean;
    comments?: string;
    suggestion?: string;
  };
  outcome: {
    problem_resolved: boolean;
    time_to_resolution: number;
    subsequent_actions: string[];
  };
}

export interface HelpAgent {
  id: string;
  name: string;
  personality: 'friendly' | 'professional' | 'enthusiastic' | 'technical' | 'minimalist';
  expertise_area: string[];
  communication_style: 'text' | 'voice' | 'visual' | 'interactive';
  availability: '24/7' | 'business_hours' | 'on_demand';
  capabilities: {
    proactive_help: boolean;
    contextual_awareness: boolean;
    learning_adaptation: boolean;
    multilingual: boolean;
    emotional_intelligence: boolean;
  };
  response_templates: { [key: string]: string[] };
}

export class ContextualHelpSystem {
  private helpContents: HelpContent[] = [];
  private helpInteractions: HelpInteraction[] = [];
  private helpAgents: HelpAgent[] = [];
  private userProfiles: Map<string, any> = new Map();
  private activeSessions: Map<string, HelpContext> = new Map();

  constructor() {
    this.initializeHelpContents();
    this.initializeHelpAgents();
  }

  private initializeHelpContents(): void {
    this.helpContents = [
      // Conteúdo de Ajuda Básica
      {
        id: 'help_basics_navigation',
        title: 'Navegação Básica',
        content: 'Use as abas no topo para navegar entre diferentes módulos do sistema. Cada aba representa uma área funcional específica.',
        type: 'tooltip',
        context_triggers: ['first_visit', 'navigation_confusion'],
        user_level_restriction: 'beginner',
        priority: 'high',
        category: 'navigation',
        multimedia: {
          images: ['navigation_diagram.png'],
          diagrams: ['tab_structure.svg']
        },
        related_help: ['help_basics_interface', 'help_basics_shortcuts'],
        estimated_read_time: 30,
        difficulty: 1,
        effectiveness_metrics: {
          helpfulness_score: 4.5,
          resolution_rate: 0.92,
          average_time_to_resolution: 45
        }
      },

      {
        id: 'help_basics_interface',
        title: 'Elementos da Interface',
        content: 'A interface é composta por cards, botões, formulários e menus. Cada elemento tem funções específicas e dicas contextuais.',
        type: 'inline',
        context_triggers: ['interface_elements_hover', 'first_interaction'],
        user_level_restriction: 'beginner',
        priority: 'high',
        category: 'functionality',
        multimedia: {
          images: ['interface_elements.png'],
          diagrams: ['ui_components.svg']
        },
        related_help: ['help_basics_navigation', 'help_interaction_forms'],
        estimated_read_time: 45,
        difficulty: 2,
        effectiveness_metrics: {
          helpfulness_score: 4.3,
          resolution_rate: 0.88,
          average_time_to_resolution: 60
        }
      },

      {
        id: 'help_interaction_forms',
        title: 'Trabalhando com Formulários',
        content: 'Os formulários são usados para entrada de dados. Eles incluem validação automática e salvamento progressivo.',
        type: 'modal',
        context_triggers: ['form_interaction', 'validation_error'],
        user_level_restriction: 'beginner',
        priority: 'medium',
        category: 'functionality',
        multimedia: {
          images: ['form_example.png'],
          code_examples: ['form_validation.js']
        },
        related_help: ['help_basics_interface', 'help_troubleshooting_errors'],
        estimated_read_time: 60,
        difficulty: 3,
        effectiveness_metrics: {
          helpfulness_score: 4.1,
          resolution_rate: 0.85,
          average_time_to_resolution: 90
        }
      },

      // Conteúdo de Ajuda Intermediária
      {
        id: 'help_intermediate_customization',
        title: 'Personalização do Ambiente',
        content: 'Personalize sua experiência ajustando temas, layouts e preferências de comportamento do sistema.',
        type: 'sidebar',
        context_triggers: ['settings_access', 'customization_intent'],
        user_level_restriction: 'intermediate',
        priority: 'medium',
        category: 'functionality',
        multimedia: {
          images: ['customization_options.png'],
          videos: ['customization_tutorial.mp4']
        },
        related_help: ['help_intermediate_workflows', 'help_accessibility_options'],
        estimated_read_time: 90,
        difficulty: 4,
        effectiveness_metrics: {
          helpfulness_score: 4.4,
          resolution_rate: 0.90,
          average_time_to_resolution: 120
        }
      },

      {
        id: 'help_intermediate_workflows',
        title: 'Fluxos de Trabalho',
        content: 'Crie e gerencie fluxos de trabalho personalizados para automatizar tarefas repetitivas e melhorar produtividade.',
        type: 'interactive',
        context_triggers: ['workflow_creation', 'automation_intent'],
        user_level_restriction: 'intermediate',
        priority: 'medium',
        category: 'best_practice',
        multimedia: {
          images: ['workflow_builder.png'],
          videos: ['workflow_demo.mp4'],
          diagrams: ['workflow_logic.svg']
        },
        related_help: ['help_intermediate_customization', 'help_advanced_integration'],
        estimated_read_time: 120,
        difficulty: 5,
        effectiveness_metrics: {
          helpfulness_score: 4.2,
          resolution_rate: 0.87,
          average_time_to_resolution: 180
        }
      },

      // Conteúdo de Ajuda Avançada
      {
        id: 'help_advanced_integration',
        title: 'Integração com APIs',
        content: 'Integre o sistema com plataformas externas usando APIs e webhooks para expandir funcionalidades.',
        type: 'modal',
        context_triggers: ['api_access', 'integration_attempt'],
        user_level_restriction: 'advanced',
        priority: 'low',
        category: 'functionality',
        multimedia: {
          code_examples: ['api_integration.js', 'webhook_setup.py'],
          diagrams: ['api_architecture.svg']
        },
        related_help: ['help_intermediate_workflows', 'help_expert_architecture'],
        estimated_read_time: 180,
        difficulty: 7,
        effectiveness_metrics: {
          helpfulness_score: 4.0,
          resolution_rate: 0.82,
          average_time_to_resolution: 300
        }
      },

      {
        id: 'help_advanced_optimization',
        title: 'Otimização de Performance',
        content: 'Aprenda técnicas avançadas para otimizar o desempenho do sistema e melhorar eficiência operacional.',
        type: 'sidebar',
        context_triggers: ['performance_monitoring', 'optimization_intent'],
        user_level_restriction: 'advanced',
        priority: 'medium',
        category: 'best_practice',
        multimedia: {
          images: ['performance_metrics.png'],
          diagrams: ['optimization_workflow.svg'],
          code_examples: ['optimization_script.js']
        },
        related_help: ['help_advanced_integration', 'help_troubleshooting_performance'],
        estimated_read_time: 150,
        difficulty: 8,
        effectiveness_metrics: {
          helpfulness_score: 4.1,
          resolution_rate: 0.85,
          average_time_to_resolution: 240
        }
      },

      // Conteúdo de Ajuda Expert
      {
        id: 'help_expert_architecture',
        title: 'Arquitetura do Sistema',
        content: 'Compreenda a arquitetura interna do sistema, padrões de design e princípios de implementação.',
        type: 'modal',
        context_triggers: ['architecture_exploration', 'code_analysis'],
        user_level_restriction: 'expert',
        priority: 'low',
        category: 'concept',
        multimedia: {
          diagrams: ['system_architecture.svg', 'data_flow.svg', 'component_hierarchy.svg'],
          code_examples: ['architecture_patterns.js', 'design_principles.md']
        },
        related_help: ['help_advanced_integration', 'help_expert_contribution'],
        estimated_read_time: 240,
        difficulty: 9,
        effectiveness_metrics: {
          helpfulness_score: 4.3,
          resolution_rate: 0.88,
          average_time_to_resolution: 360
        }
      },

      {
        id: 'help_expert_contribution',
        title: 'Contribuição para o Sistema',
        content: 'Aprenda como contribuir para o desenvolvimento do sistema, incluindo código, documentação e pesquisas.',
        type: 'interactive',
        context_triggers: ['contribution_intent', 'development_access'],
        user_level_restriction: 'expert',
        priority: 'low',
        category: 'best_practice',
        multimedia: {
          videos: ['contribution_guide.mp4'],
          code_examples: ['contribution_template.js', 'documentation_template.md'],
          diagrams: ['contribution_workflow.svg']
        },
        related_help: ['help_expert_architecture', 'help_expert_research'],
        estimated_read_time: 200,
        difficulty: 10,
        effectiveness_metrics: {
          helpfulness_score: 4.5,
          resolution_rate: 0.92,
          average_time_to_resolution: 420
        }
      },

      // Conteúdo de Solução de Problemas
      {
        id: 'help_troubleshooting_errors',
        title: 'Resolução de Erros Comuns',
        content: 'Encontre soluções para erros frequentes e aprenda a diagnosticar problemas no sistema.',
        type: 'modal',
        context_triggers: ['error_occurrence', 'frustration_detected'],
        priority: 'critical',
        category: 'troubleshooting',
        multimedia: {
          images: ['error_screenshots.png'],
          diagrams: ['error_resolution_flow.svg']
        },
        related_help: ['help_basics_interface', 'help_troubleshooting_performance'],
        estimated_read_time: 90,
        difficulty: 3,
        effectiveness_metrics: {
          helpfulness_score: 4.6,
          resolution_rate: 0.94,
          average_time_to_resolution: 120
        }
      },

      {
        id: 'help_troubleshooting_performance',
        title: 'Problemas de Performance',
        content: 'Identifique e resolva problemas de performance do sistema para melhorar a experiência do usuário.',
        type: 'sidebar',
        context_triggers: ['slow_response', 'performance_issue'],
        priority: 'high',
        category: 'troubleshooting',
        multimedia: {
          images: ['performance_monitoring.png'],
          diagrams: ['performance_bottlenecks.svg']
        },
        related_help: ['help_advanced_optimization', 'help_troubleshooting_errors'],
        estimated_read_time: 120,
        difficulty: 6,
        effectiveness_metrics: {
          helpfulness_score: 4.2,
          resolution_rate: 0.86,
          average_time_to_resolution: 180
        }
      },

      // Conteúdo de Acessibilidade
      {
        id: 'help_accessibility_options',
        title: 'Opções de Acessibilidade',
        content: 'Configure opções de acessibilidade como leitor de tela, alto contraste, navegação por teclado e mais.',
        type: 'modal',
        context_triggers: ['accessibility_settings', 'accessibility_need_detected'],
        priority: 'high',
        category: 'functionality',
        multimedia: {
          images: ['accessibility_options.png'],
          videos: ['accessibility_demo.mp4']
        },
        related_help: ['help_basics_interface', 'help_intermediate_customization'],
        estimated_read_time: 75,
        difficulty: 2,
        effectiveness_metrics: {
          helpfulness_score: 4.7,
          resolution_rate: 0.96,
          average_time_to_resolution: 90
        }
      }
    ];
  }

  private initializeHelpAgents(): void {
    this.helpAgents = [
      {
        id: 'agent_friendly_guide',
        name: 'Guia Amigável',
        personality: 'friendly',
        expertise_area: ['navegação básica', 'interface', 'conceitos fundamentais'],
        communication_style: 'text',
        availability: '24/7',
        capabilities: {
          proactive_help: true,
          contextual_awareness: true,
          learning_adaptation: true,
          multilingual: false,
          emotional_intelligence: true
        },
        response_templates: {
          greeting: [
            'Olá! Estou aqui para ajudar você a navegar pelo sistema.',
            'Oi! Precisa de ajuda com alguma funcionalidade?',
            'Bem-vindo! Como posso auxiliar você hoje?'
          ],
          assistance: [
            'Vou te mostrar como isso funciona passo a passo.',
            'Posso te guiar através deste processo.',
            'Vamos resolver isso juntos!'
          ],
          encouragement: [
            'Você está indo muito bem!',
            'Continue assim, você está aprendendo rápido.',
            'Ótimo progresso! Continue explorando.'
          ]
        }
      },

      {
        id: 'agent_technical_expert',
        name: 'Especialista Técnico',
        personality: 'technical',
        expertise_area: ['integração', 'APIs', 'arquitetura', 'performance'],
        communication_style: 'text',
        availability: 'business_hours',
        capabilities: {
          proactive_help: false,
          contextual_awareness: true,
          learning_adaptation: true,
          multilingual: false,
          emotional_intelligence: false
        },
        response_templates: {
          greeting: [
            'Posso ajudar com questões técnicas avançadas.',
            'Especialista técnico disponível para consultoria.',
            'Como posso auxiliar com aspectos técnicos do sistema?'
          ],
          assistance: [
            'Vamos analisar a arquitetura técnica desta funcionalidade.',
            'Posso fornecer exemplos de código e documentação técnica.',
            'Vamos revisar as especificações técnicas.'
          ],
          encouragement: [
            'Sua compreensão técnica está evoluindo bem.',
            'Excelente análise técnica.',
            'Você está dominando os conceitos avançados.'
          ]
        }
      },

      {
        id: 'agent_accessibility_helper',
        name: 'Assistente de Acessibilidade',
        personality: 'professional',
        expertise_area: ['acessibilidade', 'interface adaptativa', 'navegação assistiva'],
        communication_style: 'text',
        availability: '24/7',
        capabilities: {
          proactive_help: true,
          contextual_awareness: true,
          learning_adaptation: true,
          multilingual: false,
          emotional_intelligence: true
        },
        response_templates: {
          greeting: [
            'Estou aqui para ajudar a tornar o sistema mais acessível para você.',
            'Assistente de acessibilidade disponível.',
            'Como posso ajudar com suas necessidades de acessibilidade?'
          ],
          assistance: [
            'Vou te guiar na configuração das opções de acessibilidade.',
            'Posso ajudar a adaptar a interface para suas necessidades.',
            'Vamos explorar as ferramentas de acessibilidade disponíveis.'
          ],
          encouragement: [
            'O sistema está se tornando mais acessível para você.',
            'Ótimo uso das ferramentas de acessibilidade.',
            'Você está navegando com excelência usando os recursos adaptativos.'
          ]
        }
      }
    ];
  }

  public startHelpSession(userId: string, initialContext: Partial<HelpContext>): void {
    const context: HelpContext = {
      current_screen: initialContext.current_screen || 'unknown',
      current_action: initialContext.current_action || 'none',
      user_level: initialContext.user_level || 'beginner',
      user_history: initialContext.user_history || [],
      time_spent_current_session: initialContext.time_spent_current_session || 0,
      interaction_frequency: initialContext.interaction_frequency || 0,
      frustration_indicators: {
        repeated_actions: initialContext.frustration_indicators?.repeated_actions || 0,
        error_count: initialContext.frustration_indicators?.error_count || 0,
        help_requests: initialContext.frustration_indicators?.help_requests || 0,
        time_per_action: initialContext.frustration_indicators?.time_per_action || 0
      },
      accessibility_needs: {
        screen_reader: initialContext.accessibility_needs?.screen_reader || false,
        high_contrast: initialContext.accessibility_needs?.high_contrast || false,
        simplified_ui: initialContext.accessibility_needs?.simplified_ui || false,
        audio_guidance: initialContext.accessibility_needs?.audio_guidance || false
      }
    };

    this.activeSessions.set(userId, context);
  }

  public updateContext(userId: string, contextUpdate: Partial<HelpContext>): void {
    const currentContext = this.activeSessions.get(userId);
    if (!currentContext) return;

    const updatedContext = { ...currentContext, ...contextUpdate };
    this.activeSessions.set(userId, updatedContext);

    // Check for proactive help triggers
    this.checkProactiveHelpTriggers(userId, updatedContext);
  }

  private checkProactiveHelpTriggers(userId: string, context: HelpContext): void {
    const triggers: string[] = [];

    // Detect frustration patterns
    if (context.frustration_indicators.repeated_actions > 5) {
      triggers.push('frustration_detected');
    }

    if (context.frustration_indicators.error_count > 3) {
      triggers.push('error_occurrence');
    }

    if (context.frustration_indicators.time_per_action > 120) {
      triggers.push('slow_response');
    }

    // Detect accessibility needs
    if (context.accessibility_needs.screen_reader) {
      triggers.push('accessibility_need_detected');
    }

    // Detect user level patterns
    if (context.user_level === 'beginner' && context.time_spent_current_session > 300) {
      triggers.push('extended_session_beginner');
    }

    // Get relevant help content for triggers
    const relevantHelp = this.helpContents.filter(help => 
      help.context_triggers.some(trigger => triggers.includes(trigger))
    );

    // Offer proactive help
    if (relevantHelp.length > 0) {
      this.offerProactiveHelp(userId, relevantHelp[0]); // Offer most relevant help
    }
  }

  private offerProactiveHelp(userId: string, helpContent: HelpContent): void {
    // In a real implementation, this would show a notification or modal
    console.log(`Proactive help offered to user ${userId}: ${helpContent.title}`);
    
    // Record the help offer
    const interaction: HelpInteraction = {
      user_id: userId,
      help_id: helpContent.id,
      interaction_type: 'viewed',
      timestamp: Date.now(),
      context: this.activeSessions.get(userId) || {} as HelpContext,
      outcome: {
        problem_resolved: false,
        time_to_resolution: 0,
        subsequent_actions: []
      }
    };

    this.helpInteractions.push(interaction);
  }

  public getRelevantHelp(userId: string, context: HelpContext): HelpContent[] {
    const userLevel = context.user_level;
    
    return this.helpContents.filter(help => {
      // Filter by user level restriction
      if (help.user_level_restriction && help.user_level_restriction !== userLevel) {
        return false;
      }

      // Filter by context triggers (simplified for this example)
      const hasRelevantTrigger = help.context_triggers.length === 0 || 
        help.context_triggers.some(trigger => 
          context.current_screen.includes(trigger) ||
          context.current_action.includes(trigger)
        );

      return hasRelevantTrigger;
    }).sort((a, b) => {
      // Sort by priority
      const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 };
      return priorityOrder[b.priority] - priorityOrder[a.priority];
    });
  }

  public recordHelpInteraction(interaction: HelpInteraction): void {
    this.helpInteractions.push(interaction);
    this.updateHelpEffectiveness(interaction);
  }

  private updateHelpEffectiveness(interaction: HelpInteraction): void {
    const helpContent = this.helpContents.find(help => help.id === interaction.help_id);
    if (!helpContent) return;

    // Update effectiveness metrics based on feedback
    if (interaction.feedback) {
      const metrics = helpContent.effectiveness_metrics;
      
      // Update helpfulness score
      if (interaction.feedback.rating) {
        metrics.helpfulness_score = (metrics.helpfulness_score + interaction.feedback.rating) / 2;
      }

      // Update resolution rate
      if (interaction.outcome.problem_resolved) {
        metrics.resolution_rate = (metrics.resolution_rate + 1) / 2;
      } else {
        metrics.resolution_rate = metrics.resolution_rate / 2;
      }

      // Update average time to resolution
      if (interaction.outcome.time_to_resolution > 0) {
        metrics.average_time_to_resolution = 
          (metrics.average_time_to_resolution + interaction.outcome.time_to_resolution) / 2;
      }
    }
  }

  public getHelpAgent(userId: string, context: HelpContext): HelpAgent | null {
    // Select appropriate agent based on context and user needs
    if (context.accessibility_needs.screen_reader || 
        context.accessibility_needs.high_contrast || 
        context.accessibility_needs.simplified_ui) {
      return this.helpAgents.find(agent => agent.id === 'agent_accessibility_helper') || null;
    }

    if (context.user_level === 'advanced' || context.user_level === 'expert') {
      return this.helpAgents.find(agent => agent.id === 'agent_technical_expert') || null;
    }

    // Default to friendly guide
    return this.helpAgents.find(agent => agent.id === 'agent_friendly_guide') || null;
  }

  public generatePersonalizedHelpReport(userId: string): string {
    const userInteractions = this.helpInteractions.filter(interaction => 
      interaction.user_id === userId
    );

    const context = this.activeSessions.get(userId);
    if (!context) return 'No active session found';

    const report = `
# Relatório de Ajuda Personalizada

## Contexto Atual do Usuário
- **Nível do Usuário:** ${context.user_level}
- **Tela Atual:** ${context.current_screen}
- **Ação Atual:** ${context.current_action}
- **Tempo na Sessão:** ${context.time_spent_current_session} segundos
- **Frequência de Interação:** ${context.interaction_frequency} interações/minuto

## Indicadores de Frustração
- **Ações Repetidas:** ${context.frustration_indicators.repeated_actions}
- **Contagem de Erros:** ${context.frustration_indicators.error_count}
- **Solicitações de Ajuda:** ${context.frustration_indicators.help_requests}
- **Tempo por Ação:** ${context.frustration_indicators.time_per_action} segundos

## Necessidades de Acessibilidade
${Object.entries(context.accessibility_needs).map(([need, enabled]) => 
  `- **${need}:** ${enabled ? 'Sim' : 'Não'}`
).join('\n')}

## Histórico de Interações de Ajuda
- **Total de Interações:** ${userInteractions.length}
- **Taxa de Resolução:** ${this.calculateResolutionRate(userInteractions).toFixed(1)}%
- **Tempo Médio de Resolução:** ${this.calculateAverageResolutionTime(userInteractions).toFixed(0)} segundos
- **Avaliação Média:** ${this.calculateAverageRating(userInteractions).toFixed(1)}/5

## Conteúdo de Ajuda Mais Utilizado
${this.getMostUsedHelpContent(userInteractions).map(item => 
  `- **${item.title}:** ${item.count} vezes (avaliação: ${item.rating.toFixed(1)}/5)`
).join('\n')}

## Recomendações de Ajuda
${this.generateHelpRecommendations(context, userInteractions)}

## Agente de Ajuda Recomendado
${this.getRecommendedAgent(context)}

## Próximos Passos Sugeridos
${this.suggestNextSteps(context, userInteractions).map(step => `- ${step}`).join('\n')}
`;

    return report;
  }

  private calculateResolutionRate(interactions: HelpInteraction[]): number {
    if (interactions.length === 0) return 0;
    
    const resolved = interactions.filter(interaction => interaction.outcome.problem_resolved).length;
    return (resolved / interactions.length) * 100;
  }

  private calculateAverageResolutionTime(interactions: HelpInteraction[]): number {
    const resolvedInteractions = interactions.filter(interaction => 
      interaction.outcome.problem_resolved && interaction.outcome.time_to_resolution > 0
    );
    
    if (resolvedInteractions.length === 0) return 0;
    
    const totalTime = resolvedInteractions.reduce((sum, interaction) => 
      sum + interaction.outcome.time_to_resolution, 0
    );
    
    return totalTime / resolvedInteractions.length;
  }

  private calculateAverageRating(interactions: HelpInteraction[]): number {
    const ratedInteractions = interactions.filter(interaction => 
      interaction.feedback && interaction.feedback.rating
    );
    
    if (ratedInteractions.length === 0) return 0;
    
    const totalRating = ratedInteractions.reduce((sum, interaction) => 
      sum + (interaction.feedback?.rating || 0), 0
    );
    
    return totalRating / ratedInteractions.length;
  }

  private getMostUsedHelpContent(interactions: HelpInteraction[]): Array<{title: string, count: number, rating: number}> {
    const usageCount: { [helpId: string]: { count: number, rating: number } } = {};
    
    interactions.forEach(interaction => {
      if (!usageCount[interaction.help_id]) {
        usageCount[interaction.help_id] = { count: 0, rating: 0 };
      }
      usageCount[interaction.help_id].count++;
      
      if (interaction.feedback?.rating) {
        usageCount[interaction.help_id].rating += interaction.feedback.rating;
      }
    });

    return Object.entries(usageCount)
      .map(([helpId, data]) => {
        const helpContent = this.helpContents.find(help => help.id === helpId);
        return {
          title: helpContent?.title || helpId,
          count: data.count,
          rating: data.count > 0 ? data.rating / data.count : 0
        };
      })
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }

  private generateHelpRecommendations(context: HelpContext, interactions: HelpInteraction[]): string {
    const recommendations: string[] = [];

    // Based on frustration indicators
    if (context.frustration_indicators.error_count > 3) {
      recommendations.push('Considere revisar o conteúdo de resolução de erros.');
    }

    if (context.frustration_indicators.repeated_actions > 5) {
      recommendations.push('Pode ser útil explorar tutoriais sobre a funcionalidade atual.');
    }

    // Based on user level
    if (context.user_level === 'beginner') {
      recommendations.push('Continue com os tutoriais básicos para construir confiança.');
    } else if (context.user_level === 'expert') {
      recommendations.push('Explore a documentação técnica avançada e guias de contribuição.');
    }

    // Based on accessibility needs
    if (context.accessibility_needs.screen_reader) {
      recommendations.push('Utilize o assistente de acessibilidade para orientação especializada.');
    }

    return recommendations.join('\n');
  }

  private getRecommendedAgent(context: HelpContext): string {
    const agent = this.getHelpAgent('current', context);
    if (!agent) return 'Nenhum agente disponível';

    return `
- **Nome:** ${agent.name}
- **Personalidade:** ${agent.personality}
- **Áreas de Expertise:** ${agent.expertise_area.join(', ')}
- **Estilo de Comunicação:** ${agent.communication_style}
- **Disponibilidade:** ${agent.availability}
- **Capacidades:** ${Object.entries(agent.capabilities)
  .filter(([_, enabled]) => enabled)
  .map(([capability, _]) => capability)
  .join(', ')}
`;
  }

  private suggestNextSteps(context: HelpContext, interactions: HelpInteraction[]): string[] {
    const nextSteps: string[] = [];

    // Based on current context
    if (context.current_action === 'none') {
      nextSteps.push('Explore a navegação básica do sistema');
    }

    // Based on interaction history
    const recentHelp = interactions.slice(-3);
    if (recentHelp.length > 0) {
      const lastHelp = recentHelp[recentHelp.length - 1];
      const helpContent = this.helpContents.find(help => help.id === lastHelp.help_id);
      if (helpContent) {
        nextSteps.push(`Continue explorando: ${helpContent.related_help[0] || 'conteúdo relacionado'}`);
      }
    }

    // Based on user level progression
    if (context.user_level === 'beginner' && context.time_spent_current_session > 600) {
      nextSteps.push('Considere avançar para conteúdos intermediários');
    }

    return nextSteps;
  }

  public getAllHelpContents(): HelpContent[] {
    return [...this.helpContents];
  }

  public getAllHelpAgents(): HelpAgent[] {
    return [...this.helpAgents];
  }

  public getHelpInteractions(userId?: string): HelpInteraction[] {
    if (userId) {
      return this.helpInteractions.filter(interaction => interaction.user_id === userId);
    }
    return [...this.helpInteractions];
  }
}