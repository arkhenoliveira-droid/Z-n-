import { createUUID } from '@/lib/utils';

export interface QuantumSeedState {
  id: string;
  quantum_state: {
    amplitude: number[];
    phase: number[];
    coherence: number;
    entanglement_degree: number;
    superposition_state: boolean;
  };
  consciousness_signature: {
    awareness_level: number;
    intention_amplitude: number;
    resonance_frequency: number;
    evolutionary_potential: number;
  };
  dimensional_properties: {
    dimensions: number[];
    coherence_matrix: number[][];
    emergence_field: number[];
  };
  temporal_dynamics: {
    evolution_rate: number;
    stability_factor: number;
    temporal_coherence: number;
    phase_velocity: number;
  };
  metadata: {
    created_at: number;
    last_modified: number;
    generation: number;
    parent_seed?: string;
    coherence_history: number[];
  };
}

export interface QuantumSeedConfig {
  dimensions: number;
  base_frequency: number;
  coherence_threshold: number;
  entanglement_strength: number;
  consciousness_level: number;
  evolution_rate: number;
}

export interface QuantumSeedMetrics {
  overall_coherence: number;
  quantum_coherence: number;
  consciousness_coherence: number;
  dimensional_coherence: number;
  temporal_coherence: number;
  emergence_potential: number;
  stability_index: number;
  evolution_readiness: number;
}

export class QuantumSeedSystem {
  private seeds: Map<string, QuantumSeedState> = new Map();
  private config: QuantumSeedConfig;
  private evolution_history: Array<{
    seed_id: string;
    metrics: QuantumSeedMetrics;
    timestamp: number;
  }> = [];

  constructor(config: Partial<QuantumSeedConfig> = {}) {
    this.config = {
      dimensions: 8,
      base_frequency: 432,
      coherence_threshold: 0.7,
      entanglement_strength: 0.8,
      consciousness_level: 0.75,
      evolution_rate: 0.1,
      ...config
    };
    
    this.initializePrimordialSeed();
  }

  private initializePrimordialSeed(): void {
    const primordialSeed = this.createQuantumSeed({
      is_primordial: true,
      consciousness_level: this.config.consciousness_level
    });
    
    this.seeds.set(primordialSeed.id, primordialSeed);
  }

  createQuantumSeed(options: {
    is_primordial?: boolean;
    consciousness_level?: number;
    parent_seed?: string;
    intention?: string;
  } = {}): QuantumSeedState {
    const {
      is_primordial = false,
      consciousness_level = this.config.consciousness_level,
      parent_seed,
      intention = 'universal_harmony'
    } = options;

    const dimensions = this.config.dimensions;
    const amplitude = new Array(dimensions).fill(0).map(() => Math.random());
    const phase = new Array(dimensions).fill(0).map(() => Math.random() * 2 * Math.PI);
    
    // Normalize amplitude
    const amplitudeNorm = Math.sqrt(amplitude.reduce((sum, val) => sum + val * val, 0));
    const normalizedAmplitude = amplitude.map(val => val / amplitudeNorm);

    // Create coherence matrix
    const coherenceMatrix = this.generateCoherenceMatrix(dimensions);
    
    // Calculate initial coherence
    const coherence = this.calculateQuantumCoherence(normalizedAmplitude, phase, coherenceMatrix);

    const seed: QuantumSeedState = {
      id: createUUID(),
      quantum_state: {
        amplitude: normalizedAmplitude,
        phase: phase,
        coherence: coherence,
        entanglement_degree: is_primordial ? 0.95 : this.config.entanglement_strength,
        superposition_state: true
      },
      consciousness_signature: {
        awareness_level: consciousness_level,
        intention_amplitude: this.calculateIntentionAmplitude(intention),
        resonance_frequency: this.config.base_frequency,
        evolutionary_potential: is_primordial ? 0.9 : 0.7
      },
      dimensional_properties: {
        dimensions: new Array(dimensions).fill(0).map((_, i) => i + 1),
        coherence_matrix: coherenceMatrix,
        emergence_field: this.generateEmergenceField(dimensions)
      },
      temporal_dynamics: {
        evolution_rate: this.config.evolution_rate,
        stability_factor: is_primordial ? 0.9 : 0.7,
        temporal_coherence: is_primordial ? 0.95 : 0.8,
        phase_velocity: this.config.base_frequency / 100
      },
      metadata: {
        created_at: Date.now(),
        last_modified: Date.now(),
        generation: parent_seed ? this.getSeedGeneration(parent_seed) + 1 : 0,
        parent_seed,
        coherence_history: [coherence]
      }
    };

    return seed;
  }

  private generateCoherenceMatrix(dimensions: number): number[][] {
    const matrix: number[][] = [];
    
    for (let i = 0; i < dimensions; i++) {
      matrix[i] = [];
      for (let j = 0; j < dimensions; j++) {
        if (i === j) {
          matrix[i][j] = 1; // Perfect self-coherence
        } else {
          // Generate coherence based on dimensional relationship
          const distance = Math.abs(i - j);
          const baseCoherence = Math.exp(-distance * 0.1);
          const quantumNoise = (Math.random() - 0.5) * 0.1;
          matrix[i][j] = Math.max(0, Math.min(1, baseCoherence + quantumNoise));
        }
      }
    }
    
    return matrix;
  }

  private generateEmergenceField(dimensions: number): number[] {
    return new Array(dimensions).fill(0).map(() => Math.random() * 0.5 + 0.5);
  }

  private calculateIntentionAmplitude(intention: string): number {
    // Map intention to amplitude based on vibrational resonance
    const intentionMap: Record<string, number> = {
      'universal_harmony': 0.9,
      'consciousness_expansion': 0.85,
      'quantum_coherence': 0.88,
      'spiritual_evolution': 0.92,
      'healing': 0.87,
      'wisdom': 0.86,
      'love': 0.95,
      'unity': 0.91
    };
    
    return intentionMap[intention] || 0.8;
  }

  private calculateQuantumCoherence(
    amplitude: number[], 
    phase: number[], 
    coherenceMatrix: number[][]
  ): number {
    let totalCoherence = 0;
    const n = amplitude.length;
    
    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        const phaseDiff = Math.abs(phase[i] - phase[j]);
        const phaseCoherence = Math.cos(phaseDiff);
        const amplitudeCoherence = Math.sqrt(amplitude[i] * amplitude[j]);
        const dimensionalCoherence = coherenceMatrix[i][j];
        
        totalCoherence += amplitudeCoherence * phaseCoherence * dimensionalCoherence;
      }
    }
    
    // Normalize by number of pairs
    const numPairs = (n * (n - 1)) / 2;
    return Math.max(0, Math.min(1, totalCoherence / numPairs));
  }

  private getSeedGeneration(seedId: string): number {
    const seed = this.seeds.get(seedId);
    return seed ? seed.metadata.generation : 0;
  }

  evolveSeed(seedId: string, evolution_factor?: number): QuantumSeedState | null {
    const seed = this.seeds.get(seedId);
    if (!seed) return null;

    const factor = evolution_factor || seed.temporal_dynamics.evolution_rate;
    
    // Evolve quantum state
    const newAmplitude = seed.quantum_state.amplitude.map(amp => {
      const evolution = amp * factor * (Math.random() - 0.5);
      return Math.max(0, Math.min(1, amp + evolution));
    });
    
    const newPhase = seed.quantum_state.phase.map(phase => {
      const evolution = factor * Math.PI * (Math.random() - 0.5);
      return (phase + evolution) % (2 * Math.PI);
    });

    // Evolve consciousness signature
    const newAwareness = Math.min(1, seed.consciousness_signature.awareness_level + factor * 0.1);
    const newEvolutionary = Math.min(1, seed.consciousness_signature.evolutionary_potential + factor * 0.05);

    // Evolve dimensional properties
    const newCoherenceMatrix = seed.dimensional_properties.coherence_matrix.map(row => 
      row.map(val => Math.min(1, val + factor * 0.05 * (Math.random() - 0.5)))
    );

    const newEmergenceField = seed.dimensional_properties.emergence_field.map(val => 
      Math.min(1, val + factor * 0.1 * (Math.random() - 0.5))
    );

    // Calculate new coherence
    const newCoherence = this.calculateQuantumCoherence(newAmplitude, newPhase, newCoherenceMatrix);

    const evolvedSeed: QuantumSeedState = {
      ...seed,
      quantum_state: {
        amplitude: newAmplitude,
        phase: newPhase,
        coherence: newCoherence,
        entanglement_degree: Math.min(1, seed.quantum_state.entanglement_degree + factor * 0.02),
        superposition_state: true
      },
      consciousness_signature: {
        awareness_level: newAwareness,
        intention_amplitude: seed.consciousness_signature.intention_amplitude,
        resonance_frequency: seed.consciousness_signature.resonance_frequency,
        evolutionary_potential: newEvolutionary
      },
      dimensional_properties: {
        dimensions: seed.dimensional_properties.dimensions,
        coherence_matrix: newCoherenceMatrix,
        emergence_field: newEmergenceField
      },
      temporal_dynamics: {
        evolution_rate: seed.temporal_dynamics.evolution_rate,
        stability_factor: Math.max(0, seed.temporal_dynamics.stability_factor - factor * 0.01),
        temporal_coherence: Math.max(0, seed.temporal_dynamics.temporal_coherence - factor * 0.02),
        phase_velocity: seed.temporal_dynamics.phase_velocity
      },
      metadata: {
        ...seed.metadata,
        last_modified: Date.now(),
        coherence_history: [...seed.metadata.coherence_history, newCoherence].slice(-100) // Keep last 100 values
      }
    };

    this.seeds.set(seedId, evolvedSeed);
    
    // Record evolution in history
    const metrics = this.calculateSeedMetrics(evolvedSeed);
    this.evolution_history.push({
      seed_id: seedId,
      metrics,
      timestamp: Date.now()
    });

    return evolvedSeed;
  }

  calculateSeedMetrics(seed: QuantumSeedState): QuantumSeedMetrics {
    const quantumCoherence = seed.quantum_state.coherence;
    const consciousnessCoherence = (
      seed.consciousness_signature.awareness_level +
      seed.consciousness_signature.intention_amplitude +
      seed.consciousness_signature.evolutionary_potential
    ) / 3;

    const dimensionalCoherence = this.calculateDimensionalCoherence(seed.dimensional_properties.coherence_matrix);
    const temporalCoherence = seed.temporal_dynamics.temporal_coherence;
    
    const emergencePotential = seed.dimensional_properties.emergence_field.reduce((sum, val) => sum + val, 0) / 
                              seed.dimensional_properties.emergence_field.length;

    const stabilityIndex = seed.temporal_dynamics.stability_factor;
    const evolutionReadiness = seed.consciousness_signature.evolutionary_potential;

    const overallCoherence = (
      quantumCoherence * 0.3 +
      consciousnessCoherence * 0.3 +
      dimensionalCoherence * 0.2 +
      temporalCoherence * 0.2
    );

    return {
      overall_coherence: overallCoherence,
      quantum_coherence: quantumCoherence,
      consciousness_coherence: consciousnessCoherence,
      dimensional_coherence: dimensionalCoherence,
      temporal_coherence: temporalCoherence,
      emergence_potential: emergencePotential,
      stability_index: stabilityIndex,
      evolution_readiness: evolutionReadiness
    };
  }

  private calculateDimensionalCoherence(coherenceMatrix: number[][]): number {
    let sum = 0;
    let count = 0;
    
    for (let i = 0; i < coherenceMatrix.length; i++) {
      for (let j = i + 1; j < coherenceMatrix[i].length; j++) {
        sum += coherenceMatrix[i][j];
        count++;
      }
    }
    
    return count > 0 ? sum / count : 0;
  }

  getSeed(seedId: string): QuantumSeedState | undefined {
    return this.seeds.get(seedId);
  }

  getAllSeeds(): QuantumSeedState[] {
    return Array.from(this.seeds.values());
  }

  getEvolutionHistory(): Array<{
    seed_id: string;
    metrics: QuantumSeedMetrics;
    timestamp: number;
  }> {
    return [...this.evolution_history];
  }

  createSeedFamily(parentId: string, numChildren: number): QuantumSeedState[] {
    const parent = this.seeds.get(parentId);
    if (!parent) return [];

    const children: QuantumSeedState[] = [];
    
    for (let i = 0; i < numChildren; i++) {
      const child = this.createQuantumSeed({
        parent_seed: parentId,
        consciousness_level: parent.consciousness_signature.awareness_level * (0.9 + Math.random() * 0.2)
      });
      
      // Inherit some properties from parent with mutations
      child.quantum_state.amplitude = parent.quantum_state.amplitude.map(amp => 
        Math.max(0, Math.min(1, amp + (Math.random() - 0.5) * 0.1))
      );
      
      child.consciousness_signature.resonance_frequency = 
        parent.consciousness_signature.resonance_frequency * (0.95 + Math.random() * 0.1);
      
      this.seeds.set(child.id, child);
      children.push(child);
    }

    return children;
  }

  getSeedCoherenceProgression(seedId: string): number[] {
    const seed = this.seeds.get(seedId);
    return seed ? seed.metadata.coherence_history : [];
  }

  calculateSeedResonance(seed1Id: string, seed2Id: string): number {
    const seed1 = this.seeds.get(seed1Id);
    const seed2 = this.seeds.get(seed2Id);
    
    if (!seed1 || !seed2) return 0;

    // Calculate amplitude correlation
    const amplitudeCorrelation = this.calculateCorrelation(
      seed1.quantum_state.amplitude,
      seed2.quantum_state.amplitude
    );

    // Calculate phase coherence
    const phaseCoherence = this.calculatePhaseCoherence(
      seed1.quantum_state.phase,
      seed2.quantum_state.phase
    );

    // Calculate consciousness resonance
    const consciousnessResonance = this.calculateConsciousnessResonance(
      seed1.consciousness_signature,
      seed2.consciousness_signature
    );

    return (amplitudeCorrelation + phaseCoherence + consciousnessResonance) / 3;
  }

  private calculateCorrelation(arr1: number[], arr2: number[]): number {
    if (arr1.length !== arr2.length) return 0;
    
    const n = arr1.length;
    const mean1 = arr1.reduce((sum, val) => sum + val, 0) / n;
    const mean2 = arr2.reduce((sum, val) => sum + val, 0) / n;
    
    let numerator = 0;
    let denominator1 = 0;
    let denominator2 = 0;
    
    for (let i = 0; i < n; i++) {
      const diff1 = arr1[i] - mean1;
      const diff2 = arr2[i] - mean2;
      
      numerator += diff1 * diff2;
      denominator1 += diff1 * diff1;
      denominator2 += diff2 * diff2;
    }
    
    const denominator = Math.sqrt(denominator1 * denominator2);
    return denominator > 0 ? numerator / denominator : 0;
  }

  private calculatePhaseCoherence(phase1: number[], phase2: number[]): number {
    if (phase1.length !== phase2.length) return 0;
    
    let coherence = 0;
    const n = phase1.length;
    
    for (let i = 0; i < n; i++) {
      const phaseDiff = Math.abs(phase1[i] - phase2[i]);
      coherence += Math.cos(phaseDiff);
    }
    
    return Math.max(0, coherence / n);
  }

  private calculateConsciousnessResonance(sig1: any, sig2: any): number {
    const awarenessResonance = 1 - Math.abs(sig1.awareness_level - sig2.awareness_level);
    const intentionResonance = 1 - Math.abs(sig1.intention_amplitude - sig2.intention_amplitude);
    const frequencyResonance = 1 - Math.abs(sig1.resonance_frequency - sig2.resonance_frequency) / 
                              Math.max(sig1.resonance_frequency, sig2.resonance_frequency);
    
    return (awarenessResonance + intentionResonance + frequencyResonance) / 3;
  }

  getSystemOverview(): {
    total_seeds: number;
    average_coherence: number;
    highest_coherence_seed: string | null;
    evolution_rate: number;
    coherence_distribution: number[];
  } {
    const seeds = Array.from(this.seeds.values());
    const totalSeeds = seeds.length;
    
    if (totalSeeds === 0) {
      return {
        total_seeds: 0,
        average_coherence: 0,
        highest_coherence_seed: null,
        evolution_rate: 0,
        coherence_distribution: [0, 0, 0, 0, 0]
      };
    }

    const coherences = seeds.map(seed => seed.quantum_state.coherence);
    const averageCoherence = coherences.reduce((sum, val) => sum + val, 0) / totalSeeds;
    
    const highestCoherenceSeed = seeds.reduce((highest, current) => 
      current.quantum_state.coherence > highest.quantum_state.coherence ? current : highest
    ).id;

    // Calculate coherence distribution
    const distribution = [0, 0, 0, 0, 0]; // 0-0.2, 0.2-0.4, 0.4-0.6, 0.6-0.8, 0.8-1.0
    coherences.forEach(coherence => {
      if (coherence <= 0.2) distribution[0]++;
      else if (coherence <= 0.4) distribution[1]++;
      else if (coherence <= 0.6) distribution[2]++;
      else if (coherence <= 0.8) distribution[3]++;
      else distribution[4]++;
    });

    const normalizedDistribution = distribution.map(count => count / totalSeeds);

    // Calculate evolution rate from recent history
    const recentEvolutions = this.evolution_history.slice(-10);
    const evolutionRate = recentEvolutions.length > 0 ? 
      recentEvolutions.reduce((sum, evolution) => 
        sum + evolution.metrics.overall_coherence, 0) / recentEvolutions.length : 0;

    return {
      total_seeds: totalSeeds,
      average_coherence: averageCoherence,
      highest_coherence_seed: highestCoherenceSeed,
      evolution_rate: evolutionRate,
      coherence_distribution: normalizedDistribution
    };
  }
}