/**
 * Coherent API Type Definitions
 * 
 * This file provides type definitions that ensure consistency across
 * API endpoints, database models, and client-side data structures.
 */

import { 
  ID, 
  UUID, 
  Email, 
  URL, 
  Timestamp, 
  Result, 
  AsyncResult, 
  ApiResponse, 
  PaginatedResponse, 
  PaginationParams,
  DatabaseEntity,
  CreatableEntity,
  UpdatableEntity
} from './utils';

// User Types
export interface User extends DatabaseEntity {
  email: Email;
  name: string;
  avatar?: URL;
  role: UserRole;
  isActive: boolean;
  lastLoginAt?: Timestamp;
}

export type UserRole = 'admin' | 'user' | 'moderator';

export type CreateUserRequest = CreatableEntity<User> & {
  password: string;
};

export type UpdateUserRequest = UpdatableEntity<User> & {
  password?: string;
};

export type UserResponse = Omit<User, 'password'>;

// Authentication Types
export interface LoginRequest {
  email: Email;
  password: string;
}

export interface LoginResponse {
  user: UserResponse;
  token: string;
  refreshToken: string;
  expiresAt: Timestamp;
}

export interface RefreshTokenRequest {
  refreshToken: string;
}

export interface RegisterRequest {
  email: Email;
  password: string;
  name: string;
}

// API Endpoint Types
export interface APIEndpoint<TRequest, TResponse> {
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  requestSchema?: TRequest;
  responseSchema: TResponse;
  authRequired?: boolean;
  rateLimit?: {
    requests: number;
    windowMs: number;
  };
}

// API Client Types
export interface APIClient {
  get<T>(endpoint: string, params?: Record<string, any>): Promise<ApiResponse<T>>;
  post<T>(endpoint: string, data: any): Promise<ApiResponse<T>>;
  put<T>(endpoint: string, data: any): Promise<ApiResponse<T>>;
  delete<T>(endpoint: string): Promise<ApiResponse<T>>;
  patch<T>(endpoint: string, data: any): Promise<ApiResponse<T>>;
}

// WebSocket Types
export interface WebSocketMessage<T = any> {
  type: string;
  payload: T;
  timestamp: Timestamp;
  id: UUID;
}

export interface WebSocketEventMap {
  'user:connected': { userId: ID };
  'user:disconnected': { userId: ID };
  'message:received': { messageId: ID; content: string };
  'notification:received': { notificationId: ID; title: string; body: string };
}

// File Upload Types
export interface FileUpload {
  id: ID;
  name: string;
  size: number;
  type: string;
  url: URL;
  uploadedAt: Timestamp;
  uploadedBy: ID;
}

export interface FileUploadRequest {
  file: File;
  folder?: string;
  metadata?: Record<string, any>;
}

// Search Types
export interface SearchQuery {
  query: string;
  filters?: Record<string, any>;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
}

export interface SearchResult<T> {
  items: T[];
  total: number;
  query: string;
  filters: Record<string, any>;
  took: number;
}

// Notification Types
export interface Notification extends DatabaseEntity {
  userId: ID;
  type: NotificationType;
  title: string;
  body: string;
  isRead: boolean;
  data?: Record<string, any>;
  expiresAt?: Timestamp;
}

export type NotificationType = 
  | 'info'
  | 'success'
  | 'warning'
  | 'error'
  | 'system';

export interface MarkNotificationReadRequest {
  notificationIds: ID[];
}

// Settings Types
export interface UserSettings extends DatabaseEntity {
  userId: ID;
  theme: 'light' | 'dark' | 'system';
  language: string;
  timezone: string;
  notifications: {
    email: boolean;
    push: boolean;
    sms: boolean;
  };
  privacy: {
    profileVisible: boolean;
    showEmail: boolean;
    allowMessages: boolean;
  };
}

export interface UpdateUserSettingsRequest {
  theme?: 'light' | 'dark' | 'system';
  language?: string;
  timezone?: string;
  notifications?: Partial<UserSettings['notifications']>;
  privacy?: Partial<UserSettings['privacy']>;
}

// Audit Log Types
export interface AuditLog extends DatabaseEntity {
  userId?: ID;
  action: string;
  resource: string;
  resourceId: ID;
  details: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
}

// Health Check Types
export interface HealthCheck {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: Timestamp;
  version: string;
  checks: {
    database: HealthStatus;
    redis?: HealthStatus;
    externalServices: Record<string, HealthStatus>;
  };
}

export interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  message?: string;
  responseTime?: number;
}

// Rate Limiting Types
export interface RateLimitInfo {
  limit: number;
  remaining: number;
  reset: Timestamp;
  windowMs: number;
}

// API Error Types
export interface APIError {
  code: string;
  message: string;
  details?: Record<string, any>;
  stack?: string;
}

export const API_ERROR_CODES = {
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  AUTHENTICATION_ERROR: 'AUTHENTICATION_ERROR',
  AUTHORIZATION_ERROR: 'AUTHORIZATION_ERROR',
  NOT_FOUND: 'NOT_FOUND',
  CONFLICT: 'CONFLICT',
  RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED',
  INTERNAL_SERVER_ERROR: 'INTERNAL_SERVER_ERROR',
  SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',
} as const;

// Type-safe API route handlers
export type APIRouteHandler<TRequest = any, TResponse = any> = (
  request: Request & { json: () => Promise<TRequest> },
  context?: { params: Record<string, string> }
) => Promise<ApiResponse<TResponse>>;

// API Middleware Types
export interface APIMiddleware {
  name: string;
  handler: (
    request: Request,
    response: Response,
    next: () => Promise<void>
  ) => Promise<void>;
}

// API Documentation Types
export interface APIDocumentation {
  title: string;
  version: string;
  description: string;
  endpoints: APIEndpoint<any, any>[];
  schemas: Record<string, any>;
  servers: {
    url: string;
    description: string;
  }[];
}

// API Versioning Types
export type APIVersion = 'v1' | 'v2' | 'v3';

export interface VersionedAPIResponse<T> {
  data: T;
  version: APIVersion;
  deprecated?: boolean;
  sunsetDate?: Timestamp;
}

// Webhook Types
export interface Webhook extends DatabaseEntity {
  userId: ID;
  url: URL;
  events: string[];
  secret: string;
  isActive: boolean;
  lastTriggeredAt?: Timestamp;
}

export interface WebhookPayload<T = any> {
  event: string;
  data: T;
  timestamp: Timestamp;
  webhookId: ID;
  signature: string;
}

// Batch Operation Types
export interface BatchOperation<T> {
  operation: 'create' | 'update' | 'delete';
  data: T;
}

export interface BatchResponse<T> {
  successful: T[];
  failed: {
    data: T;
    error: APIError;
  }[];
  totalProcessed: number;
}