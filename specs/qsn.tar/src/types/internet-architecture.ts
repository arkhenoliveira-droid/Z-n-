// Internet Architecture Framework - Core Types and Interfaces
// This framework defines the fundamental building blocks for rebuilding the Internet

import { ID, Timestamp, Result, Option } from './utils';

// Core Internet Protocol Types
export interface IPAddress {
  value: string;
  version: 'IPv4' | 'IPv6';
  isPrivate: boolean;
  isLoopback: boolean;
  subnet: string;
}

export interface MACAddress {
  value: string;
  manufacturer: string;
  isMulticast: boolean;
}

export interface Port {
  number: number;
  protocol: 'TCP' | 'UDP' | 'SCTP';
  service?: string;
  isOpen: boolean;
}

// Network Entity Types
export interface NetworkNode {
  id: ID;
  name: string;
  ipAddress: IPAddress;
  macAddress?: MACAddress;
  ports: Port[];
  type: 'router' | 'switch' | 'host' | 'server' | 'firewall' | 'load-balancer';
  status: 'online' | 'offline' | 'degraded' | 'maintenance';
  location: {
    latitude: number;
    longitude: number;
    region: string;
    country: string;
  };
  capabilities: string[];
  resources: {
    cpu: number;
    memory: number;
    storage: number;
    bandwidth: number;
  };
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface NetworkLink {
  id: ID;
  sourceNode: ID;
  targetNode: ID;
  bandwidth: number; // in Mbps
  latency: number; // in ms
  reliability: number; // 0-1
  encryption: 'none' | 'TLS' | 'SSL' | 'IPsec' | 'VPN';
  protocol: 'Ethernet' | 'Fiber' | 'Wireless' | 'Satellite';
  status: 'active' | 'inactive' | 'congested' | 'failed';
  createdAt: Timestamp;
}

// Network Topology Types
export interface NetworkTopology {
  id: ID;
  name: string;
  description: string;
  type: 'mesh' | 'star' | 'ring' | 'tree' | 'hybrid' | 'full-mesh';
  nodes: NetworkNode[];
  links: NetworkLink[];
  routingTable: RoutingTable;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface RoutingTable {
  id: ID;
  entries: RouteEntry[];
  lastUpdated: Timestamp;
  version: number;
}

export interface RouteEntry {
  destination: IPAddress;
  subnetMask: string;
  gateway: IPAddress;
  interface: string;
  metric: number;
  type: 'static' | 'dynamic' | 'default';
  protocol?: 'RIP' | 'OSPF' | 'BGP' | 'EIGRP';
}

// Protocol Stack Types
export interface ProtocolLayer {
  name: string;
  layer: number; // 1-7 OSI model
  protocols: Protocol[];
  responsibilities: string[];
}

export interface Protocol {
  name: string;
  version: string;
  port?: number;
  isSecure: boolean;
  specifications: string;
  implementation: ProtocolImplementation;
}

export interface ProtocolImplementation {
  code: string;
  complexity: 'simple' | 'medium' | 'complex';
  performance: {
    throughput: number;
    latency: number;
    reliability: number;
  };
  security: {
    encryption: boolean;
    authentication: boolean;
    integrity: boolean;
  };
}

// Internet Services Types
export interface InternetService {
  id: ID;
  name: string;
  type: 'web' | 'email' | 'dns' | 'cdn' | 'streaming' | 'cloud' | 'blockchain';
  provider: string;
  endpoints: ServiceEndpoint[];
  protocol: string;
  sla: ServiceLevelAgreement;
  status: 'operational' | 'degraded' | 'outage' | 'maintenance';
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface ServiceEndpoint {
  id: ID;
  url: string;
  ipAddress: IPAddress;
  port: Port;
  health: 'healthy' | 'warning' | 'critical';
  responseTime: number;
  uptime: number;
}

export interface ServiceLevelAgreement {
  uptime: number; // percentage
  responseTime: number; // in ms
  throughput: number; // in Mbps
  availability: number; // percentage
  penalties: SLAPenalty[];
}

export interface SLAPenalty {
  condition: string;
  penalty: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

// Security Framework Types
export interface SecurityPolicy {
  id: ID;
  name: string;
  description: string;
  rules: SecurityRule[];
  scope: 'network' | 'service' | 'application' | 'global';
  priority: number;
  isActive: boolean;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface SecurityRule {
  id: ID;
  name: string;
  action: 'allow' | 'deny' | 'log' | 'encrypt' | 'decrypt';
  conditions: RuleCondition[];
  priority: number;
  isLogging: boolean;
}

export interface RuleCondition {
  field: 'source-ip' | 'destination-ip' | 'port' | 'protocol' | 'payload' | 'header';
  operator: 'equals' | 'contains' | 'starts-with' | 'ends-with' | 'regex' | 'range';
  value: string;
}

export interface EncryptionFramework {
  algorithms: EncryptionAlgorithm[];
  keyManagement: KeyManagement;
  certificates: Certificate[];
  policies: SecurityPolicy[];
}

export interface EncryptionAlgorithm {
  name: string;
  type: 'symmetric' | 'asymmetric' | 'hash';
  keySize: number;
  strength: number; // bits
  useCase: string;
  isStandard: boolean;
}

export interface KeyManagement {
  rotationInterval: number; // in days
  keyLength: number;
  algorithm: string;
  distribution: 'centralized' | 'distributed' | 'hybrid';
}

export interface Certificate {
  id: ID;
  domain: string;
  issuer: string;
  validFrom: Timestamp;
  validTo: Timestamp;
  fingerprint: string;
  type: 'SSL' | 'TLS' | 'Code Signing' | 'Email';
  status: 'valid' | 'expired' | 'revoked';
}

// Data Flow and Traffic Types
export interface DataPacket {
  id: ID;
  source: IPAddress;
  destination: IPAddress;
  protocol: string;
  payload: string;
  size: number;
  ttl: number;
  flags: string[];
  headers: PacketHeader[];
  timestamp: Timestamp;
}

export interface PacketHeader {
  name: string;
  value: string;
  isEncrypted: boolean;
}

export interface TrafficFlow {
  id: ID;
  source: IPAddress;
  destination: IPAddress;
  protocol: string;
  packets: DataPacket[];
  bandwidth: number;
  latency: number;
  jitter: number;
  packetLoss: number;
  startTime: Timestamp;
  endTime: Timestamp;
}

// Internet Infrastructure Types
export interface InternetInfrastructure {
  id: ID;
  name: string;
  version: string;
  topologies: NetworkTopology[];
  services: InternetService[];
  security: EncryptionFramework;
  monitoring: MonitoringSystem;
  governance: GovernanceFramework;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface MonitoringSystem {
  id: ID;
  metrics: Metric[];
  alerts: Alert[];
  dashboards: Dashboard[];
  retentionPeriod: number; // in days
}

export interface Metric {
  id: ID;
  name: string;
  type: 'counter' | 'gauge' | 'histogram' | 'summary';
  description: string;
  unit: string;
  tags: Record<string, string>;
  collectionInterval: number; // in seconds
}

export interface Alert {
  id: ID;
  name: string;
  condition: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  channels: NotificationChannel[];
  isActive: boolean;
  createdAt: Timestamp;
}

export interface NotificationChannel {
  id: ID;
  type: 'email' | 'sms' | 'webhook' | 'slack' | 'pagerduty';
  destination: string;
  isActive: boolean;
}

export interface Dashboard {
  id: ID;
  name: string;
  widgets: Widget[];
  layout: DashboardLayout;
  refreshInterval: number; // in seconds
  isPublic: boolean;
}

export interface Widget {
  id: ID;
  type: 'chart' | 'table' | 'metric' | 'map' | 'log';
  title: string;
  dataSource: string;
  config: Record<string, any>;
}

export interface DashboardLayout {
  columns: number;
  rows: number;
  widgets: LayoutItem[];
}

export interface LayoutItem {
  widgetId: ID;
  x: number;
  y: number;
  width: number;
  height: number;
}

// Governance Framework Types
export interface GovernanceFramework {
  id: ID;
  name: string;
  policies: GovernancePolicy[];
  compliance: ComplianceFramework;
  audit: AuditSystem;
  standards: Standard[];
}

export interface GovernancePolicy {
  id: ID;
  name: string;
  description: string;
  category: 'security' | 'privacy' | 'accessibility' | 'performance' | 'reliability';
  requirements: PolicyRequirement[];
  enforcement: 'mandatory' | 'recommended' | 'optional';
  isActive: boolean;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface PolicyRequirement {
  id: ID;
  title: string;
  description: string;
  criteria: string[];
  validation: ValidationRule[];
  penalty: string;
}

export interface ValidationRule {
  field: string;
  condition: string;
  expected: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export interface ComplianceFramework {
  id: ID;
  standards: ComplianceStandard[];
  assessments: ComplianceAssessment[];
  reports: ComplianceReport[];
}

export interface ComplianceStandard {
  id: ID;
  name: string;
  version: string;
  authority: string;
  requirements: string[];
  lastUpdated: Timestamp;
}

export interface ComplianceAssessment {
  id: ID;
  standardId: ID;
  score: number;
  findings: ComplianceFinding[];
  assessor: string;
  date: Timestamp;
}

export interface ComplianceFinding {
  id: ID;
  requirement: string;
  status: 'compliant' | 'non-compliant' | 'partial' | 'not-assessed';
  evidence: string;
  recommendation: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export interface ComplianceReport {
  id: ID;
  title: string;
  period: {
    start: Timestamp;
    end: Timestamp;
  };
  summary: string;
  findings: ComplianceFinding[];
  recommendations: string[];
  generatedAt: Timestamp;
}

export interface AuditSystem {
  id: ID;
  logs: AuditLog[];
  trails: AuditTrail[];
  retentionPeriod: number; // in days
  isRealTime: boolean;
}

export interface AuditLog {
  id: ID;
  timestamp: Timestamp;
  userId: ID;
  action: string;
  resource: string;
  result: 'success' | 'failure' | 'error';
  details: Record<string, any>;
  ipAddress: IPAddress;
}

export interface AuditTrail {
  id: ID;
  sessionId: ID;
  userId: ID;
  startTime: Timestamp;
  endTime: Timestamp;
  actions: AuditLog[];
  ipAddress: IPAddress;
}

export interface Standard {
  id: ID;
  name: string;
  description: string;
  category: 'technical' | 'operational' | 'security' | 'privacy' | 'accessibility';
  version: string;
  authority: string;
  requirements: string[];
  isMandatory: boolean;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}