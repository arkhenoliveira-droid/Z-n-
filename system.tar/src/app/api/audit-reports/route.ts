import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const type = searchParams.get('type');
    const period = searchParams.get('period');
    const status = searchParams.get('status');

    const skip = (page - 1) * limit;

    const where: any = {};
    if (type) where.type = type;
    if (period) where.period = period;
    if (status) where.status = status;

    const [reports, total] = await Promise.all([
      db.auditReport.findMany({
        where,
        include: {
          walletTests: {
            include: {
              wallet: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      db.auditReport.count({ where })
    ]);

    return NextResponse.json({
      reports,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Error fetching audit reports:', error);
    return NextResponse.json(
      { error: 'Failed to fetch audit reports' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      title,
      description,
      type,
      period,
      summary,
      findings,
      recommendations,
      score,
      confidence,
      metadata,
      createdBy
    } = body;

    // Validate required fields
    if (!title || !type || !period || !createdBy) {
      return NextResponse.json(
        { error: 'Title, type, period, and createdBy are required' },
        { status: 400 }
      );
    }

    const report = await db.auditReport.create({
      data: {
        title,
        description,
        type,
        period,
        summary,
        findings: findings ? JSON.stringify(findings) : null,
        recommendations: recommendations ? JSON.stringify(recommendations) : null,
        score,
        confidence,
        metadata: metadata ? JSON.stringify(metadata) : null,
        createdBy,
        status: 'draft'
      },
      include: {
        walletTests: {
          include: {
            wallet: true
          }
        }
      }
    });

    return NextResponse.json(report, { status: 201 });
  } catch (error) {
    console.error('Error creating audit report:', error);
    return NextResponse.json(
      { error: 'Failed to create audit report' },
      { status: 500 }
    );
  }
}