import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const minCoherence = searchParams.get('minCoherence');

    const where: any = {};
    if (type) where.patternType = type;
    if (minCoherence) where.coherence = { gte: parseFloat(minCoherence) };

    const patterns = await db.realityPattern.findMany({
      where,
      orderBy: { discoveredAt: 'desc' },
    });

    // Parse metadata JSON
    const parsedPatterns = patterns.map(pattern => ({
      ...pattern,
      metadata: pattern.metadata ? JSON.parse(pattern.metadata) : null,
    }));

    return NextResponse.json(parsedPatterns);
  } catch (error) {
    console.error('Error fetching reality patterns:', error);
    return NextResponse.json(
      { error: 'Failed to fetch reality patterns' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, description, patternType, frequency, amplitude, phase, coherence, stability, metadata } = body;

    if (!name || !patternType) {
      return NextResponse.json(
        { error: 'Name and pattern type are required' },
        { status: 400 }
      );
    }

    const pattern = await db.realityPattern.create({
      data: {
        name,
        description,
        patternType,
        frequency,
        amplitude,
        phase,
        coherence,
        stability,
        metadata: JSON.stringify(metadata || {}),
      },
    });

    // Parse metadata for response
    const parsedPattern = {
      ...pattern,
      metadata: pattern.metadata ? JSON.parse(pattern.metadata) : null,
    };

    return NextResponse.json(parsedPattern);
  } catch (error) {
    console.error('Error creating reality pattern:', error);
    return NextResponse.json(
      { error: 'Failed to create reality pattern' },
      { status: 500 }
    );
  }
}