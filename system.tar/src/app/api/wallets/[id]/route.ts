import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const wallet = await db.wallet.findUnique({
      where: { id: params.id },
      include: {
        auditTests: {
          orderBy: { createdAt: 'desc' }
        },
        ownershipClaims: {
          orderBy: { createdAt: 'desc' }
        },
        transactions: {
          orderBy: { timestamp: 'desc' },
          take: 50
        }
      }
    });

    if (!wallet) {
      return NextResponse.json(
        { error: 'Wallet not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(wallet);
  } catch (error) {
    console.error('Error fetching wallet:', error);
    return NextResponse.json(
      { error: 'Failed to fetch wallet' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const {
      name,
      description,
      owner,
      balance,
      status,
      riskLevel,
      metadata
    } = body;

    const wallet = await db.wallet.update({
      where: { id: params.id },
      data: {
        ...(name && { name }),
        ...(description !== undefined && { description }),
        ...(owner !== undefined && { owner }),
        ...(balance !== undefined && { balance }),
        ...(status && { status }),
        ...(riskLevel && { riskLevel }),
        ...(metadata !== undefined && { metadata: metadata ? JSON.stringify(metadata) : null })
      },
      include: {
        auditTests: true,
        ownershipClaims: true,
        transactions: true
      }
    });

    return NextResponse.json(wallet);
  } catch (error) {
    console.error('Error updating wallet:', error);
    return NextResponse.json(
      { error: 'Failed to update wallet' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.wallet.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ message: 'Wallet deleted successfully' });
  } catch (error) {
    console.error('Error deleting wallet:', error);
    return NextResponse.json(
      { error: 'Failed to delete wallet' },
      { status: 500 }
    );
  }
}