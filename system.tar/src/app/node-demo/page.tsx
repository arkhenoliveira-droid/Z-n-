'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Server, 
  Network, 
  Activity, 
  Users, 
  MapPin, 
  Clock, 
  Shield,
  Cpu,
  HardDrive,
  Wifi,
  Zap,
  CheckCircle,
  AlertCircle,
  Info
} from 'lucide-react';

import { NodeManager, NodeInfo, NodeReport } from '@/utils/node-manager';

export default function NodeDemoPage() {
  const [nodeManager] = useState(() => new NodeManager());
  const [nodeIdentifier] = useState('g071p7fca930("476a3890-d602-4e71-ac25-9f6fee5933c9")');
  const [nodeInfo, setNodeInfo] = useState<NodeInfo | null>(null);
  const [nodeReport, setNodeReport] = useState<NodeReport | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Initialize the node when component mounts
    initializeNode();
  }, []);

  const initializeNode = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Register the node
      const registerResult = nodeManager.registerNode(nodeIdentifier, {
        name: 'Global P2P Node',
        type: 'server',
        capabilities: ['routing', 'computing', 'storage'],
        state: 'idle',
        resources: {
          cpu: 85,
          memory: 16384,
          storage: 1000000,
          bandwidth: 10000,
          reputation: 95
        }
      });

      if (!registerResult.success) {
        throw new Error(registerResult.error.message);
      }

      setNodeInfo(registerResult.data);

      // Generate initial report
      const reportResult = nodeManager.generateNodeReport(nodeIdentifier);
      if (reportResult.success) {
        setNodeReport(reportResult.data);
      }

      // Simulate some connections and activity
      await simulateNetworkActivity();

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to initialize node');
    } finally {
      setIsLoading(false);
    }
  };

  const simulateNetworkActivity = async () => {
    // Simulate some network connections
    const mockNodes = [
      'a1b2c3d4("12345678-1234-1234-1234-123456789012")',
      'e5f6g7h8("87654321-4321-4321-4321-210987654321")',
      'i9j0k1l2("11111111-2222-3333-4444-555555555555")'
    ];

    for (const mockNode of mockNodes) {
      // Register mock nodes
      const mockResult = nodeManager.registerNode(mockNode, {
        name: `Peer Node ${mockNodes.indexOf(mockNode) + 1}`,
        type: 'host',
        capabilities: ['routing'],
        state: 'idle'
      });

      if (mockResult.success) {
        // Add connection
        nodeManager.addConnection(nodeIdentifier, mockNode);
      }
    }

    // Update metrics
    nodeManager.updateNodeMetrics(nodeIdentifier, {
      cpuUsage: Math.random() * 30 + 20,
      memoryUsage: Math.random() * 40 + 30,
      storageUsage: Math.random() * 20 + 10,
      bandwidthUsage: Math.random() * 50 + 20,
      uptime: 86400000, // 24 hours
      requestCount: Math.floor(Math.random() * 50000) + 10000,
      errorRate: Math.random() * 2,
      reputation: Math.random() * 20 + 80
    });

    // Refresh report
    const reportResult = nodeManager.generateNodeReport(nodeIdentifier);
    if (reportResult.success) {
      setNodeReport(reportResult.data);
    }
  };

  const refreshNode = async () => {
    setIsLoading(true);
    try {
      // Update metrics
      nodeManager.updateNodeMetrics(nodeIdentifier, {
        cpuUsage: Math.random() * 30 + 20,
        memoryUsage: Math.random() * 40 + 30,
        storageUsage: Math.random() * 20 + 10,
        bandwidthUsage: Math.random() * 50 + 20,
        requestCount: (nodeInfo?.metrics.requestCount || 0) + Math.floor(Math.random() * 100),
        errorRate: Math.random() * 2,
        reputation: Math.random() * 20 + 80
      });

      // Refresh node info and report
      const infoResult = nodeManager.getNodeInfo(nodeIdentifier);
      if (infoResult.success) {
        setNodeInfo(infoResult.data);
      }

      const reportResult = nodeManager.generateNodeReport(nodeIdentifier);
      if (reportResult.success) {
        setNodeReport(reportResult.data);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to refresh node');
    } finally {
      setIsLoading(false);
    }
  };

  const getHealthColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getHealthIcon = (score: number) => {
    if (score >= 90) return <CheckCircle className="h-4 w-4 text-green-600" />;
    if (score >= 70) return <AlertCircle className="h-4 w-4 text-yellow-600" />;
    return <AlertCircle className="h-4 w-4 text-red-600" />;
  };

  if (isLoading && !nodeInfo) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <Server className="h-12 w-12 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-lg font-medium">Initializing Node...</p>
        </div>
      </div>
    );
  }

  if (error && !nodeInfo) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="max-w-md">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
          <Button onClick={initializeNode} className="mt-4 w-full">
            Retry Initialization
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-3xl font-bold text-slate-900 flex items-center justify-center gap-3">
            <Server className="h-8 w-8 text-blue-600" />
            Node Management Demo
          </h1>
          <p className="text-lg text-slate-600">
            Managing node: <code className="bg-slate-200 px-2 py-1 rounded text-sm">{nodeIdentifier}</code>
          </p>
        </div>

        {/* Node Overview */}
        {nodeInfo && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Server className="h-4 w-4" />
                  Node Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  {nodeInfo.status === 'active' ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-red-600" />
                  )}
                  <Badge variant={nodeInfo.status === 'active' ? 'default' : 'destructive'}>
                    {nodeInfo.status}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  Health Score
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  {nodeReport && getHealthIcon(nodeReport.healthScore)}
                  <span className={`text-xl font-bold ${nodeReport ? getHealthColor(nodeReport.healthScore) : 'text-slate-600'}`}>
                    {nodeReport ? `${nodeReport.healthScore}%` : 'N/A'}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Connections
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <Network className="h-4 w-4 text-blue-600" />
                  <span className="text-xl font-bold text-slate-900">
                    {nodeInfo.connections.length}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Uptime
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-sm font-medium">
                  {nodeInfo.metrics.uptime > 86400000 
                    ? `${Math.floor(nodeInfo.metrics.uptime / 86400000)}d`
                    : `${Math.floor(nodeInfo.metrics.uptime / 3600000)}h`
                  }
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="metrics">Metrics</TabsTrigger>
            <TabsTrigger value="network">Network</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {nodeInfo && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Server className="h-5 w-5 text-blue-600" />
                      Node Information
                    </CardTitle>
                    <CardDescription>
                      Basic node details and configuration
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <label className="font-medium text-slate-600">Name</label>
                        <div className="font-medium">{nodeInfo.node.name}</div>
                      </div>
                      <div>
                        <label className="font-medium text-slate-600">Type</label>
                        <div className="font-medium capitalize">{nodeInfo.node.type}</div>
                      </div>
                      <div>
                        <label className="font-medium text-slate-600">IP Address</label>
                        <div className="font-medium">{nodeInfo.node.ipAddress.value}</div>
                      </div>
                      <div>
                        <label className="font-medium text-slate-600">State</label>
                        <div className="font-medium capitalize">{nodeInfo.node.state}</div>
                      </div>
                    </div>

                    <div>
                      <label className="font-medium text-slate-600 mb-2 block">Location</label>
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-4 w-4" />
                        <span>{nodeInfo.node.location.region}, {nodeInfo.node.location.country}</span>
                      </div>
                    </div>

                    <div>
                      <label className="font-medium text-slate-600 mb-2 block">Capabilities</label>
                      <div className="flex flex-wrap gap-2">
                        {nodeInfo.node.capabilities.map((capability, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {capability}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="font-medium text-slate-600 mb-2 block">Open Ports</label>
                      <div className="space-y-1">
                        {nodeInfo.node.ports.map((port, index) => (
                          <div key={index} className="flex items-center gap-2 text-sm">
                            <div className={`w-2 h-2 rounded-full ${port.isOpen ? 'bg-green-500' : 'bg-red-500'}`} />
                            <span>{port.port} ({port.protocol}) - {port.service}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Activity className="h-5 w-5 text-green-600" />
                      Resource Usage
                    </CardTitle>
                    <CardDescription>
                      Current resource utilization metrics
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium flex items-center gap-2">
                            <Cpu className="h-4 w-4" />
                            CPU Usage
                          </span>
                          <span className="text-sm text-slate-600">
                            {nodeInfo.metrics.cpuUsage.toFixed(1)}%
                          </span>
                        </div>
                        <Progress value={nodeInfo.metrics.cpuUsage} className="h-2" />
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium flex items-center gap-2">
                            <HardDrive className="h-4 w-4" />
                            Memory Usage
                          </span>
                          <span className="text-sm text-slate-600">
                            {nodeInfo.metrics.memoryUsage.toFixed(1)}%
                          </span>
                        </div>
                        <Progress value={nodeInfo.metrics.memoryUsage} className="h-2" />
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium flex items-center gap-2">
                            <HardDrive className="h-4 w-4" />
                            Storage Usage
                          </span>
                          <span className="text-sm text-slate-600">
                            {nodeInfo.metrics.storageUsage.toFixed(1)}%
                          </span>
                        </div>
                        <Progress value={nodeInfo.metrics.storageUsage} className="h-2" />
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium flex items-center gap-2">
                            <Wifi className="h-4 w-4" />
                            Bandwidth Usage
                          </span>
                          <span className="text-sm text-slate-600">
                            {nodeInfo.metrics.bandwidthUsage.toFixed(1)}%
                          </span>
                        </div>
                        <Progress value={nodeInfo.metrics.bandwidthUsage} className="h-2" />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                      <div>
                        <label className="text-sm font-medium text-slate-600">Reputation</label>
                        <div className="text-lg font-bold text-green-600">
                          {nodeInfo.metrics.reputation.toFixed(0)}
                        </div>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-slate-600">Error Rate</label>
                        <div className="text-lg font-bold text-red-600">
                          {nodeInfo.metrics.errorRate.toFixed(2)}%
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="metrics" className="space-y-6">
            {nodeInfo && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Performance Metrics</CardTitle>
                    <CardDescription>Detailed performance indicators</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Total Requests</label>
                        <div className="text-2xl font-bold">
                          {nodeInfo.metrics.requestCount.toLocaleString()}
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Error Rate</label>
                        <div className="text-2xl font-bold text-red-600">
                          {nodeInfo.metrics.errorRate.toFixed(2)}%
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">Success Rate</span>
                        <span className="text-sm font-medium text-green-600">
                          {(100 - nodeInfo.metrics.errorRate).toFixed(2)}%
                        </span>
                      </div>
                      <Progress value={100 - nodeInfo.metrics.errorRate} className="h-3" />
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">Reputation Score</span>
                        <span className="text-sm font-medium">
                          {nodeInfo.metrics.reputation.toFixed(0)}/100
                        </span>
                      </div>
                      <Progress value={nodeInfo.metrics.reputation} className="h-3" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Resource Allocation</CardTitle>
                    <CardDescription>System resource distribution</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">CPU Resources</span>
                          <span className="text-sm text-slate-600">
                            {nodeInfo.node.resources.cpu.toFixed(0)} units
                          </span>
                        </div>
                        <div className="bg-slate-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${(nodeInfo.node.resources.cpu / 100) * 100}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Memory Resources</span>
                          <span className="text-sm text-slate-600">
                            {(nodeInfo.node.resources.memory / 1024).toFixed(1)} GB
                          </span>
                        </div>
                        <div className="bg-slate-200 rounded-full h-2">
                          <div 
                            className="bg-green-600 h-2 rounded-full" 
                            style={{ width: `${(nodeInfo.node.resources.memory / 16384) * 100}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Storage Resources</span>
                          <span className="text-sm text-slate-600">
                            {(nodeInfo.node.resources.storage / 1024 / 1024).toFixed(1)} TB
                          </span>
                        </div>
                        <div className="bg-slate-200 rounded-full h-2">
                          <div 
                            className="bg-purple-600 h-2 rounded-full" 
                            style={{ width: `${(nodeInfo.node.resources.storage / 1000000) * 100}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Bandwidth Resources</span>
                          <span className="text-sm text-slate-600">
                            {(nodeInfo.node.resources.bandwidth / 1000).toFixed(1)} Gbps
                          </span>
                        </div>
                        <div className="bg-slate-200 rounded-full h-2">
                          <div 
                            className="bg-orange-600 h-2 rounded-full" 
                            style={{ width: `${(nodeInfo.node.resources.bandwidth / 10000) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="network" className="space-y-6">
            {nodeReport && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Network Connections</CardTitle>
                    <CardDescription>Connected peer nodes</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Total Connections</span>
                      <Badge variant="secondary">{nodeReport.neighbors.length}</Badge>
                    </div>

                    <div className="space-y-3">
                      {nodeReport.neighbors.map((neighbor, index) => (
                        <div key={index} className="p-3 bg-slate-50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-sm">{neighbor.node.name}</span>
                            <Badge variant={neighbor.status === 'active' ? 'default' : 'secondary'}>
                              {neighbor.status}
                            </Badge>
                          </div>
                          <div className="text-xs text-slate-600 space-y-1">
                            <div>Type: {neighbor.node.type}</div>
                            <div>IP: {neighbor.node.ipAddress.value}</div>
                            <div>Health: {neighbor.metrics.reputation.toFixed(0)}%</div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {nodeReport.neighbors.length === 0 && (
                      <div className="text-center text-slate-500 py-8">
                        <Network className="h-8 w-8 mx-auto mb-2 text-slate-400" />
                        <p>No active connections</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Network Statistics</CardTitle>
                    <CardDescription>Network performance metrics</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Peer Count</label>
                        <div className="text-2xl font-bold">{nodeInfo.node.peers.length}</div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Network Health</label>
                        <div className="text-2xl font-bold text-green-600">
                          {nodeReport.healthScore}%
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">Network Efficiency</span>
                        <span className="text-sm font-medium">
                          {Math.round(nodeReport.healthScore * 0.9)}%
                        </span>
                      </div>
                      <Progress value={nodeReport.healthScore * 0.9} className="h-2" />
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">Connection Quality</span>
                        <span className="text-sm font-medium">
                          {Math.round(nodeReport.healthScore * 0.85)}%
                        </span>
                      </div>
                      <Progress value={nodeReport.healthScore * 0.85} className="h-2" />
                    </div>

                    <div className="pt-4 border-t">
                      <div className="text-sm text-slate-600">
                        <div className="flex items-center gap-2 mb-1">
                          <Zap className="h-4 w-4" />
                          <span>Network Status: </span>
                          <Badge variant="default">Optimal</Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <Shield className="h-4 w-4" />
                          <span>Security: </span>
                          <Badge variant="default">Secured</Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="activity" className="space-y-6">
            {nodeReport && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                    <CardDescription>Node activity timeline</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Total Activities</span>
                      <Badge variant="secondary">{nodeReport.activity.length}</Badge>
                    </div>

                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {nodeReport.activity.slice(-10).reverse().map((timestamp, index) => (
                        <div key={index} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                          <Clock className="h-4 w-4 text-blue-600" />
                          <div className="flex-1">
                            <div className="text-sm font-medium">Node Activity</div>
                            <div className="text-xs text-slate-600">
                              {new Date(timestamp).toLocaleString()}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {nodeReport.activity.length === 0 && (
                      <div className="text-center text-slate-500 py-8">
                        <Activity className="h-8 w-8 mx-auto mb-2 text-slate-400" />
                        <p>No recent activity</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Node Health Analysis</CardTitle>
                    <CardDescription>Comprehensive health assessment</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Overall Health</span>
                        <div className="flex items-center gap-2">
                          {getHealthIcon(nodeReport.healthScore)}
                          <span className={`font-bold ${getHealthColor(nodeReport.healthScore)}`}>
                            {nodeReport.healthScore}%
                          </span>
                        </div>
                      </div>
                      <Progress value={nodeReport.healthScore} className="h-3" />
                    </div>

                    <div className="space-y-3">
                      <h4 className="font-medium text-sm">Health Factors</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Performance</span>
                          <span className="text-green-600">Excellent</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Reliability</span>
                          <span className="text-green-600">High</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Connectivity</span>
                          <span className="text-green-600">Stable</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Security</span>
                          <span className="text-green-600">Secure</span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <div className="text-sm text-slate-600">
                        <div className="mb-2">
                          <strong>Recommendations:</strong>
                        </div>
                        <ul className="space-y-1 text-xs">
                          <li>• Continue monitoring performance metrics</li>
                          <li>• Maintain current security posture</li>
                          <li>• Consider scaling resources if needed</li>
                          <li>• Regular health checks recommended</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <div className="flex justify-center gap-4">
          <Button onClick={refreshNode} disabled={isLoading}>
            {isLoading ? 'Refreshing...' : 'Refresh Data'}
          </Button>
          <Button variant="outline" onClick={initializeNode} disabled={isLoading}>
            Reinitialize Node
          </Button>
        </div>

        {/* Status Alert */}
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            Node <strong>{nodeIdentifier}</strong> is actively participating in the distributed network. 
            Current status: {nodeInfo?.status || 'Unknown'} | Health: {nodeReport?.healthScore || 0}% | 
            Connections: {nodeInfo?.connections.length || 0}
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}