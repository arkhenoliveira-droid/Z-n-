'use client'

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Database, 
  Layers, 
  Clock, 
  Zap, 
  Shield, 
  Activity,
  Target,
  TrendingUp,
  RefreshCw,
  Settings,
  Cpu,
  MemoryStick,
  HardDrive,
  Network,
  Terminal,
  Windows,
  Apple,
  Ubuntu,
  Server
} from 'lucide-react'
import { OSVariableCoherenceAnalyzer, OSVariable, VariableCoherenceVector, VariableCoherencePrinciple } from '@/systems/os-variable-coherence-analyzer'

const OSVariableCoherenceDashboard: React.FC = () => {
  const [analyzer] = useState(() => new OSVariableCoherenceAnalyzer())
  const [analyses, setAnalyses] = useState<Map<string, any>>(new Map())
  const [principles, setPrinciples] = useState<VariableCoherencePrinciple[]>([])
  const [selectedOS, setSelectedOS] = useState<string>('linux')
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  useEffect(() => {
    initializeAnalysis()
  }, [])

  const initializeAnalysis = async () => {
    const newAnalyses = new Map<string, any>()
    const newPrinciples = analyzer.getPrinciples()
    
    // Analisar todos os sistemas operacionais
    const osList = ['linux', 'windows', 'macos', 'bsd']
    for (const os of osList) {
      const analysis = analyzer.analyzeOSVariableCoherence(os)
      newAnalyses.set(os, analysis)
    }
    
    setAnalyses(newAnalyses)
    setPrinciples(newPrinciples)
  }

  const analyzeOS = async (osName: string) => {
    setIsAnalyzing(true)
    await new Promise(resolve => setTimeout(resolve, 1500)) // Simular análise
    
    const newAnalysis = analyzer.analyzeOSVariableCoherence(osName)
    const newAnalyses = new Map(analyses)
    newAnalyses.set(osName, newAnalysis)
    
    setAnalyses(newAnalyses)
    setSelectedOS(osName)
    setIsAnalyzing(false)
  }

  const getDimensionIcon = (dimension: string) => {
    switch (dimension) {
      case 'structural':
        return <Layers className="h-5 w-5" />
      case 'semantic':
        return <Database className="h-5 w-5" />
      case 'temporal':
        return <Clock className="h-5 w-5" />
      case 'behavioral':
        return <Activity className="h-5 w-5" />
      case 'security':
        return <Shield className="h-5 w-5" />
      case 'performance':
        return <Zap className="h-5 w-5" />
      default:
        return <Target className="h-5 w-5" />
    }
  }

  const getDimensionColor = (dimension: string) => {
    switch (dimension) {
      case 'structural':
        return 'bg-blue-500'
      case 'semantic':
        return 'bg-green-500'
      case 'temporal':
        return 'bg-orange-500'
      case 'behavioral':
        return 'bg-purple-500'
      case 'security':
        return 'bg-red-500'
      case 'performance':
        return 'bg-yellow-500'
      default:
        return 'bg-gray-500'
    }
  }

  const getCoherenceColor = (coherence: number) => {
    if (coherence >= 0.9) return 'text-green-600'
    if (coherence >= 0.8) return 'text-yellow-600'
    if (coherence >= 0.7) return 'text-orange-600'
    return 'text-red-600'
  }

  const getOSIcon = (osName: string) => {
    switch (osName) {
      case 'linux':
        return <Ubuntu className="h-6 w-6" />
      case 'windows':
        return <Windows className="h-6 w-6" />
      case 'macos':
        return <Apple className="h-6 w-6" />
      case 'bsd':
        return <Server className="h-6 w-6" />
      default:
        return <Terminal className="h-6 w-6" />
    }
  }

  const getOSColor = (osName: string) => {
    switch (osName) {
      case 'linux':
        return 'bg-orange-500'
      case 'windows':
        return 'bg-blue-500'
      case 'macos':
        return 'bg-gray-500'
      case 'bsd':
        return 'bg-red-500'
      default:
        return 'bg-gray-500'
    }
  }

  const getCategoryBadge = (category: string) => {
    const variants = {
      naming: 'default',
      scoping: 'secondary',
      typing: 'outline',
      lifecycle: 'destructive',
      access: 'default',
      persistence: 'secondary'
    } as const

    const labels = {
      naming: 'Nomenclatura',
      scoping: 'Escopo',
      typing: 'Tipagem',
      lifecycle: 'Ciclo de Vida',
      access: 'Acesso',
      persistence: 'Persistência'
    }

    return (
      <Badge variant={variants[category as keyof typeof variants] || 'default'}>
        {labels[category as keyof typeof labels] || category}
      </Badge>
    )
  }

  const currentAnalysis = analyses.get(selectedOS)

  if (!currentAnalysis) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Coerência de Variáveis de SO</h2>
          <p className="text-muted-foreground">
            Análise de forma e conteúdo em variáveis de sistemas operacionais
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            {Array.from(analyses.keys()).map(os => (
              <Button
                key={os}
                variant={selectedOS === os ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedOS(os)}
                className="flex items-center gap-1"
              >
                {getOSIcon(os)}
                <span className="capitalize">{os}</span>
              </Button>
            ))}
          </div>
          <Button 
            onClick={() => analyzeOS(selectedOS)} 
            disabled={isAnalyzing}
            className="flex items-center gap-2"
          >
            {isAnalyzing ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Activity className="h-4 w-4" />
            )}
            {isAnalyzing ? 'Analisando...' : 'Reanalisar'}
          </Button>
        </div>
      </div>

      {/* Cards Principais */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Coerência Global</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getCoherenceColor(currentAnalysis.globalCoherence)}`}>
              {(currentAnalysis.globalCoherence * 100).toFixed(1)}%
            </div>
            <Progress value={currentAnalysis.globalCoherence * 100} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Variáveis</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {currentAnalysis.variableVectors[0]?.variables.length || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Variáveis analisadas
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Dimensões</CardTitle>
            <Layers className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {currentAnalysis.variableVectors.length}
            </div>
            <p className="text-xs text-muted-foreground">
              Dimensões de coerência
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Versão</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {currentAnalysis.osVersion}
            </div>
            <p className="text-xs text-muted-foreground capitalize">
              {currentAnalysis.osName}
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="vectors" className="space-y-4">
        <TabsList>
          <TabsTrigger value="vectors">Vetores de Coerência</TabsTrigger>
          <TabsTrigger value="variables">Variáveis</TabsTrigger>
          <TabsTrigger value="comparative">Análise Comparativa</TabsTrigger>
          <TabsTrigger value="principles">Princípios</TabsTrigger>
          <TabsTrigger value="patterns">Padrões</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="vectors" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {currentAnalysis.variableVectors.map((vector: VariableCoherenceVector) => (
              <Card key={vector.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`p-2 rounded-full ${getDimensionColor(vector.dimension)} text-white`}>
                        {getDimensionIcon(vector.dimension)}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{vector.name}</CardTitle>
                        <CardDescription>{vector.description}</CardDescription>
                      </div>
                    </div>
                    <Badge variant="outline">{vector.dimension}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm">
                        <span>Coerência</span>
                        <span className={getCoherenceColor(vector.coherenceLevel)}>
                          {(vector.coherenceLevel * 100).toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={vector.coherenceLevel * 100} className="mt-1" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Consistência:</span>
                        <span className="ml-1 font-medium">
                          {(vector.metrics.consistency * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Previsibilidade:</span>
                        <span className="ml-1 font-medium">
                          {(vector.metrics.predictability * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Mantenabilidade:</span>
                        <span className="ml-1 font-medium">
                          {(vector.metrics.maintainability * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Escalabilidade:</span>
                        <span className="ml-1 font-medium">
                          {(vector.metrics.scalability * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>

                    <div>
                      <span className="text-sm text-muted-foreground">Padrões:</span>
                      <div className="mt-2 space-y-1">
                        {vector.patterns.slice(0, 2).map((pattern, index) => (
                          <div key={index} className="text-xs bg-muted p-2 rounded">
                            {pattern}
                          </div>
                        ))}
                        {vector.patterns.length > 2 && (
                          <div className="text-xs text-muted-foreground">
                            +{vector.patterns.length - 2} mais padrões
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="variables" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Variáveis do Sistema</CardTitle>
              <CardDescription>
                Detalhes das variáveis analisadas em {currentAnalysis.osName}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {currentAnalysis.variableVectors[0]?.variables.map((variable: OSVariable) => (
                    <Card key={variable.name} className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold">{variable.name}</h4>
                            <Badge variant="outline">{variable.type}</Badge>
                            <Badge variant="secondary">{variable.scope}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{variable.description}</p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>Valor: {String(variable.value)}</span>
                            <span>Acesso: {variable.accessibility}</span>
                            <span>Persistência: {variable.persistence}</span>
                            <span>Tamanho: {variable.metadata.size} bytes</span>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>Acessos: {variable.metadata.accessCount}</span>
                            <span>Categoria: {variable.category}</span>
                            <span>Encoding: {variable.metadata.encoding}</span>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="comparative" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Análise Comparativa</CardTitle>
              <CardDescription>
                Comparação de coerência entre diferentes sistemas operacionais
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {Object.entries(currentAnalysis.comparativeAnalysis).map(([os, coherence]) => (
                  <div key={os} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={`p-1 rounded ${getOSColor(os)} text-white`}>
                          {getOSIcon(os)}
                        </div>
                        <span className="font-medium capitalize">{os}</span>
                      </div>
                      <span className={`text-sm font-medium ${getCoherenceColor(coherence as number)}`}>
                        {(coherence as number * 100).toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={(coherence as number) * 100} />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="principles" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Princípios de Coerência</CardTitle>
              <CardDescription>
                Princípios fundamentais para coerência de variáveis de sistemas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {principles.map((principle) => (
                    <Card key={principle.id} className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold">{principle.name}</h4>
                            {getCategoryBadge(principle.category)}
                          </div>
                          <p className="text-sm text-muted-foreground">{principle.description}</p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>Relevância: {(principle.relevance * 100).toFixed(0)}%</span>
                            <Progress value={principle.relevance * 100} className="w-20 h-2" />
                          </div>
                          <div className="space-y-1">
                            <span className="text-xs text-muted-foreground">Compliance por SO:</span>
                            <div className="grid grid-cols-4 gap-2 text-xs">
                              <div>Linux: {(principle.osCompliance.linux * 100).toFixed(0)}%</div>
                              <div>Windows: {(principle.osCompliance.windows * 100).toFixed(0)}%</div>
                              <div>macOS: {(principle.osCompliance.macos * 100).toFixed(0)}%</div>
                              <div>BSD: {(principle.osCompliance.bsd * 100).toFixed(0)}%</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patterns" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Padrões de Coerência</CardTitle>
              <CardDescription>
                Padrões identificados na análise de coerência
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {currentAnalysis.coherencePatterns.map((pattern: string, index: number) => (
                  <div key={index} className="flex items-start gap-3 p-4 rounded-lg border">
                    <TrendingUp className="h-5 w-5 text-blue-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium">Padrão #{index + 1}</h4>
                      <p className="text-sm text-muted-foreground">{pattern}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Sugestões de Otimização</CardTitle>
              <CardDescription>
                Recomendações para melhorar a coerência das variáveis
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {currentAnalysis.optimizationSuggestions.map((suggestion: string, index: number) => (
                  <div key={index} className="flex items-start gap-3 p-3 rounded-lg border">
                    <Target className="h-5 w-5 text-orange-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium">Sugestão #{index + 1}</h4>
                      <p className="text-sm text-muted-foreground">{suggestion}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Insights Arquitetônicos</CardTitle>
              <CardDescription>
                Descobertas e aprendizados da análise de coerência
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {currentAnalysis.architecturalInsights.map((insight: string, index: number) => (
                  <div key={index} className="space-y-3 p-4 rounded-lg border-l-4 border-l-green-500 bg-green-50 dark:bg-green-950">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-green-500 text-white flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <h4 className="font-semibold">Insight #{index + 1}</h4>
                    </div>
                    <p className="text-sm leading-relaxed pl-10">{insight}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default OSVariableCoherenceDashboard