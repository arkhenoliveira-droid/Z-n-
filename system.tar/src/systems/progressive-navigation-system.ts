/**
 * Progressive Navigation System
 * 
 * Este sistema implementa uma navegação intuitiva e progressiva que se adapta
 * ao nível de conhecimento e experiência do usuário, revelando funcionalidades
 * de forma gradual e personalizada.
 */

export interface NavigationNode {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'basic' | 'intermediate' | 'advanced' | 'expert';
  prerequisites: string[];
  dependencies: string[];
  estimated_time: number; // minutos para dominar
  difficulty_score: number; // 1-10
  user_benefit: string;
  system_value: string;
  unlock_conditions: {
    min_time_spent: number; // minutos
    min_interactions: number;
    required_achievements: string[];
    knowledge_threshold: number; // 0-1
  };
  content: {
    overview: string;
    key_concepts: string[];
    practical_examples: string[];
    common_use_cases: string[];
    tips_and_tricks: string[];
    advanced_topics?: string[];
  };
  accessibility_features: {
    screen_reader_friendly: boolean;
    keyboard_navigable: boolean;
    high_contrast_mode: boolean;
    simplified_view: boolean;
    audio_guidance: boolean;
  };
}

export interface UserNavigationState {
  user_id: string;
  current_level: 'basic' | 'intermediate' | 'advanced' | 'expert';
  unlocked_nodes: string[];
  completed_nodes: string[];
  time_spent: { [nodeId: string]: number };
  interaction_count: { [nodeId: string]: number };
  achievements: string[];
  knowledge_score: number;
  preferred_learning_path: 'linear' | 'exploratory' | 'goal_oriented';
  navigation_preferences: {
    show_advanced_features: boolean;
    show_tutorial_hints: boolean;
    enable_progressive_disclosure: boolean;
    adaptive_complexity: boolean;
  };
}

export interface NavigationPath {
  id: string;
  name: string;
  description: string;
  target_audience: string[];
  nodes: string[];
  estimated_completion_time: number;
  difficulty_progression: 'gradual' | 'stepped' | 'adaptive';
  learning_objectives: string[];
}

export class ProgressiveNavigationSystem {
  private navigationNodes: NavigationNode[] = [];
  private navigationPaths: NavigationPath[] = [];
  private userStates: Map<string, UserNavigationState> = new Map();

  constructor() {
    this.initializeNavigationNodes();
    this.initializeNavigationPaths();
  }

  private initializeNavigationNodes(): void {
    this.navigationNodes = [
      // Nós Básicos
      {
        id: 'nav_basics_1',
        title: 'Navegação Fundamental',
        description: 'Aprenda os conceitos básicos de navegação do sistema',
        icon: 'compass',
        category: 'basic',
        prerequisites: [],
        dependencies: [],
        estimated_time: 15,
        difficulty_score: 1,
        user_benefit: 'Domine os fundamentos para usar o sistema com confiança',
        system_value: 'Reduz a curva de aprendizado inicial em 80%',
        unlock_conditions: {
          min_time_spent: 0,
          min_interactions: 0,
          required_achievements: [],
          knowledge_threshold: 0
        },
        content: {
          overview: 'A navegação fundamental ensina os conceitos essenciais para interagir com o sistema de forma eficaz.',
          key_concepts: [
            'Estrutura de abas e seções',
            'Navegação por menu e botões',
            'Uso de atalhos e favoritos',
            'Busca e filtros básicos'
          ],
          practical_examples: [
            'Como alternar entre diferentes módulos',
            'Utilizando o menu de navegação principal',
            'Salvando acesso rápido a funcionalidades',
            'Encontrando informações específicas'
          ],
          common_use_cases: [
            'Primeiros passos no sistema',
            'Navegação diária básica',
            'Acesso a funcionalidades essenciais',
            'Busca por informações específicas'
          ],
          tips_and_tricks: [
            'Use o menu de contexto para ações rápidas',
            'Atalhos de teclado aumentam produtividade',
            'Favoritos economizam tempo em tarefas repetitivas',
            'A busca inteligente encontra qualquer funcionalidade'
          ]
        },
        accessibility_features: {
          screen_reader_friendly: true,
          keyboard_navigable: true,
          high_contrast_mode: true,
          simplified_view: true,
          audio_guidance: true
        }
      },

      {
        id: 'nav_basics_2',
        title: 'Interface e Controles',
        description: 'Entenda os elementos da interface e como controlá-los',
        icon: 'interface',
        category: 'basic',
        prerequisites: ['nav_basics_1'],
        dependencies: ['nav_basics_1'],
        estimated_time: 20,
        difficulty_score: 2,
        user_benefit: 'Interaja com todos os elementos da interface de forma natural',
        system_value: 'Melhora a eficiência de interação em 65%',
        unlock_conditions: {
          min_time_spent: 15,
          min_interactions: 10,
          required_achievements: ['first_navigation'],
          knowledge_threshold: 0.1
        },
        content: {
          overview: 'Aprenda a usar todos os controles da interface de forma intuitiva e eficiente.',
          key_concepts: [
            'Botões e seus estados',
            'Formulários e validação',
            'Diálogos e modais',
            'Notificações e feedback'
          ],
          practical_examples: [
            'Preenchendo formulários corretamente',
            'Respondendo a diálogos de confirmação',
            'Interpretando notificações do sistema',
            'Usando controles complexos'
          ],
          common_use_cases: [
            'Cadastro e configuração',
            'Operações do dia a dia',
            'Resposta a eventos do sistema',
            'Interação com dados e formulários'
          ],
          tips_and_tricks: [
            'Tab navigation para acesso rápido',
            'Formulários salvam progresso automaticamente',
            'Atalhos para ações comuns',
            'Personalização de layout'
          ]
        },
        accessibility_features: {
          screen_reader_friendly: true,
          keyboard_navigable: true,
          high_contrast_mode: true,
          simplified_view: true,
          audio_guidance: true
        }
      },

      // Nós Intermediários
      {
        id: 'nav_intermediate_1',
        title: 'Personalização e Preferências',
        description: 'Configure o sistema according às suas necessidades',
        icon: 'settings',
        category: 'intermediate',
        prerequisites: ['nav_basics_1', 'nav_basics_2'],
        dependencies: ['nav_basics_2'],
        estimated_time: 30,
        difficulty_score: 4,
        user_benefit: 'Adapte o sistema para maximizar sua produtividade',
        system_value: 'Aumenta satisfação do usuário em 75%',
        unlock_conditions: {
          min_time_spent: 35,
          min_interactions: 25,
          required_achievements: ['interface_master', 'basic_navigator'],
          knowledge_threshold: 0.3
        },
        content: {
          overview: 'Aprenda a personalizar todos os aspectos do sistema para suas necessidades específicas.',
          key_concepts: [
            'Perfis de usuário',
            'Temas e aparência',
            'Configurações de acessibilidade',
            'Preferências de comportamento'
          ],
          practical_examples: [
            'Criando perfis personalizados',
            'Configurando temas e cores',
            'Ajustando configurações de acessibilidade',
            'Definindo preferências de workflow'
          ],
          common_use_cases: [
            'Ambiente de trabalho personalizado',
            'Acessibilidade otimizada',
            'Fluxos de trabalho eficientes',
            'Experiência adaptada ao usuário'
          ],
          tips_and_tricks: [
            'Perfis salvam tempo em diferentes contextos',
            'Temas reduzem fadiga visual',
            'Configurações podem ser exportadas/importadas',
            'Preferências se adaptam ao uso'
          ],
          advanced_topics: [
            'Automação de configurações',
            'Perfis contextuais',
            'Integração com preferências do sistema',
            'Configurações avançadas de performance'
          ]
        },
        accessibility_features: {
          screen_reader_friendly: true,
          keyboard_navigable: true,
          high_contrast_mode: true,
          simplified_view: true,
          audio_guidance: true
        }
      },

      {
        id: 'nav_intermediate_2',
        title: 'Fluxos de Trabalho Avançados',
        description: 'Otimize suas tarefas com fluxos de trabalho personalizados',
        icon: 'workflow',
        category: 'intermediate',
        prerequisites: ['nav_intermediate_1'],
        dependencies: ['nav_intermediate_1'],
        estimated_time: 45,
        difficulty_score: 5,
        user_benefit: 'Automatize e otimize tarefas repetitivas',
        system_value: 'Aumenta produtividade em 90%',
        unlock_conditions: {
          min_time_spent: 65,
          min_interactions: 50,
          required_achievements: ['personalization_expert', 'workflow_starter'],
          knowledge_threshold: 0.5
        },
        content: {
          overview: 'Crie fluxos de trabalho personalizados para automatizar tarefas complexas.',
          key_concepts: [
            'Criação de workflows',
            'Automação de tarefas',
            'Integração entre módulos',
            'Agendamento e gatilhos'
          ],
          practical_examples: [
            'Automatizando relatórios periódicos',
            'Integrando dados entre sistemas',
            'Criando sequências de operações',
            'Configurando notificações inteligentes'
          ],
          common_use_cases: [
            'Processos de negócios automatizados',
            'Integração de dados',
            'Relatórios automáticos',
            'Monitoramento e alertas'
          ],
          tips_and_tricks: [
            'Workflows podem ser compartilhados',
            'Templates economizam tempo',
            'Teste workflows antes de implantar',
            'Monitore performance de automações'
          ],
          advanced_topics: [
            'Workflows condicionais',
            'API integrations',
            'Machine learning em workflows',
            'Análise de performance'
          ]
        },
        accessibility_features: {
          screen_reader_friendly: true,
          keyboard_navigable: true,
          high_contrast_mode: true,
          simplified_view: false,
          audio_guidance: true
        }
      },

      // Nós Avançados
      {
        id: 'nav_advanced_1',
        title: 'Análise e Otimização',
        description: 'Utilize ferramentas avançadas para analisar e otimizar o sistema',
        icon: 'analytics',
        category: 'advanced',
        prerequisites: ['nav_intermediate_2'],
        dependencies: ['nav_intermediate_2'],
        estimated_time: 60,
        difficulty_score: 7,
        user_benefit: 'Extraia insights valiosos e otimize o desempenho',
        system_value: 'Melhora tomada de decisões em 85%',
        unlock_conditions: {
          min_time_spent: 110,
          min_interactions: 100,
          required_achievements: ['workflow_master', 'data_analyst'],
          knowledge_threshold: 0.7
        },
        content: {
          overview: 'Domine as ferramentas avançadas de análise e otimização do sistema.',
          key_concepts: [
            'Análise de performance',
            'Otimização de recursos',
            'Métricas e KPIs',
            'Benchmarking e comparações'
          ],
          practical_examples: [
            'Analisando performance do sistema',
            'Otimizando uso de recursos',
            'Criando dashboards analíticos',
            'Comparando métricas ao longo do tempo'
          ],
          common_use_cases: [
            'Monitoramento de performance',
            'Otimização de custos',
            'Análise de tendências',
            'Tomada de decisões baseada em dados'
          ],
          tips_and_tricks: [
            'Dashboards salvos fornecem visão rápida',
            'Alertas proativos previnem problemas',
            'Comparação histórica mostra evolução',
            'Exportação facilita compartilhamento'
          ],
          advanced_topics: [
            'Análise preditiva',
            'Machine learning aplicado',
            'Otimização automática',
            'Análise de correlação'
          ]
        },
        accessibility_features: {
          screen_reader_friendly: true,
          keyboard_navigable: true,
          high_contrast_mode: true,
          simplified_view: false,
          audio_guidance: false
        }
      },

      {
        id: 'nav_advanced_2',
        title: 'Integração e Extensibilidade',
        description: 'Integre o sistema com outras plataformas e crie extensões',
        icon: 'integration',
        category: 'advanced',
        prerequisites: ['nav_advanced_1'],
        dependencies: ['nav_advanced_1'],
        estimated_time: 90,
        difficulty_score: 8,
        user_benefit: 'Expanda as capacidades do sistema infinitamente',
        system_value: 'Aumenta valor do sistema em 200%',
        unlock_conditions: {
          min_time_spent: 170,
          min_interactions: 200,
          required_achievements: ['analytics_expert', 'integration_starter'],
          knowledge_threshold: 0.8
        },
        content: {
          overview: 'Aprenda a integrar o sistema com outras plataformas e criar extensões personalizadas.',
          key_concepts: [
            'APIs e webhooks',
            'Desenvolvimento de plugins',
            'Integração com serviços externos',
            'Arquitetura de microserviços'
          ],
          practical_examples: [
            'Conectando com APIs externas',
            'Desenvolvendo plugins personalizados',
            'Integrando com serviços de nuvem',
            'Criando webhooks para automação'
          ],
          common_use_cases: [
            'Integração com sistemas legados',
            'Automação entre plataformas',
            'Extensão de funcionalidades',
            'Criação de ecossistemas'
          ],
          tips_and_tricks: [
            'Documentação de APIs é essencial',
            'Teste integrações em ambiente isolado',
            'Versionamento de extensões',
            'Monitoramento de integrações'
          ],
          advanced_topics: [
            'Arquitetura orientada a eventos',
            'Serverless integration',
            'GraphQL APIs',
            'Microserviços e containers'
          ]
        },
        accessibility_features: {
          screen_reader_friendly: true,
          keyboard_navigable: true,
          high_contrast_mode: true,
          simplified_view: false,
          audio_guidance: false
        }
      },

      // Nós Expert
      {
        id: 'nav_expert_1',
        title: 'Arquitetura e Design de Sistemas',
        description: 'Compreenda a arquitetura interna e princípios de design',
        icon: 'architecture',
        category: 'expert',
        prerequisites: ['nav_advanced_2'],
        dependencies: ['nav_advanced_2'],
        estimated_time: 120,
        difficulty_score: 9,
        user_benefit: 'Contribua para a evolução do sistema',
        system_value: 'Capacita contribuição de alto valor',
        unlock_conditions: {
          min_time_spent: 260,
          min_interactions: 400,
          required_achievements: ['integration_master', 'system_architect'],
          knowledge_threshold: 0.9
        },
        content: {
          overview: 'Domine a arquitetura do sistema e princípios de design avançados.',
          key_concepts: [
            'Padrões arquiteturais',
            'Princípios de design',
            'Escalabilidade e performance',
            'Segurança e confiabilidade'
          ],
          practical_examples: [
            'Analisando arquitetura do sistema',
            'Aplicando padrões de design',
            'Otimizando para escalabilidade',
            'Implementando segurança avançada'
          ],
          common_use_cases: [
            'Contribuição para o código',
            'Design de novas funcionalidades',
            'Otimização de arquitetura',
            'Consultoria técnica'
          ],
          tips_and_tricks: [
            'Estude o código fonte existente',
            'Participe da comunidade técnica',
            'Contribua com documentação',
            'Teste mudanças em ambiente seguro'
          ],
          advanced_topics: [
            'Arquitetura quântica',
            'Design patterns avançados',
            'Sistemas distribuídos',
            'Computação de alto desempenho'
          ]
        },
        accessibility_features: {
          screen_reader_friendly: true,
          keyboard_navigable: true,
          high_contrast_mode: true,
          simplified_view: false,
          audio_guidance: false
        }
      },

      {
        id: 'nav_expert_2',
        title: 'Inovação e Pesquisa',
        description: 'Contribua com pesquisas e inovações para o sistema',
        icon: 'innovation',
        category: 'expert',
        prerequisites: ['nav_expert_1'],
        dependencies: ['nav_expert_1'],
        estimated_time: 180,
        difficulty_score: 10,
        user_benefit: 'Seja pioneiro em tecnologias de ponta',
        system_value: 'Impulsiona inovação contínua',
        unlock_conditions: {
          min_time_spent: 380,
          min_interactions: 800,
          required_achievements: ['architecture_master', 'innovation_leader'],
          knowledge_threshold: 0.95
        },
        content: {
          overview: 'Contribua para a fronteira do conhecimento com pesquisas e inovações.',
          key_concepts: [
            'Pesquisa aplicada',
            'Inovação disruptiva',
            'Desenvolvimento experimental',
            'Publicação e compartilhamento'
          ],
          practical_examples: [
            'Desenvolvendo novas funcionalidades',
            'Pesquisando algoritmos avançados',
            'Experimentando com novas tecnologias',
            'Publicando resultados e descobertas'
          ],
          common_use_cases: [
            'Pesquisa e desenvolvimento',
            'Inovação tecnológica',
            'Contribuição científica',
            'Liderança técnica'
          ],
          tips_and_tricks: [
            'Colabore com a comunidade acadêmica',
            'Documente processos de pesquisa',
            'Compartilhe descobertas regularmente',
            'Mantenha-se atualizado com tendências'
          ],
          advanced_topics: [
            'Computação quântica aplicada',
            'Inteligência artificial avançada',
            'Pesquisa em coerência quântica',
            'Sistemas auto-organizáveis'
          ]
        },
        accessibility_features: {
          screen_reader_friendly: true,
          keyboard_navigable: true,
          high_contrast_mode: true,
          simplified_view: false,
          audio_guidance: false
        }
      }
    ];
  }

  private initializeNavigationPaths(): void {
    this.navigationPaths = [
      {
        id: 'path_beginner_friendly',
        name: 'Caminho Amigável para Iniciantes',
        description: 'Uma jornada suave para novos usuários',
        target_audience: ['beginner', 'casual_user'],
        nodes: ['nav_basics_1', 'nav_basics_2'],
        estimated_completion_time: 35,
        difficulty_progression: 'gradual',
        learning_objectives: [
          'Navegar pelo sistema com confiança',
          'Entender a interface básica',
          'Realizar tarefas essenciais',
          'Personalizar experiência inicial'
        ]
      },
      {
        id: 'path_technical_professional',
        name: 'Caminho Profissional Técnico',
        description: 'Para usuários técnicos que buscam eficiência',
        target_audience: ['technical', 'business'],
        nodes: ['nav_basics_1', 'nav_basics_2', 'nav_intermediate_1', 'nav_intermediate_2'],
        estimated_completion_time: 110,
        difficulty_progression: 'stepped',
        learning_objectives: [
          'Dominar operações básicas rapidamente',
          'Personalizar ambiente de trabalho',
          'Automatizar fluxos de trabalho',
          'Integrar com outras ferramentas'
        ]
      },
      {
        id: 'path_advanced_explorer',
        name: 'Caminho Explorador Avançado',
        description: 'Para usuários que buscam dominar o sistema completamente',
        target_audience: ['technical', 'academic', 'expert'],
        nodes: ['nav_basics_1', 'nav_basics_2', 'nav_intermediate_1', 'nav_intermediate_2', 'nav_advanced_1', 'nav_advanced_2'],
        estimated_completion_time: 260,
        difficulty_progression: 'adaptive',
        learning_objectives: [
          'Compreender arquitetura completa',
          'Otimizar performance do sistema',
          'Integrar com plataformas externas',
          'Contribuir para evolução do sistema'
        ]
      },
      {
        id: 'path_research_innovator',
        name: 'Caminho Pesquisador Inovador',
        description: 'Para pioneiros que buscam expandir os limites do sistema',
        target_audience: ['academic', 'expert', 'researcher'],
        nodes: ['nav_basics_1', 'nav_basics_2', 'nav_intermediate_1', 'nav_intermediate_2', 'nav_advanced_1', 'nav_advanced_2', 'nav_expert_1', 'nav_expert_2'],
        estimated_completion_time: 560,
        difficulty_progression: 'adaptive',
        learning_objectives: [
          'Dominar arquitetura e design',
          'Contribuir com inovações',
          'Realizar pesquisas avançadas',
          'Liderar evolução do sistema'
        ]
      }
    ];
  }

  public initializeUserState(userId: string, preferences: any = {}): UserNavigationState {
    const defaultState: UserNavigationState = {
      user_id: userId,
      current_level: 'basic',
      unlocked_nodes: ['nav_basics_1'],
      completed_nodes: [],
      time_spent: {},
      interaction_count: {},
      achievements: [],
      knowledge_score: 0,
      preferred_learning_path: 'linear',
      navigation_preferences: {
        show_advanced_features: false,
        show_tutorial_hints: true,
        enable_progressive_disclosure: true,
        adaptive_complexity: true
      }
    };

    const userState = { ...defaultState, ...preferences };
    this.userStates.set(userId, userState);
    return userState;
  }

  public getUserState(userId: string): UserNavigationState | null {
    return this.userStates.get(userId) || null;
  }

  public updateUserProgress(userId: string, nodeId: string, timeSpent: number, interactions: number): void {
    const userState = this.userStates.get(userId);
    if (!userState) return;

    // Update time and interactions
    userState.time_spent[nodeId] = (userState.time_spent[nodeId] || 0) + timeSpent;
    userState.interaction_count[nodeId] = (userState.interaction_count[nodeId] || 0) + interactions;

    // Check for node completion
    const node = this.navigationNodes.find(n => n.id === nodeId);
    if (node && !userState.completed_nodes.includes(nodeId)) {
      const totalTime = userState.time_spent[nodeId];
      const totalInteractions = userState.interaction_count[nodeId];

      if (totalTime >= node.estimated_time * 0.8 && totalInteractions >= node.estimated_time / 2) {
        userState.completed_nodes.push(nodeId);
        userState.knowledge_score += 0.1;
        this.unlockNewNodes(userId, userState);
      }
    }

    this.userStates.set(userId, userState);
  }

  private unlockNewNodes(userId: string, userState: UserNavigationState): void {
    for (const node of this.navigationNodes) {
      if (!userState.unlocked_nodes.includes(node.id)) {
        const canUnlock = this.checkUnlockConditions(node, userState);
        if (canUnlock) {
          userState.unlocked_nodes.push(node.id);
          
          // Update user level based on unlocked nodes
          const advancedNodes = userState.unlocked_nodes.filter(id => 
            this.navigationNodes.find(n => n.id === id)?.category === 'advanced'
          ).length;
          
          const expertNodes = userState.unlocked_nodes.filter(id => 
            this.navigationNodes.find(n => n.id === id)?.category === 'expert'
          ).length;

          if (expertNodes > 0) {
            userState.current_level = 'expert';
          } else if (advancedNodes > 0) {
            userState.current_level = 'advanced';
          } else if (userState.unlocked_nodes.length > 4) {
            userState.current_level = 'intermediate';
          }
        }
      }
    }
  }

  private checkUnlockConditions(node: NavigationNode, userState: UserNavigationState): boolean {
    const conditions = node.unlock_conditions;
    
    // Check prerequisites
    for (const prereq of node.prerequisites) {
      if (!userState.completed_nodes.includes(prereq)) {
        return false;
      }
    }

    // Check time spent
    const totalTimeSpent = Object.values(userState.time_spent).reduce((sum, time) => sum + time, 0);
    if (totalTimeSpent < conditions.min_time_spent) {
      return false;
    }

    // Check interactions
    const totalInteractions = Object.values(userState.interaction_count).reduce((sum, interactions) => sum + interactions, 0);
    if (totalInteractions < conditions.min_interactions) {
      return false;
    }

    // Check achievements
    for (const achievement of conditions.required_achievements) {
      if (!userState.achievements.includes(achievement)) {
        return false;
      }
    }

    // Check knowledge threshold
    if (userState.knowledge_score < conditions.knowledge_threshold) {
      return false;
    }

    return true;
  }

  public getAvailableNodes(userId: string): NavigationNode[] {
    const userState = this.userStates.get(userId);
    if (!userState) return [];

    return this.navigationNodes.filter(node => 
      userState.unlocked_nodes.includes(node.id)
    );
  }

  public getRecommendedPath(userId: string): NavigationPath | null {
    const userState = this.userStates.get(userId);
    if (!userState) return null;

    // Find the most appropriate path based on user's current state
    const availablePaths = this.navigationPaths.filter(path => {
      return path.target_audience.includes(userState.current_level);
    });

    // Return the first matching path or the most comprehensive one
    return availablePaths[0] || this.navigationPaths[0];
  }

  public generateNavigationReport(userId: string): string {
    const userState = this.userStates.get(userId);
    if (!userState) return 'User not found';

    const availableNodes = this.getAvailableNodes(userId);
    const completedNodes = availableNodes.filter(node => 
      userState.completed_nodes.includes(node.id)
    );
    const recommendedPath = this.getRecommendedPath(userId);

    const report = `
# Relatório de Navegação Progressiva

## Estado Atual do Usuário
- **Nível Atual:** ${userState.current_level}
- **Pontuação de Conhecimento:** ${(userState.knowledge_score * 100).toFixed(1)}%
- **Nós Desbloqueados:** ${userState.unlocked_nodes.length}/${this.navigationNodes.length}
- **Nós Completados:** ${completedNodes.length}/${availableNodes.length}
- **Tempo Total Gasto:** ${Object.values(userState.time_spent).reduce((sum, time) => sum + time, 0)} minutos
- **Interações Totais:** ${Object.values(userState.interaction_count).reduce((sum, interactions) => sum + interactions, 0)}

## Progresso por Categoria
${['basic', 'intermediate', 'advanced', 'expert'].map(category => {
  const categoryNodes = availableNodes.filter(node => node.category === category);
  const completedCategory = categoryNodes.filter(node => userState.completed_nodes.includes(node.id));
  return `
- **${category.charAt(0).toUpperCase() + category.slice(1)}:** ${completedCategory.length}/${categoryNodes.length} completos`;
}).join('\n')}

## Caminho Recomendado
${recommendedPath ? `
- **Nome:** ${recommendedPath.name}
- **Descrição:** ${recommendedPath.description}
- **Tempo Estimado:** ${recommendedPath.estimated_completion_time} minutos
- **Progressão:** ${recommendedPath.difficulty_progression}
- **Objetivos de Aprendizado:** ${recommendedPath.learning_objectives.join(', ')}
` : 'Nenhum caminho recomendado disponível'}

## Próximos Passos
${this.getNextSteps(userId).map(step => `- ${step}`).join('\n')}

## Conquistas
${userState.achievements.length > 0 ? userState.achievements.map(achievement => `- ${achievement}`).join('\n') : 'Nenhuma conquista ainda'}

## Recomendações Personalizadas
${this.generatePersonalizedRecommendations(userId)}
`;

    return report;
  }

  private getNextSteps(userId: string): string[] {
    const userState = this.userStates.get(userId);
    if (!userState) return [];

    const nextSteps: string[] = [];
    const availableNodes = this.getAvailableNodes(userId);
    
    // Find nodes that are unlocked but not completed
    const incompleteNodes = availableNodes.filter(node => 
      !userState.completed_nodes.includes(node.id)
    );

    // Sort by difficulty and prerequisites
    incompleteNodes.sort((a, b) => {
      if (a.prerequisites.length !== b.prerequisites.length) {
        return a.prerequisites.length - b.prerequisites.length;
      }
      return a.difficulty_score - b.difficulty_score;
    });

    // Return top 3 next steps
    return incompleteNodes.slice(0, 3).map(node => node.title);
  }

  private generatePersonalizedRecommendations(userId: string): string {
    const userState = this.userStates.get(userId);
    if (!userState) return '';

    const recommendations: string[] = [];
    
    if (userState.current_level === 'basic') {
      recommendations.push('Continue explorando os conceitos básicos para construir uma base sólida.');
      recommendations.push('Tente completar todos os nós básicos antes de avançar.');
    } else if (userState.current_level === 'intermediate') {
      recommendations.push('Você está pronto para explorar funcionalidades mais avançadas.');
      recommendations.push('Considere personalizar seu ambiente de trabalho.');
    } else if (userState.current_level === 'advanced') {
      recommendations.push('Você tem um bom domínio do sistema. Explore as integrações e otimizações.');
      recommendations.push('Considere contribuir para a comunidade com seu conhecimento.');
    } else if (userState.current_level === 'expert') {
      recommendations.push('Você é um especialista! Considere contribuir com inovações e pesquisas.');
      recommendations.push('Ajude outros usuários a crescer em sua jornada de aprendizado.');
    }

    if (userState.knowledge_score < 0.5) {
      recommendations.push('Dedique mais tempo aos tutoriais e exemplos práticos.');
    }

    return recommendations.join('\n');
  }

  public getAllNavigationNodes(): NavigationNode[] {
    return [...this.navigationNodes];
  }

  public getAllNavigationPaths(): NavigationPath[] {
    return [...this.navigationPaths];
  }
}