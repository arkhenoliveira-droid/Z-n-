/**
 * Coherent File System Type Definitions
 * 
 * This file provides comprehensive type definitions for file systems,
 * archive formats, compression algorithms, and data coherence structures.
 */

import { ID, UUID, Timestamp, Result } from './utils';

// Basic File Types
export interface FileInfo {
  id: ID;
  name: string;
  extension: string;
  path: string;
  size: number;
  mimeType: string;
  checksum: string;
  createdAt: Timestamp;
  modifiedAt: Timestamp;
  accessedAt: Timestamp;
  permissions: FilePermissions;
  metadata: Record<string, any>;
}

export interface FilePermissions {
  owner: string;
  group: string;
  user: PermissionSet;
  group: PermissionSet;
  other: PermissionSet;
}

export interface PermissionSet {
  read: boolean;
  write: boolean;
  execute: boolean;
}

// Archive and Compression Types
export interface ArchiveEntry {
  path: string;
  size: number;
  mode: number;
  uid: number;
  gid: number;
  mtime: Timestamp;
  type: 'file' | 'directory' | 'symlink' | 'char' | 'block' | 'fifo';
  linkname?: string;
  uname?: string;
  gname?: string;
  devmajor?: number;
  devminor?: number;
  data?: Buffer;
}

export interface ArchiveMetadata {
  format: ArchiveFormat;
  compression?: CompressionFormat;
  totalSize: number;
  entryCount: number;
  checksum: string;
  createdAt: Timestamp;
  compressionRatio?: number;
  algorithm: string;
  version: string;
}

export type ArchiveFormat = 
  | 'tar' 
  | 'zip' 
  | 'rar' 
  | '7z' 
  | 'iso' 
  | 'cpio' 
  | 'ar' 
  | 'shar';

export type CompressionFormat = 
  | 'none' 
  | 'gzip' 
  | 'bzip2' 
  | 'xz' 
  | 'lzma' 
  | 'zstd' 
  | 'lz4' 
  | 'compress';

// File System Coherence Types
export interface FileSystemCoherence {
  id: ID;
  name: string;
  description: string;
  fileTypes: FileType[];
  relationships: CoherenceRelationship[];
  validationRules: ValidationRule[];
  compatibilityMatrix: CompatibilityMatrix;
  metadata: Record<string, any>;
}

export interface FileType {
  id: ID;
  name: string;
  extension: string;
  mimeType: string;
  category: FileCategory;
  structure: FileStructure;
  encoding?: string;
  signature?: string;
  magicNumber?: string;
  version?: string;
  specifications: FileSpecification[];
}

export type FileCategory = 
  | 'document' 
  | 'image' 
  | 'audio' 
  | 'video' 
  | 'archive' 
  | 'executable' 
  | 'database' 
  | 'system' 
  | 'config' 
  | 'log' 
  | 'code' 
  | 'data';

export interface FileStructure {
  type: 'binary' | 'text' | 'mixed';
  format: 'structured' | 'unstructured' | 'semi-structured';
  schema?: any;
  encoding?: string;
  endian?: 'little' | 'big';
  sections?: FileSection[];
}

export interface FileSection {
  name: string;
  offset: number;
  size: number;
  type: string;
  description?: string;
  checksum?: string;
}

export interface FileSpecification {
  name: string;
  version: string;
  url?: string;
  description?: string;
  complianceLevel: 'full' | 'partial' | 'minimal';
}

export interface CoherenceRelationship {
  id: ID;
  sourceType: ID;
  targetType: ID;
  relationshipType: RelationshipType;
  transformation: TransformationRule[];
  bidirectional: boolean;
  strength: number; // 0-1
  description?: string;
}

export type RelationshipType = 
  | 'convertible' 
  | 'compatible' 
  | 'derivative' 
  | 'container' 
  | 'compressed' 
  | 'encrypted' 
  | 'encoded' 
  | 'linked';

export interface TransformationRule {
  name: string;
  algorithm: string;
  parameters: Record<string, any>;
  lossiness: 'lossless' | 'lossy' | 'mixed';
  quality?: number;
  speed?: number;
}

export interface ValidationRule {
  id: ID;
  name: string;
  description: string;
  type: 'syntax' | 'semantic' | 'structure' | 'integrity';
  validator: string;
  parameters: Record<string, any>;
  severity: 'error' | 'warning' | 'info';
}

export interface CompatibilityMatrix {
  formats: CompatibilityEntry[][];
  conversions: ConversionRule[];
  recommendations: CompatibilityRecommendation[];
}

export interface CompatibilityEntry {
  sourceFormat: ID;
  targetFormat: ID;
  compatibility: 'full' | 'partial' | 'none';
  conversionMethod?: string;
  qualityLoss?: number;
  notes?: string;
}

export interface ConversionRule {
  id: ID;
  name: string;
  sourceFormat: ID;
  targetFormat: ID;
  algorithm: string;
  parameters: Record<string, any>;
  quality: number;
  speed: number;
  reliability: number;
}

export interface CompatibilityRecommendation {
  scenario: string;
  sourceFormat: ID;
  recommendedFormat: ID;
  reason: string;
  benefits: string[];
  considerations: string[];
}

// TAR-specific Types
export interface TarHeader {
  name: string;
  mode: number;
  uid: number;
  gid: number;
  size: number;
  mtime: number;
  checksum: number;
  typeflag: number;
  linkname: string;
  magic: string;
  version: string;
  uname: string;
  gname: string;
  devmajor: number;
  devminor: number;
  prefix: string;
  padding: Buffer;
}

export interface TarFile {
  header: TarHeader;
  data: Buffer;
  padding: Buffer;
}

export interface TarArchive {
  files: TarFile[];
  metadata: ArchiveMetadata;
  globalHeader?: any;
  globalFooter?: any;
}

// Compression Engine Types
export interface CompressionEngine {
  id: ID;
  name: string;
  algorithm: CompressionFormat;
  level: number;
  strategy: CompressionStrategy;
  performance: CompressionPerformance;
  supportedFormats: string[];
}

export type CompressionStrategy = 
  | 'speed' 
  | 'balanced' 
  | 'compression' 
  | 'extreme' 
  | 'adaptive';

export interface CompressionPerformance {
  compressionSpeed: number; // MB/s
  decompressionSpeed: number; // MB/s
  compressionRatio: number; // 0-1
  memoryUsage: number; // MB
  cpuUsage: number; // percentage
}

// Raw Data Types
export interface RawData {
  id: ID;
  type: RawDataType;
  data: Buffer;
  metadata: RawDataMetadata;
  structure?: DataStructure;
  encoding?: string;
  checksum: string;
}

export type RawDataType = 
  | 'binary' 
  | 'text' 
  | 'hex' 
  | 'base64' 
  | 'numeric' 
  | 'structured' 
  | 'stream';

export interface RawDataMetadata {
  source: string;
  format: string;
  encoding: string;
  byteOrder: 'little' | 'big';
  createdAt: Timestamp;
  modifiedAt: Timestamp;
  size: number;
  checksum: string;
  tags: string[];
  description?: string;
}

export interface DataStructure {
  type: 'array' | 'object' | 'matrix' | 'graph' | 'tree' | 'list';
  dimensions: number[];
  dataType: string;
  schema?: any;
  constraints: DataConstraint[];
}

export interface DataConstraint {
  type: string;
  value: any;
  description?: string;
}

// Operating System Coherence Types
export interface OSFileCoherence {
  id: ID;
  osName: string;
  osVersion: string;
  fileSystem: string;
  supportedFormats: string[];
  nativeFormats: string[];
  compatibilityLayers: CompatibilityLayer[];
  systemCalls: SystemCall[];
  drivers: Driver[];
}

export interface CompatibilityLayer {
  name: string;
  version: string;
  supportedFormats: string[];
  performance: PerformanceMetrics;
  reliability: number;
  description?: string;
}

export interface SystemCall {
  name: string;
  parameters: Parameter[];
  returnType: string;
  description: string;
  supportedFormats: string[];
}

export interface Parameter {
  name: string;
  type: string;
  required: boolean;
  description?: string;
  defaultValue?: any;
}

export interface Driver {
  name: string;
  version: string;
  type: 'filesystem' | 'compression' | 'encryption' | 'archive';
  supportedFormats: string[];
  capabilities: string[];
  performance: PerformanceMetrics;
}

export interface PerformanceMetrics {
  throughput: number;
  latency: number;
  memoryUsage: number;
  cpuUsage: number;
  reliability: number;
}

// Coherent Archive System
export interface CoherentArchiveSystem {
  id: ID;
  name: string;
  version: string;
  description: string;
  supportedFormats: ArchiveFormat[];
  supportedCompressions: CompressionFormat[];
  coherenceRules: CoherenceRule[];
  transformationEngine: TransformationEngine;
  validationEngine: ValidationEngine;
  optimizationEngine: OptimizationEngine;
}

export interface CoherenceRule {
  id: ID;
  name: string;
  description: string;
  type: 'structural' | 'semantic' | 'performance' | 'security';
  conditions: RuleCondition[];
  actions: RuleAction[];
  priority: number;
}

export interface RuleCondition {
  field: string;
  operator: string;
  value: any;
}

export interface RuleAction {
  type: 'transform' | 'validate' | 'optimize' | 'warn' | 'error';
  parameters: Record<string, any>;
}

export interface TransformationEngine {
  id: ID;
  name: string;
  transformers: Transformer[];
  pipeline: TransformationPipeline[];
}

export interface Transformer {
  id: ID;
  name: string;
  inputFormat: string;
  outputFormat: string;
  algorithm: string;
  parameters: Record<string, any>;
  performance: PerformanceMetrics;
}

export interface TransformationPipeline {
  id: ID;
  name: string;
  stages: PipelineStage[];
  parallel: boolean;
  optimization: OptimizationStrategy;
}

export interface PipelineStage {
  id: ID;
  name: string;
  transformer: ID;
  parameters: Record<string, any>;
  dependencies: ID[];
  timeout?: number;
}

export type OptimizationStrategy = 
  | 'speed' 
  | 'memory' 
  | 'quality' 
  | 'balanced' 
  | 'adaptive';

export interface ValidationEngine {
  id: ID;
  name: string;
  validators: Validator[];
  rules: ValidationRule[];
  reporting: ValidationReporting;
}

export interface Validator {
  id: ID;
  name: string;
  format: string;
  algorithm: string;
  parameters: Record<string, any>;
  reliability: number;
}

export interface ValidationReporting {
  level: 'minimal' | 'normal' | 'detailed' | 'verbose';
  format: 'text' | 'json' | 'xml' | 'html';
  destination: 'console' | 'file' | 'network' | 'database';
}

export interface OptimizationEngine {
  id: ID;
  name: string;
  optimizers: Optimizer[];
  strategies: OptimizationStrategy[];
  metrics: OptimizationMetrics;
}

export interface Optimizer {
  id: ID;
  name: string;
  type: 'compression' | 'structure' | 'layout' | 'metadata';
  algorithm: string;
  parameters: Record<string, any>;
  effectiveness: number;
}

export interface OptimizationMetrics {
  compressionRatio: number;
  processingTime: number;
  memoryUsage: number;
  qualityScore: number;
  coherenceScore: number;
}