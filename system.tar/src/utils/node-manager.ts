// Node Manager Utility
// Provides utilities for managing and interacting with network nodes

import { ID, Timestamp, Result } from '@/types/utils';
import { NetworkNode, IPAddress, MACAddress, Port } from '@/types/internet-architecture';
import { DistributedNode } from '@/patterns/distributed-systems';

export interface NodeIdentifier {
  id: string;
  uuid: string;
  network: string;
  timestamp: Timestamp;
}

export interface NodeInfo {
  identifier: NodeIdentifier;
  node: DistributedNode;
  status: 'active' | 'inactive' | 'unknown';
  lastActivity: Timestamp;
  connections: string[];
  metrics: NodeMetrics;
}

export interface NodeMetrics {
  cpuUsage: number;
  memoryUsage: number;
  storageUsage: number;
  bandwidthUsage: number;
  uptime: number;
  requestCount: number;
  errorRate: number;
  reputation: number;
}

export class NodeManager {
  private nodes: Map<string, NodeInfo> = new Map();
  private nodeHistory: Map<string, Timestamp[]> = new Map();

  // Parse node identifier string
  parseNodeIdentifier(identifierString: string): Result<NodeIdentifier> {
    try {
      // Example format: g071p7fca930("476a3890-d602-4e71-ac25-9f6fee5933c9")
      const match = identifierString.match(/([a-z0-9]+)\(\"([a-z0-9\-]+)\"\)/i);
      
      if (!match) {
        return { success: false, error: new Error('Invalid node identifier format') };
      }

      const [, id, uuid] = match;

      const nodeIdentifier: NodeIdentifier = {
        id,
        uuid,
        network: 'global-p2p',
        timestamp: Date.now()
      };

      return { success: true, data: nodeIdentifier };
    } catch (error) {
      return { success: false, error: error as Error };
    }
  }

  // Register a new node
  registerNode(identifierString: string, nodeData: Partial<DistributedNode>): Result<NodeInfo> {
    try {
      const identifierResult = this.parseNodeIdentifier(identifierString);
      if (!identifierResult.success) {
        return identifierResult;
      }

      const identifier = identifierResult.data;

      // Check if node already exists
      if (this.nodes.has(identifier.uuid)) {
        return { success: false, error: new Error('Node already registered') };
      }

      // Create distributed node
      const distributedNode: DistributedNode = {
        id: identifier.uuid as ID,
        name: nodeData.name || `Node-${identifier.id}`,
        ipAddress: nodeData.ipAddress || this.generateIPAddress(),
        macAddress: nodeData.macAddress || this.generateMACAddress(),
        ports: nodeData.ports || this.generateDefaultPorts(),
        type: nodeData.type || 'host',
        status: nodeData.status || 'online',
        location: nodeData.location || this.generateLocation(),
        capabilities: nodeData.capabilities || ['routing', 'computing'],
        resources: {
          cpu: nodeData.resources?.cpu || Math.random() * 100,
          memory: nodeData.resources?.memory || Math.random() * 16000,
          storage: nodeData.resources?.storage || Math.random() * 1000000,
          bandwidth: nodeData.resources?.bandwidth || Math.random() * 10000,
          reputation: nodeData.resources?.reputation || 50
        },
        nodeId: identifier.uuid,
        publicKey: this.generatePublicKey(),
        privateKey: this.generatePrivateKey(),
        state: nodeData.state || 'idle',
        lastSeen: Date.now(),
        peers: []
      };

      // Create node info
      const nodeInfo: NodeInfo = {
        identifier,
        node: distributedNode,
        status: 'active',
        lastActivity: Date.now(),
        connections: [],
        metrics: this.generateInitialMetrics()
      };

      this.nodes.set(identifier.uuid, nodeInfo);
      this.recordActivity(identifier.uuid);

      return { success: true, data: nodeInfo };
    } catch (error) {
      return { success: false, error: error as Error };
    }
  }

  // Get node information
  getNodeInfo(identifierString: string): Result<NodeInfo> {
    try {
      const identifierResult = this.parseNodeIdentifier(identifierString);
      if (!identifierResult.success) {
        return identifierResult;
      }

      const nodeInfo = this.nodes.get(identifierResult.data.uuid);
      if (!nodeInfo) {
        return { success: false, error: new Error('Node not found') };
      }

      return { success: true, data: nodeInfo };
    } catch (error) {
      return { success: false, error: error as Error };
    }
  }

  // Update node status
  updateNodeStatus(identifierString: string, status: NodeInfo['status']): Result<void> {
    try {
      const identifierResult = this.parseNodeIdentifier(identifierString);
      if (!identifierResult.success) {
        return identifierResult;
      }

      const nodeInfo = this.nodes.get(identifierResult.data.uuid);
      if (!nodeInfo) {
        return { success: false, error: new Error('Node not found') };
      }

      nodeInfo.status = status;
      nodeInfo.lastActivity = Date.now();
      this.recordActivity(identifierResult.data.uuid);

      return { success: true, data: undefined };
    } catch (error) {
      return { success: false, error: error as Error };
    }
  }

  // Update node metrics
  updateNodeMetrics(identifierString: string, metrics: Partial<NodeMetrics>): Result<void> {
    try {
      const identifierResult = this.parseNodeIdentifier(identifierString);
      if (!identifierResult.success) {
        return identifierResult;
      }

      const nodeInfo = this.nodes.get(identifierResult.data.uuid);
      if (!nodeInfo) {
        return { success: false, error: new Error('Node not found') };
      }

      nodeInfo.metrics = { ...nodeInfo.metrics, ...metrics };
      nodeInfo.lastActivity = Date.now();
      this.recordActivity(identifierResult.data.uuid);

      return { success: true, data: undefined };
    } catch (error) {
      return { success: false, error: error as Error };
    }
  }

  // Add connection between nodes
  addConnection(sourceIdentifier: string, targetIdentifier: string): Result<void> {
    try {
      const sourceResult = this.parseNodeIdentifier(sourceIdentifier);
      const targetResult = this.parseNodeIdentifier(targetIdentifier);

      if (!sourceResult.success || !targetResult.success) {
        return { success: false, error: new Error('Invalid node identifiers') };
      }

      const sourceNode = this.nodes.get(sourceResult.data.uuid);
      const targetNode = this.nodes.get(targetResult.data.uuid);

      if (!sourceNode || !targetNode) {
        return { success: false, error: new Error('One or both nodes not found') };
      }

      // Add connection
      if (!sourceNode.connections.includes(targetResult.data.uuid)) {
        sourceNode.connections.push(targetResult.data.uuid);
      }

      if (!targetNode.connections.includes(sourceResult.data.uuid)) {
        targetNode.connections.push(sourceResult.data.uuid);
      }

      // Update peer lists in distributed nodes
      if (!sourceNode.node.peers.includes(targetResult.data.uuid)) {
        sourceNode.node.peers.push(targetResult.data.uuid);
      }

      if (!targetNode.node.peers.includes(sourceResult.data.uuid)) {
        targetNode.node.peers.push(sourceResult.data.uuid);
      }

      sourceNode.lastActivity = Date.now();
      targetNode.lastActivity = Date.now();

      this.recordActivity(sourceResult.data.uuid);
      this.recordActivity(targetResult.data.uuid);

      return { success: true, data: undefined };
    } catch (error) {
      return { success: false, error: error as Error };
    }
  }

  // Get node activity history
  getNodeActivity(identifierString: string): Result<Timestamp[]> {
    try {
      const identifierResult = this.parseNodeIdentifier(identifierString);
      if (!identifierResult.success) {
        return identifierResult;
      }

      const history = this.nodeHistory.get(identifierResult.data.uuid) || [];
      return { success: true, data: history };
    } catch (error) {
      return { success: false, error: error as Error };
    }
  }

  // Get all active nodes
  getActiveNodes(): NodeInfo[] {
    return Array.from(this.nodes.values()).filter(node => node.status === 'active');
  }

  // Get node neighbors
  getNodeNeighbors(identifierString: string): Result<NodeInfo[]> {
    try {
      const identifierResult = this.parseNodeIdentifier(identifierString);
      if (!identifierResult.success) {
        return identifierResult;
      }

      const nodeInfo = this.nodes.get(identifierResult.data.uuid);
      if (!nodeInfo) {
        return { success: false, error: new Error('Node not found') };
      }

      const neighbors: NodeInfo[] = [];
      for (const connectionId of nodeInfo.connections) {
        const neighbor = this.nodes.get(connectionId);
        if (neighbor) {
          neighbors.push(neighbor);
        }
      }

      return { success: true, data: neighbors };
    } catch (error) {
      return { success: false, error: error as Error };
    }
  }

  // Calculate node health score
  calculateNodeHealth(identifierString: string): Result<number> {
    try {
      const nodeResult = this.getNodeInfo(identifierString);
      if (!nodeResult.success) {
        return nodeResult;
      }

      const nodeInfo = nodeResult.data;
      const metrics = nodeInfo.metrics;

      // Calculate health based on various factors
      const cpuHealth = Math.max(0, 100 - metrics.cpuUsage);
      const memoryHealth = Math.max(0, 100 - metrics.memoryUsage);
      const storageHealth = Math.max(0, 100 - metrics.storageUsage);
      const errorHealth = Math.max(0, 100 - metrics.errorRate * 100);
      const reputationHealth = metrics.reputation;

      const overallHealth = (
        cpuHealth * 0.2 +
        memoryHealth * 0.2 +
        storageHealth * 0.1 +
        errorHealth * 0.3 +
        reputationHealth * 0.2
      );

      return { success: true, data: Math.round(overallHealth) };
    } catch (error) {
      return { success: false, error: error as Error };
    }
  }

  // Generate node report
  generateNodeReport(identifierString: string): Result<NodeReport> {
    try {
      const nodeResult = this.getNodeInfo(identifierString);
      if (!nodeResult.success) {
        return nodeResult;
      }

      const nodeInfo = nodeResult.data;
      const healthResult = this.calculateNodeHealth(identifierString);
      const neighborsResult = this.getNodeNeighbors(identifierString);
      const activityResult = this.getNodeActivity(identifierString);

      const report: NodeReport = {
        node: nodeInfo,
        healthScore: healthResult.success ? healthResult.data : 0,
        neighbors: neighborsResult.success ? neighborsResult.data : [],
        activity: activityResult.success ? activityResult.data : [],
        generatedAt: Date.now()
      };

      return { success: true, data: report };
    } catch (error) {
      return { success: false, error: error as Error };
    }
  }

  // Private helper methods
  private generateIPAddress(): IPAddress {
    return {
      value: `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
      version: 'IPv4',
      isPrivate: true,
      isLoopback: false,
      subnet: '255.255.255.0'
    };
  }

  private generateMACAddress(): MACAddress {
    const mac = Array.from({ length: 6 }, () => 
      Math.floor(Math.random() * 256).toString(16).padStart(2, '0')
    ).join(':');

    return {
      value: mac.toUpperCase(),
      manufacturer: 'Virtual Manufacturer',
      isMulticast: false
    };
  }

  private generateDefaultPorts(): Port[] {
    return [
      {
        number: 80,
        protocol: 'TCP',
        service: 'HTTP',
        isOpen: true
      },
      {
        number: 443,
        protocol: 'TCP',
        service: 'HTTPS',
        isOpen: true
      },
      {
        number: 22,
        protocol: 'TCP',
        service: 'SSH',
        isOpen: true
      }
    ];
  }

  private generateLocation() {
    return {
      latitude: Math.random() * 180 - 90,
      longitude: Math.random() * 360 - 180,
      region: `Region-${Math.floor(Math.random() * 100)}`,
      country: `Country-${Math.floor(Math.random() * 50)}`
    };
  }

  private generatePublicKey(): string {
    return `-----BEGIN PUBLIC KEY-----\n${Math.random().toString(36).substring(2, 66)}\n-----END PUBLIC KEY-----`;
  }

  private generatePrivateKey(): string {
    return `-----BEGIN PRIVATE KEY-----\n${Math.random().toString(36).substring(2, 66)}\n-----END PRIVATE KEY-----`;
  }

  private generateInitialMetrics(): NodeMetrics {
    return {
      cpuUsage: Math.random() * 50,
      memoryUsage: Math.random() * 60,
      storageUsage: Math.random() * 40,
      bandwidthUsage: Math.random() * 30,
      uptime: Math.random() * 86400000, // Up to 24 hours
      requestCount: Math.floor(Math.random() * 10000),
      errorRate: Math.random() * 5,
      reputation: Math.random() * 100
    };
  }

  private recordActivity(nodeId: string): void {
    if (!this.nodeHistory.has(nodeId)) {
      this.nodeHistory.set(nodeId, []);
    }
    
    const history = this.nodeHistory.get(nodeId)!;
    history.push(Date.now());
    
    // Keep only last 1000 activities
    if (history.length > 1000) {
      history.shift();
    }
  }
}

// Report types
export interface NodeReport {
  node: NodeInfo;
  healthScore: number;
  neighbors: NodeInfo[];
  activity: Timestamp[];
  generatedAt: Timestamp;
}