import { NextRequest, NextResponse } from 'next/server';

// Mock analytics data
const generateWeeklyData = () => {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  return days.map((day, index) => ({
    day,
    coherenceScore: Math.floor(Math.random() * 20) + 75, // 75-95
    focusTime: Math.floor(Math.random() * 4) + 4, // 4-8 hours
    stressLevel: Math.floor(Math.random() * 20) + 10, // 10-30%
    productivity: Math.floor(Math.random() * 20) + 80 // 80-100%
  }));
};

const generateInsights = () => [
  {
    category: 'Productivity',
    insights: [
      'Your peak focus hours are 9-11 AM',
      'Coherence improves with natural lighting',
      'Team sync is most effective at 2 PM',
      'Stress levels decrease with regular breaks'
    ]
  },
  {
    category: 'Optimization',
    insights: [
      'Schedule important tasks during peak hours',
      'Increase natural light in workspace',
      'Implement 25-minute focus sessions',
      'Team sync meetings at 2 PM daily'
    ]
  }
];

export async function GET() {
  try {
    const weeklyData = generateWeeklyData();
    const insights = generateInsights();
    
    // Calculate summary metrics
    const avgCoherence = Math.round(weeklyData.reduce((sum, day) => sum + day.coherenceScore, 0) / 7);
    const avgFocusTime = Math.round(weeklyData.reduce((sum, day) => sum + day.focusTime, 0) / 7 * 10) / 10;
    const avgStressLevel = Math.round(weeklyData.reduce((sum, day) => sum + day.stressLevel, 0) / 7);
    const avgProductivity = Math.round(weeklyData.reduce((sum, day) => sum + day.productivity, 0) / 7);

    const summaryMetrics = {
      dailyAverage: {
        coherence: avgCoherence,
        focusTime: avgFocusTime,
        stressLevel: avgStressLevel,
        productivity: avgProductivity
      },
      weeklyTrends: {
        coherence: avgCoherence > 82 ? 'Improving' : 'Stable',
        focusTime: avgFocusTime > 5.5 ? 'Increasing' : 'Stable',
        stressLevel: avgStressLevel < 20 ? 'Decreasing' : 'Stable',
        productivity: avgProductivity > 87 ? 'Excellent' : 'Good'
      }
    };

    return NextResponse.json({
      success: true,
      data: {
        weeklyData,
        insights,
        summaryMetrics,
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('Analytics API error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch analytics data' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, timeRange, metrics } = body;

    // Simulate different analytics based on request
    let responseData;
    
    switch (type) {
      case 'personal':
        responseData = {
          type: 'personal',
          timeRange,
          metrics: {
            coherence: Math.floor(Math.random() * 20) + 80,
            focus: Math.floor(Math.random() * 20) + 70,
            stress: Math.floor(Math.random() * 15) + 10,
            energy: Math.floor(Math.random() * 25) + 60
          },
          patterns: {
            peakHours: ['9-11 AM', '2-4 PM'],
            optimalEnvironment: 'Natural lighting, moderate temperature',
            bestCollaborationTime: '2 PM'
          }
        };
        break;

      case 'team':
        responseData = {
          type: 'team',
          timeRange,
          metrics: {
            synchronization: Math.floor(Math.random() * 15) + 85,
            collaboration: Math.floor(Math.random() * 20) + 75,
            productivity: Math.floor(Math.random() * 15) + 85,
            satisfaction: Math.floor(Math.random() * 10) + 90
          },
          patterns: {
            bestMeetingTime: '2 PM',
            optimalTeamSize: '4-6 members',
            preferredCollaboration: 'Pair programming'
          }
        };
        break;

      default:
        return NextResponse.json(
          { success: false, error: 'Invalid analytics type' },
          { status: 400 }
        );
    }

    return NextResponse.json({
      success: true,
      data: {
        ...responseData,
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('Analytics API POST error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to process analytics request' },
      { status: 500 }
    );
  }
}