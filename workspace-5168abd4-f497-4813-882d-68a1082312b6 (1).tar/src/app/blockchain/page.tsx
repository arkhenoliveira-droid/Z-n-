'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Blockchain, Block, Transaction, BlockData, blockchain, initializeBlockchain } from '@/lib/blockchain';
import { BlockCard } from '@/components/blockchain/block-card';
import { WalletBalance } from '@/components/blockchain/wallet-balance';
import { TransactionForm } from '@/components/blockchain/transaction-form';
import { 
  Chain, 
  Wallet, 
  TrendingUp, 
  AlertCircle, 
  RefreshCw, 
  BarChart3,
  Activity,
  Zap
} from 'lucide-react';

export default function BlockchainPage() {
  const [blocks, setBlocks] = useState<BlockData[]>([]);
  const [pendingTransactions, setPendingTransactions] = useState<Transaction[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [selectedWallet, setSelectedWallet] = useState<string>('');
  const [walletBalances, setWalletBalances] = useState<{[key: string]: number}>({});
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialize blockchain
  useEffect(() => {
    if (!isInitialized) {
      const { wallets } = initializeBlockchain();
      setSelectedWallet(wallets[0]);
      setIsInitialized(true);
      updateBlockchainState();
    }
  }, [isInitialized]);

  const updateBlockchainState = () => {
    // Convert blocks to plain objects for React state
    const blocksData = blockchain.chain.map(block => ({
      index: block.index,
      timestamp: block.timestamp,
      transactions: block.transactions,
      previousHash: block.previousHash,
      hash: block.hash,
      nonce: block.nonce
    }));
    
    setBlocks(blocksData);
    setPendingTransactions([...blockchain.pendingTransactions]);
    setStats(blockchain.getChainStats());
    
    // Update wallet balances
    const balances: {[key: string]: number} = {};
    if (selectedWallet) {
      balances[selectedWallet] = blockchain.getBalance(selectedWallet);
    }
    setWalletBalances(balances);
  };

  const handleCreateTransaction = (transaction: Omit<Transaction, 'timestamp'>) => {
    try {
      blockchain.createTransaction(transaction);
      updateBlockchainState();
    } catch (error) {
      console.error('Error creating transaction:', error);
      alert(error instanceof Error ? error.message : 'Failed to create transaction');
    }
  };

  const handleMineBlock = (minerAddress: string) => {
    try {
      blockchain.minePendingTransactions(minerAddress);
      updateBlockchainState();
    } catch (error) {
      console.error('Error mining block:', error);
      alert(error instanceof Error ? error.message : 'Failed to mine block');
    }
  };

  const handleGenerateWallet = () => {
    return blockchain.generateWalletAddress();
  };

  const handleRefresh = () => {
    updateBlockchainState();
  };

  const getWalletTransactions = (address: string) => {
    return blockchain.getAllTransactionsForWallet(address);
  };

  if (!isInitialized) {
    return (
      <div className="container mx-auto py-8">
        <div className="flex items-center justify-center space-x-2">
          <RefreshCw className="h-6 w-6 animate-spin" />
          <span>Initializing blockchain...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <Chain className="h-10 w-10 text-blue-600" />
          <h1 className="text-4xl font-bold">Blockchain Demo</h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Interactive blockchain visualization. Create transactions, mine blocks, and explore the distributed ledger technology.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Blocks</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalBlocks || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Transactions</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.pendingTransactions || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Mining Reward</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.miningReward || 0} coins</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Chain Valid</CardTitle>
            <AlertCircle className={`h-4 w-4 ${stats?.isValid ? 'text-green-600' : 'text-red-600'}`} />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${stats?.isValid ? 'text-green-600' : 'text-red-600'}`}>
              {stats?.isValid ? 'Valid' : 'Invalid'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="blocks" className="space-y-6">
        <div className="flex items-center justify-between">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="blocks">Blockchain</TabsTrigger>
            <TabsTrigger value="wallet">Wallet</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
          </TabsList>
          
          <Button variant="outline" size="sm" onClick={handleRefresh}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>

        <TabsContent value="blocks" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Chain className="h-5 w-5" />
                    <span>Blockchain</span>
                    <Badge variant="outline">
                      {blocks.length} blocks
                    </Badge>
                  </CardTitle>
                  <CardDescription>
                    Complete chain of blocks from genesis to latest
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {[...blocks].reverse().map((block) => (
                      <BlockCard
                        key={block.index}
                        block={block}
                        isGenesis={block.index === 0}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <TransactionForm
                onCreateTransaction={handleCreateTransaction}
                onMineBlock={handleMineBlock}
                pendingTransactions={pendingTransactions.length}
                onGenerateWallet={handleGenerateWallet}
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="wallet" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Wallet className="h-5 w-5" />
                    <span>Wallet Balance</span>
                  </CardTitle>
                  <CardDescription>
                    Check balance and transaction history
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Wallet Address</label>
                    <div className="flex space-x-2">
                      <input
                        value={selectedWallet}
                        onChange={(e) => setSelectedWallet(e.target.value)}
                        placeholder="0x..."
                        className="flex-1 px-3 py-2 border border-input rounded-md text-sm font-mono"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedWallet(blockchain.generateWalletAddress())}
                      >
                        Generate
                      </Button>
                    </div>
                  </div>
                  
                  {selectedWallet && (
                    <WalletBalance
                      address={selectedWallet}
                      balance={blockchain.getBalance(selectedWallet)}
                      transactions={getWalletTransactions(selectedWallet).length}
                    />
                  )}
                </CardContent>
              </Card>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5" />
                    <span>Transaction History</span>
                  </CardTitle>
                  <CardDescription>
                    Recent transactions for selected wallet
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {selectedWallet ? (
                      getWalletTransactions(selectedWallet).map((tx, index) => (
                        <div key={index} className="p-3 bg-muted/50 rounded-lg text-sm">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium">
                              {tx.fromAddress === selectedWallet ? 'Sent' : 'Received'} {tx.amount} coins
                            </span>
                            <Badge variant={tx.fromAddress === selectedWallet ? "destructive" : "default"}>
                              {tx.fromAddress === selectedWallet ? '-' : '+'}
                            </Badge>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {tx.fromAddress === selectedWallet ? `To: ${tx.toAddress.substring(0, 16)}...` : `From: ${tx.fromAddress?.substring(0, 16)}...`}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center text-muted-foreground py-8">
                        Select a wallet address to view transaction history
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Activity className="h-5 w-5" />
                <span>Pending Transactions</span>
                <Badge variant="secondary">
                  {pendingTransactions.length} pending
                </Badge>
              </CardTitle>
              <CardDescription>
                Transactions waiting to be mined into blocks
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pendingTransactions.length > 0 ? (
                  pendingTransactions.map((tx, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{tx.amount} coins</span>
                        <Badge variant="outline">Pending</Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        <div>From: {tx.fromAddress?.substring(0, 20)}...</div>
                        <div>To: {tx.toAddress.substring(0, 20)}...</div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center text-muted-foreground py-8">
                    No pending transactions. Create a transaction to get started!
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}