'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { 
  Activity, 
  Heart, 
  Brain, 
  Zap, 
  Users, 
  Code, 
  Lightbulb, 
  Music, 
  Thermometer,
  Rocket,
  Target,
  Award,
  TrendingUp,
  Layers,
  Zap as Bolt,
  Shield,
  Globe
} from 'lucide-react';

export default function Presentation() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const slides = [
    {
      title: "Coherence-Enhanced Development Environment",
      subtitle: "Integrating gradus.dev & CoherenceStudio for optimal developer experience",
      content: "revolutionary"
    },
    {
      title: "The Vision",
      subtitle: "Human-scale coherence meets modern development",
      content: "vision"
    },
    {
      title: "Core Architecture",
      subtitle: "Microservices-based coherence processing platform",
      content: "architecture"
    },
    {
      title: "Real-time Coherence Metrics",
      subtitle: "Live monitoring of developer state and environment",
      content: "metrics"
    },
    {
      title: "Intelligent Insights",
      subtitle: "AI-powered recommendations for optimization",
      content: "insights"
    },
    {
      title: "Collaboration Enhancement",
      subtitle: "Team synchronization and coherence harmonization",
      content: "collaboration"
    },
    {
      title: "Advanced Analytics",
      subtitle: "Comprehensive productivity and well-being tracking",
      content: "analytics"
    },
    {
      title: "The Future of Development",
      subtitle: "Where technology meets human potential",
      content: "future"
    }
  ];

  useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, slides.length]);

  const renderSlideContent = (slideIndex: number) => {
    switch (slideIndex) {
      case 0:
        return (
          <div className="text-center space-y-6">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Coherence-Enhanced Development Environment
              </h1>
              <p className="text-xl md:text-2xl text-slate-600 dark:text-slate-400">
                Integrating gradus.dev & CoherenceStudio for optimal developer experience
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              <Card>
                <CardHeader className="text-center">
                  <Brain className="w-12 h-12 mx-auto text-purple-500" />
                  <CardTitle className="text-lg">Human-Centered</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-center">
                    Focuses on developer well-being and productivity through coherence principles
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <Activity className="w-12 h-12 mx-auto text-blue-500" />
                  <CardTitle className="text-lg">Real-time</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-center">
                    Live monitoring and adaptive optimization of development environments
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <Users className="w-12 h-12 mx-auto text-green-500" />
                  <CardTitle className="text-lg">Collaborative</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-center">
                    Enhanced team synchronization and coherence harmonization
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold">The Vision</h2>
              <p className="text-lg text-slate-600 dark:text-slate-400">
                Transforming development workflows through coherence principles
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-blue-500" />
                    Core Philosophy
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="text-sm">Human-scale coherence experiment</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="text-sm">Infrastructure + Culture integration</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="text-sm">Time, Light, Sound → Empathy = Value</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="text-sm">AI-powered optimization</span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Rocket className="w-5 h-5 text-purple-500" />
                    Innovation Highlights
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span className="text-sm">First-of-its-kind integration</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span className="text-sm">Real-time biometric feedback</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span className="text-sm">Adaptive environments</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <span className="text-sm">Machine learning insights</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold">Core Architecture</h2>
              <p className="text-lg text-slate-600 dark:text-slate-400">
                Scalable microservices design for optimal performance
              </p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Layers className="w-5 h-5 text-green-500" />
                    Frontend Layer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Next.js 15</span>
                      <Badge variant="outline">React</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>TypeScript</span>
                      <Badge variant="outline">Type-safe</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Tailwind CSS</span>
                      <Badge variant="outline">Styling</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>shadcn/ui</span>
                      <Badge variant="outline">Components</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bolt className="w-5 h-5 text-yellow-500" />
                    Backend Services
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Node.js</span>
                      <Badge variant="outline">Runtime</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Express.js</span>
                      <Badge variant="outline">Framework</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Socket.io</span>
                      <Badge variant="outline">Real-time</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Microservices</span>
                      <Badge variant="outline">Architecture</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5 text-red-500" />
                    Data Layer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>PostgreSQL</span>
                      <Badge variant="outline">Primary</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Redis</span>
                      <Badge variant="outline">Cache</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>InfluxDB</span>
                      <Badge variant="outline">Time-series</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Docker</span>
                      <Badge variant="outline">Container</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold">Real-time Coherence Metrics</h2>
              <p className="text-lg text-slate-600 dark:text-slate-400">
                Live monitoring of developer state and environmental factors
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="text-center">
                  <Activity className="w-8 h-8 mx-auto text-blue-500" />
                  <CardTitle className="text-lg">Coherence Score</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-3xl font-bold text-green-600">87/100</div>
                  <Progress value={87} className="mt-2" />
                  <p className="text-xs text-slate-500 mt-1">Optimal</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <Heart className="w-8 h-8 mx-auto text-red-500" />
                  <CardTitle className="text-lg">Heart Rate</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-3xl font-bold text-slate-700">72 bpm</div>
                  <Progress value={80} className="mt-2" />
                  <p className="text-xs text-slate-500 mt-1">Normal</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <Brain className="w-8 h-8 mx-auto text-purple-500" />
                  <CardTitle className="text-lg">Focus Level</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-3xl font-bold text-purple-600">85%</div>
                  <Progress value={85} className="mt-2" />
                  <p className="text-xs text-slate-500 mt-1">High</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <Zap className="w-8 h-8 mx-auto text-yellow-500" />
                  <CardTitle className="text-lg">Energy Level</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-3xl font-bold text-yellow-600">78%</div>
                  <Progress value={78} className="mt-2" />
                  <p className="text-xs text-slate-500 mt-1">Stable</p>
                </CardContent>
              </Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>Multi-modal Data Integration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <Lightbulb className="w-6 h-6 mx-auto text-yellow-500 mb-2" />
                    <h4 className="font-semibold">Light</h4>
                    <p className="text-sm">Optimal lighting conditions</p>
                  </div>
                  <div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                    <Music className="w-6 h-6 mx-auto text-blue-500 mb-2" />
                    <h4 className="font-semibold">Sound</h4>
                    <p className="text-sm">Balanced ambient noise</p>
                  </div>
                  <div className="text-center p-4 bg-red-50 dark:bg-red-950 rounded-lg">
                    <Thermometer className="w-6 h-6 mx-auto text-red-500 mb-2" />
                    <h4 className="font-semibold">Temperature</h4>
                    <p className="text-sm">Comfortable climate</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold">Intelligent Insights</h2>
              <p className="text-lg text-slate-600 dark:text-slate-400">
                AI-powered recommendations for continuous optimization
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5 text-purple-500" />
                    Machine Learning Engine
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Pattern Recognition</span>
                      <Badge variant="default">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Predictive Analytics</span>
                      <Badge variant="default">Enabled</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Personalization</span>
                      <Badge variant="default">Adaptive</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Real-time Processing</span>
                      <Badge variant="default">Live</Badge>
                    </div>
                  </div>
                  <Separator />
                  <div className="text-center">
                    <p className="text-sm text-slate-600">
                      Accuracy: <span className="font-bold text-green-600">94%</span>
                    </p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-green-500" />
                    Smart Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                      <h4 className="font-semibold text-sm text-blue-900 dark:text-blue-100">Break Optimization</h4>
                      <p className="text-xs text-blue-700 dark:text-blue-300">
                        Take a break in 25 minutes to maintain optimal focus
                      </p>
                    </div>
                    <div className="p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                      <h4 className="font-semibold text-sm text-green-900 dark:text-green-100">Environment Tuning</h4>
                      <p className="text-xs text-green-700 dark:text-green-300">
                        Adjust workspace lighting to reduce eye strain
                      </p>
                    </div>
                    <div className="p-3 bg-purple-50 dark:bg-purple-950 rounded-lg">
                      <h4 className="font-semibold text-sm text-purple-900 dark:text-purple-100">Team Synchronization</h4>
                      <p className="text-xs text-purple-700 dark:text-purple-300">
                        Your team is ready for a synchronization session
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold">Collaboration Enhancement</h2>
              <p className="text-lg text-slate-600 dark:text-slate-400">
                Team synchronization and coherence harmonization
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-blue-500" />
                    Team Dynamics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Synchronization</span>
                      <Badge variant="secondary">92%</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Flow State</span>
                      <Badge variant="default">High</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Empathy Level</span>
                      <Badge variant="outline">88%</Badge>
                    </div>
                  </div>
                  <Separator />
                  <div className="text-center">
                    <p className="text-lg font-bold text-blue-600">Harmonized</p>
                    <p className="text-xs text-slate-500">Team Status</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Code className="w-5 h-5 text-green-500" />
                    Pair Programming
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Coherence Match</span>
                      <Badge variant="default">95%</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Code Quality</span>
                      <Badge variant="default">Excellent</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Learning Rate</span>
                      <Badge variant="secondary">High</Badge>
                    </div>
                  </div>
                  <Button className="w-full" variant="outline">
                    Start Session
                  </Button>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="w-5 h-5 text-purple-500" />
                    Communication
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Video Conference</span>
                      <Badge variant="default">Ready</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Real-time Chat</span>
                      <Badge variant="default">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Screen Sharing</span>
                      <Badge variant="secondary">Available</Badge>
                    </div>
                  </div>
                  <Button className="w-full" variant="outline">
                    Join Team Room
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold">Advanced Analytics</h2>
              <p className="text-lg text-slate-600 dark:text-slate-400">
                Comprehensive productivity and well-being tracking
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="text-center">
                  <Award className="w-8 h-8 mx-auto text-yellow-500" />
                  <CardTitle className="text-lg">Daily Average</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-2xl font-bold text-green-600">84%</div>
                  <p className="text-sm text-slate-500">Coherence Score</p>
                  <div className="text-xs text-green-600">↑ 5% from yesterday</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <Brain className="w-8 h-8 mx-auto text-purple-500" />
                  <CardTitle className="text-lg">Focus Time</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-2xl font-bold text-blue-600">6.2h</div>
                  <p className="text-sm text-slate-500">Today</p>
                  <div className="text-xs text-blue-600">↑ 1.2h from average</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <Heart className="w-8 h-8 mx-auto text-red-500" />
                  <CardTitle className="text-lg">Stress Reduction</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-2xl font-bold text-purple-600">32%</div>
                  <p className="text-sm text-slate-500">This Week</p>
                  <div className="text-xs text-purple-600">↑ 8% improvement</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <TrendingUp className="w-8 h-8 mx-auto text-green-500" />
                  <CardTitle className="text-lg">Productivity</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-2xl font-bold text-orange-600">94%</div>
                  <p className="text-sm text-slate-500">Sprint Goal</p>
                  <div className="text-xs text-orange-600">On track</div>
                </CardContent>
              </Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>Weekly Trends</CardTitle>
                <CardDescription>Your coherence and productivity patterns</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-2 text-center">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => (
                    <div key={day} className="space-y-1">
                      <div className="text-xs text-slate-500">{day}</div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full" 
                          style={{ width: `${75 + index * 3}%` }}
                        ></div>
                      </div>
                      <div className="text-xs">{75 + index * 3}%</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 7:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold">The Future of Development</h2>
              <p className="text-lg text-slate-600 dark:text-slate-400">
                Where technology meets human potential
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Rocket className="w-5 h-5 text-blue-500" />
                    Roadmap 2024
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Q1: Beta Release</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm">Q2: Mobile App</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                      <span className="text-sm">Q3: Enterprise Features</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                      <span className="text-sm">Q4: Global Expansion</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-green-500" />
                    Success Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Developer Productivity</span>
                      <Badge variant="default">+40%</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Team Collaboration</span>
                      <Badge variant="default">+60%</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Well-being Improvement</span>
                      <Badge variant="default">+50%</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Project Success Rate</span>
                      <Badge variant="default">+35%</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle className="text-center">Join the Coherence Revolution</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-lg mb-4">
                  Experience the future of development with human-scale coherence
                </p>
                <div className="flex justify-center gap-4">
                  <Button size="lg">Get Started</Button>
                  <Button size="lg" variant="outline">Learn More</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
              Coherence-Enhanced Development Environment
            </h1>
            <p className="text-slate-600 dark:text-slate-400">
              Prototype Presentation
            </p>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsAutoPlaying(!isAutoPlaying)}
            >
              {isAutoPlaying ? 'Pause' : 'Play'}
            </Button>
            <div className="flex items-center gap-2">
              {slides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    currentSlide === index ? 'bg-blue-500' : 'bg-slate-300'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 mb-8">
          {renderSlideContent(currentSlide)}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            onClick={() => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)}
          >
            Previous
          </Button>
          <div className="text-sm text-slate-500">
            {currentSlide + 1} of {slides.length}
          </div>
          <Button
            onClick={() => setCurrentSlide((prev) => (prev + 1) % slides.length)}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}