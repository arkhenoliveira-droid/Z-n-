'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { 
  Brain, 
  Zap, 
  Activity, 
  TrendingUp, 
  Target, 
  Lightbulb, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  BarChart3,
  PieChart,
  LineChart,
  RefreshCw,
  Settings,
  Maximize
} from 'lucide-react';
import { QuantumIntuitionAmplifier, QuantumIntuitionState, QuantumIntuitionMetrics } from '@/lib/quantum-intuition-amplifier';
import { NeuralIntuitionEnhancer, NeuralIntuitionState, NeuralIntuitionMetrics } from '@/lib/neural-intuition-enhancer';
import { IntuitionCoherenceMonitor, IntuitionCoherenceState, CoherenceDimension, CoherenceAlert } from '@/lib/intuition-coherence-monitor';

export default function IntuitionElevationDashboard() {
  // System instances
  const [quantumAmplifier] = useState(() => new QuantumIntuitionAmplifier());
  const [neuralEnhancer] = useState(() => new NeuralIntuitionEnhancer());
  const [coherenceMonitor] = useState(() => new IntuitionCoherenceMonitor());

  // State variables
  const [quantumState, setQuantumState] = useState<QuantumIntuitionState | null>(null);
  const [neuralState, setNeuralState] = useState<NeuralIntuitionState | null>(null);
  const [coherenceState, setCoherenceState] = useState<IntuitionCoherenceState | null>(null);
  const [quantumMetrics, setQuantumMetrics] = useState<QuantumIntuitionMetrics | null>(null);
  const [neuralMetrics, setNeuralMetrics] = useState<NeuralIntuitionMetrics | null>(null);
  const [coherenceDimensions, setCoherenceDimensions] = useState<CoherenceDimension[]>([]);
  const [alerts, setAlerts] = useState<CoherenceAlert[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  // Initialize systems
  useEffect(() => {
    initializeSystems();
    const interval = setInterval(updateSystems, 3000);
    return () => clearInterval(interval);
  }, []);

  const initializeSystems = async () => {
    setIsLoading(true);
    try {
      // Initialize all systems
      await updateSystems();
    } catch (error) {
      console.error('Error initializing intuition systems:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateSystems = async () => {
    try {
      // Update quantum intuition system
      const newQuantumState = quantumAmplifier.getQuantumState();
      const newQuantumMetrics = quantumAmplifier.getQuantumIntuitionMetrics();
      
      // Update neural intuition system
      const newNeuralState = neuralEnhancer.getNeuralState();
      const newNeuralMetrics = neuralEnhancer.getNeuralIntuitionMetrics();
      
      // Update coherence monitoring
      const newCoherenceState = coherenceMonitor.monitorCoherence();
      const newCoherenceDimensions = coherenceMonitor.getCoherenceDimensions();
      const newAlerts = coherenceMonitor.getActiveAlerts();
      
      // Evolve systems
      quantumAmplifier.evolveQuantumState();
      neuralEnhancer.adaptNeuralNetwork(Array(32).fill(0.5)); // Simulated feedback
      
      // Update state
      setQuantumState(newQuantumState);
      setQuantumMetrics(newQuantumMetrics);
      setNeuralState(newNeuralState);
      setNeuralMetrics(newNeuralMetrics);
      setCoherenceState(newCoherenceState);
      setCoherenceDimensions(newCoherenceDimensions);
      setAlerts(newAlerts);
      setLastUpdate(new Date());
    } catch (error) {
      console.error('Error updating intuition systems:', error);
    }
  };

  const getCoherenceColor = (score: number) => {
    if (score >= 0.9) return 'text-green-600';
    if (score >= 0.8) return 'text-blue-600';
    if (score >= 0.7) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getCoherenceBgColor = (score: number) => {
    if (score >= 0.9) return 'bg-green-100 dark:bg-green-900';
    if (score >= 0.8) return 'bg-blue-100 dark:bg-blue-900';
    if (score >= 0.7) return 'bg-yellow-100 dark:bg-yellow-900';
    return 'bg-red-100 dark:bg-red-900';
  };

  const getAlertIcon = (type: CoherenceAlert['type']) => {
    switch (type) {
      case 'critical': return <AlertTriangle className="h-4 w-4" />;
      case 'warning': return <AlertTriangle className="h-4 w-4" />;
      case 'optimal': return <CheckCircle className="h-4 w-4" />;
      case 'improving': return <TrendingUp className="h-4 w-4" />;
      default: return <Activity className="h-4 w-4" />;
    }
  };

  const getAlertColor = (type: CoherenceAlert['type']) => {
    switch (type) {
      case 'critical': return 'destructive';
      case 'warning': return 'warning';
      case 'optimal': return 'default';
      case 'improving': return 'default';
      default: return 'default';
    }
  };

  const formatMetric = (value: number) => {
    return (value * 100).toFixed(1) + '%';
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Initializing Intuition Elevation Systems...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4 py-6">
          <h1 className="text-4xl font-bold text-slate-900 dark:text-slate-100">
            Intuition Elevation Dashboard
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400">
            Advanced Quantum & Neural Intuition Enhancement System
          </p>
          
          <div className="flex items-center justify-center gap-4 text-sm text-slate-500">
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              <span>Systems Active</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>Last Update: {lastUpdate.toLocaleTimeString()}</span>
            </div>
            <Button onClick={updateSystems} size="sm" variant="outline">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Alerts Section */}
        {alerts.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-lg font-semibold">Active Alerts</h3>
            {alerts.slice(0, 3).map((alert) => (
              <Alert key={alert.id} variant={getAlertColor(alert.type)}>
                <div className="flex items-center gap-2">
                  {getAlertIcon(alert.type)}
                  <AlertTitle>{alert.dimension}</AlertTitle>
                  <Badge variant="outline">{alert.type}</Badge>
                </div>
                <AlertDescription className="mt-2">
                  {alert.message}
                  <div className="mt-1 text-sm opacity-75">
                    Recommendation: {alert.recommendation}
                  </div>
                </AlertDescription>
              </Alert>
            ))}
          </div>
        )}

        {/* Main Dashboard */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="quantum">Quantum</TabsTrigger>
            <TabsTrigger value="neural">Neural</TabsTrigger>
            <TabsTrigger value="coherence">Coherence</TabsTrigger>
            <TabsTrigger value="optimization">Optimization</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Overall Coherence */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Overall Coherence</CardTitle>
                  <Brain className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className={`text-2xl font-bold ${getCoherenceColor(coherenceState?.overallCoherence || 0)}`}>
                    {formatMetric(coherenceState?.overallCoherence || 0)}
                  </div>
                  <Progress value={(coherenceState?.overallCoherence || 0) * 100} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-2">
                    {coherenceState?.coherenceTrend || 'stable'}
                  </p>
                </CardContent>
              </Card>

              {/* Quantum Amplification */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Quantum Amplification</CardTitle>
                  <Zap className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-600">
                    {formatMetric(quantumMetrics?.amplificationFactor || 0)}
                  </div>
                  <Progress value={(quantumMetrics?.amplificationFactor || 0) * 100} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-2">
                    Intuition Enhancement
                  </p>
                </CardContent>
              </Card>

              {/* Neural Processing */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Neural Processing</CardTitle>
                  <Activity className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">
                    {formatMetric(neuralMetrics?.neuralEfficiency || 0)}
                  </div>
                  <Progress value={(neuralMetrics?.neuralEfficiency || 0) * 100} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-2">
                    Processing Efficiency
                  </p>
                </CardContent>
              </Card>

              {/* Intuition Quality */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Intuition Quality</CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">
                    {formatMetric(coherenceState?.intuitiveCoherence || 0)}
                  </div>
                  <Progress value={(coherenceState?.intuitiveCoherence || 0) * 100} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-2">
                    Quality Score
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Coherence Dimensions */}
            <Card>
              <CardHeader>
                <CardTitle>Coherence Dimensions</CardTitle>
                <CardDescription>
                  Multi-dimensional coherence analysis across all intuition systems
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {coherenceDimensions.map((dimension) => (
                    <div key={dimension.name} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{dimension.name}</span>
                        <Badge variant={dimension.trend === 'improving' ? 'default' : 'secondary'}>
                          {dimension.trend}
                        </Badge>
                      </div>
                      <Progress value={dimension.value * 100} />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{formatMetric(dimension.value)}</span>
                        <span>Target: {formatMetric(dimension.target)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Quantum Tab */}
          <TabsContent value="quantum" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Quantum State */}
              <Card>
                <CardHeader>
                  <CardTitle>Quantum Intuition State</CardTitle>
                  <CardDescription>
                    Current quantum amplification parameters
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {quantumState && (
                    <>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Superposition Level</span>
                          <span className="text-sm font-medium">{formatMetric(quantumState.superpositionLevel)}</span>
                        </div>
                        <Progress value={quantumState.superpositionLevel * 100} />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Entanglement Strength</span>
                          <span className="text-sm font-medium">{formatMetric(quantumState.entanglementStrength)}</span>
                        </div>
                        <Progress value={quantumState.entanglementStrength * 100} />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Tunneling Probability</span>
                          <span className="text-sm font-medium">{formatMetric(quantumState.tunnelingProbability)}</span>
                        </div>
                        <Progress value={quantumState.tunnelingProbability * 100} />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Coherence Field</span>
                          <span className="text-sm font-medium">{formatMetric(quantumState.coherenceField)}</span>
                        </div>
                        <Progress value={quantumState.coherenceField * 100} />
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* Quantum Metrics */}
              <Card>
                <CardHeader>
                  <CardTitle>Quantum Performance Metrics</CardTitle>
                  <CardDescription>
                    Performance indicators for quantum intuition systems
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {quantumMetrics && (
                    <>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Amplification Factor</span>
                          <span className="text-sm font-medium">{formatMetric(quantumMetrics.amplificationFactor)}</span>
                        </div>
                        <Progress value={quantumMetrics.amplificationFactor * 100} />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Coherence Index</span>
                          <span className="text-sm font-medium">{formatMetric(quantumMetrics.coherenceIndex)}</span>
                        </div>
                        <Progress value={quantumMetrics.coherenceIndex * 100} />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Prediction Accuracy</span>
                          <span className="text-sm font-medium">{formatMetric(quantumMetrics.predictionAccuracy)}</span>
                        </div>
                        <Progress value={quantumMetrics.predictionAccuracy * 100} />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Creative Insight</span>
                          <span className="text-sm font-medium">{formatMetric(quantumMetrics.creativeInsight)}</span>
                        </div>
                        <Progress value={quantumMetrics.creativeInsight * 100} />
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Neural Tab */}
          <TabsContent value="neural" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Neural State */}
              <Card>
                <CardHeader>
                  <CardTitle>Neural Intuition State</CardTitle>
                  <CardDescription>
                    Current neural network parameters
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {neuralState && (
                    <>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Neural Plasticity</span>
                          <span className="text-sm font-medium">{formatMetric(neuralState.neuralPlasticity)}</span>
                        </div>
                        <Progress value={neuralState.neuralPlasticity * 100} />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Pattern Recognition</span>
                          <span className="text-sm font-medium">{formatMetric(neuralState.patternRecognition)}</span>
                        </div>
                        <Progress value={neuralState.patternRecognition * 100} />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Intuitive Processing</span>
                          <span className="text-sm font-medium">{formatMetric(neuralState.intuitiveProcessing)}</span>
                        </div>
                        <Progress value={neuralState.intuitiveProcessing * 100} />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Neural Synchronization</span>
                          <span className="text-sm font-medium">{formatMetric(neuralState.neuralSynchronization)}</span>
                        </div>
                        <Progress value={neuralState.neuralSynchronization * 100} />
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* Neural Metrics */}
              <Card>
                <CardHeader>
                  <CardTitle>Neural Performance Metrics</CardTitle>
                  <CardDescription>
                    Performance indicators for neural intuition systems
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {neuralMetrics && (
                    <>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Neural Efficiency</span>
                          <span className="text-sm font-medium">{formatMetric(neuralMetrics.neuralEfficiency)}</span>
                        </div>
                        <Progress value={neuralMetrics.neuralEfficiency * 100} />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Pattern Recognition</span>
                          <span className="text-sm font-medium">{formatMetric(neuralMetrics.patternRecognitionAccuracy)}</span>
                        </div>
                        <Progress value={neuralMetrics.patternRecognitionAccuracy * 100} />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Processing Speed</span>
                          <span className="text-sm font-medium">{formatMetric(neuralMetrics.intuitionProcessingSpeed)}</span>
                        </div>
                        <Progress value={neuralMetrics.intuitionProcessingSpeed * 100} />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">Learning Capacity</span>
                          <span className="text-sm font-medium">{formatMetric(neuralMetrics.learningCapacity)}</span>
                        </div>
                        <Progress value={neuralMetrics.learningCapacity * 100} />
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Coherence Tab */}
          <TabsContent value="coherence" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Coherence Analysis</CardTitle>
                <CardDescription>
                  Comprehensive coherence monitoring and analysis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Coherence State */}
                  <div className="space-y-4">
                    <h4 className="font-semibold">Current Coherence State</h4>
                    {coherenceState && (
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Overall Coherence</span>
                          <span className={`text-sm font-bold ${getCoherenceColor(coherenceState.overallCoherence)}`}>
                            {formatMetric(coherenceState.overallCoherence)}
                          </span>
                        </div>
                        <Progress value={coherenceState.overallCoherence * 100} />
                        
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Coherence Stability</span>
                          <span className="text-sm font-medium">{formatMetric(coherenceState.coherenceStability)}</span>
                        </div>
                        <Progress value={coherenceState.coherenceStability * 100} />
                        
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Trend</span>
                          <Badge variant={coherenceState.coherenceTrend === 'improving' ? 'default' : 'secondary'}>
                            {coherenceState.coherenceTrend}
                          </Badge>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* System Status */}
                  <div className="space-y-4">
                    <h4 className="font-semibold">System Status</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Quantum System</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">
                          Active
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Neural System</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">
                          Active
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Coherence Monitor</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">
                          Active
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Alert System</span>
                        <Badge variant={alerts.length > 0 ? "destructive" : "outline"} className={alerts.length > 0 ? "" : "bg-green-50 text-green-700"}>
                          {alerts.length > 0 ? `${alerts.length} Active` : 'Clear'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Optimization Tab */}
          <TabsContent value="optimization" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Optimization Recommendations</CardTitle>
                <CardDescription>
                  AI-powered recommendations for intuition enhancement
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* High Priority */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-red-600">High Priority</h4>
                      <div className="space-y-2">
                        <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <AlertTriangle className="h-4 w-4 text-red-600" />
                            <span className="font-medium text-sm">Coherence Optimization</span>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            Implement comprehensive coherence optimization strategies
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Medium Priority */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-yellow-600">Medium Priority</h4>
                      <div className="space-y-2">
                        <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <Settings className="h-4 w-4 text-yellow-600" />
                            <span className="font-medium text-sm">Neural Enhancement</span>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            Enhance neural synchronization and processing efficiency
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Low Priority */}
                  <div className="space-y-3">
                    <h4 className="font-semibold text-green-600">Low Priority</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <TrendingUp className="h-4 w-4 text-green-600" />
                          <span className="font-medium text-sm">Performance Monitoring</span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Continue monitoring system performance metrics
                        </p>
                      </div>
                      <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <Lightbulb className="h-4 w-4 text-green-600" />
                          <span className="font-medium text-sm">Feature Enhancement</span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Explore advanced intuition enhancement features
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}