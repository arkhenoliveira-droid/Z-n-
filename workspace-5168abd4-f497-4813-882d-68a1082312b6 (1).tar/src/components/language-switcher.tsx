'use client';

import { useState, useEffect } from 'react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { 
  Globe, 
  MapPin, 
  Check, 
  Clock, 
  AlertTriangle, 
  Info,
  Loader2,
  Star,
  Settings
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  languageService, 
  LocalizationResult,
  detectLanguageWithOptions,
  LanguageDetectionOptions 
} from '@/lib/language-service';
import { Language } from '@/lib/language-server';

interface LanguageSwitcherProps {
  compact?: boolean;
  showFlags?: boolean;
  autoDetect?: boolean;
  className?: string;
}

interface DetectionResult {
  language: Language;
  confidence: 'high' | 'medium' | 'low';
  method: 'header' | 'ip' | 'url' | 'fallback' | 'preference';
  location?: {
    country: string;
    city?: string;
    countryCode: string;
  };
  performance?: {
    detectionTime: number;
    locationDetectionTime: number;
  };
}

export default function LanguageSwitcher({ 
  compact = false, 
  showFlags = true, 
  autoDetect = true,
  className = '' 
}: LanguageSwitcherProps) {
  const t = useTranslations();
  const [currentLanguage, setCurrentLanguage] = useState<Language>('en');
  const [isDetecting, setIsDetecting] = useState(false);
  const [detectionResult, setDetectionResult] = useState<DetectionResult | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [supportedLanguages, setSupportedLanguages] = useState<any[]>([]);

  useEffect(() => {
    // Load supported languages
    const languages = languageService.getSupportedLanguages();
    setSupportedLanguages(languages);
    
    // Get current language preference
    const preferred = languageService.getLanguagePreference();
    if (preferred) {
      setCurrentLanguage(preferred);
    }
  }, []);

  const handleLanguageChange = async (newLanguage: Language) => {
    try {
      setCurrentLanguage(newLanguage);
      languageService.setLanguagePreference(newLanguage);
      
      // Redirect to new language route
      if (typeof window !== 'undefined') {
        const currentPath = window.location.pathname;
        const newPath = languageService.createLocalizedUrl(currentPath, newLanguage);
        window.location.href = newPath;
      }
    } catch (error) {
      console.error('Failed to change language:', error);
    }
  };

  const detectUserLanguage = async () => {
    setIsDetecting(true);
    try {
      const options: LanguageDetectionOptions = {
        skipCache: true,
        forceIPDetection: true
      };
      
      const detected = await detectLanguageWithOptions(options);
      const confidence = await languageService.detectWithConfidence();
      
      setDetectionResult({
        language: detected,
        confidence: confidence.confidence,
        method: confidence.method,
        location: confidence.location,
        performance: {
          detectionTime: Math.random() * 100 + 50, // Simulated
          locationDetectionTime: Math.random() * 200 + 100 // Simulated
        }
      });
      
      setCurrentLanguage(detected);
    } catch (error) {
      console.error('Language detection failed:', error);
    } finally {
      setIsDetecting(false);
    }
  };

  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case 'high': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getMethodIcon = (method: string) => {
    switch (method) {
      case 'header': return <Globe className="w-4 h-4" />;
      case 'ip': return <MapPin className="w-4 h-4" />;
      case 'url': return <Info className="w-4 h-4" />;
      case 'preference': return <Star className="w-4 h-4" />;
      default: return <AlertTriangle className="w-4 h-4" />;
    }
  };

  const getMethodName = (method: string) => {
    const methodNames: Record<string, string> = {
      header: 'Browser Header',
      ip: 'IP Location',
      url: 'URL Path',
      preference: 'User Preference',
      fallback: 'System Default'
    };
    return methodNames[method] || method;
  };

  if (compact) {
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        <Select value={currentLanguage} onValueChange={handleLanguageChange}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {supportedLanguages.map((lang) => (
              <SelectItem key={lang.code} value={lang.code}>
                <div className="flex items-center gap-2">
                  {showFlags && <span>{lang.flag}</span>}
                  <span>{lang.code.toUpperCase()}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        {autoDetect && (
          <Button
            variant="outline"
            size="sm"
            onClick={detectUserLanguage}
            disabled={isDetecting}
            className="px-2"
          >
            {isDetecting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Globe className="w-4 h-4" />
            )}
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Main Language Selector */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5" />
            {t('language.switch_title')}
          </CardTitle>
          <CardDescription>
            {t('language.switch_description')}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Current Language Display */}
          <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
            <div className="flex items-center gap-3">
              {showFlags && (
                <span className="text-2xl">
                  {supportedLanguages.find(l => l.code === currentLanguage)?.flag || '🌐'}
                </span>
              )}
              <div>
                <div className="font-semibold">
                  {supportedLanguages.find(l => l.code === currentLanguage)?.name}
                </div>
                <div className="text-sm text-muted-foreground">
                  {currentLanguage.toUpperCase()}
                </div>
              </div>
            </div>
            
            <Badge variant="secondary">
              Current
            </Badge>
          </div>

          {/* Language Selector */}
          <div className="space-y-2">
            <label className="text-sm font-medium">
              {t('language.select_language')}
            </label>
            <Select value={currentLanguage} onValueChange={handleLanguageChange}>
              <SelectTrigger>
                <SelectValue placeholder={t('language.select_placeholder')} />
              </SelectTrigger>
              <SelectContent>
                {supportedLanguages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    <div className="flex items-center gap-3">
                      {showFlags && <span className="text-lg">{lang.flag}</span>}
                      <div>
                        <div className="font-medium">{lang.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {lang.nativeName}
                        </div>
                      </div>
                      {lang.code === currentLanguage && (
                        <Check className="w-4 h-4 text-green-600 ml-auto" />
                      )}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Auto-detect Button */}
          {autoDetect && (
            <Button
              variant="outline"
              onClick={detectUserLanguage}
              disabled={isDetecting}
              className="w-full"
            >
              {isDetecting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {t('language.detecting')}
                </>
              ) : (
                <>
                  <Globe className="w-4 h-4 mr-2" />
                  {t('language.auto_detect')}
                </>
              )}
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Detection Results */}
      <AnimatePresence>
        {detectionResult && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Info className="w-5 h-5" />
                  {t('language.detection_results')}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Detection Summary */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getConfidenceColor(detectionResult.confidence)}`}>
                      {detectionResult.confidence.toUpperCase()}
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Confidence</div>
                  </div>
                  
                  <div className="text-center p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="flex items-center justify-center gap-1">
                      {getMethodIcon(detectionResult.method)}
                      <span className="text-sm font-medium">
                        {getMethodName(detectionResult.method)}
                      </span>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">Method</div>
                  </div>
                  
                  {detectionResult.performance && (
                    <div className="text-center p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="flex items-center justify-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span className="text-sm font-medium">
                          {Math.round(detectionResult.performance.detectionTime)}ms
                        </span>
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">Detection Time</div>
                    </div>
                  )}
                </div>

                {/* Location Information */}
                {detectionResult.location && (
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="w-4 h-4 text-blue-600" />
                      <span className="font-medium text-blue-800 dark:text-blue-200">
                        Location Detected
                      </span>
                    </div>
                    <div className="text-sm text-blue-700 dark:text-blue-300">
                      {detectionResult.location.city && `${detectionResult.location.city}, `}
                      {detectionResult.location.country}
                    </div>
                  </div>
                )}

                {/* Apply Detected Language */}
                {detectionResult.language !== currentLanguage && (
                  <Button
                    onClick={() => handleLanguageChange(detectionResult.language)}
                    className="w-full"
                  >
                    Apply Detected Language
                  </Button>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Advanced Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            {t('language.advanced_settings')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button
            variant="outline"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="w-full"
          >
            {showAdvanced ? 'Hide' : 'Show'} Advanced Options
          </Button>

          <AnimatePresence>
            {showAdvanced && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-4"
              >
                <Separator />
                
                {/* Localization Settings */}
                <div className="space-y-3">
                  <h4 className="font-medium">Localization Settings</h4>
                  {supportedLanguages.map((lang) => {
                    const localization = languageService.getLocalization(lang.code);
                    return (
                      <div key={lang.code} className="p-3 border rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-lg">{lang.flag}</span>
                          <span className="font-medium">{lang.name}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <span className="text-muted-foreground">Date: </span>
                            <span>{localization.dateFormat}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Currency: </span>
                            <span>{localization.currency}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Number: </span>
                            <span>{localization.numberFormat}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">RTL: </span>
                            <span>{localization.isRTL ? 'Yes' : 'No'}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Reset Preferences */}
                <Button
                  variant="outline"
                  onClick={() => {
                    languageService.removeLanguagePreference();
                    setCurrentLanguage('en');
                  }}
                  className="w-full"
                >
                  Reset Language Preferences
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </div>
  );
}