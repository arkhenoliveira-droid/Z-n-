'use client'

import * as React from 'react'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/enhanced-button'
import { cn } from '@/lib/utils'
import { designSystem } from '@/lib/design-system'
import { motion, AnimatePresence } from 'framer-motion'
import { MoreHorizontal, X, Maximize2, Minimize2 } from 'lucide-react'

export interface EnhancedCardProps extends React.HTMLAttributes<HTMLDivElement> {
  // Layout variants
  variant?: 'default' | 'elevated' | 'outlined' | 'glass' | 'gradient'
  
  // Sizing
  size?: 'sm' | 'md' | 'lg' | 'xl'
  
  // Header
  title?: React.ReactNode
  subtitle?: React.ReactNode
  description?: React.ReactNode
  
  // Actions
  actions?: React.ReactNode
  actionPosition?: 'top' | 'bottom' | 'both'
  
  // Status
  status?: 'default' | 'success' | 'warning' | 'error' | 'info'
  statusText?: string
  
  // Interactive features
  hoverable?: boolean
  expandable?: boolean
  expanded?: boolean
  onExpandChange?: (expanded: boolean) => void
  
  // Loading state
  loading?: boolean
  loadingContent?: React.ReactNode
  
  // Empty state
  empty?: boolean
  emptyContent?: React.ReactNode
  
  // Footer
  footer?: React.ReactNode
  
  // Badge
  badge?: React.ReactNode
  badgePosition?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right'
  
  // Menu
  menu?: React.ReactNode
  menuPosition?: 'top-right' | 'top-left'
  
  // Custom styling
  gradient?: string
  border?: boolean
  shadow?: boolean
  
  // Animation
  animation?: 'none' | 'fade' | 'slide' | 'scale'
  
  // Grid layout
  grid?: boolean
  gridCols?: 1 | 2 | 3 | 4 | 6 | 12
  
  // Overflow handling
  scrollable?: boolean
  maxHeight?: string
}

const variantClasses = {
  default: 'bg-card text-card-foreground border border-border',
  elevated: 'bg-card text-card-foreground border-0 shadow-lg',
  outlined: 'bg-background text-foreground border-2 border-border',
  glass: 'bg-background/80 backdrop-blur-sm border border-border/50',
  gradient: 'border-0 text-white'
}

const sizeClasses = {
  sm: 'p-3',
  md: 'p-6',
  lg: 'p-8',
  xl: 'p-10'
}

const statusClasses = {
  default: '',
  success: 'border-l-4 border-l-green-500',
  warning: 'border-l-4 border-l-yellow-500',
  error: 'border-l-4 border-l-red-500',
  info: 'border-l-4 border-l-blue-500'
}

const animationVariants = {
  none: {},
  fade: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 }
  },
  slide: {
    initial: { y: 20, opacity: 0 },
    animate: { y: 0, opacity: 1 },
    exit: { y: -20, opacity: 0 }
  },
  scale: {
    initial: { scale: 0.9, opacity: 0 },
    animate: { scale: 1, opacity: 1 },
    exit: { scale: 0.9, opacity: 0 }
  }
}

export const EnhancedCard = React.forwardRef<HTMLDivElement, EnhancedCardProps>(
  ({
    className,
    variant = 'default',
    size = 'md',
    title,
    subtitle,
    description,
    actions,
    actionPosition = 'bottom',
    status = 'default',
    statusText,
    hoverable = false,
    expandable = false,
    expanded = false,
    onExpandChange,
    loading = false,
    loadingContent,
    empty = false,
    emptyContent,
    footer,
    badge,
    badgePosition = 'top-right',
    menu,
    menuPosition = 'top-right',
    gradient,
    border = true,
    shadow = true,
    animation = 'fade',
    grid = false,
    gridCols = 1,
    scrollable = false,
    maxHeight = '400px',
    children,
    ...props
  }, ref) => {
    const [isExpanded, setIsExpanded] = React.useState(expanded)
    const [isHovered, setIsHovered] = React.useState(false)

    React.useEffect(() => {
      setIsExpanded(expanded)
    }, [expanded])

    const handleExpand = () => {
      const newExpanded = !isExpanded
      setIsExpanded(newExpanded)
      onExpandChange?.(newExpanded)
    }

    const getCardClasses = () => {
      const baseClasses = cn(
        'relative rounded-lg transition-all duration-200',
        variantClasses[variant],
        sizeClasses[size],
        statusClasses[status],
        !border && 'border-0',
        !shadow && 'shadow-none',
        hoverable && 'hover:shadow-lg cursor-pointer transition-shadow duration-200',
        grid && `grid grid-cols-${gridCols} gap-4`,
        className
      )

      const gradientClasses = gradient 
        ? `bg-gradient-to-br ${gradient}`
        : ''

      return cn(baseClasses, gradientClasses)
    }

    const renderHeader = () => {
      if (!title && !subtitle && !description && !menu) return null

      return (
        <CardHeader className={cn(
          'pb-4',
          actions && actionPosition === 'top' && 'pb-2'
        )}>
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              {title && (
                <CardTitle className={cn(
                  'text-lg font-semibold truncate',
                  subtitle && 'mb-1'
                )}>
                  {title}
                </CardTitle>
              )}
              {subtitle && (
                <div className="text-sm text-muted-foreground truncate">
                  {subtitle}
                </div>
              )}
              {description && (
                <CardDescription className="mt-2">
                  {description}
                </CardDescription>
              )}
            </div>
            
            {/* Menu */}
            {menu && (
              <div className={cn(
                'flex-shrink-0 ml-2',
                menuPosition === 'top-left' && 'order-first mr-2'
              )}>
                {menu}
              </div>
            )}
            
            {/* Expand/Collapse Button */}
            {expandable && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleExpand}
                className="flex-shrink-0 ml-2"
              >
                {isExpanded ? (
                  <Minimize2 className="w-4 h-4" />
                ) : (
                  <Maximize2 className="w-4 h-4" />
                )}
              </Button>
            )}
          </div>
          
          {/* Status Badge */}
          {status !== 'default' && statusText && (
            <div className="mt-2">
              <Badge variant={status === 'success' ? 'default' : 'secondary'}>
                {statusText}
              </Badge>
            </div>
          )}
        </CardHeader>
      )
    }

    const renderContent = () => {
      if (loading) {
        return (
          <CardContent className="py-8">
            <div className="flex items-center justify-center">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
                <p className="text-sm text-muted-foreground">
                  {loadingContent || 'Loading...'}
                </p>
              </div>
            </div>
          </CardContent>
        )
      }

      if (empty) {
        return (
          <CardContent className="py-8">
            <div className="flex items-center justify-center">
              <div className="text-center">
                {emptyContent || (
                  <>
                    <div className="text-4xl mb-2">📭</div>
                    <p className="text-sm text-muted-foreground">No data available</p>
                  </>
                )}
              </div>
            </div>
          </CardContent>
        )
      }

      return (
        <CardContent className={cn(
          scrollable && 'overflow-y-auto',
          scrollable && maxHeight && `max-h-[${maxHeight}]`
        )}>
          {children}
        </CardContent>
      )
    }

    const renderActions = () => {
      if (!actions) return null

      return (
        <div className={cn(
          'px-6 pt-4 border-t border-border',
          actionPosition === 'top' && 'border-t-0 pt-0 pb-4',
          actionPosition === 'both' && 'border-t pt-4'
        )}>
          <div className="flex items-center gap-2">
            {actions}
          </div>
        </div>
      )
    }

    const renderFooter = () => {
      if (!footer) return null

      return (
        <CardFooter className="pt-4 border-t border-border">
          {footer}
        </CardFooter>
      )
    }

    const renderBadge = () => {
      if (!badge) return null

      const positionClasses = {
        'top-left': 'absolute top-2 left-2',
        'top-right': 'absolute top-2 right-2',
        'bottom-left': 'absolute bottom-2 left-2',
        'bottom-right': 'absolute bottom-2 right-2'
      }

      return (
        <div className={positionClasses[badgePosition]}>
          {badge}
        </div>
      )
    }

    const MotionCard = motion(Card)

    return (
      <MotionCard
        ref={ref}
        className={getCardClasses()}
        {...animationVariants[animation]}
        {...(hoverable && {
          onHoverStart: () => setIsHovered(true),
          onHoverEnd: () => setIsHovered(false)
        })}
        {...props}
      >
        {/* Badge */}
        {renderBadge()}
        
        {/* Header */}
        {renderHeader()}
        
        {/* Top Actions */}
        {actions && actionPosition === 'top' && renderActions()}
        
        {/* Content */}
        {renderContent()}
        
        {/* Bottom Actions */}
        {actions && (actionPosition === 'bottom' || actionPosition === 'both') && renderActions()}
        
        {/* Footer */}
        {renderFooter()}
        
        {/* Hover Overlay */}
        {hoverable && (
          <AnimatePresence>
            {isHovered && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/5 rounded-lg pointer-events-none"
              />
            )}
          </AnimatePresence>
        )}
      </MotionCard>
    )
  }
)

EnhancedCard.displayName = 'EnhancedCard'

// Card Grid Component
export interface CardGridProps {
  children: React.ReactNode
  cols?: 1 | 2 | 3 | 4 | 6 | 12
  gap?: 'sm' | 'md' | 'lg'
  className?: string
}

export const CardGrid: React.FC<CardGridProps> = ({
  children,
  cols = 3,
  gap = 'md',
  className
}) => {
  const gapClasses = {
    sm: 'gap-4',
    md: 'gap-6',
    lg: 'gap-8'
  }

  return (
    <div className={cn(
      'grid',
      `grid-cols-1 md:grid-cols-${Math.min(cols, 6)} lg:grid-cols-${cols}`,
      gapClasses[gap],
      className
    )}>
      {children}
    </div>
  )
}

CardGrid.displayName = 'CardGrid'

// Card Stack Component
export interface CardStackProps {
  children: React.ReactNode
  spacing?: 'sm' | 'md' | 'lg'
  className?: string
}

export const CardStack: React.FC<CardStackProps> = ({
  children,
  spacing = 'md',
  className
}) => {
  const spacingClasses = {
    sm: '-space-y-2',
    md: '-space-y-4',
    lg: '-space-y-6'
  }

  return (
    <div className={cn('relative', spacingClasses[spacing], className)}>
      {React.Children.map(children, (child, index) => {
        if (React.isValidElement(child) && child.type === EnhancedCard) {
          return (
            <div
              key={index}
              className={cn(
                'relative',
                index > 0 && 'transform',
                index === 1 && 'translate-y-2',
                index === 2 && 'translate-y-4',
                index === 3 && 'translate-y-6',
                index > 3 && 'translate-y-8'
              )}
              style={{ zIndex: React.Children.count(children) - index }}
            >
              {React.cloneElement(child, {
                ...child.props,
                className: cn(
                  'shadow-lg',
                  child.props.className
                )
              })}
            </div>
          )
        }
        return child
      })}
    </div>
  )
}

CardStack.displayName = 'CardStack'

export { EnhancedCard as Card }
export default EnhancedCard