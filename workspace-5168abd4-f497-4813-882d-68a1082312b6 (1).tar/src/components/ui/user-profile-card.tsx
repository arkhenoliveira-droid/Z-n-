'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Mail, 
  User, 
  Briefcase, 
  MapPin, 
  Calendar, 
  Link as LinkIcon,
  Edit,
  MessageCircle,
  Star
} from 'lucide-react';
import { cn } from '@/lib/utils';

export interface UserProfileData {
  avatar: string;
  name: string;
  email: string;
  bio: string;
  role?: string;
  location?: string;
  joinDate?: string | Date;
  website?: string;
  stats?: {
    followers?: number;
    following?: number;
    posts?: number;
  };
  badges?: string[];
  isVerified?: boolean;
}

export interface UserProfileCardProps {
  user: UserProfileData;
  variant?: 'default' | 'compact' | 'detailed';
  showActions?: boolean;
  className?: string;
  onEdit?: () => void;
  onMessage?: () => void;
  onFollow?: () => void;
}

const UserProfileCard: React.FC<UserProfileCardProps> = ({
  user,
  variant = 'default',
  showActions = true,
  className,
  onEdit,
  onMessage,
  onFollow
}) => {
  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  if (variant === 'compact') {
    return (
      <Card className={cn('w-full max-w-sm', className)}>
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <Avatar className="h-12 w-12">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-medium truncate">{user.name}</h3>
                {user.isVerified && (
                  <Badge variant="secondary" className="text-xs">
                    <Star className="w-3 h-3 mr-1" />
                    Verified
                  </Badge>
                )}
              </div>
              <p className="text-xs text-muted-foreground truncate">{user.email}</p>
              {user.role && (
                <Badge variant="outline" className="text-xs mt-1">
                  {user.role}
                </Badge>
              )}
            </div>
          </div>
          {user.bio && (
            <p className="text-xs text-muted-foreground mt-3 line-clamp-2">
              {user.bio}
            </p>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn('w-full max-w-md', className)}>
      <CardHeader className="text-center pb-4">
        <div className="flex flex-col items-center space-y-4">
          <Avatar className="h-24 w-24">
            <AvatarImage src={user.avatar} alt={user.name} />
            <AvatarFallback className="text-lg">{getInitials(user.name)}</AvatarFallback>
          </Avatar>
          
          <div className="space-y-2">
            <div className="flex items-center justify-center space-x-2">
              <CardTitle className="text-xl">{user.name}</CardTitle>
              {user.isVerified && (
                <Badge variant="secondary" className="text-xs">
                  <Star className="w-3 h-3 mr-1" />
                  Verified
                </Badge>
              )}
            </div>
            
            {user.role && (
              <CardDescription className="flex items-center justify-center space-x-1">
                <Briefcase className="w-4 h-4" />
                <span>{user.role}</span>
              </CardDescription>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Contact Info */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Mail className="w-4 h-4" />
            <span>{user.email}</span>
          </div>
          
          {user.location && (
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <MapPin className="w-4 h-4" />
              <span>{user.location}</span>
            </div>
          )}
          
          {user.joinDate && (
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Calendar className="w-4 h-4" />
              <span>Joined {formatDate(user.joinDate)}</span>
            </div>
          )}
          
          {user.website && (
            <div className="flex items-center space-x-2 text-sm">
              <LinkIcon className="w-4 h-4" />
              <a 
                href={user.website} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                {user.website.replace(/^https?:\/\//, '')}
              </a>
            </div>
          )}
        </div>

        {/* Bio */}
        {user.bio && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium flex items-center space-x-1">
              <User className="w-4 h-4" />
              <span>About</span>
            </h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {user.bio}
            </p>
          </div>
        )}

        {/* Badges */}
        {user.badges && user.badges.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Badges</h4>
            <div className="flex flex-wrap gap-1">
              {user.badges.map((badge, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {badge}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Stats */}
        {user.stats && (
          <div className="grid grid-cols-3 gap-4 text-center">
            {user.stats.followers !== undefined && (
              <div>
                <div className="text-lg font-bold">{user.stats.followers}</div>
                <div className="text-xs text-muted-foreground">Followers</div>
              </div>
            )}
            {user.stats.following !== undefined && (
              <div>
                <div className="text-lg font-bold">{user.stats.following}</div>
                <div className="text-xs text-muted-foreground">Following</div>
              </div>
            )}
            {user.stats.posts !== undefined && (
              <div>
                <div className="text-lg font-bold">{user.stats.posts}</div>
                <div className="text-xs text-muted-foreground">Posts</div>
              </div>
            )}
          </div>
        )}

        {/* Actions */}
        {showActions && (
          <div className="flex space-x-2 pt-2">
            {onEdit && (
              <Button variant="outline" size="sm" onClick={onEdit} className="flex-1">
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>
            )}
            {onMessage && (
              <Button variant="outline" size="sm" onClick={onMessage} className="flex-1">
                <MessageCircle className="w-4 h-4 mr-2" />
                Message
              </Button>
            )}
            {onFollow && (
              <Button size="sm" onClick={onFollow} className="flex-1">
                Follow
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default UserProfileCard;