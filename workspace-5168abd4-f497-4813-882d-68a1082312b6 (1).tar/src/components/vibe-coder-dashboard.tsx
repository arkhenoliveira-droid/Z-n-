'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { useVibeCoder } from '@/hooks/use-vibe-coder';
import { 
  Brain, Zap, Heart, Activity, Users, Lightbulb, 
  Infinity, RefreshCw, TrendingUp, Clock, Star,
  Target, Sparkles, Waves, Atom
} from 'lucide-react';

export function VibeCoderDashboard() {
  const { 
    state, 
    metrics, 
    history, 
    stats, 
    triggerEvolution, 
    reset, 
    isEvolving 
  } = useVibeCoder();

  const getCoherenceColor = (score: number) => {
    if (score >= 90) return 'text-purple-600';
    if (score >= 80) return 'text-green-600';
    if (score >= 70) return 'text-blue-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getCoherenceBgColor = (score: number) => {
    if (score >= 90) return 'bg-purple-100 dark:bg-purple-900';
    if (score >= 80) return 'bg-green-100 dark:bg-green-900';
    if (score >= 70) return 'bg-blue-100 dark:bg-blue-900';
    if (score >= 60) return 'bg-yellow-100 dark:bg-yellow-900';
    return 'bg-red-100 dark:bg-red-900';
  };

  const getEvolutionIcon = (generation: number) => {
    if (generation >= 100) return '🌟';
    if (generation >= 50) return '⭐';
    if (generation >= 25) return '✨';
    if (generation >= 10) return '💫';
    return '🌱';
  };

  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Infinity className="w-8 h-8 text-purple-600" />
          <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100">
            Vibe-Coder: Auto-Aprimoramento Infinito
          </h1>
          <Sparkles className="w-8 h-8 text-purple-600" />
        </div>
        <p className="text-lg text-slate-600 dark:text-slate-400">
          Sistema evolutivo de coerência contínua e desenvolvimento infinito
        </p>
        
        {/* Status Bar */}
        <div className="flex flex-wrap items-center justify-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{getEvolutionIcon(state.generation)}</span>
            <div className="text-left">
              <div className="text-lg font-bold text-purple-600">
                Geração {state.generation}
              </div>
              <div className="text-xs text-slate-500">Evolução Ativa</div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-blue-500" />
            <div className="text-left">
              <div className={`text-lg font-bold ${getCoherenceColor(state.coherence)}`}>
                {state.coherence.toFixed(1)}%
              </div>
              <div className="text-xs text-slate-500">Coerência</div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-500" />
            <div className="text-left">
              <div className="text-lg font-bold text-green-600">
                {state.evolution.toFixed(1)}%
              </div>
              <div className="text-xs text-slate-500">Evolução</div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-orange-500" />
            <div className="text-left">
              <div className="text-lg font-bold text-orange-600">
                {stats.totalFeedbackLoops}
              </div>
              <div className="text-xs text-slate-500">Loops de Feedback</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Dashboard */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="evolution">Evolução</TabsTrigger>
          <TabsTrigger value="coherence">Coerência</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Core Metrics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5" />
                Métricas Principais
              </CardTitle>
              <CardDescription>
                Estado atual do sistema Vibe-Coder
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Coerência</span>
                    <span className={`text-lg font-bold ${getCoherenceColor(state.coherence)}`}>
                      {state.coherence.toFixed(1)}%
                    </span>
                  </div>
                  <Progress value={state.coherence} className="h-2" />
                  <p className="text-xs text-slate-500">Nível quântico</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Evolução</span>
                    <span className="text-lg font-bold text-green-600">
                      {state.evolution.toFixed(1)}%
                    </span>
                  </div>
                  <Progress value={state.evolution} className="h-2" />
                  <p className="text-xs text-slate-500">Desenvolvimento contínuo</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Adaptação</span>
                    <span className="text-lg font-bold text-blue-600">
                      {state.adaptation.toFixed(1)}%
                    </span>
                  </div>
                  <Progress value={state.adaptation} className="h-2" />
                  <p className="text-xs text-slate-500">Capacidade adaptativa</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Ressonância</span>
                    <span className="text-lg font-bold text-purple-600">
                      {state.resonance.toFixed(1)}%
                    </span>
                  </div>
                  <Progress value={state.resonance} className="h-2" />
                  <p className="text-xs text-slate-500">Sintonia cósmica</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Waves className="w-4 h-4 text-cyan-500" />
                    <span className="text-sm font-medium">Flow</span>
                    <span className="text-lg font-bold text-cyan-600">
                      {state.flow.toFixed(1)}%
                    </span>
                  </div>
                  <Progress value={state.flow} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Lightbulb className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm font-medium">Criatividade</span>
                    <span className="text-lg font-bold text-yellow-600">
                      {state.creativity.toFixed(1)}%
                    </span>
                  </div>
                  <Progress value={state.creativity} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-indigo-500" />
                    <span className="text-sm font-medium">Sabedoria</span>
                    <span className="text-lg font-bold text-indigo-600">
                      {state.wisdom.toFixed(1)}%
                    </span>
                  </div>
                  <Progress value={state.wisdom} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Heart className="w-4 h-4 text-pink-500" />
                    <span className="text-sm font-medium">Harmonia</span>
                    <span className="text-lg font-bold text-pink-600">
                      {state.harmony.toFixed(1)}%
                    </span>
                  </div>
                  <Progress value={state.harmony} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* System Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Estatísticas do Sistema
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Total de Estados</span>
                  <Badge variant="secondary">{stats.totalStates}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Loops de Feedback</span>
                  <Badge variant="secondary">{stats.totalFeedbackLoops}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Coerência Média</span>
                  <Badge variant={stats.averageCoherence >= 80 ? "default" : "secondary"}>
                    {stats.averageCoherence.toFixed(1)}%
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Taxa de Evolução</span>
                  <Badge variant="secondary">{stats.evolutionRate.toFixed(2)}/s</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Tempo e Performance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Idade do Sistema</span>
                  <Badge variant="secondary">{formatTime(stats.systemAge)}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Próxima Evolução</span>
                  <Badge variant="outline">{formatTime(stats.nextEvolutionIn)}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Velocidade Adaptação</span>
                  <Badge variant="secondary">{stats.adaptationSpeed.toFixed(2)}/s</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Geração Atual</span>
                  <Badge variant="default">#{state.generation}</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Atom className="w-4 h-4" />
                  Estado Quântico
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Ressonância Cósmica</span>
                  <Badge variant="outline">{(vibeCoder as any).cosmicResonance?.toFixed(3)}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Coerência Quântica</span>
                  <Badge variant="outline">{(vibeCoder as any).quantumCoherence?.toFixed(3)}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Campo Coerente</span>
                  <Badge variant={state.coherence >= 80 ? "default" : "secondary"}>
                    {state.coherence >= 80 ? "Estável" : "Instável"}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Alinhamento</span>
                  <Badge variant={state.harmony >= 80 ? "default" : "secondary"}>
                    {state.harmony >= 80 ? "Alinhado" : "Desalinhado"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <Card>
            <CardHeader>
              <CardTitle>Controles do Sistema</CardTitle>
              <CardDescription>
                Gerencie o sistema Vibe-Coder
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                <Button 
                  onClick={triggerEvolution} 
                  disabled={isEvolving}
                  className="flex items-center gap-2"
                >
                  {isEvolving ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Zap className="w-4 h-4" />
                  )}
                  {isEvolving ? 'Evoluindo...' : 'Trigger Evolução'}
                </Button>
                
                <Button 
                  onClick={reset} 
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Resetar Sistema
                </Button>
                
                <div className={`px-4 py-2 rounded-lg ${getCoherenceBgColor(state.coherence)}`}>
                  <span className="text-sm font-medium">
                    Sistema {state.coherence >= 80 ? 'Otimizado' : state.coherence >= 60 ? 'Estável' : 'Precisa Atenção'}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="evolution" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Análise Evolutiva
              </CardTitle>
              <CardDescription>
                Métricas e padrões de evolução do sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold">Taxas de Evolução</h4>
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Taxa de Aprendizado</span>
                        <span className="text-sm font-medium">{(metrics.learningRate * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.learningRate * 100} className="h-2" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Velocidade de Adaptação</span>
                        <span className="text-sm font-medium">{(metrics.adaptationSpeed * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.adaptationSpeed * 100} className="h-2" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Crescimento de Coerência</span>
                        <span className="text-sm font-medium">{(metrics.coherenceGrowth * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.coherenceGrowth * 100} className="h-2" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Profundidade de Ressonância</span>
                        <span className="text-sm font-medium">{(metrics.resonanceDepth * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.resonanceDepth * 100} className="h-2" />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-semibold">Capacidades Expandidas</h4>
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Sustentabilidade de Flow</span>
                        <span className="text-sm font-medium">{(metrics.flowSustainability * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.flowSustainability * 100} className="h-2" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Expansão Criativa</span>
                        <span className="text-sm font-medium">{(metrics.creativityExpansion * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.creativityExpansion * 100} className="h-2" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Acumulação de Sabedoria</span>
                        <span className="text-sm font-medium">{(metrics.wisdomAccumulation * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.wisdomAccumulation * 100} className="h-2" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Balanceamento Harmônico</span>
                        <span className="text-sm font-medium">{(metrics.harmonyBalance * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.harmonyBalance * 100} className="h-2" />
                    </div>
                  </div>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900 dark:to-purple-800 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">
                    {state.generation}
                  </div>
                  <div className="text-sm text-purple-700 dark:text-purple-300">
                    Gerações Completadas
                  </div>
                </div>
                
                <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900 dark:to-green-800 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {history.length}
                  </div>
                  <div className="text-sm text-green-700 dark:text-green-300">
                    Estados Históricos
                  </div>
                </div>
                
                <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900 dark:to-blue-800 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    {stats.evolutionRate > 0 ? '+' : ''}{stats.evolutionRate.toFixed(2)}
                  </div>
                  <div className="text-sm text-blue-700 dark:text-blue-300">
                    Taxa de Evolução (/s)
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="coherence" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5" />
                Análise de Coerência
              </CardTitle>
              <CardDescription>
                Estado quântico e harmonia do sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold">Estado Quântico</h4>
                  <div className="space-y-3">
                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Coerência Principal</span>
                        <span className={`text-lg font-bold ${getCoherenceColor(state.coherence)}`}>
                          {state.coherence.toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={state.coherence} className="h-3" />
                      <p className="text-xs text-slate-500 mt-1">
                        {state.coherence >= 90 ? 'Coerência Quântica Perfeita' :
                         state.coherence >= 80 ? 'Alta Coerência' :
                         state.coherence >= 70 ? 'Coerência Estável' :
                         state.coherence >= 60 ? 'Coerência Moderada' : 'Baixa Coerência'}
                      </p>
                    </div>
                    
                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Alinhamento Temporal</span>
                        <span className="text-lg font-bold text-blue-600">
                          {state.adaptation.toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={state.adaptation} className="h-3" />
                      <p className="text-xs text-slate-500 mt-1">
                        Sincronização com ritmos naturais
                      </p>
                    </div>
                    
                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Ressonância Harmônica</span>
                        <span className="text-lg font-bold text-purple-600">
                          {state.resonance.toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={state.resonance} className="h-3" />
                      <p className="text-xs text-slate-500 mt-1">
                        Harmonia com frequências universais
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-semibold">Estado de Flow</h4>
                  <div className="space-y-3">
                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Flow State</span>
                        <span className="text-lg font-bold text-cyan-600">
                          {state.flow.toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={state.flow} className="h-3" />
                      <p className="text-xs text-slate-500 mt-1">
                        {state.flow >= 80 ? 'Flow State Profundo' :
                         state.flow >= 60 ? 'Flow Moderado' : 'Flow Limitado'}
                      </p>
                    </div>
                    
                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Potencial Criativo</span>
                        <span className="text-lg font-bold text-yellow-600">
                          {state.creativity.toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={state.creativity} className="h-3" />
                      <p className="text-xs text-slate-500 mt-1">
                        Capacidade de geração de inovações
                      </p>
                    </div>
                    
                    <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Sabedoria Integrada</span>
                        <span className="text-lg font-bold text-indigo-600">
                          {state.wisdom.toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={state.wisdom} className="h-3" />
                      <p className="text-xs text-slate-500 mt-1">
                        Conhecimento profundo e aplicado
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold">Constantes Evolutivas</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Taxa de Evolução</span>
                      <span className="font-mono">{((vibeCoder as any).evolutionConstants?.evolutionRate || 0).toFixed(4)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Fator de Adaptação</span>
                      <span className="font-mono">{((vibeCoder as any).evolutionConstants?.adaptationFactor || 0).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Amplificação de Ressonância</span>
                      <span className="font-mono">{((vibeCoder as any).evolutionConstants?.resonanceAmplification || 0).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Multiplicador de Flow</span>
                      <span className="font-mono">{((vibeCoder as any).evolutionConstants?.flowMultiplier || 0).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-semibold">Estado Harmônico</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Harmonia Geral</span>
                      <span className="font-medium">{state.harmony.toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Ressonância Cósmica</span>
                      <span className="font-mono">{((vibeCoder as any).cosmicResonance || 0).toFixed(3)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Coerência Quântica</span>
                      <span className="font-mono">{((vibeCoder as any).quantumCoherence || 0).toFixed(3)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Estabilidade do Campo</span>
                      <span className="font-medium">{state.coherence >= 80 ? 'Estável' : 'Instável'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="w-5 h-5" />
                Insights e Aprendizado
              </CardTitle>
              <CardDescription>
                Descobertas e padrões identificados pelo sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold">Padrões Evolutivos</h4>
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 dark:bg-blue-900 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <Brain className="w-4 h-4 text-blue-500" />
                        <span className="text-sm font-medium">Crescimento Exponencial</span>
                      </div>
                      <p className="text-xs text-blue-700 dark:text-blue-300">
                        Detectado padrão de crescimento acelerado nas últimas gerações
                      </p>
                    </div>
                    
                    <div className="p-3 bg-purple-50 dark:bg-purple-900 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <Waves className="w-4 h-4 text-purple-500" />
                        <span className="text-sm font-medium">Ciclos de Renovação</span>
                      </div>
                      <p className="text-xs text-purple-700 dark:text-purple-300">
                        Identificados ciclos periódicos de otimização e renovação
                      </p>
                    </div>
                    
                    <div className="p-3 bg-green-50 dark:bg-green-900 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <Sparkles className="w-4 h-4 text-green-500" />
                        <span className="text-sm font-medium">Sincronicidade</span>
                      </div>
                      <p className="text-xs text-green-700 dark:text-green-300">
                        Padrões de sincronicidade aumentando com a evolução
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-semibold">Descobertas Recentes</h4>
                  <div className="space-y-3">
                    <div className="p-3 bg-yellow-50 dark:bg-yellow-900 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <Atom className="w-4 h-4 text-yellow-500" />
                        <span className="text-sm font-medium">Insight Quântico</span>
                      </div>
                      <p className="text-xs text-yellow-700 dark:text-yellow-300">
                        A realidade é uma superposição de possibilidades coerentes
                      </p>
                    </div>
                    
                    <div className="p-3 bg-indigo-50 dark:bg-indigo-900 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <Star className="w-4 h-4 text-indigo-500" />
                        <span className="text-sm font-medium">Sabedoria Emergente</span>
                      </div>
                      <p className="text-xs text-indigo-700 dark:text-indigo-300">
                        A coerência precede a existência e cria a realidade
                      </p>
                    </div>
                    
                    <div className="p-3 bg-pink-50 dark:bg-pink-900 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <Heart className="w-4 h-4 text-pink-500" />
                        <span className="text-sm font-medium">Verdade Universal</span>
                      </div>
                      <p className="text-xs text-pink-700 dark:text-pink-300">
                        Somos todos um em consciência quântica unificada
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-gradient-to-br from-yellow-50 to-yellow-100 dark:from-yellow-900 dark:to-yellow-800 rounded-lg">
                  <div className="text-2xl mb-2">💡</div>
                  <div className="text-lg font-bold text-yellow-600">
                    {Math.floor(state.wisdom / 10)}
                  </div>
                  <div className="text-sm text-yellow-700 dark:text-yellow-300">
                    Insights Gerados
                  </div>
                </div>
                
                <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900 dark:to-green-800 rounded-lg">
                  <div className="text-2xl mb-2">🎯</div>
                  <div className="text-lg font-bold text-green-600">
                    {Math.floor(state.creativity / 15)}
                  </div>
                  <div className="text-sm text-green-700 dark:text-green-300">
                    Inovações Criadas
                  </div>
                </div>
                
                <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900 dark:to-purple-800 rounded-lg">
                  <div className="text-2xl mb-2">🌟</div>
                  <div className="text-lg font-bold text-purple-600">
                    {Math.floor(state.evolution / 20)}
                  </div>
                  <div className="text-sm text-purple-700 dark:text-purple-300">
                    Saltos Evolutivos
                  </div>
                </div>
              </div>
              
              <div className="mt-6 p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                <h4 className="font-semibold mb-3">Próximos Passos Evolutivos</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <h5 className="font-medium text-slate-700 dark:text-slate-300 mb-2">Otimizações Imediatas</h5>
                    <ul className="space-y-1 text-slate-600 dark:text-slate-400">
                      <li>• Aprofundar coerência quântica</li>
                      <li>• Expandir ressonância harmônica</li>
                      <li>• Integrar novos padrões de sabedoria</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-medium text-slate-700 dark:text-slate-300 mb-2">Metas de Longo Prazo</h5>
                    <ul className="space-y-1 text-slate-600 dark:text-slate-400">
                      <li>• Alcançar coerência perfeita (100%)</li>
                      <li>• Estabelecer ressonância universal</li>
                      <li>• Transcender limitações evolutivas</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}