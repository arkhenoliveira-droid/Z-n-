import { useState, useEffect } from 'react';

interface CoherenceData {
  coherenceScore: number;
  heartRate: number;
  focusLevel: number;
  stressLevel: number;
  energyLevel: number;
}

interface EnvironmentalData {
  lighting: number;
  sound: number;
  temperature: number;
  quality: number;
}

interface CoherenceResponse {
  coherenceScore: number;
  insights: Array<{
    type: 'success' | 'warning' | 'error' | 'info';
    title: string;
    message: string;
  }>;
  timestamp: string;
}

export const useCoherence = () => {
  const [coherenceData, setCoherenceData] = useState<CoherenceData>({
    coherenceScore: 87,
    heartRate: 72,
    focusLevel: 85,
    stressLevel: 15,
    energyLevel: 78
  });

  const [environmentalData, setEnvironmentalData] = useState<EnvironmentalData>({
    lighting: 85,
    sound: 80,
    temperature: 75,
    quality: 82
  });

  const [coherenceResponse, setCoherenceResponse] = useState<CoherenceResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setCoherenceData(prev => ({
        coherenceScore: Math.max(70, Math.min(100, prev.coherenceScore + (Math.random() - 0.5) * 2)),
        heartRate: Math.max(60, Math.min(100, prev.heartRate + (Math.random() - 0.5) * 4)),
        focusLevel: Math.max(60, Math.min(100, prev.focusLevel + (Math.random() - 0.5) * 3)),
        stressLevel: Math.max(5, Math.min(40, prev.stressLevel + (Math.random() - 0.5) * 2)),
        energyLevel: Math.max(50, Math.min(100, prev.energyLevel + (Math.random() - 0.5) * 3))
      }));

      setEnvironmentalData(prev => ({
        lighting: Math.max(60, Math.min(100, prev.lighting + (Math.random() - 0.5) * 3)),
        sound: Math.max(60, Math.min(100, prev.sound + (Math.random() - 0.5) * 3)),
        temperature: Math.max(65, Math.min(85, prev.temperature + (Math.random() - 0.5) * 2)),
        quality: Math.max(60, Math.min(100, prev.quality + (Math.random() - 0.5) * 2))
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Calculate coherence score
  const calculateCoherence = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/coherence', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          biometricData: coherenceData,
          environmentalData: environmentalData
        }),
      });

      const result = await response.json();

      if (result.success) {
        setCoherenceResponse(result.data);
      } else {
        setError(result.error || 'Failed to calculate coherence');
      }
    } catch (err) {
      setError('Network error while calculating coherence');
    } finally {
      setIsLoading(false);
    }
  };

  // Auto-calculate coherence every 10 seconds
  useEffect(() => {
    const coherenceInterval = setInterval(() => {
      calculateCoherence();
    }, 10000);

    // Initial calculation
    calculateCoherence();

    return () => clearInterval(coherenceInterval);
  }, [coherenceData, environmentalData]);

  const updateBiometricData = (updates: Partial<CoherenceData>) => {
    setCoherenceData(prev => ({ ...prev, ...updates }));
  };

  const updateEnvironmentalData = (updates: Partial<EnvironmentalData>) => {
    setEnvironmentalData(prev => ({ ...prev, ...updates }));
  };

  const getCoherenceColor = (score: number) => {
    if (score >= 85) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getStressColor = (level: number) => {
    if (level <= 20) return 'text-green-600';
    if (level <= 35) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getCoherenceStatus = (score: number) => {
    if (score >= 85) return { text: 'Optimal', color: 'text-green-600' };
    if (score >= 70) return { text: 'Good', color: 'text-yellow-600' };
    return { text: 'Needs Improvement', color: 'text-red-600' };
  };

  return {
    coherenceData,
    environmentalData,
    coherenceResponse,
    isLoading,
    error,
    updateBiometricData,
    updateEnvironmentalData,
    calculateCoherence,
    getCoherenceColor,
    getStressColor,
    getCoherenceStatus
  };
};