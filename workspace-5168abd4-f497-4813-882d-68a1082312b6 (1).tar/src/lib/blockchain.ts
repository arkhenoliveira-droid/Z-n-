import { createHash, randomBytes } from 'crypto';

export interface Transaction {
  fromAddress: string | null;
  toAddress: string;
  amount: number;
  timestamp?: number;
}

export interface BlockData {
  index: number;
  timestamp: number | string;
  transactions: Transaction[] | string;
  previousHash: string;
  hash: string;
  nonce?: number;
}

export class Block {
  public index: number;
  public timestamp: number | string;
  public transactions: Transaction[] | string;
  public previousHash: string;
  public hash: string;
  public nonce: number = 0;

  constructor(index: number, timestamp: number | string, transactions: Transaction[] | string, previousHash: string = '') {
    this.index = index;
    this.timestamp = timestamp;
    this.transactions = transactions;
    this.previousHash = previousHash;
    this.hash = this.calculateHash();
  }

  calculateHash(): string {
    return createHash('sha256')
      .update(
        this.index +
        this.previousHash +
        this.timestamp +
        JSON.stringify(this.transactions) +
        this.nonce
      )
      .digest('hex');
  }

  mineBlock(difficulty: number): void {
    const target = Array(difficulty + 1).join('0');
    while (this.hash.substring(0, difficulty) !== target) {
      this.nonce++;
      this.hash = this.calculateHash();
    }
    console.log(`Block mined: ${this.hash}`);
  }
}

export class Blockchain {
  public chain: Block[];
  public pendingTransactions: Transaction[];
  public difficulty: number;
  public miningReward: number;
  public maxTransactionsPerBlock: number;

  constructor() {
    this.chain = [this.createGenesisBlock()];
    this.pendingTransactions = [];
    this.difficulty = 2;
    this.miningReward = 100;
    this.maxTransactionsPerBlock = 10;
  }

  createGenesisBlock(): Block {
    return new Block(0, Date.now(), [], '0');
  }

  getLatestBlock(): Block {
    return this.chain[this.chain.length - 1];
  }

  minePendingTransactions(miningRewardAddress: string): Block {
    const transactionsToMine = this.pendingTransactions.slice(0, this.maxTransactionsPerBlock);
    const rewardTransaction: Transaction = {
      fromAddress: null,
      toAddress: miningRewardAddress,
      amount: this.miningReward,
      timestamp: Date.now()
    };

    const block = new Block(
      this.chain.length,
      Date.now(),
      [...transactionsToMine, rewardTransaction],
      this.getLatestBlock().hash
    );

    block.mineBlock(this.difficulty);
    this.chain.push(block);

    // Remove mined transactions from pending
    this.pendingTransactions = this.pendingTransactions.slice(this.maxTransactionsPerBlock);

    return block;
  }

  createTransaction(transaction: Transaction): void {
    if (!transaction.fromAddress || !transaction.toAddress) {
      throw new Error('Transaction must include from and to address');
    }

    if (transaction.amount <= 0) {
      throw new Error('Transaction amount should be higher than 0');
    }

    if (this.getBalance(transaction.fromAddress) < transaction.amount) {
      throw new Error('Not enough balance');
    }

    this.pendingTransactions.push({
      ...transaction,
      timestamp: Date.now()
    });
  }

  getBalance(address: string): number {
    let balance = 0;

    for (const block of this.chain) {
      const transactions = Array.isArray(block.transactions) ? block.transactions : [];
      
      for (const trans of transactions) {
        if (trans.fromAddress === address) {
          balance -= trans.amount;
        }
        if (trans.toAddress === address) {
          balance += trans.amount;
        }
      }
    }

    return balance;
  }

  getAllTransactionsForWallet(address: string): Transaction[] {
    const txs: Transaction[] = [];

    for (const block of this.chain) {
      const transactions = Array.isArray(block.transactions) ? block.transactions : [];
      
      for (const tx of transactions) {
        if (tx.fromAddress === address || tx.toAddress === address) {
          txs.push(tx);
        }
      }
    }

    return txs;
  }

  isChainValid(): boolean {
    for (let i = 1; i < this.chain.length; i++) {
      const currentBlock = this.chain[i];
      const previousBlock = this.chain[i - 1];

      if (currentBlock.hash !== currentBlock.calculateHash()) {
        return false;
      }

      if (currentBlock.previousHash !== previousBlock.hash) {
        return false;
      }
    }

    return true;
  }

  getChainStats() {
    return {
      totalBlocks: this.chain.length,
      pendingTransactions: this.pendingTransactions.length,
      difficulty: this.difficulty,
      miningReward: this.miningReward,
      isValid: this.isChainValid()
    };
  }

  // Utility method to generate a random wallet address
  generateWalletAddress(): string {
    return '0x' + randomBytes(20).toString('hex');
  }
}

// Global blockchain instance
export const blockchain = new Blockchain();

// Initialize with some sample data
export function initializeBlockchain() {
  // Create some initial wallets
  const wallet1 = blockchain.generateWalletAddress();
  const wallet2 = blockchain.generateWalletAddress();
  const wallet3 = blockchain.generateWalletAddress();

  // Create initial transactions
  blockchain.createTransaction({
    fromAddress: null, // Genesis transaction
    toAddress: wallet1,
    amount: 1000
  });

  blockchain.createTransaction({
    fromAddress: wallet1,
    toAddress: wallet2,
    amount: 100
  });

  blockchain.createTransaction({
    fromAddress: wallet2,
    toAddress: wallet3,
    amount: 50
  });

  // Mine the first block
  blockchain.minePendingTransactions('miner1');

  return {
    wallets: [wallet1, wallet2, wallet3],
    miner: 'miner1'
  };
}