/**
 * Comprehensive Design System for Holistic UI/UX Consistency
 * This file provides centralized design tokens, utilities, and patterns
 */

// Design Tokens
export const designTokens = {
  // Spacing Scale (8px base)
  spacing: {
    px: '1px',
    0: '0',
    1: '0.25rem', // 4px
    2: '0.5rem',  // 8px
    3: '0.75rem', // 12px
    4: '1rem',    // 16px
    5: '1.25rem', // 20px
    6: '1.5rem',  // 24px
    8: '2rem',    // 32px
    10: '2.5rem', // 40px
    12: '3rem',   // 48px
    16: '4rem',   // 64px
    20: '5rem',   // 80px
    24: '6rem',   // 96px
    32: '8rem',   // 128px
    40: '10rem',  // 160px
    48: '12rem',  // 192px
    56: '14rem',  // 224px
    64: '16rem',  // 256px
  },

  // Border Radius
  radius: {
    none: '0',
    sm: '0.25rem',
    md: '0.375rem',
    lg: '0.5rem',
    xl: '0.75rem',
    '2xl': '1rem',
    '3xl': '1.5rem',
    full: '9999px',
  },

  // Shadow System
  shadows: {
    none: 'none',
    sm: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
    md: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
    lg: '0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)',
    xl: '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)',
    '2xl': '0 25px 50px -12px rgb(0 0 0 / 0.25)',
    inner: 'inset 0 2px 4px 0 rgb(0 0 0 / 0.05)',
  },

  // Typography Scale
  typography: {
    fontFamily: {
      sans: ['Inter', 'system-ui', 'sans-serif'],
      mono: ['JetBrains Mono', 'Consolas', 'monospace'],
    },
    fontSize: {
      xs: ['0.75rem', { lineHeight: '1rem' }],
      sm: ['0.875rem', { lineHeight: '1.25rem' }],
      base: ['1rem', { lineHeight: '1.5rem' }],
      lg: ['1.125rem', { lineHeight: '1.75rem' }],
      xl: ['1.25rem', { lineHeight: '1.75rem' }],
      '2xl': ['1.5rem', { lineHeight: '2rem' }],
      '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
      '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
      '5xl': ['3rem', { lineHeight: '1' }],
      '6xl': ['3.75rem', { lineHeight: '1' }],
      '7xl': ['4.5rem', { lineHeight: '1' }],
      '8xl': ['6rem', { lineHeight: '1' }],
      '9xl': ['8rem', { lineHeight: '1' }],
    },
    fontWeight: {
      light: '300',
      normal: '400',
      medium: '500',
      semibold: '600',
      bold: '700',
      extrabold: '800',
    },
    letterSpacing: {
      tight: '-0.025em',
      normal: '0',
      wide: '0.025em',
    },
  },

  // Animation Durations
  animation: {
    fast: '150ms',
    normal: '300ms',
    slow: '500ms',
    extraSlow: '1000ms',
  },

  // Z-Index Scale
  zIndex: {
    auto: 'auto',
    0: '0',
    10: '10',
    20: '20',
    30: '30',
    40: '40',
    50: '50',
    dropdown: '1000',
    sticky: '1020',
    fixed: '1030',
    modal: '1040',
    popover: '1050',
    tooltip: '1060',
    notification: '1070',
  },

  // Breakpoints
  breakpoints: {
    sm: '640px',
    md: '768px',
    lg: '1024px',
    xl: '1280px',
    '2xl': '1536px',
  },
};

// Color System Extensions
export const colorSystem = {
  // Semantic Color Mapping
  semantic: {
    success: {
      50: 'oklch(0.97 0.1 142)',
      100: 'oklch(0.94 0.15 142)',
      500: 'oklch(0.62 0.18 142)',
      600: 'oklch(0.52 0.2 142)',
      700: 'oklch(0.42 0.22 142)',
    },
    warning: {
      50: 'oklch(0.98 0.08 85)',
      100: 'oklch(0.96 0.12 85)',
      500: 'oklch(0.68 0.18 85)',
      600: 'oklch(0.58 0.2 85)',
      700: 'oklch(0.48 0.22 85)',
    },
    error: {
      50: 'oklch(0.97 0.1 15)',
      100: 'oklch(0.94 0.15 15)',
      500: 'oklch(0.62 0.18 15)',
      600: 'oklch(0.52 0.2 15)',
      700: 'oklch(0.42 0.22 15)',
    },
    info: {
      50: 'oklch(0.97 0.1 220)',
      100: 'oklch(0.94 0.15 220)',
      500: 'oklch(0.62 0.18 220)',
      600: 'oklch(0.52 0.2 220)',
      700: 'oklch(0.42 0.22 220)',
    },
  },

  // Gradient Presets
  gradients: {
    primary: 'linear-gradient(135deg, oklch(0.646 0.222 41.116) 0%, oklch(0.6 0.118 184.704) 100%)',
    secondary: 'linear-gradient(135deg, oklch(0.769 0.188 70.08) 0%, oklch(0.828 0.189 84.429) 100%)',
    accent: 'linear-gradient(135deg, oklch(0.645 0.246 16.439) 0%, oklch(0.627 0.265 303.9) 100%)',
    success: 'linear-gradient(135deg, oklch(0.62 0.18 142) 0%, oklch(0.52 0.2 142) 100%)',
    warning: 'linear-gradient(135deg, oklch(0.68 0.18 85) 0%, oklch(0.58 0.2 85) 100%)',
    error: 'linear-gradient(135deg, oklch(0.62 0.18 15) 0%, oklch(0.52 0.2 15) 100%)',
  },
};

// Component Patterns
export const componentPatterns = {
  // Card Patterns
  card: {
    base: 'rounded-lg border bg-card text-card-foreground shadow-sm',
    interactive: 'hover:shadow-md transition-shadow duration-200 cursor-pointer',
    elevated: 'shadow-lg border-0',
    glass: 'bg-background/80 backdrop-blur-sm border border-border/50',
  },

  // Button Patterns
  button: {
    base: 'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50',
    variants: {
      size: {
        sm: 'h-8 px-3 text-xs',
        md: 'h-9 px-4 py-2',
        lg: 'h-10 px-6',
        xl: 'h-11 px-8',
      },
      loading: 'opacity-70 cursor-not-allowed',
    },
  },

  // Input Patterns
  input: {
    base: 'flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50',
    error: 'border-destructive focus-visible:ring-destructive',
    success: 'border-green-500 focus-visible:ring-green-500',
  },

  // Badge Patterns
  badge: {
    base: 'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium transition-colors',
    variants: {
      size: {
        sm: 'px-2 py-0.5 text-xs',
        md: 'px-2.5 py-0.5 text-xs',
        lg: 'px-3 py-1 text-sm',
      },
    },
  },

  // Alert Patterns
  alert: {
    base: 'rounded-lg border p-4 [&>svg~*]:pl-7 [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground',
    variants: {
      default: 'bg-background text-foreground',
      destructive: 'border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive',
      warning: 'border-warning/50 text-warning dark:border-warning [&>svg]:text-warning',
      success: 'border-green-500/50 text-green-700 dark:border-green-500 [&>svg]:text-green-500',
      info: 'border-blue-500/50 text-blue-700 dark:border-blue-500 [&>svg]:text-blue-500',
    },
  },
};

// Layout Patterns
export const layoutPatterns = {
  // Container Patterns
  container: {
    base: 'mx-auto px-4',
    sizes: {
      sm: 'max-w-screen-sm',
      md: 'max-w-screen-md',
      lg: 'max-w-screen-lg',
      xl: 'max-w-screen-xl',
      '2xl': 'max-w-screen-2xl',
      full: 'max-w-full',
    },
  },

  // Grid Patterns
  grid: {
    base: 'grid gap-4',
    cols: {
      1: 'grid-cols-1',
      2: 'grid-cols-2',
      3: 'grid-cols-3',
      4: 'grid-cols-4',
      5: 'grid-cols-5',
      6: 'grid-cols-6',
      12: 'grid-cols-12',
    },
    responsive: {
      '1@sm': 'sm:grid-cols-1',
      '2@sm': 'sm:grid-cols-2',
      '3@sm': 'sm:grid-cols-3',
      '4@sm': 'sm:grid-cols-4',
      '1@md': 'md:grid-cols-1',
      '2@md': 'md:grid-cols-2',
      '3@md': 'md:grid-cols-3',
      '4@md': 'md:grid-cols-4',
      '1@lg': 'lg:grid-cols-1',
      '2@lg': 'lg:grid-cols-2',
      '3@lg': 'lg:grid-cols-3',
      '4@lg': 'lg:grid-cols-4',
    },
  },

  // Flex Patterns
  flex: {
    base: 'flex gap-4',
    directions: {
      row: 'flex-row',
      col: 'flex-col',
      'row-reverse': 'flex-row-reverse',
      'col-reverse': 'flex-col-reverse',
    },
    wraps: {
      nowrap: 'flex-nowrap',
      wrap: 'flex-wrap',
      'wrap-reverse': 'flex-wrap-reverse',
    },
    justifies: {
      start: 'justify-start',
      end: 'justify-end',
      center: 'justify-center',
      between: 'justify-between',
      around: 'justify-around',
      evenly: 'justify-evenly',
    },
    aligns: {
      start: 'items-start',
      end: 'items-end',
      center: 'items-center',
      baseline: 'items-baseline',
      stretch: 'items-stretch',
    },
  },
};

// Animation Patterns
export const animationPatterns = {
  // Fade Animations
  fade: {
    in: 'animate-in fade-in duration-300',
    out: 'animate-out fade-out duration-300',
  },

  // Slide Animations
  slide: {
    'in-from-top': 'animate-in slide-in-from-top duration-300',
    'in-from-bottom': 'animate-in slide-in-from-bottom duration-300',
    'in-from-left': 'animate-in slide-in-from-left duration-300',
    'in-from-right': 'animate-in slide-in-from-right duration-300',
    'out-to-top': 'animate-out slide-out-to-top duration-300',
    'out-to-bottom': 'animate-out slide-out-to-bottom duration-300',
    'out-to-left': 'animate-out slide-out-to-left duration-300',
    'out-to-right': 'animate-out slide-out-to-right duration-300',
  },

  // Scale Animations
  scale: {
    'in': 'animate-in zoom-in duration-300',
    'out': 'animate-out zoom-out duration-300',
  },

  // Combined Animations
  combined: {
    'fade-slide-up': 'animate-in fade-in slide-in-from-bottom duration-500',
    'fade-slide-down': 'animate-in fade-in slide-in-from-top duration-500',
    'fade-slide-left': 'animate-in fade-in slide-in-from-left duration-500',
    'fade-slide-right': 'animate-in fade-in slide-in-from-right duration-500',
  },
};

// Utility Functions
export const designUtils = {
  // Generate spacing classes
  spacing: (value: keyof typeof designTokens.spacing) => designTokens.spacing[value],

  // Generate color classes with opacity
  color: (color: string, opacity: number = 100) => {
    const opacityValue = opacity / 100;
    return color.replace(')', `, ${opacityValue})`).replace('oklch', 'oklch');
  },

  // Generate responsive classes
  responsive: (classes: string, breakpoint?: keyof typeof designTokens.breakpoints) => {
    return breakpoint ? `${breakpoint}:${classes}` : classes;
  },

  // Generate animation classes
  animation: (type: keyof typeof animationPatterns, variant?: string) => {
    if (variant && animationPatterns[type][variant as keyof typeof animationPatterns[typeof type]]) {
      return animationPatterns[type][variant as keyof typeof animationPatterns[typeof type]];
    }
    return animationPatterns[type];
  },

  // Generate component classes
  component: (type: keyof typeof componentPatterns, variant?: string) => {
    if (variant && componentPatterns[type][variant as keyof typeof componentPatterns[typeof type]]) {
      return componentPatterns[type][variant as keyof typeof componentPatterns[typeof type]];
    }
    return componentPatterns[type];
  },

  // Generate layout classes
  layout: (type: keyof typeof layoutPatterns, variant?: string) => {
    if (variant && layoutPatterns[type][variant as keyof typeof layoutPatterns[typeof type]]) {
      return layoutPatterns[type][variant as keyof typeof layoutPatterns[typeof type]];
    }
    return layoutPatterns[type];
  },
};

// Theme Helpers
export const themeHelpers = {
  // Check if dark mode is active
  isDarkMode: () => {
    return typeof document !== 'undefined' && document.documentElement.classList.contains('dark');
  },

  // Toggle dark mode
  toggleDarkMode: () => {
    if (typeof document !== 'undefined') {
      document.documentElement.classList.toggle('dark');
    }
  },

  // Get current theme
  getCurrentTheme: () => {
    return themeHelpers.isDarkMode() ? 'dark' : 'light';
  },

  // Set theme
  setTheme: (theme: 'light' | 'dark' | 'system') => {
    if (typeof document !== 'undefined') {
      if (theme === 'system') {
        const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        document.documentElement.classList.toggle('dark', systemTheme === 'dark');
      } else {
        document.documentElement.classList.toggle('dark', theme === 'dark');
      }
    }
  },
};

// Export all design system utilities
export const designSystem = {
  tokens: designTokens,
  colors: colorSystem,
  components: componentPatterns,
  layouts: layoutPatterns,
  animations: animationPatterns,
  utils: designUtils,
  theme: themeHelpers,
};

export default designSystem;