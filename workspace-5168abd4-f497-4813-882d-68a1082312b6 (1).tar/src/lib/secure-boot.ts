/**
 * Secure Boot Verification System
 * 
 * This module provides comprehensive secure boot verification functionality including
 * UEFI Secure Boot validation, firmware integrity checking, boot component verification,
 * and platform key management.
 */

import { createId } from '@/lib/utils';
import { performanceMonitor } from '@/lib/performance';
import { ErrorHandler } from '@/lib/error-handling';
import { trustedComputingManager } from '@/lib/trusted-computing';
import { tpmSimulationManager } from '@/lib/tpm-simulation';

// Secure Boot Constants
export const SECURE_BOOT_STATES = {
  ENABLED: 'enabled',
  DISABLED: 'disabled',
  SETUP_MODE: 'setup_mode',
  AUDIT_MODE: 'audit_mode',
  DEPLOYED_MODE: 'deployed_mode'
} as const;

export const BOOT_COMPONENTS = {
  BIOS: 'bios',
  FIRMWARE: 'firmware',
  BOOTLOADER: 'bootloader',
  KERNEL: 'kernel',
  INITRAMFS: 'initramfs',
  DRIVERS: 'drivers',
  APPLICATIONS: 'applications'
} as const;

export const SIGNATURE_FORMATS = {
  PKCS7: 'PKCS7',
  X509: 'X509',
  RAW: 'RAW',
  DER: 'DER',
  PEM: 'PEM'
} as const;

export const VERIFICATION_RESULTS = {
  PASSED: 'passed',
  FAILED: 'failed',
  WARNING: 'warning',
  SKIPPED: 'skipped',
  ERROR: 'error'
} as const;

// Core Types
export interface SecureBootConfig {
  state: keyof typeof SECURE_BOOT_STATES;
  platformKey: PlatformKey;
  keyExchangeKeys: PlatformKey[];
  database: DatabaseEntry[];
  forbiddenDatabase: DatabaseEntry[];
  auditEnabled: boolean;
  auditLogSize: number;
  verificationMode: 'strict' | 'permissive' | 'custom';
}

export interface PlatformKey {
  id: string;
  name: string;
  keyData: string;
  algorithm: string;
  keySize: number;
  created: number;
  expires?: number;
  usage: string[];
  source: string;
  fingerprint: string;
  revoked: boolean;
}

export interface DatabaseEntry {
  id: string;
  keyId: string;
  signature: string;
  format: keyof typeof SIGNATURE_FORMATS;
  owner: string;
  description: string;
  created: number;
  lastUsed: number;
  usageCount: number;
  revoked: boolean;
  revocationReason?: string;
  revocationDate?: number;
}

export interface BootComponent {
  name: keyof typeof BOOT_COMPONENTS;
  path: string;
  version: string;
  vendor: string;
  checksum: string;
  signature: string;
  signatureKeyId: string;
  verified: boolean;
  verificationTime: number;
  verificationResult: keyof typeof VERIFICATION_RESULTS;
  verificationDetails?: string;
}

export interface SecureBootStatus {
  enabled: boolean;
  state: keyof typeof SECURE_BOOT_STATES;
  lastVerification: number;
  verificationResult: keyof typeof VERIFICATION_RESULTS;
  verifiedComponents: number;
  totalComponents: number;
  platformKeyValid: boolean;
  keyExchangeKeysValid: boolean;
  databaseValid: boolean;
  warnings: string[];
  errors: string[];
}

export interface VerificationReport {
  id: string;
  timestamp: number;
  duration: number;
  overallResult: keyof typeof VERIFICATION_RESULTS;
  components: BootComponent[];
  platformKeyStatus: VerificationStatus;
  keyExchangeKeysStatus: VerificationStatus;
  databaseStatus: VerificationStatus;
  securityScore: number;
  recommendations: string[];
  criticalIssues: string[];
}

export interface VerificationStatus {
  valid: boolean;
  checked: boolean;
  issues: string[];
  warnings: string[];
  score: number;
}

export interface AuditLogEntry {
  id: string;
  timestamp: number;
  type: 'verification' | 'key_update' | 'component_change' | 'state_change' | 'error';
  component?: string;
  details: string;
  result?: keyof typeof VERIFICATION_RESULTS;
  severity: 'info' | 'warning' | 'error' | 'critical';
}

// Secure Boot Verification Manager
export class SecureBootVerificationManager {
  private config: SecureBootConfig;
  private bootComponents: Map<string, BootComponent>;
  private auditLog: AuditLogEntry[];
  private verificationHistory: VerificationReport[];
  private initialized: boolean;

  constructor() {
    this.config = this.initializeConfig();
    this.bootComponents = new Map();
    this.auditLog = [];
    this.verificationHistory = [];
    this.initialized = false;
  }

  private initializeConfig(): SecureBootConfig {
    // Generate platform key
    const platformKey: PlatformKey = {
      id: 'PK-001',
      name: 'Platform Key',
      keyData: this.generateKeyData('RSA-2048'),
      algorithm: 'RSA-2048',
      keySize: 2048,
      created: Date.now() - 86400000 * 365, // 1 year ago
      usage: ['platform_authority'],
      source: 'OEM',
      fingerprint: this.generateFingerprint(),
      revoked: false
    };

    // Generate key exchange keys
    const keyExchangeKeys: PlatformKey[] = [
      {
        id: 'KEK-001',
        name: 'Microsoft KEK',
        keyData: this.generateKeyData('RSA-2048'),
        algorithm: 'RSA-2048',
        keySize: 2048,
        created: Date.now() - 86400000 * 300,
        usage: ['key_exchange'],
        source: 'Microsoft Corporation',
        fingerprint: this.generateFingerprint(),
        revoked: false
      },
      {
        id: 'KEK-002',
        name: 'Canonical KEK',
        keyData: this.generateKeyData('RSA-2048'),
        algorithm: 'RSA-2048',
        keySize: 2048,
        created: Date.now() - 86400000 * 250,
        usage: ['key_exchange'],
        source: 'Canonical Ltd.',
        fingerprint: this.generateFingerprint(),
        revoked: false
      }
    ];

    // Initialize database with trusted signatures
    const database: DatabaseEntry[] = [
      {
        id: 'DB-001',
        keyId: 'KEK-001',
        signature: this.generateSignature(),
        format: 'PKCS7',
        owner: 'Microsoft Corporation',
        description: 'Windows Boot Manager',
        created: Date.now() - 86400000 * 200,
        lastUsed: Date.now() - 86400000 * 10,
        usageCount: 150,
        revoked: false
      },
      {
        id: 'DB-002',
        keyId: 'KEK-002',
        signature: this.generateSignature(),
        format: 'PKCS7',
        owner: 'Canonical Ltd.',
        description: 'Ubuntu Shim',
        created: Date.now() - 86400000 * 180,
        lastUsed: Date.now() - 86400000 * 5,
        usageCount: 89,
        revoked: false
      }
    ];

    return {
      state: 'ENABLED',
      platformKey,
      keyExchangeKeys,
      database,
      forbiddenDatabase: [],
      auditEnabled: true,
      auditLogSize: 1000,
      verificationMode: 'strict'
    };
  }

  async initialize(): Promise<void> {
    if (this.initialized) {
      return;
    }

    try {
      // Initialize TPM if not already done
      await tpmSimulationManager.startup('clear');
      
      // Initialize boot components
      await this.initializeBootComponents();
      
      // Extend TPM PCRs with boot measurements
      await this.measureBootComponents();
      
      this.initialized = true;
      this.logAudit('state_change', 'Secure Boot verification system initialized', 'info');
      
    } catch (error) {
      this.logAudit('error', `Initialization failed: ${error.message}`, 'error');
      throw ErrorHandler.createError('SECURE_BOOT_INIT_FAILED', error.message);
    }
  }

  private async initializeBootComponents(): Promise<void> {
    const components = [
      {
        name: 'BIOS' as const,
        path: '/firmware/bios.bin',
        version: '1.2.3',
        vendor: 'OEM Firmware',
        checksum: this.generateChecksum(),
        signature: this.generateSignature(),
        signatureKeyId: 'PK-001'
      },
      {
        name: 'FIRMWARE' as const,
        path: '/firmware/uefi.bin',
        version: '2.1.0',
        vendor: 'OEM UEFI',
        checksum: this.generateChecksum(),
        signature: this.generateSignature(),
        signatureKeyId: 'PK-001'
      },
      {
        name: 'BOOTLOADER' as const,
        path: '/boot/loader.efi',
        version: '1.0.0',
        vendor: 'GNU GRUB',
        checksum: this.generateChecksum(),
        signature: this.generateSignature(),
        signatureKeyId: 'DB-001'
      },
      {
        name: 'KERNEL' as const,
        path: '/boot/vmlinuz',
        version: '5.15.0-52-generic',
        vendor: 'Linux Foundation',
        checksum: this.generateChecksum(),
        signature: this.generateSignature(),
        signatureKeyId: 'DB-001'
      },
      {
        name: 'INITRAMFS' as const,
        path: '/boot/initrd.img',
        version: '5.15.0-52-generic',
        vendor: 'Linux Foundation',
        checksum: this.generateChecksum(),
        signature: this.generateSignature(),
        signatureKeyId: 'DB-001'
      }
    ];

    for (const component of components) {
      const bootComponent: BootComponent = {
        ...component,
        verified: false,
        verificationTime: 0,
        verificationResult: 'SKIPPED'
      };

      this.bootComponents.set(component.name, bootComponent);
    }
  }

  private async measureBootComponents(): Promise<void> {
    // Extend TPM PCRs with boot component measurements
    const measurements = [
      { pcr: 0, component: 'BIOS', description: 'BIOS Code Measurement' },
      { pcr: 1, component: 'BIOS', description: 'BIOS Configuration' },
      { pcr: 2, component: 'FIRMWARE', description: 'Option ROM Code' },
      { pcr: 4, component: 'BOOTLOADER', description: 'MBR/Bootloader' },
      { pcr: 5, component: 'KERNEL', description: 'Boot Configuration' },
      { pcr: 6, component: 'KERNEL', description: 'Kernel/Driver Configuration' },
      { pcr: 7, component: 'APPLICATIONS', description: 'Application Code' }
    ];

    for (const measurement of measurements) {
      try {
        await tpmSimulationManager.extendPCR(
          measurement.pcr,
          measurement.component,
          'SHA256'
        );
      } catch (error) {
        this.logAudit('error', `Failed to extend PCR ${measurement.pcr}: ${error.message}`, 'error');
      }
    }
  }

  // Main Verification Process
  async verifySecureBoot(): Promise<VerificationReport> {
    const startTime = performance.now();
    
    try {
      if (!this.initialized) {
        await this.initialize();
      }

      const reportId = createId();
      
      // Verify all boot components
      const componentResults = await this.verifyAllComponents();
      
      // Verify platform key
      const platformKeyStatus = await this.verifyPlatformKey();
      
      // Verify key exchange keys
      const keyExchangeKeysStatus = await this.verifyKeyExchangeKeys();
      
      // Verify database
      const databaseStatus = await this.verifyDatabase();
      
      // Calculate overall result and security score
      const overallResult = this.calculateOverallResult(componentResults, platformKeyStatus, keyExchangeKeysStatus, databaseStatus);
      const securityScore = this.calculateSecurityScore(componentResults, platformKeyStatus, keyExchangeKeysStatus, databaseStatus);
      
      // Generate recommendations
      const recommendations = this.generateRecommendations(componentResults, platformKeyStatus, keyExchangeKeysStatus, databaseStatus);
      
      // Identify critical issues
      const criticalIssues = this.identifyCriticalIssues(componentResults, platformKeyStatus, keyExchangeKeysStatus, databaseStatus);

      const report: VerificationReport = {
        id: reportId,
        timestamp: Date.now(),
        duration: performance.now() - startTime,
        overallResult: overallResult.result,
        components: componentResults,
        platformKeyStatus,
        keyExchangeKeysStatus,
        databaseStatus,
        securityScore,
        recommendations,
        criticalIssues
      };

      this.verificationHistory.push(report);
      this.logAudit('verification', `Secure Boot verification completed: ${overallResult.result}`, overallResult.severity);
      
      performanceMonitor.trackMetric('secure_boot_verification_duration', report.duration);
      performanceMonitor.trackMetric('secure_boot_security_score', securityScore);
      
      return report;
    } catch (error) {
      this.logAudit('error', `Secure Boot verification failed: ${error.message}`, 'error');
      throw ErrorHandler.createError('SECURE_BOOT_VERIFICATION_FAILED', error.message);
    }
  }

  private async verifyAllComponents(): Promise<BootComponent[]> {
    const results: BootComponent[] = [];
    
    for (const [name, component] of this.bootComponents) {
      try {
        const verifiedComponent = await this.verifyComponent(component);
        this.bootComponents.set(name, verifiedComponent);
        results.push(verifiedComponent);
      } catch (error) {
        const failedComponent: BootComponent = {
          ...component,
          verified: false,
          verificationTime: Date.now(),
          verificationResult: 'ERROR',
          verificationDetails: error.message
        };
        
        this.bootComponents.set(name, failedComponent);
        results.push(failedComponent);
        
        this.logAudit('error', `Component verification failed for ${name}: ${error.message}`, 'error');
      }
    }
    
    return results;
  }

  private async verifyComponent(component: BootComponent): Promise<BootComponent> {
    const startTime = performance.now();
    
    try {
      // Verify signature
      const signatureValid = await this.verifySignature(component.signature, component.signatureKeyId);
      
      // Verify checksum
      const checksumValid = this.verifyChecksum(component.checksum);
      
      // Check if key is valid and not revoked
      const keyValid = this.isKeyValid(component.signatureKeyId);
      
      const verified = signatureValid && checksumValid && keyValid;
      const result = verified ? 'PASSED' : 'FAILED';
      
      const verifiedComponent: BootComponent = {
        ...component,
        verified,
        verificationTime: Date.now(),
        verificationResult: result,
        verificationDetails: verified ? 
          'Component verified successfully' : 
          `Signature: ${signatureValid ? 'Valid' : 'Invalid'}, Checksum: ${checksumValid ? 'Valid' : 'Invalid'}, Key: ${keyValid ? 'Valid' : 'Invalid'}`
      };

      this.logAudit('component_change', 
        `Component ${component.name} verification: ${result}`, 
        result === 'PASSED' ? 'info' : 'warning'
      );
      
      return verifiedComponent;
    } catch (error) {
      const failedComponent: BootComponent = {
        ...component,
        verified: false,
        verificationTime: Date.now(),
        verificationResult: 'ERROR',
        verificationDetails: error.message
      };

      this.logAudit('error', `Component verification error for ${component.name}: ${error.message}`, 'error');
      
      return failedComponent;
    }
  }

  private async verifySignature(signature: string, keyId: string): Promise<boolean> {
    // Simulate signature verification
    await new Promise(resolve => setTimeout(resolve, 10 + Math.random() * 20));
    
    // Check if key exists in database
    const dbEntry = this.config.database.find(entry => entry.keyId === keyId);
    if (!dbEntry) {
      return false;
    }
    
    // Check if key is revoked
    if (dbEntry.revoked) {
      return false;
    }
    
    // Simulate signature validation (always valid in simulation)
    return true;
  }

  private verifyChecksum(checksum: string): boolean {
    // Simulate checksum verification
    return checksum.length === 64; // SHA-256 hash length
  }

  private isKeyValid(keyId: string): boolean {
    // Check platform key
    if (keyId === this.config.platformKey.id && !this.config.platformKey.revoked) {
      return true;
    }
    
    // Check key exchange keys
    if (this.config.keyExchangeKeys.some(kek => kek.id === keyId && !kek.revoked)) {
      return true;
    }
    
    // Check database
    if (this.config.database.some(entry => entry.keyId === keyId && !entry.revoked)) {
      return true;
    }
    
    return false;
  }

  private async verifyPlatformKey(): Promise<VerificationStatus> {
    const startTime = performance.now();
    
    try {
      const issues: string[] = [];
      const warnings: string[] = [];
      let score = 100;
      
      // Check if platform key exists
      if (!this.config.platformKey) {
        issues.push('Platform key not found');
        score = 0;
      } else {
        // Check if platform key is revoked
        if (this.config.platformKey.revoked) {
          issues.push('Platform key is revoked');
          score -= 50;
        }
        
        // Check if platform key is expired
        if (this.config.platformKey.expires && this.config.platformKey.expires < Date.now()) {
          issues.push('Platform key has expired');
          score -= 30;
        }
        
        // Check key strength
        if (this.config.platformKey.keySize < 2048) {
          warnings.push('Platform key size is less than recommended (2048 bits)');
          score -= 10;
        }
      }
      
      const status: VerificationStatus = {
        valid: issues.length === 0,
        checked: true,
        issues,
        warnings,
        score: Math.max(0, score)
      };

      this.logAudit('verification', 
        `Platform key verification: ${status.valid ? 'PASSED' : 'FAILED'}`, 
        status.valid ? 'info' : 'warning'
      );
      
      return status;
    } catch (error) {
      this.logAudit('error', `Platform key verification error: ${error.message}`, 'error');
      
      return {
        valid: false,
        checked: true,
        issues: [error.message],
        warnings: [],
        score: 0
      };
    }
  }

  private async verifyKeyExchangeKeys(): Promise<VerificationStatus> {
    const startTime = performance.now();
    
    try {
      const issues: string[] = [];
      const warnings: string[] = [];
      let score = 100;
      
      // Check if any key exchange keys exist
      if (this.config.keyExchangeKeys.length === 0) {
        issues.push('No key exchange keys found');
        score = 0;
      } else {
        // Check each key exchange key
        for (const kek of this.config.keyExchangeKeys) {
          if (kek.revoked) {
            issues.push(`Key exchange key ${kek.name} is revoked`);
            score -= 25;
          }
          
          if (kek.expires && kek.expires < Date.now()) {
            issues.push(`Key exchange key ${kek.name} has expired`);
            score -= 15;
          }
          
          if (kek.keySize < 2048) {
            warnings.push(`Key exchange key ${kek.name} size is less than recommended (2048 bits)`);
            score -= 5;
          }
        }
      }
      
      const status: VerificationStatus = {
        valid: issues.length === 0,
        checked: true,
        issues,
        warnings,
        score: Math.max(0, score)
      };

      this.logAudit('verification', 
        `Key exchange keys verification: ${status.valid ? 'PASSED' : 'FAILED'}`, 
        status.valid ? 'info' : 'warning'
      );
      
      return status;
    } catch (error) {
      this.logAudit('error', `Key exchange keys verification error: ${error.message}`, 'error');
      
      return {
        valid: false,
        checked: true,
        issues: [error.message],
        warnings: [],
        score: 0
      };
    }
  }

  private async verifyDatabase(): Promise<VerificationStatus> {
    const startTime = performance.now();
    
    try {
      const issues: string[] = [];
      const warnings: string[] = [];
      let score = 100;
      
      // Check if database entries exist
      if (this.config.database.length === 0) {
        issues.push('No database entries found');
        score = 0;
      } else {
        // Check each database entry
        for (const entry of this.config.database) {
          if (entry.revoked) {
            warnings.push(`Database entry ${entry.description} is revoked`);
            score -= 5;
          }
          
          if (entry.usageCount === 0) {
            warnings.push(`Database entry ${entry.description} has never been used`);
            score -= 2;
          }
          
          // Check if key still exists
          const keyExists = this.isKeyValid(entry.keyId);
          if (!keyExists) {
            issues.push(`Database entry ${entry.description} references invalid key`);
            score -= 20;
          }
        }
      }
      
      const status: VerificationStatus = {
        valid: issues.length === 0,
        checked: true,
        issues,
        warnings,
        score: Math.max(0, score)
      };

      this.logAudit('verification', 
        `Database verification: ${status.valid ? 'PASSED' : 'FAILED'}`, 
        status.valid ? 'info' : 'warning'
      );
      
      return status;
    } catch (error) {
      this.logAudit('error', `Database verification error: ${error.message}`, 'error');
      
      return {
        valid: false,
        checked: true,
        issues: [error.message],
        warnings: [],
        score: 0
      };
    }
  }

  private calculateOverallResult(
    components: BootComponent[],
    platformKeyStatus: VerificationStatus,
    keyExchangeKeysStatus: VerificationStatus,
    databaseStatus: VerificationStatus
  ): { result: keyof typeof VERIFICATION_RESULTS; severity: 'info' | 'warning' | 'error' | 'critical' } {
    
    const failedComponents = components.filter(c => c.verificationResult === 'FAILED' || c.verificationResult === 'ERROR');
    const criticalFailures = failedComponents.filter(c => c.name === 'BIOS' || c.name === 'FIRMWARE');
    
    if (criticalFailures.length > 0 || !platformKeyStatus.valid) {
      return { result: 'FAILED', severity: 'critical' };
    }
    
    if (failedComponents.length > 0 || !keyExchangeKeysStatus.valid || !databaseStatus.valid) {
      return { result: 'FAILED', severity: 'error' };
    }
    
    const warnings = components.filter(c => c.verificationResult === 'WARNING').length +
                    platformKeyStatus.warnings.length +
                    keyExchangeKeysStatus.warnings.length +
                    databaseStatus.warnings.length;
    
    if (warnings > 0) {
      return { result: 'WARNING', severity: 'warning' };
    }
    
    return { result: 'PASSED', severity: 'info' };
  }

  private calculateSecurityScore(
    components: BootComponent[],
    platformKeyStatus: VerificationStatus,
    keyExchangeKeysStatus: VerificationStatus,
    databaseStatus: VerificationStatus
  ): number {
    
    const componentScore = components.reduce((sum, component) => {
      return sum + (component.verified ? 20 : 0);
    }, 0);
    
    const totalScore = componentScore + 
                      platformKeyStatus.score * 0.2 +
                      keyExchangeKeysStatus.score * 0.2 +
                      databaseStatus.score * 0.2;
    
    return Math.round(totalScore);
  }

  private generateRecommendations(
    components: BootComponent[],
    platformKeyStatus: VerificationStatus,
    keyExchangeKeysStatus: VerificationStatus,
    databaseStatus: VerificationStatus
  ): string[] {
    
    const recommendations: string[] = [];
    
    // Component recommendations
    const failedComponents = components.filter(c => !c.verified);
    if (failedComponents.length > 0) {
      recommendations.push(`Update or repair failed boot components: ${failedComponents.map(c => c.name).join(', ')}`);
    }
    
    // Platform key recommendations
    if (!platformKeyStatus.valid) {
      recommendations.push('Regenerate or restore platform key');
    }
    if (platformKeyStatus.warnings.length > 0) {
      recommendations.push('Consider upgrading platform key to stronger cryptography');
    }
    
    // Key exchange key recommendations
    if (!keyExchangeKeysStatus.valid) {
      recommendations.push('Update or restore key exchange keys');
    }
    if (this.config.keyExchangeKeys.length === 0) {
      recommendations.push('Add trusted key exchange keys to enhance security');
    }
    
    // Database recommendations
    if (!databaseStatus.valid) {
      recommendations.push('Clean up invalid database entries');
    }
    if (this.config.database.length === 0) {
      recommendations.push('Add trusted signatures to the database');
    }
    
    // General recommendations
    const revokedEntries = [...this.config.keyExchangeKeys.filter(k => k.revoked), 
                           ...this.config.database.filter(d => d.revoked)];
    if (revokedEntries.length > 0) {
      recommendations.push('Remove revoked keys and signatures from the system');
    }
    
    return recommendations;
  }

  private identifyCriticalIssues(
    components: BootComponent[],
    platformKeyStatus: VerificationStatus,
    keyExchangeKeysStatus: VerificationStatus,
    databaseStatus: VerificationStatus
  ): string[] {
    
    const criticalIssues: string[] = [];
    
    // Critical component failures
    const criticalComponents = components.filter(c => 
      (c.name === 'BIOS' || c.name === 'FIRMWARE') && !c.verified
    );
    if (criticalComponents.length > 0) {
      criticalIssues.push(`Critical boot components failed verification: ${criticalComponents.map(c => c.name).join(', ')}`);
    }
    
    // Platform key issues
    if (!platformKeyStatus.valid) {
      criticalIssues.push('Platform key validation failed - system integrity compromised');
    }
    
    // Multiple key exchange key failures
    const failedKEKs = this.config.keyExchangeKeys.filter(k => k.revoked).length;
    if (failedKEKs > this.config.keyExchangeKeys.length / 2) {
      criticalIssues.push('Majority of key exchange keys are revoked');
    }
    
    return criticalIssues;
  }

  // Utility Methods
  private generateKeyData(algorithm: string): string {
    return `KEY-${algorithm}-${createId()}`;
  }

  private generateFingerprint(): string {
    return Array.from({ length: 40 }, () => 
      Math.floor(Math.random() * 16).toString(16)
    ).join('');
  }

  private generateChecksum(): string {
    return Array.from({ length: 64 }, () => 
      Math.floor(Math.random() * 16).toString(16)
    ).join('');
  }

  private generateSignature(): string {
    return `SIG-${createId()}`;
  }

  private logAudit(type: AuditLogEntry['type'], details: string, severity: AuditLogEntry['severity'], component?: string): void {
    const entry: AuditLogEntry = {
      id: createId(),
      timestamp: Date.now(),
      type,
      component,
      details,
      severity
    };

    this.auditLog.push(entry);
    
    // Keep only recent entries
    if (this.auditLog.length > this.config.auditLogSize) {
      this.auditLog = this.auditLog.slice(-this.config.auditLogSize);
    }
  }

  // Status and Monitoring
  getStatus(): SecureBootStatus {
    const verifiedComponents = Array.from(this.bootComponents.values()).filter(c => c.verified).length;
    const totalComponents = this.bootComponents.size;
    
    return {
      enabled: this.config.state === 'ENABLED',
      state: this.config.state,
      lastVerification: this.verificationHistory.length > 0 ? 
        this.verificationHistory[this.verificationHistory.length - 1].timestamp : 0,
      verificationResult: this.verificationHistory.length > 0 ? 
        this.verificationHistory[this.verificationHistory.length - 1].overallResult : 'SKIPPED',
      verifiedComponents,
      totalComponents,
      platformKeyValid: !this.config.platformKey.revoked,
      keyExchangeKeysValid: this.config.keyExchangeKeys.every(k => !k.revoked),
      databaseValid: this.config.database.every(d => !d.revoked),
      warnings: [],
      errors: []
    };
  }

  getAuditLog(limit: number = 50): AuditLogEntry[] {
    return this.auditLog.slice(-limit).reverse();
  }

  getVerificationHistory(limit: number = 10): VerificationReport[] {
    return this.verificationHistory.slice(-limit).reverse();
  }

  getBootComponents(): BootComponent[] {
    return Array.from(this.bootComponents.values());
  }

  getConfig(): SecureBootConfig {
    return { ...this.config };
  }
}

// Global instance
export const secureBootVerificationManager = new SecureBootVerificationManager();

// Utility functions for easy access
export async function verifySecureBoot(): Promise<VerificationReport> {
  return await secureBootVerificationManager.verifySecureBoot();
}

export function getSecureBootStatus(): SecureBootStatus {
  return secureBootVerificationManager.getStatus();
}

export function getSecureBootAuditLog(limit?: number): AuditLogEntry[] {
  return secureBootVerificationManager.getAuditLog(limit);
}

export function getSecureBootHistory(limit?: number): VerificationReport[] {
  return secureBootVerificationManager.getVerificationHistory(limit);
}

export function getBootComponents(): BootComponent[] {
  return secureBootVerificationManager.getBootComponents();
}

export async function initializeSecureBoot(): Promise<void> {
  await secureBootVerificationManager.initialize();
}