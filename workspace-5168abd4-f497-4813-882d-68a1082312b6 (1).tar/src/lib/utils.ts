import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { designSystem } from "./design-system"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Enhanced utility functions for holistic development
export const utils = {
  // Class name utility with design system integration
  cx: (...inputs: ClassValue[]) => cn(...inputs),
  
  // Design system utilities
  design: designSystem.utils,
  
  // Format utilities
  format: {
    // Number formatting
    number: (value: number, options?: Intl.NumberFormatOptions) => {
      return new Intl.NumberFormat('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2,
        ...options,
      }).format(value)
    },
    
    // Currency formatting
    currency: (value: number, currency = 'USD') => {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency,
      }).format(value)
    },
    
    // Percentage formatting
    percentage: (value: number, decimals = 1) => {
      return `${value.toFixed(decimals)}%`
    },
    
    // Date formatting
    date: (date: Date | string, options?: Intl.DateTimeFormatOptions) => {
      const dateObj = typeof date === 'string' ? new Date(date) : date
      return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        ...options,
      }).format(dateObj)
    },
    
    // Relative time formatting
    relativeTime: (date: Date | string) => {
      const dateObj = typeof date === 'string' ? new Date(date) : date
      const now = new Date()
      const diff = now.getTime() - dateObj.getTime()
      
      const seconds = Math.floor(diff / 1000)
      const minutes = Math.floor(seconds / 60)
      const hours = Math.floor(minutes / 60)
      const days = Math.floor(hours / 24)
      
      if (seconds < 60) return 'just now'
      if (minutes < 60) return `${minutes}m ago`
      if (hours < 24) return `${hours}h ago`
      if (days < 7) return `${days}d ago`
      
      return utils.format.date(dateObj)
    },
    
    // File size formatting
    fileSize: (bytes: number) => {
      const sizes = ['B', 'KB', 'MB', 'GB', 'TB']
      if (bytes === 0) return '0 B'
      
      const i = Math.floor(Math.log(bytes) / Math.log(1024))
      return `${Math.round(bytes / Math.pow(1024, i) * 100) / 100} ${sizes[i]}`
    },
  },
  
  // Validation utilities
  validation: {
    // Email validation
    isEmail: (email: string) => {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      return emailRegex.test(email)
    },
    
    // URL validation
    isUrl: (url: string) => {
      try {
        new URL(url)
        return true
      } catch {
        return false
      }
    },
    
    // Phone number validation (basic)
    isPhone: (phone: string) => {
      const phoneRegex = /^\+?[\d\s\-\(\)]+$/
      return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 10
    },
    
    // Required field validation
    isRequired: (value: any) => {
      if (value === null || value === undefined) return false
      if (typeof value === 'string') return value.trim().length > 0
      if (Array.isArray(value)) return value.length > 0
      return true
    },
    
    // Password strength validation
    isStrongPassword: (password: string) => {
      return password.length >= 8 &&
             /[a-z]/.test(password) &&
             /[A-Z]/.test(password) &&
             /[0-9]/.test(password) &&
             /[^a-zA-Z0-9]/.test(password)
    },
  },
  
  // Array utilities
  array: {
    // Unique array
    unique: <T>(array: T[]) => [...new Set(array)],
    
    // Group by
    groupBy: <T>(array: T[], key: keyof T) => {
      return array.reduce((groups, item) => {
        const group = String(item[key])
        if (!groups[group]) groups[group] = []
        groups[group].push(item)
        return groups
      }, {} as Record<string, T[]>)
    },
    
    // Sort by
    sortBy: <T>(array: T[], key: keyof T, direction: 'asc' | 'desc' = 'asc') => {
      return [...array].sort((a, b) => {
        const aValue = a[key]
        const bValue = b[key]
        
        if (aValue < bValue) return direction === 'asc' ? -1 : 1
        if (aValue > bValue) return direction === 'asc' ? 1 : -1
        return 0
      })
    },
    
    // Chunk array
    chunk: <T>(array: T[], size: number) => {
      const chunks: T[][] = []
      for (let i = 0; i < array.length; i += size) {
        chunks.push(array.slice(i, i + size))
      }
      return chunks
    },
    
    // Flatten array
    flatten: <T>(array: T[]) => {
      return array.flat()
    },
  },
  
  // Object utilities
  object: {
    // Deep clone
    deepClone: <T>(obj: T): T => {
      if (obj === null || typeof obj !== 'object') return obj
      if (obj instanceof Date) return new Date(obj.getTime()) as T
      if (obj instanceof Array) return obj.map(item => utils.object.deepClone(item)) as T
      if (typeof obj === 'object') {
        const cloned = {} as T
        Object.keys(obj).forEach(key => {
          cloned[key as keyof T] = utils.object.deepClone(obj[key as keyof T])
        })
        return cloned
      }
      return obj
    },
    
    // Pick properties
    pick: <T, K extends keyof T>(obj: T, keys: K[]) => {
      return keys.reduce((picked, key) => {
        picked[key] = obj[key]
        return picked
      }, {} as Pick<T, K>)
    },
    
    // Omit properties
    omit: <T, K extends keyof T>(obj: T, keys: K[]) => {
      const result = { ...obj }
      keys.forEach(key => delete result[key])
      return result as Omit<T, K>
    },
    
    // Merge objects
    merge: <T extends Record<string, any>>(...objects: T[]) => {
      return objects.reduce((merged, obj) => {
        Object.keys(obj).forEach(key => {
          if (typeof obj[key] === 'object' && obj[key] !== null && !Array.isArray(obj[key])) {
            merged[key] = utils.object.merge(merged[key] || {}, obj[key])
          } else {
            merged[key] = obj[key]
          }
        })
        return merged
      }, {} as T)
    },
  },
  
  // String utilities
  string: {
    // Capitalize first letter
    capitalize: (str: string) => {
      return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase()
    },
    
    // Title case
    titleCase: (str: string) => {
      return str.replace(/\w\S*/g, txt => 
        txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
      )
    },
    
    // Camel case
    camelCase: (str: string) => {
      return str
        .replace(/(?:^\w|[A-Z]|\b\w)/g, (word, index) => 
          index === 0 ? word.toLowerCase() : word.toUpperCase()
        )
        .replace(/\s+/g, '')
    },
    
    // Kebab case
    kebabCase: (str: string) => {
      return str
        .replace(/([a-z])([A-Z])/g, '$1-$2')
        .replace(/\s+/g, '-')
        .toLowerCase()
    },
    
    // Snake case
    snakeCase: (str: string) => {
      return str
        .replace(/([a-z])([A-Z])/g, '$1_$2')
        .replace(/\s+/g, '_')
        .toLowerCase()
    },
    
    // Truncate string
    truncate: (str: string, length: number, suffix = '...') => {
      if (str.length <= length) return str
      return str.slice(0, length) + suffix
    },
    
    // Generate slug
    slugify: (str: string) => {
      return str
        .toLowerCase()
        .replace(/[^\w\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .trim()
    },
  },
  
  // DOM utilities
  dom: {
    // Get element by selector
    get: (selector: string) => {
      return document.querySelector(selector)
    },
    
    // Get all elements by selector
    getAll: (selector: string) => {
      return document.querySelectorAll(selector)
    },
    
    // Create element
    create: (tag: string, attributes?: Record<string, string>, content?: string) => {
      const element = document.createElement(tag)
      if (attributes) {
        Object.entries(attributes).forEach(([key, value]) => {
          element.setAttribute(key, value)
        })
      }
      if (content) {
        element.textContent = content
      }
      return element
    },
    
    // Add event listener
    on: (element: Element | string, event: string, handler: EventListener) => {
      const el = typeof element === 'string' ? utils.dom.get(element) : element
      if (el) {
        el.addEventListener(event, handler)
      }
    },
    
    // Remove event listener
    off: (element: Element | string, event: string, handler: EventListener) => {
      const el = typeof element === 'string' ? utils.dom.get(element) : element
      if (el) {
        el.removeEventListener(event, handler)
      }
    },
    
    // Check if element is in viewport
    isInViewport: (element: Element) => {
      const rect = element.getBoundingClientRect()
      return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
      )
    },
    
    // Scroll to element
    scrollTo: (element: Element | string, options?: ScrollIntoViewOptions) => {
      const el = typeof element === 'string' ? utils.dom.get(element) : element
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', ...options })
      }
    },
  },
  
  // Async utilities
  async: {
    // Delay execution
    delay: (ms: number) => new Promise(resolve => setTimeout(resolve, ms)),
    
    // Retry function
    retry: async <T>(
      fn: () => Promise<T>,
      maxAttempts = 3,
      delayMs = 1000
    ): Promise<T> => {
      let lastError: Error
      
      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
          return await fn()
        } catch (error) {
          lastError = error as Error
          if (attempt < maxAttempts) {
            await utils.async.delay(delayMs)
          }
        }
      }
      
      throw lastError!
    },
    
    // Timeout promise
    timeout: <T>(
      promise: Promise<T>,
      ms: number,
      timeoutError = new Error('Operation timed out')
    ): Promise<T> => {
      return Promise.race([
        promise,
        new Promise<never>((_, reject) => 
          setTimeout(() => reject(timeoutError), ms)
        )
      ])
    },
    
    // Debounce function
    debounce: <T extends (...args: any[]) => any>(
      func: T,
      wait: number
    ): (...args: Parameters<T>) => void => {
      let timeout: NodeJS.Timeout
      
      return (...args: Parameters<T>) => {
        clearTimeout(timeout)
        timeout = setTimeout(() => func(...args), wait)
      }
    },
    
    // Throttle function
    throttle: <T extends (...args: any[]) => any>(
      func: T,
      limit: number
    ): (...args: Parameters<T>) => void => {
      let inThrottle: boolean
      
      return (...args: Parameters<T>) => {
        if (!inThrottle) {
          func(...args)
          inThrottle = true
          setTimeout(() => inThrottle = false, limit)
        }
      }
    },
  },
  
  // Storage utilities
  storage: {
    // Local storage
    local: {
      get: <T>(key: string, defaultValue?: T): T | null => {
        try {
          const item = localStorage.getItem(key)
          return item ? JSON.parse(item) : defaultValue || null
        } catch {
          return defaultValue || null
        }
      },
      
      set: <T>(key: string, value: T): void => {
        try {
          localStorage.setItem(key, JSON.stringify(value))
        } catch (error) {
          console.error('Failed to set localStorage item:', error)
        }
      },
      
      remove: (key: string): void => {
        try {
          localStorage.removeItem(key)
        } catch (error) {
          console.error('Failed to remove localStorage item:', error)
        }
      },
      
      clear: (): void => {
        try {
          localStorage.clear()
        } catch (error) {
          console.error('Failed to clear localStorage:', error)
        }
      },
    },
    
    // Session storage
    session: {
      get: <T>(key: string, defaultValue?: T): T | null => {
        try {
          const item = sessionStorage.getItem(key)
          return item ? JSON.parse(item) : defaultValue || null
        } catch {
          return defaultValue || null
        }
      },
      
      set: <T>(key: string, value: T): void => {
        try {
          sessionStorage.setItem(key, JSON.stringify(value))
        } catch (error) {
          console.error('Failed to set sessionStorage item:', error)
        }
      },
      
      remove: (key: string): void => {
        try {
          sessionStorage.removeItem(key)
        } catch (error) {
          console.error('Failed to remove sessionStorage item:', error)
        }
      },
      
      clear: (): void => {
        try {
          sessionStorage.clear()
        } catch (error) {
          console.error('Failed to clear sessionStorage:', error)
        }
      },
    },
  },
  
  // Math utilities
  math: {
    // Random number in range
    random: (min: number, max: number) => {
      return Math.random() * (max - min) + min
    },
    
    // Random integer in range
    randomInt: (min: number, max: number) => {
      return Math.floor(utils.math.random(min, max + 1))
    },
    
    // Clamp number
    clamp: (value: number, min: number, max: number) => {
      return Math.min(Math.max(value, min), max)
    },
    
    // Linear interpolation
    lerp: (start: number, end: number, t: number) => {
      return start + (end - start) * t
    },
    
    // Map value from one range to another
    map: (value: number, inMin: number, inMax: number, outMin: number, outMax: number) => {
      return ((value - inMin) / (inMax - inMin)) * (outMax - outMin) + outMin
    },
    
    // Round to decimal places
    round: (value: number, decimals: number) => {
      const factor = Math.pow(10, decimals)
      return Math.round(value * factor) / factor
    },
    
    // Calculate percentage
    percentage: (value: number, total: number) => {
      return total === 0 ? 0 : (value / total) * 100
    },
    
    // Calculate average
    average: (numbers: number[]) => {
      return numbers.reduce((sum, num) => sum + num, 0) / numbers.length
    },
    
    // Calculate sum
    sum: (numbers: number[]) => {
      return numbers.reduce((sum, num) => sum + num, 0)
    },
    
    // Find min and max
    minMax: (numbers: number[]) => {
      return {
        min: Math.min(...numbers),
        max: Math.max(...numbers)
      }
    },
  },
  
  // Color utilities
  color: {
    // Convert hex to RGB
    hexToRgb: (hex: string) => {
      const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
      return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
      } : null
    },
    
    // Convert RGB to hex
    rgbToHex: (r: number, g: number, b: number) => {
      return "#" + [r, g, b].map(x => {
        const hex = x.toString(16)
        return hex.length === 1 ? "0" + hex : hex
      }).join("")
    },
    
    // Lighten color
    lighten: (hex: string, percent: number) => {
      const rgb = utils.color.hexToRgb(hex)
      if (!rgb) return hex
      
      const factor = percent / 100
      return utils.color.rgbToHex(
        Math.min(255, Math.round(rgb.r + (255 - rgb.r) * factor)),
        Math.min(255, Math.round(rgb.g + (255 - rgb.g) * factor)),
        Math.min(255, Math.round(rgb.b + (255 - rgb.b) * factor))
      )
    },
    
    // Darken color
    darken: (hex: string, percent: number) => {
      const rgb = utils.color.hexToRgb(hex)
      if (!rgb) return hex
      
      const factor = percent / 100
      return utils.color.rgbToHex(
        Math.max(0, Math.round(rgb.r - rgb.r * factor)),
        Math.max(0, Math.round(rgb.g - rgb.g * factor)),
        Math.max(0, Math.round(rgb.b - rgb.b * factor))
      )
    },
    
    // Generate color palette
    generatePalette: (baseColor: string, count = 5) => {
      const palette = []
      for (let i = 0; i < count; i++) {
        const percent = (i - Math.floor(count / 2)) * 20
        palette.push(percent > 0 ? utils.color.lighten(baseColor, percent) : utils.color.darken(baseColor, -percent))
      }
      return palette
    },
  },
}

export default utils
