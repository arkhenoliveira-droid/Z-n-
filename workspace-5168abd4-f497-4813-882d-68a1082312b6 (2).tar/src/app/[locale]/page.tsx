'use client';

import { useState, useEffect, useRef } from 'react';
import { useTranslations, useLocale } from 'next-intl';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Slider } from '@/components/ui/slider';
import { 
  Cpu, 
  Zap, 
  Activity, 
  Radio, 
  Monitor, 
  Volume2,
  Play,
  Pause,
  Square,
  Settings,
  Brain,
  Network,
  Thermometer,
  MemoryStick,
  HardDrive,
  Wifi,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface EdgeNodeMetrics {
  cpuUsage: number;
  memoryUsage: number;
  gpuUsage: number;
  temperature: number;
  networkLatency: number;
  inferenceSpeed: number;
  activeModels: number;
  generatedFrames: number;
  generatedAudioSamples: number;
}

interface AIModel {
  id: string;
  name: string;
  type: 'pixel' | 'audio' | 'multimodal';
  status: 'loading' | 'ready' | 'running' | 'error';
  size: string;
  description: string;
}

interface GenerationParams {
  resolution: [number, number];
  frameRate: number;
  audioSampleRate: number;
  audioChannels: number;
  complexity: number;
  style: string;
}

export default function EdgeNodeInference() {
  const t = useTranslations();
  const locale = useLocale();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const animationRef = useRef<number | null>(null);
  
  const [isRunning, setIsRunning] = useState(false);
  const [metrics, setMetrics] = useState<EdgeNodeMetrics>({
    cpuUsage: 0,
    memoryUsage: 0,
    gpuUsage: 0,
    temperature: 0,
    networkLatency: 0,
    inferenceSpeed: 0,
    activeModels: 0,
    generatedFrames: 0,
    generatedAudioSamples: 0
  });
  
  const [models, setModels] = useState<AIModel[]>([
    {
      id: 'pixel-gen-v1',
      name: 'Pixel Generator v1',
      type: 'pixel',
      status: 'ready',
      size: '2.3GB',
      description: 'Real-time pixel generation using neural networks'
    },
    {
      id: 'audio-synth-v1',
      name: 'Audio Synthesizer v1',
      type: 'audio',
      status: 'ready',
      size: '1.8GB',
      description: 'AI-powered audio synthesis and generation'
    },
    {
      id: 'multimodal-v1',
      name: 'Multimodal Engine v1',
      type: 'multimodal',
      status: 'loading',
      size: '4.7GB',
      description: 'Combined pixel and audio generation with cross-modal understanding'
    }
  ]);
  
  const [params, setParams] = useState<GenerationParams>({
    resolution: [1920, 1080],
    frameRate: 60,
    audioSampleRate: 48000,
    audioChannels: 2,
    complexity: 50,
    style: 'neural-art'
  });
  
  const [currentModel, setCurrentModel] = useState('pixel-gen-v1');

  // Initialize audio context
  useEffect(() => {
    if (typeof window !== 'undefined') {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  // Simulate edge node metrics
  useEffect(() => {
    const interval = setInterval(() => {
      if (isRunning) {
        setMetrics(prev => ({
          cpuUsage: Math.min(100, prev.cpuUsage + Math.random() * 10 - 3),
          memoryUsage: Math.min(100, prev.memoryUsage + Math.random() * 5 - 2),
          gpuUsage: Math.min(100, prev.gpuUsage + Math.random() * 15 - 5),
          temperature: Math.min(85, prev.temperature + Math.random() * 2 - 0.5),
          networkLatency: Math.max(1, prev.networkLatency + Math.random() * 5 - 2.5),
          inferenceSpeed: Math.max(10, prev.inferenceSpeed + Math.random() * 20 - 8),
          activeModels: models.filter(m => m.status === 'running').length,
          generatedFrames: prev.generatedFrames + Math.floor(Math.random() * 3),
          generatedAudioSamples: prev.generatedAudioSamples + Math.floor(Math.random() * 1000)
        }));
      } else {
        setMetrics(prev => ({
          ...prev,
          cpuUsage: Math.max(0, prev.cpuUsage - 2),
          memoryUsage: Math.max(0, prev.memoryUsage - 1),
          gpuUsage: Math.max(0, prev.gpuUsage - 3),
          temperature: Math.max(25, prev.temperature - 0.5),
          inferenceSpeed: Math.max(0, prev.inferenceSpeed - 5)
        }));
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isRunning, models]);

  // AI pixel generation
  const generatePixels = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const [width, height] = params.resolution;
    canvas.width = width;
    canvas.height = height;

    const imageData = ctx.createImageData(width, height);
    const data = imageData.data;

    // AI-generated pixel patterns
    const time = Date.now() * 0.001;
    const complexity = params.complexity / 100;

    for (let i = 0; i < data.length; i += 4) {
      const x = (i / 4) % width;
      const y = Math.floor((i / 4) / width);
      
      // Neural network-inspired pixel generation
      const r1 = Math.sin(x * 0.01 + time) * Math.cos(y * 0.01 + time * 0.7);
      const r2 = Math.sin(x * 0.02 + time * 1.3) * Math.cos(y * 0.015 + time * 0.9);
      const r3 = Math.sin(x * 0.005 + time * 0.5) * Math.cos(y * 0.025 + time * 1.1);
      
      const intensity = (r1 + r2 + r3) * 0.5 + 0.5;
      const enhancedIntensity = Math.pow(intensity, 1 + complexity);
      
      data[i] = enhancedIntensity * 255 * (0.5 + 0.5 * Math.sin(time * 2));     // Red
      data[i + 1] = enhancedIntensity * 255 * (0.5 + 0.5 * Math.cos(time * 1.7)); // Green
      data[i + 2] = enhancedIntensity * 255 * (0.5 + 0.5 * Math.sin(time * 1.3)); // Blue
      data[i + 3] = 255; // Alpha
    }

    ctx.putImageData(imageData, 0, 0);
  };

  // AI audio generation
  const generateAudio = () => {
    if (!audioContextRef.current) return;

    const audioContext = audioContextRef.current;
    const sampleRate = params.audioSampleRate;
    const duration = 0.1; // 100ms chunks
    const frameCount = sampleRate * duration;
    
    const buffer = audioContext.createBuffer(params.audioChannels, frameCount, sampleRate);
    
    for (let channel = 0; channel < params.audioChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      const time = Date.now() * 0.001;
      const complexity = params.complexity / 100;
      
      for (let i = 0; i < frameCount; i++) {
        const t = i / sampleRate;
        
        // AI-generated audio using multiple oscillators with neural modulation
        const fundamental = 220 * Math.pow(2, Math.sin(time * 0.1) * 0.5);
        const harmonic1 = fundamental * 2;
        const harmonic2 = fundamental * 3;
        
        const modulation = Math.sin(time * 0.5) * 0.3 + 0.7;
        const complexityModulation = 1 + complexity * Math.sin(t * 10 + time);
        
        const sample = (
          Math.sin(2 * Math.PI * fundamental * t) * 0.3 +
          Math.sin(2 * Math.PI * harmonic1 * t) * 0.2 * modulation +
          Math.sin(2 * Math.PI * harmonic2 * t) * 0.1 * complexityModulation +
          (Math.random() - 0.5) * 0.05 * complexity
        ) * 0.5;
        
        channelData[i] = sample;
      }
    }
    
    const source = audioContext.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContext.destination);
    source.start();
  };

  // Main generation loop
  const generationLoop = () => {
    if (!isRunning) return;
    
    generatePixels();
    
    if (Math.random() < 0.1) { // Generate audio occasionally
      generateAudio();
    }
    
    animationRef.current = requestAnimationFrame(generationLoop);
  };

  const startGeneration = () => {
    setIsRunning(true);
    setModels(prev => prev.map(m => 
      m.id === currentModel ? { ...m, status: 'running' as const } : m
    ));
    generationLoop();
  };

  const stopGeneration = () => {
    setIsRunning(false);
    setModels(prev => prev.map(m => 
      m.status === 'running' ? { ...m, status: 'ready' as const } : m
    ));
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ready': return 'text-green-600 bg-green-100';
      case 'running': return 'text-blue-600 bg-blue-100';
      case 'loading': return 'text-yellow-600 bg-yellow-100';
      case 'error': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getMetricColor = (value: number, type: string) => {
    if (type === 'temperature') {
      if (value < 40) return 'text-green-600';
      if (value < 60) return 'text-yellow-600';
      return 'text-red-600';
    }
    if (type === 'usage') {
      if (value < 50) return 'text-green-600';
      if (value < 80) return 'text-yellow-600';
      return 'text-red-600';
    }
    if (type === 'latency') {
      if (value < 10) return 'text-green-600';
      if (value < 50) return 'text-yellow-600';
      return 'text-red-600';
    }
    return 'text-blue-600';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white">
      {/* Header */}
      <header className="border-b border-purple-800 bg-black/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Cpu className="w-8 h-8 text-purple-400" />
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                  Edge Node AI Inference
                </h1>
                <p className="text-sm text-purple-300">
                  Direct AI-powered pixel and audio generation • No traditional OS • Pure neural rendering
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="border-green-500 text-green-400">
                <Globe className="w-3 h-3 mr-1" />
                Edge Node Active
              </Badge>
              <Badge variant="outline" className="border-blue-500 text-blue-400">
                <Wifi className="w-3 h-3 mr-1" />
                {metrics.networkLatency.toFixed(1)}ms
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Control Panel */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Card className="bg-black/50 border-purple-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-400">
                <Brain className="w-5 h-5" />
                Neural Generation Control
              </CardTitle>
              <CardDescription className="text-purple-300">
                Control AI inference and generation parameters
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-4">
                <Button
                  onClick={isRunning ? stopGeneration : startGeneration}
                  className={`flex items-center gap-2 ${
                    isRunning 
                      ? 'bg-red-600 hover:bg-red-700' 
                      : 'bg-green-600 hover:bg-green-700'
                  }`}
                >
                  {isRunning ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  {isRunning ? 'Stop Generation' : 'Start Generation'}
                </Button>
                
                <Badge variant="outline" className={isRunning ? 'border-green-500 text-green-400' : 'border-gray-500 text-gray-400'}>
                  Status: {isRunning ? 'Active' : 'Idle'}
                </Badge>
                
                <Badge variant="outline" className="border-purple-500 text-purple-400">
                  <Activity className="w-3 h-3 mr-1" />
                  {metrics.inferenceSpeed.toFixed(0)} FPS
                </Badge>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2 text-purple-300">
                    Complexity: {params.complexity}%
                  </label>
                  <Slider
                    value={[params.complexity]}
                    onValueChange={(value) => setParams(prev => ({ ...prev, complexity: value[0] }))}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2 text-purple-300">
                    Frame Rate: {params.frameRate} FPS
                  </label>
                  <Slider
                    value={[params.frameRate]}
                    onValueChange={(value) => setParams(prev => ({ ...prev, frameRate: value[0] }))}
                    max={120}
                    step={1}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2 text-purple-300">
                    Audio Sample Rate: {params.audioSampleRate} Hz
                  </label>
                  <Slider
                    value={[params.audioSampleRate]}
                    onValueChange={(value) => setParams(prev => ({ ...prev, audioSampleRate: value[0] }))}
                    max={96000}
                    step={1000}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2 text-purple-300">
                    Audio Channels: {params.audioChannels}
                  </label>
                  <Slider
                    value={[params.audioChannels]}
                    onValueChange={(value) => setParams(prev => ({ ...prev, audioChannels: value[0] }))}
                    max={8}
                    step={1}
                    className="w-full"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* System Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <Card className="bg-black/50 border-purple-800">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Cpu className="w-5 h-5 text-blue-400" />
                  <div>
                    <div className={`text-lg font-bold ${getMetricColor(metrics.cpuUsage, 'usage')}`}>
                      {metrics.cpuUsage.toFixed(1)}%
                    </div>
                    <div className="text-xs text-purple-300">CPU</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/50 border-purple-800">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <MemoryStick className="w-5 h-5 text-green-400" />
                  <div>
                    <div className={`text-lg font-bold ${getMetricColor(metrics.memoryUsage, 'usage')}`}>
                      {metrics.memoryUsage.toFixed(1)}%
                    </div>
                    <div className="text-xs text-purple-300">Memory</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/50 border-purple-800">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Monitor className="w-5 h-5 text-purple-400" />
                  <div>
                    <div className={`text-lg font-bold ${getMetricColor(metrics.gpuUsage, 'usage')}`}>
                      {metrics.gpuUsage.toFixed(1)}%
                    </div>
                    <div className="text-xs text-purple-300">GPU</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/50 border-purple-800">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Thermometer className="w-5 h-5 text-orange-400" />
                  <div>
                    <div className={`text-lg font-bold ${getMetricColor(metrics.temperature, 'temperature')}`}>
                      {metrics.temperature.toFixed(1)}°C
                    </div>
                    <div className="text-xs text-purple-300">Temperature</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/50 border-purple-800">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Network className="w-5 h-5 text-yellow-400" />
                  <div>
                    <div className={`text-lg font-bold ${getMetricColor(metrics.networkLatency, 'latency')}`}>
                      {metrics.networkLatency.toFixed(1)}ms
                    </div>
                    <div className="text-xs text-purple-300">Latency</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/50 border-purple-800">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Zap className="w-5 h-5 text-red-400" />
                  <div>
                    <div className="text-lg font-bold text-red-400">
                      {metrics.activeModels}
                    </div>
                    <div className="text-xs text-purple-300">Active Models</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>

        {/* Generation Output */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8"
        >
          {/* Pixel Generation */}
          <Card className="bg-black/50 border-purple-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-400">
                <Monitor className="w-5 h-5" />
                Pixel Generation
              </CardTitle>
              <CardDescription className="text-purple-300">
                AI-generated pixels in real-time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <canvas
                  ref={canvasRef}
                  className="w-full h-64 bg-black rounded-lg border border-purple-700"
                  style={{ imageRendering: 'pixelated' }}
                />
                <div className="absolute top-2 right-2 bg-black/70 px-2 py-1 rounded text-xs text-purple-300">
                  {params.resolution[0]}×{params.resolution[1]} • {metrics.generatedFrames} frames
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Audio Generation */}
          <Card className="bg-black/50 border-purple-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-400">
                <Volume2 className="w-5 h-5" />
                Audio Generation
              </CardTitle>
              <CardDescription className="text-purple-300">
                AI-synthesized audio in real-time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="h-32 bg-black rounded-lg border border-purple-700 flex items-center justify-center">
                  <div className="text-center">
                    <Radio className="w-12 h-12 text-purple-400 mx-auto mb-2" />
                    <div className="text-sm text-purple-300">
                      {params.audioSampleRate} Hz • {params.audioChannels} channels
                    </div>
                    <div className="text-xs text-purple-400">
                      {metrics.generatedAudioSamples.toLocaleString()} samples generated
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 text-sm text-purple-300">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    Audio Output Active
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                    Neural Synthesis
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* AI Models */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="bg-black/50 border-purple-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-400">
                <Brain className="w-5 h-5" />
                AI Models
              </CardTitle>
              <CardDescription className="text-purple-300">
                Loaded neural networks for edge inference
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {models.map((model) => (
                  <Card
                    key={model.id}
                    className={`bg-black/30 border-purple-700 cursor-pointer transition-all ${
                      currentModel === model.id ? 'ring-2 ring-purple-500' : ''
                    }`}
                    onClick={() => setCurrentModel(model.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-purple-300">{model.name}</h3>
                        <Badge variant="outline" className={getStatusColor(model.status)}>
                          {model.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-purple-400 mb-2">{model.description}</p>
                      <div className="flex items-center justify-between text-xs text-purple-500">
                        <span>{model.size}</span>
                        <span className="capitalize">{model.type}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}