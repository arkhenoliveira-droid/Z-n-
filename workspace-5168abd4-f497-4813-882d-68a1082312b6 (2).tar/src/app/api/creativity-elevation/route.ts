import { NextRequest, NextResponse } from 'next/server';
import { QuantumCreativityAmplifier } from '@/lib/quantum-creativity-amplifier';
import { NeuralCreativityEnhancer } from '@/lib/neural-creativity-enhancer';
import { CreativityCoherenceMonitor } from '@/lib/creativity-coherence-monitor';

// Initialize systems
const quantumAmplifier = new QuantumCreativityAmplifier();
const neuralEnhancer = new NeuralCreativityEnhancer();
const coherenceMonitor = new CreativityCoherenceMonitor();

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const endpoint = searchParams.get('endpoint');

    switch (endpoint) {
      case 'status':
        return getStatus();
      case 'quantum-state':
        return getQuantumState();
      case 'neural-state':
        return getNeuralState();
      case 'coherence-state':
        return getCoherenceState();
      case 'quantum-metrics':
        return getQuantumMetrics();
      case 'neural-metrics':
        return getNeuralMetrics();
      case 'coherence-dimensions':
        return getCoherenceDimensions();
      case 'alerts':
        return getAlerts();
      case 'predictions':
        return getPredictions(searchParams);
      case 'recommendations':
        return getRecommendations();
      case 'quality-assessment':
        return getQualityAssessment();
      case 'flow-analysis':
        return getFlowAnalysis();
      case 'history':
        return getHistory(searchParams);
      case 'creative-field':
        return getCreativeField();
      case 'inspiration-queue':
        return getInspirationQueue();
      case 'breakthroughs':
        return getBreakthroughs();
      default:
        return NextResponse.json(
          { error: 'Invalid endpoint' },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('Creativity Elevation API Error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { endpoint, data } = await request.json();

    switch (endpoint) {
      case 'amplify-creativity':
        return amplifyCreativity(data);
      case 'generate-inspiration':
        return generateInspiration(data);
      case 'enable-creative-breakthrough':
        return enableCreativeBreakthrough(data);
      case 'enhance-creative-patterns':
        return enhanceCreativePatterns(data);
      case 'adapt-creative-network':
        return adaptCreativeNetwork(data);
      case 'generate-neural-inspiration':
        return generateNeuralInspiration(data);
      case 'enhance-creative-synchronization':
        return enhanceCreativeSynchronization();
      case 'evolve-quantum-state':
        return evolveQuantumState();
      case 'register-creative-pattern':
        return registerCreativePattern(data);
      case 'register-neural-pattern':
        return registerNeuralPattern(data);
      case 'reset-system':
        return resetSystem();
      default:
        return NextResponse.json(
          { error: 'Invalid endpoint' },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('Creativity Elevation API Error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET Endpoints

async function getStatus() {
  const quantumState = quantumAmplifier.getQuantumCreativityState();
  const neuralState = neuralEnhancer.getCreativeNeuralState();
  const coherenceState = coherenceMonitor.getCreativityCoherenceState();
  const alerts = coherenceMonitor.getActiveAlerts();

  return NextResponse.json({
    status: 'active',
    timestamp: new Date().toISOString(),
    systems: {
      quantum: { active: true, state: quantumState },
      neural: { active: true, state: neuralState },
      coherence: { active: true, state: coherenceState }
    },
    alerts: alerts.length,
    overallCreativityCoherence: coherenceState.overallCreativityCoherence,
    creativeFlowState: coherenceState.creativeFlowState,
    inspirationLevel: coherenceState.inspirationLevel
  });
}

async function getQuantumState() {
  const state = quantumAmplifier.getQuantumCreativityState();
  return NextResponse.json({
    quantumState: state,
    timestamp: new Date().toISOString()
  });
}

async function getNeuralState() {
  const state = neuralEnhancer.getCreativeNeuralState();
  return NextResponse.json({
    neuralState: state,
    timestamp: new Date().toISOString()
  });
}

async function getCoherenceState() {
  const state = coherenceMonitor.monitorCreativityCoherence();
  return NextResponse.json({
    coherenceState: state,
    timestamp: new Date().toISOString()
  });
}

async function getQuantumMetrics() {
  const metrics = quantumAmplifier.getQuantumCreativityMetrics();
  return NextResponse.json({
    quantumMetrics: metrics,
    timestamp: new Date().toISOString()
  });
}

async function getNeuralMetrics() {
  const metrics = neuralEnhancer.getNeuralCreativityMetrics();
  return NextResponse.json({
    neuralMetrics: metrics,
    timestamp: new Date().toISOString()
  });
}

async function getCoherenceDimensions() {
  const dimensions = coherenceMonitor.getCreativityCoherenceDimensions();
  return NextResponse.json({
    coherenceDimensions: dimensions,
    timestamp: new Date().toISOString()
  });
}

async function getAlerts() {
  const alerts = coherenceMonitor.getActiveAlerts();
  return NextResponse.json({
    alerts,
    timestamp: new Date().toISOString()
  });
}

async function getPredictions(searchParams: URLSearchParams) {
  const timeframe = searchParams.get('timeframe') || '1h';
  const predictions = coherenceMonitor.getCreativityCoherencePredictions(timeframe);
  return NextResponse.json({
    predictions,
    timeframe,
    timestamp: new Date().toISOString()
  });
}

async function getRecommendations() {
  const recommendations = coherenceMonitor.getCreativityOptimizationRecommendations();
  return NextResponse.json({
    recommendations,
    timestamp: new Date().toISOString()
  });
}

async function getQualityAssessment() {
  const quality = coherenceMonitor.assessCreativeQuality();
  return NextResponse.json({
    qualityAssessment: quality,
    timestamp: new Date().toISOString()
  });
}

async function getFlowAnalysis() {
  const flowAnalysis = coherenceMonitor.analyzeCreativeFlow();
  return NextResponse.json({
    flowAnalysis,
    timestamp: new Date().toISOString()
  });
}

async function getHistory(searchParams: URLSearchParams) {
  const limit = parseInt(searchParams.get('limit') || '50');
  const type = searchParams.get('type') || 'all';
  
  let history: any = {};
  
  if (type === 'all' || type === 'quantum') {
    history.quantum = quantumAmplifier.getEvolutionHistory().slice(-limit);
  }
  
  if (type === 'all' || type === 'neural') {
    history.neural = neuralEnhancer.getCreativeNeuralHistory().slice(-limit);
  }
  
  if (type === 'all' || type === 'coherence') {
    history.coherence = coherenceMonitor.getCreativityCoherenceHistory().slice(-limit);
  }
  
  return NextResponse.json({
    history,
    type,
    limit,
    timestamp: new Date().toISOString()
  });
}

async function getCreativeField() {
  const creativeField = quantumAmplifier.getCreativeField();
  return NextResponse.json({
    creativeField,
    timestamp: new Date().toISOString()
  });
}

async function getInspirationQueue() {
  const inspirationQueue = quantumAmplifier.getInspirationQueue();
  return NextResponse.json({
    inspirationQueue,
    timestamp: new Date().toISOString()
  });
}

async function getBreakthroughs() {
  const breakthroughs = quantumAmplifier.getCreativeBreakthroughs();
  return NextResponse.json({
    breakthroughs,
    timestamp: new Date().toISOString()
  });
}

// POST Endpoints

async function amplifyCreativity(data: any) {
  const { creativeInput } = data;
  
  if (!Array.isArray(creativeInput)) {
    return NextResponse.json(
      { error: 'creativeInput must be an array' },
      { status: 400 }
    );
  }
  
  const amplifiedCreativity = quantumAmplifier.amplifyCreativity(creativeInput);
  
  return NextResponse.json({
    result: 'success',
    amplifiedCreativity,
    inputLength: creativeInput.length,
    outputLength: amplifiedCreativity.length,
    timestamp: new Date().toISOString()
  });
}

async function generateInspiration(data: any) {
  const inspiration = quantumAmplifier.generateCreativeInspiration();
  
  return NextResponse.json({
    result: 'success',
    inspiration,
    timestamp: new Date().toISOString()
  });
}

async function enableCreativeBreakthrough(data: any) {
  const { currentCreativeState, targetCreativeState } = data;
  
  if (!Array.isArray(currentCreativeState) || !Array.isArray(targetCreativeState)) {
    return NextResponse.json(
      { error: 'currentCreativeState and targetCreativeState must be arrays' },
      { status: 400 }
    );
  }
  
  const breakthrough = quantumAmplifier.enableCreativeBreakthrough(currentCreativeState, targetCreativeState);
  
  return NextResponse.json({
    result: 'success',
    breakthrough,
    currentStateLength: currentCreativeState.length,
    targetStateLength: targetCreativeState.length,
    timestamp: new Date().toISOString()
  });
}

async function enhanceCreativePatterns(data: any) {
  const { patterns } = data;
  
  if (!Array.isArray(patterns)) {
    return NextResponse.json(
      { error: 'patterns must be an array' },
      { status: 400 }
    );
  }
  
  const enhancedPatterns = quantumAmplifier.enhanceCreativePatternRecognition(patterns);
  
  return NextResponse.json({
    result: 'success',
    enhancedPatterns,
    inputCount: patterns.length,
    timestamp: new Date().toISOString()
  });
}

async function adaptCreativeNetwork(data: any) {
  const { feedback, creativeMode } = data;
  
  if (!Array.isArray(feedback)) {
    return NextResponse.json(
      { error: 'feedback must be an array' },
      { status: 400 }
    );
  }
  
  neuralEnhancer.adaptCreativeNeuralNetwork(feedback, creativeMode || 'synthetic');
  
  return NextResponse.json({
    result: 'success',
    feedbackLength: feedback.length,
    creativeMode: creativeMode || 'synthetic',
    timestamp: new Date().toISOString()
  });
}

async function generateNeuralInspiration(data: any) {
  const { type } = data;
  
  if (!type) {
    return NextResponse.json(
      { error: 'type is required' },
      { status: 400 }
    );
  }
  
  const inspiration = neuralEnhancer.generateNeuralInspiration(type);
  
  return NextResponse.json({
    result: 'success',
    inspiration,
    timestamp: new Date().toISOString()
  });
}

async function enhanceCreativeSynchronization() {
  neuralEnhancer.enhanceCreativeNeuralSynchronization();
  
  return NextResponse.json({
    result: 'success',
    timestamp: new Date().toISOString()
  });
}

async function evolveQuantumState() {
  quantumAmplifier.evolveQuantumCreativityState();
  
  return NextResponse.json({
    result: 'success',
    timestamp: new Date().toISOString()
  });
}

async function registerCreativePattern(data: any) {
  const { pattern } = data;
  
  if (!pattern) {
    return NextResponse.json(
      { error: 'pattern is required' },
      { status: 400 }
    );
  }
  
  quantumAmplifier.registerCreativePattern(pattern);
  
  return NextResponse.json({
    result: 'success',
    patternId: pattern.id,
    timestamp: new Date().toISOString()
  });
}

async function registerNeuralPattern(data: any) {
  const { pattern } = data;
  
  if (!pattern) {
    return NextResponse.json(
      { error: 'pattern is required' },
      { status: 400 }
    );
  }
  
  neuralEnhancer.registerCreativeNeuralPattern(pattern);
  
  return NextResponse.json({
    result: 'success',
    patternId: pattern.id,
    timestamp: new Date().toISOString()
  });
}

async function resetSystem() {
  quantumAmplifier.reset();
  neuralEnhancer.reset();
  coherenceMonitor.reset();
  
  return NextResponse.json({
    result: 'success',
    message: 'All creativity elevation systems have been reset',
    timestamp: new Date().toISOString()
  });
}