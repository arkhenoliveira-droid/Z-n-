import { NextRequest, NextResponse } from 'next/server';
import { QuantumIntuitionAmplifier } from '@/lib/quantum-intuition-amplifier';
import { NeuralIntuitionEnhancer } from '@/lib/neural-intuition-enhancer';
import { IntuitionCoherenceMonitor } from '@/lib/intuition-coherence-monitor';

// Initialize systems
const quantumAmplifier = new QuantumIntuitionAmplifier();
const neuralEnhancer = new NeuralIntuitionEnhancer();
const coherenceMonitor = new IntuitionCoherenceMonitor();

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const endpoint = searchParams.get('endpoint');

    switch (endpoint) {
      case 'status':
        return getStatus();
      case 'quantum-state':
        return getQuantumState();
      case 'neural-state':
        return getNeuralState();
      case 'coherence-state':
        return getCoherenceState();
      case 'quantum-metrics':
        return getQuantumMetrics();
      case 'neural-metrics':
        return getNeuralMetrics();
      case 'coherence-dimensions':
        return getCoherenceDimensions();
      case 'alerts':
        return getAlerts();
      case 'predictions':
        return getPredictions(searchParams);
      case 'recommendations':
        return getRecommendations();
      case 'quality-assessment':
        return getQualityAssessment();
      case 'history':
        return getHistory(searchParams);
      default:
        return NextResponse.json(
          { error: 'Invalid endpoint' },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('Intuition Elevation API Error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { endpoint, data } = await request.json();

    switch (endpoint) {
      case 'amplify-intuition':
        return amplifyIntuition(data);
      case 'enhance-pattern-recognition':
        return enhancePatternRecognition(data);
      case 'enable-intuitive-leaps':
        return enableIntuitiveLeaps(data);
      case 'adapt-neural-network':
        return adaptNeuralNetwork(data);
      case 'enhance-neural-synchronization':
        return enhanceNeuralSynchronization();
      case 'evolve-quantum-state':
        return evolveQuantumState();
      case 'register-pattern':
        return registerPattern(data);
      case 'reset-system':
        return resetSystem();
      default:
        return NextResponse.json(
          { error: 'Invalid endpoint' },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('Intuition Elevation API Error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET Endpoints

async function getStatus() {
  const quantumState = quantumAmplifier.getQuantumState();
  const neuralState = neuralEnhancer.getNeuralState();
  const coherenceState = coherenceMonitor.getCoherenceState();
  const alerts = coherenceMonitor.getActiveAlerts();

  return NextResponse.json({
    status: 'active',
    timestamp: new Date().toISOString(),
    systems: {
      quantum: { active: true, state: quantumState },
      neural: { active: true, state: neuralState },
      coherence: { active: true, state: coherenceState }
    },
    alerts: alerts.length,
    overallCoherence: coherenceState.overallCoherence
  });
}

async function getQuantumState() {
  const state = quantumAmplifier.getQuantumState();
  return NextResponse.json({
    quantumState: state,
    timestamp: new Date().toISOString()
  });
}

async function getNeuralState() {
  const state = neuralEnhancer.getNeuralState();
  return NextResponse.json({
    neuralState: state,
    timestamp: new Date().toISOString()
  });
}

async function getCoherenceState() {
  const state = coherenceMonitor.monitorCoherence();
  return NextResponse.json({
    coherenceState: state,
    timestamp: new Date().toISOString()
  });
}

async function getQuantumMetrics() {
  const metrics = quantumAmplifier.getQuantumIntuitionMetrics();
  return NextResponse.json({
    quantumMetrics: metrics,
    timestamp: new Date().toISOString()
  });
}

async function getNeuralMetrics() {
  const metrics = neuralEnhancer.getNeuralIntuitionMetrics();
  return NextResponse.json({
    neuralMetrics: metrics,
    timestamp: new Date().toISOString()
  });
}

async function getCoherenceDimensions() {
  const dimensions = coherenceMonitor.getCoherenceDimensions();
  return NextResponse.json({
    coherenceDimensions: dimensions,
    timestamp: new Date().toISOString()
  });
}

async function getAlerts() {
  const alerts = coherenceMonitor.getActiveAlerts();
  return NextResponse.json({
    alerts,
    timestamp: new Date().toISOString()
  });
}

async function getPredictions(searchParams: URLSearchParams) {
  const timeframe = searchParams.get('timeframe') || '1h';
  const predictions = coherenceMonitor.getCoherencePredictions(timeframe);
  return NextResponse.json({
    predictions,
    timeframe,
    timestamp: new Date().toISOString()
  });
}

async function getRecommendations() {
  const recommendations = coherenceMonitor.getOptimizationRecommendations();
  return NextResponse.json({
    recommendations,
    timestamp: new Date().toISOString()
  });
}

async function getQualityAssessment() {
  const quality = coherenceMonitor.assessIntuitionQuality();
  return NextResponse.json({
    qualityAssessment: quality,
    timestamp: new Date().toISOString()
  });
}

async function getHistory(searchParams: URLSearchParams) {
  const limit = parseInt(searchParams.get('limit') || '50');
  const type = searchParams.get('type') || 'all';
  
  let history: any = {};
  
  if (type === 'all' || type === 'quantum') {
    history.quantum = quantumAmplifier.getEvolutionHistory().slice(-limit);
  }
  
  if (type === 'all' || type === 'neural') {
    history.neural = neuralEnhancer.getNeuralHistory().slice(-limit);
  }
  
  if (type === 'all' || type === 'coherence') {
    history.coherence = coherenceMonitor.getCoherenceHistory().slice(-limit);
  }
  
  return NextResponse.json({
    history,
    type,
    limit,
    timestamp: new Date().toISOString()
  });
}

// POST Endpoints

async function amplifyIntuition(data: any) {
  const { inputSignal } = data;
  
  if (!Array.isArray(inputSignal)) {
    return NextResponse.json(
      { error: 'inputSignal must be an array' },
      { status: 400 }
    );
  }
  
  const amplifiedSignal = quantumAmplifier.amplifyIntuition(inputSignal);
  
  return NextResponse.json({
    result: 'success',
    amplifiedSignal,
    inputLength: inputSignal.length,
    outputLength: amplifiedSignal.length,
    timestamp: new Date().toISOString()
  });
}

async function enhancePatternRecognition(data: any) {
  const { patterns } = data;
  
  if (!Array.isArray(patterns)) {
    return NextResponse.json(
      { error: 'patterns must be an array' },
      { status: 400 }
    );
  }
  
  const enhancedPatterns = quantumAmplifier.enhancePatternRecognition(patterns);
  
  return NextResponse.json({
    result: 'success',
    enhancedPatterns,
    inputCount: patterns.length,
    timestamp: new Date().toISOString()
  });
}

async function enableIntuitiveLeaps(data: any) {
  const { currentState, targetState } = data;
  
  if (!Array.isArray(currentState) || !Array.isArray(targetState)) {
    return NextResponse.json(
      { error: 'currentState and targetState must be arrays' },
      { status: 400 }
    );
  }
  
  const result = quantumAmplifier.enableIntuitiveLeaps(currentState, targetState);
  
  return NextResponse.json({
    result: 'success',
    leapResult: result,
    currentStateLength: currentState.length,
    targetStateLength: targetState.length,
    timestamp: new Date().toISOString()
  });
}

async function adaptNeuralNetwork(data: any) {
  const { feedback } = data;
  
  if (!Array.isArray(feedback)) {
    return NextResponse.json(
      { error: 'feedback must be an array' },
      { status: 400 }
    );
  }
  
  neuralEnhancer.adaptNeuralNetwork(feedback);
  
  return NextResponse.json({
    result: 'success',
    feedbackLength: feedback.length,
    timestamp: new Date().toISOString()
  });
}

async function enhanceNeuralSynchronization() {
  neuralEnhancer.enhanceNeuralSynchronization();
  
  return NextResponse.json({
    result: 'success',
    timestamp: new Date().toISOString()
  });
}

async function evolveQuantumState() {
  quantumAmplifier.evolveQuantumState();
  
  return NextResponse.json({
    result: 'success',
    timestamp: new Date().toISOString()
  });
}

async function registerPattern(data: any) {
  const { pattern, type } = data;
  
  if (!pattern || !type) {
    return NextResponse.json(
      { error: 'pattern and type are required' },
      { status: 400 }
    );
  }
  
  if (type === 'quantum') {
    quantumAmplifier.registerIntuitionPattern(pattern);
  } else if (type === 'neural') {
    neuralEnhancer.registerNeuralPattern(pattern);
  } else {
    return NextResponse.json(
      { error: 'type must be "quantum" or "neural"' },
      { status: 400 }
    );
  }
  
  return NextResponse.json({
    result: 'success',
    patternType: type,
    patternId: pattern.id,
    timestamp: new Date().toISOString()
  });
}

async function resetSystem() {
  quantumAmplifier.reset();
  neuralEnhancer.reset();
  coherenceMonitor.reset();
  
  return NextResponse.json({
    result: 'success',
    message: 'All intuition elevation systems have been reset',
    timestamp: new Date().toISOString()
  });
}