import { NextRequest, NextResponse } from 'next/server';
import { 
  languageNames, 
  languageUtils,
  languagePreferences,
  supportedLanguages,
  defaultLanguage,
  getLanguageFromAcceptLanguage
} from '@/lib/language-detector-client';

// Simple country to language mapping for IP detection
const countryToLanguage: Record<string, string> = {
  'BR': 'pt', 'PT': 'pt', 'AO': 'pt', 'MZ': 'pt',
  'ES': 'es', 'MX': 'es', 'AR': 'es', 'CO': 'es',
  'US': 'en', 'GB': 'en', 'CA': 'en', 'AU': 'en'
};

// Simple language detection for API
async function detectLanguageWithConfidence() {
  return {
    language: defaultLanguage,
    confidence: 'medium' as const,
    method: 'header' as const
  };
}

export async function GET(request: NextRequest) {
  try {
    const startTime = Date.now();
    
    // Get client information
    const forwarded = request.headers.get('x-forwarded-for');
    const realIp = request.headers.get('x-real-ip');
    const userAgent = request.headers.get('user-agent');
    const acceptLanguage = request.headers.get('accept-language');
    const ip = forwarded?.split(',')[0] || realIp || 'unknown';
    
    // Detect language with confidence
    const detectionResult = await detectLanguageWithConfidence();
    
    // Get detailed location information
    let locationInfo: any = null;
    let locationDetectionTime = 0;
    
    if (ip !== 'unknown') {
      try {
        const locationStart = Date.now();
        const response = await fetch(`https://ipapi.co/${ip}/json/`, {
          signal: AbortSignal.timeout(5000) // 5 second timeout
        });
        
        if (response.ok) {
          const data = await response.json();
          locationInfo = {
            city: data.city,
            country: data.country_name,
            countryCode: data.country_code,
            region: data.region,
            timezone: data.timezone,
            latitude: data.latitude,
            longitude: data.longitude,
            org: data.org,
            asn: data.asn
          };
        }
        locationDetectionTime = Date.now() - locationStart;
      } catch (error) {
        console.warn('Failed to get location info:', error);
      }
    }
    
    // Parse browser language preferences
    const browserLanguages = acceptLanguage 
      ? acceptLanguage.split(',').map(lang => {
          const [language, quality] = lang.trim().split(';');
          const q = quality ? parseFloat(quality.replace('q=', '')) : 1.0;
          return { language: language.toLowerCase(), quality: q };
        })
      : [];
    
    // Get user preferred language if available
    const preferredLanguage = languagePreferences.get();
    
    // Calculate detection metrics
    const detectionTime = Date.now() - startTime;
    
    // Determine if language should be overridden by user preference
    const finalLanguage = preferredLanguage || detectionResult.language;
    const overrideReason = preferredLanguage ? 'user_preference' : detectionResult.method;
    
    return NextResponse.json({
      success: true,
      data: {
        detected: detectionResult,
        final: {
          language: finalLanguage,
          languageName: languageNames[finalLanguage],
          reason: overrideReason
        },
        location: locationInfo,
        client: {
          ip: ip,
          userAgent: userAgent?.substring(0, 100) + ((userAgent?.length || 0) > 100 ? '...' : ''),
          browserLanguages: browserLanguages.slice(0, 5) // Limit to first 5
        },
        preferences: {
          stored: preferredLanguage,
          available: languageUtils.getAll()
        },
        performance: {
          detectionTime: detectionTime,
          locationDetectionTime: locationDetectionTime,
          totalProcessingTime: Date.now() - startTime
        },
        metadata: {
          timestamp: new Date().toISOString(),
          requestId: crypto.randomUUID(),
          version: '1.0.0'
        }
      }
    });
    
  } catch (error) {
    console.error('Language detection error:', error);
    
    // Return a graceful fallback response
    return NextResponse.json({
      success: false,
      error: 'Failed to detect language',
      fallback: {
        language: defaultLanguage,
        languageName: languageNames[defaultLanguage],
        reason: 'error_fallback'
      },
      metadata: {
        timestamp: new Date().toISOString(),
        requestId: crypto.randomUUID(),
        error: error instanceof Error ? error.message : 'Unknown error'
      }
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, language, ip, userAgent, acceptLanguage } = body;
    
    switch (action) {
      case 'set_preference':
        if (!language || !languageUtils.isValid(language)) {
          return NextResponse.json({
            success: false,
            error: 'Invalid language provided',
            validLanguages: supportedLanguages
          }, { status: 400 });
        }
        
        languagePreferences.set(language);
        
        return NextResponse.json({
          success: true,
          message: 'Language preference saved',
          preference: {
            language,
            languageName: languageNames[language]
          }
        });
        
      case 'get_preference':
        const preferred = languagePreferences.get();
        return NextResponse.json({
          success: true,
          preference: preferred ? {
            language: preferred,
            languageName: languageNames[preferred]
          } : null
        });
        
      case 'remove_preference':
        languagePreferences.remove();
        return NextResponse.json({
          success: true,
          message: 'Language preference removed'
        });
        
      case 'detect_from_data':
        if (!acceptLanguage) {
          return NextResponse.json({
            success: false,
            error: 'Accept-Language header is required'
          }, { status: 400 });
        }
        
        const detectedLanguage = getLanguageFromAcceptLanguage(acceptLanguage);
        const countryLanguage = ip && countryToLanguage[ip] ? countryToLanguage[ip] : null;
        
        return NextResponse.json({
          success: true,
          detection: {
            fromHeader: detectedLanguage,
            fromIP: countryLanguage,
            final: countryLanguage || detectedLanguage,
            confidence: countryLanguage ? 'high' : 'medium'
          }
        });
        
      case 'validate_language':
        if (!language) {
          return NextResponse.json({
            success: false,
            error: 'Language code is required'
          }, { status: 400 });
        }
        
        const isValid = languageUtils.isValid(language);
        const normalized = languageUtils.normalize(language);
        const fallback = languageUtils.getFallback(language);
        
        return NextResponse.json({
          success: true,
          validation: {
            input: language,
            isValid,
            normalized,
            fallback,
            supported: supportedLanguages
          }
        });
        
      case 'get_available_languages':
        return NextResponse.json({
          success: true,
          languages: languageUtils.getAll()
        });
        
      default:
        return NextResponse.json({
          success: false,
          error: 'Invalid action',
          availableActions: [
            'set_preference',
            'get_preference', 
            'remove_preference',
            'detect_from_data',
            'validate_language',
            'get_available_languages'
          ]
        }, { status: 400 });
    }
    
  } catch (error) {
    console.error('Language API POST error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to process request',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}