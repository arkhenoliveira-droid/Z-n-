import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const { prompt } = await request.json();

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json(
        { error: 'Valid prompt is required' },
        { status: 400 }
      );
    }

    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an expert quantum system developer. Generate clean, efficient, and well-commented code based on the user\'s request. Focus on quantum computing, system architecture, and advanced programming concepts.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      max_tokens: 500,
      temperature: 0.3,
    });

    const messageContent = completion.choices[0]?.message?.content;
    
    if (!messageContent) {
      throw new Error('No content generated');
    }

    return NextResponse.json({
      code: messageContent.trim(),
      success: true
    });

  } catch (error) {
    console.error('Error in code generation API:', error);
    return NextResponse.json(
      { 
        error: 'Failed to generate code',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}