'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import CSVVisualizer from '@/components/ui/csv-visualizer';
import { 
  BarChart3, 
  Upload, 
  Download, 
  FileText, 
  Database,
  TrendingUp,
  PieChart as PieIcon,
  Dot,
  Eye,
  Code,
  BookOpen,
  Lightbulb,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

// Sample data for demonstration
const sampleData = [
  {
    name: 'Sales Data',
    description: 'Monthly sales figures with product categories',
    columns: 'Month, Sales, Category, Region',
    rows: 24,
    url: '/sample-data/sales.csv'
  },
  {
    name: 'Customer Data',
    description: 'Customer demographics and purchase history',
    columns: 'Age, Income, Category, Satisfaction',
    rows: 1000,
    url: '/sample-data/customers.csv'
  },
  {
    name: 'Time Series',
    description: 'Temperature and humidity measurements over time',
    columns: 'Date, Temperature, Humidity, Location',
    rows: 365,
    url: '/sample-data/weather.csv'
  }
];

export default function DataVisualizationDemo() {
  const [activeTab, setActiveTab] = useState('demo');

  const downloadSampleCSV = () => {
    // Create sample CSV data
    const csvContent = `Month,Sales,Category,Region
January,15000,Electronics,North
February,18000,Electronics,North
March,22000,Electronics,North
April,19000,Clothing,North
May,25000,Clothing,North
June,28000,Clothing,North
July,16000,Electronics,South
August,20000,Electronics,South
September,24000,Electronics,South
October,21000,Clothing,South
November,26000,Clothing,South
December,30000,Clothing,South`;

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'sample_sales_data.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="container mx-auto py-8 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <BarChart3 className="h-10 w-10 text-blue-600" />
          <h1 className="text-4xl font-bold">Data Visualization</h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Upload CSV files and create interactive charts and visualizations instantly. 
          No coding required - just upload your data and explore insights.
        </p>
      </div>

      {/* Features Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6 text-center">
            <Upload className="h-8 w-8 text-blue-600 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Easy Upload</h3>
            <p className="text-sm text-muted-foreground">
              Drag & drop CSV files or click to browse
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <Dot className="h-8 w-8 text-green-600 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Multiple Charts</h3>
            <p className="text-sm text-muted-foreground">
              Dot plots, histograms, bar charts, and line charts
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <Eye className="h-8 w-8 text-purple-600 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Interactive</h3>
            <p className="text-sm text-muted-foreground">
              Hover, zoom, and explore your data dynamically
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <Download className="h-8 w-8 text-orange-600 mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Export Results</h3>
            <p className="text-sm text-muted-foreground">
              Download processed data and charts
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="demo">Live Demo</TabsTrigger>
          <TabsTrigger value="samples">Sample Data</TabsTrigger>
          <TabsTrigger value="guide">User Guide</TabsTrigger>
          <TabsTrigger value="examples">Examples</TabsTrigger>
        </TabsList>

        <TabsContent value="demo" className="space-y-6">
          <CSVVisualizer />
        </TabsContent>

        <TabsContent value="samples" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Database className="h-5 w-5" />
                <span>Sample Datasets</span>
              </CardTitle>
              <CardDescription>
                Download sample CSV files to test the visualization features
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sampleData.map((sample, index) => (
                  <Card key={index}>
                    <CardContent className="p-6 space-y-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold">{sample.name}</h3>
                          <p className="text-sm text-muted-foreground mt-1">
                            {sample.description}
                          </p>
                        </div>
                        <FileText className="h-5 w-5 text-muted-foreground" />
                      </div>
                      
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Columns:</span>
                          <span>{sample.columns}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Rows:</span>
                          <Badge variant="outline">{sample.rows}</Badge>
                        </div>
                      </div>
                      
                      <Button 
                        onClick={downloadSampleCSV} 
                        className="w-full"
                        variant="outline"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Download Sample
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Create Your Own Sample Data</CardTitle>
              <CardDescription>
                Generate custom CSV data for testing
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium">Data Generator</h4>
                  <p className="text-sm text-muted-foreground">
                    Use this template to create your own test data:
                  </p>
                  <div className="bg-muted p-4 rounded-lg">
                    <pre className="text-sm">
{`Name,Age,Salary,Department
John Doe,28,50000,Engineering
Jane Smith,32,65000,Marketing
Bob Johnson,45,80000,Management
Alice Brown,29,55000,Engineering
Charlie Wilson,38,70000,Sales`}
                    </pre>
                  </div>
                  <Button onClick={downloadSampleCSV} className="w-full">
                    <Download className="w-4 h-4 mr-2" />
                    Download Template
                  </Button>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-medium">Best Practices</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>Use clear, descriptive column headers</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>Ensure consistent data types in each column</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>Avoid special characters in column names</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>Use UTF-8 encoding for best compatibility</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="guide" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BookOpen className="h-5 w-5" />
                  <span>Getting Started</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                      1
                    </div>
                    <div>
                      <h4 className="font-medium">Upload Your CSV File</h4>
                      <p className="text-sm text-muted-foreground">
                        Click the upload area or drag and drop your CSV file
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                      2
                    </div>
                    <div>
                      <h4 className="font-medium">Review Data Overview</h4>
                      <p className="text-sm text-muted-foreground">
                        Check column types, unique values, and data quality
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                      3
                    </div>
                    <div>
                      <h4 className="font-medium">Explore Visualizations</h4>
                      <p className="text-sm text-muted-foreground">
                        Switch between chart types to find insights
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                      4
                    </div>
                    <div>
                      <h4 className="font-medium">Export & Share</h4>
                      <p className="text-sm text-muted-foreground">
                        Download charts or export processed data
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Lightbulb className="h-5 w-5" />
                  <span>Pro Tips</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Data Quality:</strong> Ensure your data is clean and consistent for the best visualizations
                    </AlertDescription>
                  </Alert>
                  
                  <div className="space-y-2 text-sm">
                    <h4 className="font-medium">Chart Selection Guide:</h4>
                    <ul className="space-y-1 text-muted-foreground">
                      <li>• <strong>Dot Plot:</strong> Relationships between two numerical variables</li>
                      <li>• <strong>Histogram:</strong> Distribution of a single numerical variable</li>
                      <li>• <strong>Bar Chart:</strong> Categorical data comparisons</li>
                      <li>• <strong>Line Chart:</strong> Trends over time or ordered data</li>
                    </ul>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <h4 className="font-medium">Performance Tips:</h4>
                    <ul className="space-y-1 text-muted-foreground">
                      <li>• Large files (&gt;10MB) may take longer to process</li>
                      <li>• Limit data to essential columns for faster loading</li>
                      <li>• Use appropriate data types for better analysis</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Supported Features</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-3">
                  <h4 className="font-medium">File Formats</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>CSV files</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>UTF-8 encoding</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>Header rows supported</span>
                    </li>
                  </ul>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-medium">Data Types</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>Numerical data</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>Categorical data</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>Date/time data</span>
                    </li>
                  </ul>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-medium">Chart Features</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>Interactive tooltips</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>Responsive design</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>Export capabilities</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="examples" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Real-World Use Cases</CardTitle>
              <CardDescription>
                Examples of how to use data visualization in different scenarios
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardContent className="p-6 space-y-4">
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="h-5 w-5 text-blue-600" />
                      <h3 className="font-semibold">Sales Analysis</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Analyze sales trends, compare product performance, and identify seasonal patterns.
                    </p>
                    <div className="space-y-2 text-xs">
                      <div className="font-medium">Ideal charts:</div>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="outline">Line Chart</Badge>
                        <Badge variant="outline">Bar Chart</Badge>
                        <Badge variant="outline">Dot Plot</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 space-y-4">
                    <div className="flex items-center space-x-2">
                      <PieIcon className="h-5 w-5 text-green-600" />
                      <h3 className="font-semibold">Customer Segmentation</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Understand customer demographics, behavior patterns, and preferences.
                    </p>
                    <div className="space-y-2 text-xs">
                      <div className="font-medium">Ideal charts:</div>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="outline">Bar Chart</Badge>
                        <Badge variant="outline">Histogram</Badge>
                        <Badge variant="outline">Dot Plot</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 space-y-4">
                    <div className="flex items-center space-x-2">
                      <Dot className="h-5 w-5 text-purple-600" />
                      <h3 className="font-semibold">Scientific Data</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Visualize experimental results, correlations, and statistical relationships.
                    </p>
                    <div className="space-y-2 text-xs">
                      <div className="font-medium">Ideal charts:</div>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="outline">Dot Plot</Badge>
                        <Badge variant="outline">Histogram</Badge>
                        <Badge variant="outline">Line Chart</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 space-y-4">
                    <div className="flex items-center space-x-2">
                      <Database className="h-5 w-5 text-orange-600" />
                      <h3 className="font-semibold">Financial Data</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Track stock prices, portfolio performance, and market trends.
                    </p>
                    <div className="space-y-2 text-xs">
                      <div className="font-medium">Ideal charts:</div>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="outline">Line Chart</Badge>
                        <Badge variant="outline">Dot Plot</Badge>
                        <Badge variant="outline">Histogram</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Integration Examples</CardTitle>
              <CardDescription>
                How to integrate the CSV visualizer into your applications
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-muted p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Basic Usage</h4>
                  <pre className="text-sm overflow-x-auto">
{`import CSVVisualizer from '@/components/ui/csv-visualizer';

function MyComponent() {
  return (
    <div>
      <CSVVisualizer />
    </div>
  );
}`}
                  </pre>
                </div>
                
                <div className="bg-muted p-4 rounded-lg">
                  <h4 className="font-medium mb-2">With Custom Styling</h4>
                  <pre className="text-sm overflow-x-auto">
{`<CSVVisualizer className="max-w-4xl mx-auto" />`}
                  </pre>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}