'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import UserProfileCard, { UserProfileData } from '@/components/ui/user-profile-card';
import { 
  Users, 
  LayoutGrid, 
  Plus, 
  Edit, 
  MessageCircle, 
  UserPlus,
  Star,
  Settings,
  Code,
  Palette,
  Heart
} from 'lucide-react';

export default function UserProfileDemo() {
  const [selectedUser, setSelectedUser] = useState<UserProfileData | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<Partial<UserProfileData>>({});

  // Sample user data
  const sampleUsers: UserProfileData[] = [
    {
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face',
      name: 'Sarah Johnson',
      email: 'sarah.johnson@example.com',
      bio: 'Full-stack developer passionate about creating beautiful and functional web applications. Love working with React, TypeScript, and modern web technologies.',
      role: 'Senior Developer',
      location: 'San Francisco, CA',
      joinDate: '2022-03-15',
      website: 'https://sarahjohnson.dev',
      stats: {
        followers: 1234,
        following: 567,
        posts: 89
      },
      badges: ['React Expert', 'TypeScript', 'Open Source'],
      isVerified: true
    },
    {
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face',
      name: 'Michael Chen',
      email: 'michael.chen@example.com',
      bio: 'UX/UI designer focused on creating intuitive and accessible user experiences. Always learning new design trends and techniques.',
      role: 'Lead Designer',
      location: 'New York, NY',
      joinDate: '2021-07-22',
      website: 'https://michaelchen.design',
      stats: {
        followers: 892,
        following: 234,
        posts: 45
      },
      badges: ['Design System', 'Figma', 'Accessibility'],
      isVerified: false
    },
    {
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face',
      name: 'Emily Rodriguez',
      email: 'emily.rodriguez@example.com',
      bio: 'Product manager with a background in software engineering. Bridging the gap between technical teams and business stakeholders.',
      role: 'Product Manager',
      location: 'Austin, TX',
      joinDate: '2023-01-10',
      stats: {
        followers: 567,
        following: 123,
        posts: 23
      },
      badges: ['Agile', 'Strategy', 'Leadership'],
      isVerified: true
    }
  ];

  const handleEdit = (user: UserProfileData) => {
    setSelectedUser(user);
    setEditForm(user);
    setIsEditing(true);
  };

  const handleSave = () => {
    if (selectedUser && editForm) {
      const updatedUser = { ...selectedUser, ...editForm };
      setSelectedUser(updatedUser);
      setIsEditing(false);
    }
  };

  const handleMessage = (user: UserProfileData) => {
    alert(`Message sent to ${user.name}!`);
  };

  const handleFollow = (user: UserProfileData) => {
    alert(`Now following ${user.name}!`);
  };

  return (
    <div className="container mx-auto py-8 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <Users className="h-10 w-10 text-blue-600" />
          <h1 className="text-4xl font-bold">User Profile Card Demo</h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Interactive demonstration of the UserProfileCard component with multiple variants and customization options.
        </p>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="showcase" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="showcase">Showcase</TabsTrigger>
          <TabsTrigger value="variants">Variants</TabsTrigger>
          <TabsTrigger value="customization">Customization</TabsTrigger>
        </TabsList>

        <TabsContent value="showcase" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <LayoutGrid className="h-5 w-5" />
                <span>Profile Cards Showcase</span>
              </CardTitle>
              <CardDescription>
                Interactive user profile cards with different layouts and information density
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sampleUsers.map((user, index) => (
                  <div key={index} className="space-y-4">
                    <UserProfileCard
                      user={user}
                      onEdit={() => handleEdit(user)}
                      onMessage={() => handleMessage(user)}
                      onFollow={() => handleFollow(user)}
                    />
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedUser(user)}
                        className="flex-1"
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Selected User Details */}
          {selectedUser && (
            <Card>
              <CardHeader>
                <CardTitle>Selected User Details</CardTitle>
                <CardDescription>
                  Detailed view of the selected user profile
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <UserProfileCard
                    user={selectedUser}
                    variant="detailed"
                    onEdit={() => handleEdit(selectedUser)}
                    onMessage={() => handleMessage(selectedUser)}
                    onFollow={() => handleFollow(selectedUser)}
                  />
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Raw Data</h3>
                    <pre className="bg-muted p-4 rounded-lg text-sm overflow-auto max-h-64">
                      {JSON.stringify(selectedUser, null, 2)}
                    </pre>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="variants" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Component Variants</CardTitle>
              <CardDescription>
                Different layout variants for various use cases
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              {/* Default Variant */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Default Variant</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {sampleUsers.slice(0, 1).map((user, index) => (
                    <UserProfileCard
                      key={index}
                      user={user}
                      showActions={true}
                    />
                  ))}
                </div>
              </div>

              {/* Compact Variant */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Compact Variant</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {sampleUsers.map((user, index) => (
                    <UserProfileCard
                      key={index}
                      user={user}
                      variant="compact"
                      showActions={false}
                    />
                  ))}
                </div>
              </div>

              {/* Detailed Variant */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Detailed Variant</h3>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {sampleUsers.slice(0, 1).map((user, index) => (
                    <UserProfileCard
                      key={index}
                      user={user}
                      variant="detailed"
                      showActions={true}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="customization" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Customization</CardTitle>
              <CardDescription>
                Edit user profile and see changes in real-time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Edit Form */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Edit Profile</h3>
                  
                  {isEditing && editForm ? (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Name</Label>
                        <Input
                          id="name"
                          value={editForm.name || ''}
                          onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={editForm.email || ''}
                          onChange={(e) => setEditForm({...editForm, email: e.target.value})}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="role">Role</Label>
                        <Input
                          id="role"
                          value={editForm.role || ''}
                          onChange={(e) => setEditForm({...editForm, role: e.target.value})}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="location">Location</Label>
                        <Input
                          id="location"
                          value={editForm.location || ''}
                          onChange={(e) => setEditForm({...editForm, location: e.target.value})}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="bio">Bio</Label>
                        <Textarea
                          id="bio"
                          value={editForm.bio || ''}
                          onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
                          rows={3}
                        />
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button onClick={handleSave}>
                          Save Changes
                        </Button>
                        <Button variant="outline" onClick={() => setIsEditing(false)}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <p className="text-muted-foreground">
                        Select a user to edit their profile information.
                      </p>
                      <div className="grid grid-cols-1 gap-2">
                        {sampleUsers.map((user, index) => (
                          <Button
                            key={index}
                            variant="outline"
                            onClick={() => handleEdit(user)}
                            className="justify-start"
                          >
                            <Avatar className="h-6 w-6 mr-2">
                              <AvatarImage src={user.avatar} alt={user.name} />
                              <AvatarFallback className="text-xs">
                                {user.name.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            {user.name}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Live Preview */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Live Preview</h3>
                  {editForm.name ? (
                    <UserProfileCard
                      user={editForm as UserProfileData}
                      onEdit={() => {}}
                      onMessage={() => {}}
                      onFollow={() => {}}
                    />
                  ) : (
                    <Card>
                      <CardContent className="p-8 text-center text-muted-foreground">
                        <Users className="h-12 w-12 mx-auto mb-4" />
                        <p>Select a user to see live preview</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}