'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { 
  Brain, 
  Download, 
  Upload, 
  Trash2, 
  Settings, 
  Play, 
  Pause,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  Clock,
  Zap,
  MemoryStick,
  HardDrive,
  Network,
  Cpu,
  Plus,
  Edit,
  Save,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface AIModel {
  id: string;
  name: string;
  type: 'pixel' | 'audio' | 'multimodal';
  version: string;
  size: string;
  status: 'available' | 'loading' | 'loaded' | 'running' | 'error' | 'unloading';
  description: string;
  capabilities: string[];
  requirements: {
    minMemory: string;
    minCpu: string;
    minGpu?: string;
  };
  performance: {
    inferenceTime: number;
    accuracy: number;
    efficiency: number;
  };
  lastUsed: number;
  downloadCount: number;
  author: string;
  tags: string[];
  isCustom: boolean;
}

interface ModelConfiguration {
  modelId: string;
  settings: {
    batchSize: number;
    precision: 'fp32' | 'fp16' | 'int8';
    optimizationLevel: number;
    maxMemoryUsage: number;
    threadCount: number;
    useGPU: boolean;
  };
}

interface ModelMarketplace {
  id: string;
  name: string;
  type: 'pixel' | 'audio' | 'multimodal';
  category: string;
  description: string;
  size: string;
  downloads: number;
  rating: number;
  author: string;
  tags: string[];
  isDownloaded: boolean;
}

export default function AIModelManagementSystem() {
  const [models, setModels] = useState<AIModel[]>([
    {
      id: 'pixel-gen-v1',
      name: 'Pixel Generator v1',
      type: 'pixel',
      version: '1.0.0',
      size: '2.3GB',
      status: 'loaded',
      description: 'Advanced neural network for real-time pixel generation with style transfer capabilities',
      capabilities: ['Real-time generation', 'Style transfer', 'Multi-resolution support', 'Edge optimization'],
      requirements: {
        minMemory: '4GB',
        minCpu: '4 cores',
        minGpu: '2GB VRAM'
      },
      performance: {
        inferenceTime: 12,
        accuracy: 94.5,
        efficiency: 87.2
      },
      lastUsed: Date.now() - 300000,
      downloadCount: 15420,
      author: 'NeuralTech AI',
      tags: ['pixel', 'generation', 'real-time', 'optimized'],
      isCustom: false
    },
    {
      id: 'audio-synth-v1',
      name: 'Audio Synthesizer v1',
      type: 'audio',
      version: '1.2.0',
      size: '1.8GB',
      status: 'running',
      description: 'AI-powered audio synthesis with multiple waveform generation and advanced effects',
      capabilities: ['Multi-waveform synthesis', 'Real-time effects', 'Multi-channel support', 'Low latency'],
      requirements: {
        minMemory: '2GB',
        minCpu: '2 cores'
      },
      performance: {
        inferenceTime: 8,
        accuracy: 96.8,
        efficiency: 91.5
      },
      lastUsed: Date.now() - 60000,
      downloadCount: 12350,
      author: 'SoundWave Labs',
      tags: ['audio', 'synthesis', 'real-time', 'multi-channel'],
      isCustom: false
    },
    {
      id: 'multimodal-v1',
      name: 'Multimodal Engine v1',
      type: 'multimodal',
      version: '0.9.0',
      size: '4.7GB',
      status: 'loading',
      description: 'Combined pixel and audio generation with cross-modal understanding and synchronization',
      capabilities: ['Cross-modal generation', 'Synchronization', 'Advanced AI reasoning', 'Multi-task processing'],
      requirements: {
        minMemory: '8GB',
        minCpu: '8 cores',
        minGpu: '4GB VRAM'
      },
      performance: {
        inferenceTime: 25,
        accuracy: 89.3,
        efficiency: 78.6
      },
      lastUsed: Date.now() - 86400000,
      downloadCount: 8765,
      author: 'MultiModal AI',
      tags: ['multimodal', 'cross-modal', 'advanced', 'ai'],
      isCustom: false
    }
  ]);

  const [marketplaceModels, setMarketplaceModels] = useState<ModelMarketplace[]>([
    {
      id: 'pixel-art-v2',
      name: 'Pixel Art Studio v2',
      type: 'pixel',
      category: 'Art Generation',
      description: 'Specialized model for pixel art creation with retro and modern styles',
      size: '3.1GB',
      downloads: 8932,
      rating: 4.8,
      author: 'RetroAI',
      tags: ['pixel-art', 'retro', 'art', 'creative'],
      isDownloaded: false
    },
    {
      id: 'orchestral-ai',
      name: 'Orchestral AI',
      type: 'audio',
      category: 'Music Generation',
      description: 'Classical music generation with full orchestral arrangement capabilities',
      size: '5.2GB',
      downloads: 6543,
      rating: 4.9,
      author: 'MusicAI Systems',
      tags: ['orchestral', 'classical', 'music', 'arrangement'],
      isDownloaded: false
    },
    {
      id: 'unified-creator',
      name: 'Unified Creator Pro',
      type: 'multimodal',
      category: 'Creative Suite',
      description: 'All-in-one creative AI for video, audio, and graphics generation',
      size: '12.4GB',
      downloads: 15432,
      rating: 4.7,
      author: 'CreativeAI Inc',
      tags: ['unified', 'creative', 'video', 'audio', 'graphics'],
      isDownloaded: true
    }
  ]);

  const [configurations, setConfigurations] = useState<ModelConfiguration[]>([
    {
      modelId: 'pixel-gen-v1',
      settings: {
        batchSize: 1,
        precision: 'fp16',
        optimizationLevel: 3,
        maxMemoryUsage: 4096,
        threadCount: 4,
        useGPU: true
      }
    }
  ]);

  const [selectedModel, setSelectedModel] = useState<string | null>(null);
  const [isEditingConfig, setIsEditingConfig] = useState(false);
  const [activeTab, setActiveTab] = useState('my-models');

  // Simulate model status changes
  useEffect(() => {
    const interval = setInterval(() => {
      setModels(prev => prev.map(model => {
        if (model.status === 'loading' && Math.random() < 0.1) {
          return { ...model, status: 'loaded' as const };
        }
        if (model.status === 'unloading' && Math.random() < 0.1) {
          return { ...model, status: 'available' as const };
        }
        return model;
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'text-gray-600 bg-gray-100';
      case 'loading': return 'text-blue-600 bg-blue-100';
      case 'loaded': return 'text-green-600 bg-green-100';
      case 'running': return 'text-purple-600 bg-purple-100';
      case 'error': return 'text-red-600 bg-red-100';
      case 'unloading': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'pixel': return <Monitor className="w-4 h-4" />;
      case 'audio': return <Network className="w-4 h-4" />;
      case 'multimodal': return <Brain className="w-4 h-4" />;
      default: return <Brain className="w-4 h-4" />;
    }
  };

  const loadModel = (modelId: string) => {
    setModels(prev => prev.map(model => 
      model.id === modelId ? { ...model, status: 'loading' as const } : model
    ));
  };

  const unloadModel = (modelId: string) => {
    setModels(prev => prev.map(model => 
      model.id === modelId ? { ...model, status: 'unloading' as const } : model
    ));
  };

  const startModel = (modelId: string) => {
    setModels(prev => prev.map(model => 
      model.id === modelId ? { ...model, status: 'running' as const, lastUsed: Date.now() } : model
    ));
  };

  const stopModel = (modelId: string) => {
    setModels(prev => prev.map(model => 
      model.id === modelId ? { ...model, status: 'loaded' as const } : model
    ));
  };

  const deleteModel = (modelId: string) => {
    setModels(prev => prev.filter(model => model.id !== modelId));
  };

  const downloadModel = (marketplaceModel: ModelMarketplace) => {
    // Add to models list
    const newModel: AIModel = {
      id: marketplaceModel.id,
      name: marketplaceModel.name,
      type: marketplaceModel.type,
      version: '1.0.0',
      size: marketplaceModel.size,
      status: 'loading',
      description: marketplaceModel.description,
      capabilities: ['AI-powered generation', 'Edge optimized'],
      requirements: {
        minMemory: '4GB',
        minCpu: '2 cores'
      },
      performance: {
        inferenceTime: 15,
        accuracy: 90.0,
        efficiency: 85.0
      },
      lastUsed: Date.now(),
      downloadCount: 0,
      author: marketplaceModel.author,
      tags: marketplaceModel.tags,
      isCustom: false
    };

    setModels(prev => [...prev, newModel]);
    
    // Update marketplace
    setMarketplaceModels(prev => prev.map(model => 
      model.id === marketplaceModel.id ? { ...model, isDownloaded: true } : model
    ));
  };

  const getModelConfiguration = (modelId: string) => {
    return configurations.find(config => config.modelId === modelId) || {
      modelId,
      settings: {
        batchSize: 1,
        precision: 'fp16' as const,
        optimizationLevel: 3,
        maxMemoryUsage: 2048,
        threadCount: 2,
        useGPU: false
      }
    };
  };

  const updateConfiguration = (modelId: string, newSettings: any) => {
    setConfigurations(prev => {
      const existing = prev.find(config => config.modelId === modelId);
      if (existing) {
        return prev.map(config => 
          config.modelId === modelId ? { ...config, settings: newSettings } : config
        );
      } else {
        return [...prev, { modelId, settings: newSettings }];
      }
    });
  };

  const formatFileSize = (size: string) => {
    return size;
  };

  const formatLastUsed = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">AI Model Management</h2>
          <p className="text-muted-foreground">Manage and configure AI models for edge inference</p>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant="outline" className="border-green-500 text-green-600">
            <CheckCircle className="w-3 h-3 mr-1" />
            {models.filter(m => m.status === 'running').length} Active
          </Badge>
          <Badge variant="outline" className="border-blue-500 text-blue-600">
            <Brain className="w-3 h-3 mr-1" />
            {models.length} Models
          </Badge>
        </div>
      </div>

      {/* Model Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Brain className="w-5 h-5 text-purple-600" />
              <div>
                <div className="text-lg font-bold">{models.length}</div>
                <div className="text-xs text-muted-foreground">Total Models</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Play className="w-5 h-5 text-green-600" />
              <div>
                <div className="text-lg font-bold">
                  {models.filter(m => m.status === 'running').length}
                </div>
                <div className="text-xs text-muted-foreground">Running</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <MemoryStick className="w-5 h-5 text-blue-600" />
              <div>
                <div className="text-lg font-bold">
                  {models.reduce((total, model) => {
                    const size = parseFloat(model.size);
                    return total + (isNaN(size) ? 0 : size);
                  }, 0).toFixed(1)}GB
                </div>
                <div className="text-xs text-muted-foreground">Total Size</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Zap className="w-5 h-5 text-orange-600" />
              <div>
                <div className="text-lg font-bold">
                  {models.reduce((total, model) => total + model.downloadCount, 0).toLocaleString()}
                </div>
                <div className="text-xs text-muted-foreground">Downloads</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="my-models">My Models</TabsTrigger>
          <TabsTrigger value="marketplace">Marketplace</TabsTrigger>
          <TabsTrigger value="configuration">Configuration</TabsTrigger>
        </TabsList>

        <TabsContent value="my-models" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {models.map((model) => (
              <Card key={model.id} className="transition-all hover:shadow-lg">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {getTypeIcon(model.type)}
                      <div>
                        <CardTitle className="text-lg">{model.name}</CardTitle>
                        <CardDescription className="capitalize">{model.type} model • v{model.version}</CardDescription>
                      </div>
                    </div>
                    <Badge variant="outline" className={getStatusColor(model.status)}>
                      {model.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{model.description}</p>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Size:</span>
                      <span>{model.size}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Last used:</span>
                      <span>{formatLastUsed(model.lastUsed)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Downloads:</span>
                      <span>{model.downloadCount.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium">Capabilities:</div>
                    <div className="flex flex-wrap gap-1">
                      {model.capabilities.slice(0, 3).map((capability, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {capability}
                        </Badge>
                      ))}
                      {model.capabilities.length > 3 && (
                        <Badge variant="secondary" className="text-xs">
                          +{model.capabilities.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2">
                    {model.status === 'available' && (
                      <Button size="sm" onClick={() => loadModel(model.id)}>
                        <Download className="w-4 h-4 mr-1" />
                        Load
                      </Button>
                    )}
                    {model.status === 'loaded' && (
                      <Button size="sm" onClick={() => startModel(model.id)}>
                        <Play className="w-4 h-4 mr-1" />
                        Start
                      </Button>
                    )}
                    {model.status === 'running' && (
                      <Button size="sm" variant="outline" onClick={() => stopModel(model.id)}>
                        <Pause className="w-4 h-4 mr-1" />
                        Stop
                      </Button>
                    )}
                    {(model.status === 'loaded' || model.status === 'running') && (
                      <Button size="sm" variant="outline" onClick={() => unloadModel(model.id)}>
                        <Upload className="w-4 h-4 mr-1" />
                        Unload
                      </Button>
                    )}
                    <Button size="sm" variant="outline" onClick={() => setSelectedModel(model.id)}>
                      <Settings className="w-4 h-4 mr-1" />
                      Configure
                    </Button>
                    {model.isCustom && (
                      <Button size="sm" variant="outline" onClick={() => deleteModel(model.id)}>
                        <Trash2 className="w-4 h-4 mr-1" />
                        Delete
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="marketplace" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {marketplaceModels.map((model) => (
              <Card key={model.id} className="transition-all hover:shadow-lg">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {getTypeIcon(model.type)}
                      <div>
                        <CardTitle className="text-lg">{model.name}</CardTitle>
                        <CardDescription className="capitalize">{model.type} • {model.category}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="border-yellow-500 text-yellow-600">
                        ⭐ {model.rating}
                      </Badge>
                      {model.isDownloaded && (
                        <Badge variant="outline" className="border-green-500 text-green-600">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Downloaded
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{model.description}</p>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Size:</span>
                      <span>{model.size}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Downloads:</span>
                      <span>{model.downloads.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Author:</span>
                      <span>{model.author}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-medium">Tags:</div>
                    <div className="flex flex-wrap gap-1">
                      {model.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2">
                    {!model.isDownloaded ? (
                      <Button size="sm" onClick={() => downloadModel(model)}>
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                    ) : (
                      <Button size="sm" variant="outline" disabled>
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Downloaded
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="configuration" className="space-y-4">
          {selectedModel ? (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Model Configuration</CardTitle>
                    <CardDescription>
                      Configure settings for {models.find(m => m.id === selectedModel)?.name}
                    </CardDescription>
                  </div>
                  <Button variant="outline" onClick={() => setSelectedModel(null)}>
                    <X className="w-4 h-4 mr-1" />
                    Close
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {(() => {
                  const config = getModelConfiguration(selectedModel);
                  return (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Batch Size: {config.settings.batchSize}
                        </label>
                        <Slider
                          value={[config.settings.batchSize]}
                          onValueChange={(value) => updateConfiguration(selectedModel, {
                            ...config.settings,
                            batchSize: value[0]
                          })}
                          max={16}
                          step={1}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Optimization Level: {config.settings.optimizationLevel}
                        </label>
                        <Slider
                          value={[config.settings.optimizationLevel]}
                          onValueChange={(value) => updateConfiguration(selectedModel, {
                            ...config.settings,
                            optimizationLevel: value[0]
                          })}
                          max={5}
                          step={1}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Max Memory Usage: {config.settings.maxMemoryUsage}MB
                        </label>
                        <Slider
                          value={[config.settings.maxMemoryUsage]}
                          onValueChange={(value) => updateConfiguration(selectedModel, {
                            ...config.settings,
                            maxMemoryUsage: value[0]
                          })}
                          max={16384}
                          step={256}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Thread Count: {config.settings.threadCount}
                        </label>
                        <Slider
                          value={[config.settings.threadCount]}
                          onValueChange={(value) => updateConfiguration(selectedModel, {
                            ...config.settings,
                            threadCount: value[0]
                          })}
                          max={16}
                          step={1}
                          className="w-full"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-2">Precision</label>
                          <select
                            value={config.settings.precision}
                            onChange={(e) => updateConfiguration(selectedModel, {
                              ...config.settings,
                              precision: e.target.value as any
                            })}
                            className="w-full p-2 border rounded-md"
                          >
                            <option value="fp32">FP32 (High Precision)</option>
                            <option value="fp16">FP16 (Balanced)</option>
                            <option value="int8">INT8 (Fastest)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-2">GPU Acceleration</label>
                          <select
                            value={config.settings.useGPU ? 'enabled' : 'disabled'}
                            onChange={(e) => updateConfiguration(selectedModel, {
                              ...config.settings,
                              useGPU: e.target.value === 'enabled'
                            })}
                            className="w-full p-2 border rounded-md"
                          >
                            <option value="enabled">Enabled</option>
                            <option value="disabled">Disabled</option>
                          </select>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button onClick={() => setIsEditingConfig(false)}>
                          <Save className="w-4 h-4 mr-1" />
                          Save Configuration
                        </Button>
                        <Button variant="outline" onClick={() => {
                          // Reset to defaults
                          updateConfiguration(selectedModel, {
                            batchSize: 1,
                            precision: 'fp16',
                            optimizationLevel: 3,
                            maxMemoryUsage: 2048,
                            threadCount: 2,
                            useGPU: false
                          });
                        }}>
                          <RefreshCw className="w-4 h-4 mr-1" />
                          Reset to Defaults
                        </Button>
                      </div>
                    </div>
                  );
                })()}
              </CardContent>
            </Card>
          ) : (
            <div className="text-center py-12">
              <Settings className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Model Selected</h3>
              <p className="text-muted-foreground mb-4">
                Select a model from "My Models" to configure its settings
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}