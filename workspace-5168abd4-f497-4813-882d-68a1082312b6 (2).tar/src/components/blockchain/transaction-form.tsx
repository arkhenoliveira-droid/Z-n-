'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Send, Plus, Hash } from 'lucide-react';
import { Transaction } from '@/lib/blockchain';

interface TransactionFormProps {
  onCreateTransaction: (transaction: Omit<Transaction, 'timestamp'>) => void;
  onMineBlock: (minerAddress: string) => void;
  pendingTransactions: number;
  onGenerateWallet: () => string;
}

export function TransactionForm({
  onCreateTransaction,
  onMineBlock,
  pendingTransactions,
  onGenerateWallet
}: TransactionFormProps) {
  const [fromAddress, setFromAddress] = useState('');
  const [toAddress, setToAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [minerAddress, setMinerAddress] = useState('');

  const handleSubmitTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fromAddress || !toAddress || !amount) return;

    onCreateTransaction({
      fromAddress,
      toAddress,
      amount: parseFloat(amount)
    });

    // Reset form
    setToAddress('');
    setAmount('');
  };

  const handleSubmitMining = (e: React.FormEvent) => {
    e.preventDefault();
    if (!minerAddress) return;

    onMineBlock(minerAddress);
  };

  const handleGenerateFromWallet = () => {
    const newWallet = onGenerateWallet();
    setFromAddress(newWallet);
  };

  const handleGenerateToWallet = () => {
    const newWallet = onGenerateWallet();
    setToAddress(newWallet);
  };

  const handleGenerateMinerWallet = () => {
    const newWallet = onGenerateWallet();
    setMinerAddress(newWallet);
  };

  return (
    <div className="space-y-6">
      {/* Transaction Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Send className="h-5 w-5" />
            <span>Create Transaction</span>
          </CardTitle>
          <CardDescription>
            Create a new transaction between wallets
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmitTransaction} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fromAddress">From Address</Label>
              <div className="flex space-x-2">
                <Input
                  id="fromAddress"
                  value={fromAddress}
                  onChange={(e) => setFromAddress(e.target.value)}
                  placeholder="0x..."
                  className="font-mono text-sm"
                  required
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleGenerateFromWallet}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Generate
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="toAddress">To Address</Label>
              <div className="flex space-x-2">
                <Input
                  id="toAddress"
                  value={toAddress}
                  onChange={(e) => setToAddress(e.target.value)}
                  placeholder="0x..."
                  className="font-mono text-sm"
                  required
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleGenerateToWallet}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Generate
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="100"
                min="1"
                step="1"
                required
              />
            </div>

            <Button type="submit" className="w-full">
              Create Transaction
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Mining Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Hash className="h-5 w-5" />
            <span>Mine Block</span>
            <Badge variant="secondary">
              {pendingTransactions} pending
            </Badge>
          </CardTitle>
          <CardDescription>
            Mine pending transactions and receive mining rewards
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmitMining} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="minerAddress">Miner Address</Label>
              <div className="flex space-x-2">
                <Input
                  id="minerAddress"
                  value={minerAddress}
                  onChange={(e) => setMinerAddress(e.target.value)}
                  placeholder="0x..."
                  className="font-mono text-sm"
                  required
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleGenerateMinerWallet}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Generate
                </Button>
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={pendingTransactions === 0}>
              Mine Block ({pendingTransactions} transactions)
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}