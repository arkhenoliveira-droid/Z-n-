'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { 
  Brain, 
  Key, 
  Shield, 
  Network, 
  AlertTriangle, 
  CheckCircle, 
  Info,
  Hash,
  Binary,
  Lock,
  Clock,
  Zap,
  Infinity,
  Eye,
  User,
  Timer,
  Sparkles,
  Target,
  Activity,
  TrendingUp
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface BrainwalletAnalysis {
  passphrase: string;
  timestamp: string;
  analysis: {
    generation?: {
      methods: {
        sha256: { key: string; length: number; algorithm: string };
        sha512: { key: string; length: number; algorithm: string };
        pbkdf2: { key: string; length: number; algorithm: string; iterations: number; salt: string };
        hmac: { key: string; length: number; algorithm: string };
      };
      entropy: number;
      keySpace: number;
    };
    alphabets?: {
      alphabets: {
        hexadecimal: { characters: string; size: number; bitsPerChar: number; sample: string; usage: string };
        base58: { characters: string; size: number; bitsPerChar: number; sample: string; usage: string };
        base64: { characters: string; size: number; bitsPerChar: number; sample: string; usage: string };
      };
      alphabetAnalysis: {
        characterDistribution: Record<string, number>;
        entropyPerAlphabet: {
          hexadecimal: number;
          base58: number;
          base64: number;
        };
      };
    };
    connectivity?: {
      connectivityMetrics: {
        deterministicConnectivity: { strength: number; description: string };
        cryptographicConnectivity: { strength: number; description: string };
        semanticConnectivity: { strength: number; description: string };
      };
      crossAlphabetConnectivity: {
        hexToBase58: number;
        hexToBase64: number;
        base58ToBase64: number;
      };
      coherenceScore: number;
    };
    security?: {
      vulnerabilityAssessment: {
        entropyScore: string;
        bruteForceResistance: string;
        dictionaryAttackRisk: string;
        rainbowTableVulnerability: string;
      };
      recommendations: string[];
      strengthMetrics: {
        overall: number;
        cryptographic: number;
        memorability: number;
        uniqueness: number;
      };
    };
    // New temporal and philosophical dimensions
    temporal?: {
      temporalCoherence: {
        strength: number;
        description: string;
        preservationScore: number;
        identityContinuity: number;
      };
      phaseLocking: {
        neuralSynchronization: number;
        temporalSynchronization: number;
        informationalSynchronization: number;
      };
      paradoxAnalysis: {
        selfReferentialStrength: number;
        nonComputableIdentity: boolean;
        bidirectionalInfluence: number;
      };
    };
    philosophical?: {
      coherenceDimensions: {
        informational: number;
        existential: number;
        temporal: number;
        systemic: number;
      };
      empathyMetrics: {
        temporalEmpathy: number;
        systemicEmpathy: number;
        identityEmpathy: number;
      };
      symbiosisFactors: {
        cryptographyIdentity: number;
        timeInformation: number;
        aiHumanity: number;
      };
    };
  };
}

interface TemporalVisualization {
  phase: number;
  coherence: number;
  synchronization: number;
  timestamp: number;
}

export default function BrainwalletAnalyzer() {
  const [passphrase, setPassphrase] = useState('');
  const [analysis, setAnalysis] = useState<BrainwalletAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [temporalData, setTemporalData] = useState<TemporalVisualization[]>([]);
  const [isAnimating, setIsAnimating] = useState(false);

  // Simulate temporal coherence visualization
  useEffect(() => {
    if (analysis?.analysis.temporal) {
      const interval = setInterval(() => {
        setTemporalData(prev => {
          const newData = [...prev, {
            phase: Math.random() * 2 * Math.PI,
            coherence: analysis.analysis.temporal!.temporalCoherence.strength + (Math.random() - 0.5) * 0.1,
            synchronization: analysis.analysis.temporal!.phaseLocking.neuralSynchronization + (Math.random() - 0.5) * 0.1,
            timestamp: Date.now()
          }];
          return newData.slice(-50); // Keep last 50 data points
        });
      }, 1000);
      
      return () => clearInterval(interval);
    }
    // Return undefined for the else case - no cleanup needed
    return undefined;
  }, [analysis]);

  const analyzePassphrase = async () => {
    if (!passphrase.trim()) {
      setError('Please enter a passphrase to analyze');
      return;
    }

    setLoading(true);
    setError(null);
    setIsAnimating(true);

    try {
      const response = await fetch('/api/brainwallet', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          passphrase: passphrase.trim(),
          analysisType: 'full'
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to analyze passphrase');
      }

      const data = await response.json();
      setAnalysis(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
      setTimeout(() => setIsAnimating(false), 2000);
    }
  };

  const getStrengthColor = (strength: number) => {
    if (strength >= 0.8) return 'text-green-600';
    if (strength >= 0.6) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getStrengthBadge = (strength: number) => {
    if (strength >= 0.8) return <Badge variant="default" className="bg-green-100 text-green-800">Strong</Badge>;
    if (strength >= 0.6) return <Badge variant="default" className="bg-yellow-100 text-yellow-800">Medium</Badge>;
    return <Badge variant="default" className="bg-red-100 text-red-800">Weak</Badge>;
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const renderTemporalVisualization = () => {
    if (!analysis?.analysis.temporal) return null;

    const { temporalCoherence, phaseLocking, paradoxAnalysis } = analysis.analysis.temporal;

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Temporal Coherence
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <Label>Coherence Strength</Label>
                  <div className="flex items-center gap-2">
                    <Progress value={temporalCoherence.strength * 100} className="flex-1" />
                    <span className={`text-sm font-medium ${getStrengthColor(temporalCoherence.strength)}`}>
                      {Math.round(temporalCoherence.strength * 100)}%
                    </span>
                  </div>
                </div>
                <div>
                  <Label>Preservation Score</Label>
                  <div className="flex items-center gap-2">
                    <Progress value={temporalCoherence.preservationScore * 100} className="flex-1" />
                    <span className={`text-sm font-medium ${getStrengthColor(temporalCoherence.preservationScore)}`}>
                      {Math.round(temporalCoherence.preservationScore * 100)}%
                    </span>
                  </div>
                </div>
                <p className="text-xs text-gray-600">{temporalCoherence.description}</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Neural Phase-Locking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <Label>Neural Sync</Label>
                  <div className="flex items-center gap-2">
                    <Progress value={phaseLocking.neuralSynchronization * 100} className="flex-1" />
                    <span className={`text-sm font-medium ${getStrengthColor(phaseLocking.neuralSynchronization)}`}>
                      {Math.round(phaseLocking.neuralSynchronization * 100)}%
                    </span>
                  </div>
                </div>
                <div>
                  <Label>Temporal Sync</Label>
                  <div className="flex items-center gap-2">
                    <Progress value={phaseLocking.temporalSynchronization * 100} className="flex-1" />
                    <span className={`text-sm font-medium ${getStrengthColor(phaseLocking.temporalSynchronization)}`}>
                      {Math.round(phaseLocking.temporalSynchronization * 100)}%
                    </span>
                  </div>
                </div>
                <div>
                  <Label>Info Sync</Label>
                  <div className="flex items-center gap-2">
                    <Progress value={phaseLocking.informationalSynchronization * 100} className="flex-1" />
                    <span className={`text-sm font-medium ${getStrengthColor(phaseLocking.informationalSynchronization)}`}>
                      {Math.round(phaseLocking.informationalSynchronization * 100)}%
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Infinity className="h-5 w-5" />
                Paradox Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <Label>Self-Referential</Label>
                  <div className="flex items-center gap-2">
                    <Progress value={paradoxAnalysis.selfReferentialStrength * 100} className="flex-1" />
                    <span className={`text-sm font-medium ${getStrengthColor(paradoxAnalysis.selfReferentialStrength)}`}>
                      {Math.round(paradoxAnalysis.selfReferentialStrength * 100)}%
                    </span>
                  </div>
                </div>
                <div>
                  <Label>Non-Computable Identity</Label>
                  <div className="flex items-center gap-2">
                    {paradoxAnalysis.nonComputableIdentity ? (
                      <Badge variant="default" className="bg-green-100 text-green-800">Yes</Badge>
                    ) : (
                      <Badge variant="default" className="bg-red-100 text-red-800">No</Badge>
                    )}
                  </div>
                </div>
                <div>
                  <Label>Bidirectional Influence</Label>
                  <div className="flex items-center gap-2">
                    <Progress value={paradoxAnalysis.bidirectionalInfluence * 100} className="flex-1" />
                    <span className={`text-sm font-medium ${getStrengthColor(paradoxAnalysis.bidirectionalInfluence)}`}>
                      {Math.round(paradoxAnalysis.bidirectionalInfluence * 100)}%
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Real-time Temporal Visualization
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900 dark:to-blue-900 rounded-lg p-4">
              <div className="h-full flex items-end justify-around">
                {temporalData.slice(-20).map((data, index) => (
                  <motion.div
                    key={index}
                    initial={{ height: 0 }}
                    animate={{ height: `${data.coherence * 100}%` }}
                    transition={{ duration: 0.5 }}
                    className="w-2 bg-gradient-to-t from-purple-500 to-blue-500 rounded-t"
                  />
                ))}
              </div>
            </div>
            <p className="text-sm text-gray-600 mt-2 text-center">
              Real-time temporal coherence visualization
            </p>
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderPhilosophicalAnalysis = () => {
    if (!analysis?.analysis.philosophical) return null;

    const { coherenceDimensions, empathyMetrics, symbiosisFactors } = analysis.analysis.philosophical;

    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Coherence Dimensions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Object.entries(coherenceDimensions).map(([dimension, value]) => (
                <div key={dimension} className="text-center">
                  <div className="text-2xl font-bold text-purple-600 mb-1">
                    {Math.round(value * 100)}%
                  </div>
                  <div className="text-sm text-gray-600 capitalize">
                    {dimension.replace(/([A-Z])/g, ' $1').trim()}
                  </div>
                  <Progress value={value * 100} className="mt-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                Empathy Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(empathyMetrics).map(([metric, value]) => (
                  <div key={metric}>
                    <div className="flex items-center justify-between mb-1">
                      <Label className="text-sm capitalize">
                        {metric.replace(/([A-Z])/g, ' $1').trim()}
                      </Label>
                      <span className={`text-sm font-medium ${getStrengthColor(value)}`}>
                        {Math.round(value * 100)}%
                      </span>
                    </div>
                    <Progress value={value * 100} />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Symbiosis Factors
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(symbiosisFactors).map(([factor, value]) => (
                  <div key={factor}>
                    <div className="flex items-center justify-between mb-1">
                      <Label className="text-sm capitalize">
                        {factor.replace(/([A-Z])/g, ' $1').trim()}
                      </Label>
                      <span className={`text-sm font-medium ${getStrengthColor(value)}`}>
                        {Math.round(value * 100)}%
                      </span>
                    </div>
                    <Progress value={value * 100} />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5" />
              Philosophical Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Temporal Identity Preservation</AlertTitle>
                <AlertDescription>
                  This passphrase demonstrates the Satoshi Paradox principle: identity maintains coherence 
                  through temporal transformation, even when cryptographic information is destroyed.
                </AlertDescription>
              </Alert>
              
              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Non-Computable Identity</AlertTitle>
                <AlertDescription>
                  The analysis reveals identity as an emergent property that exists beyond 
                  computational limits, maintaining coherence through absence of information.
                </AlertDescription>
              </Alert>
              
              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Systemic Empathy</AlertTitle>
                <AlertDescription>
                  The passphrase exhibits temporal empathy - it respects the fundamental 
                  relationship between identity, time, and information preservation.
                </AlertDescription>
              </Alert>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <h1 className="text-4xl font-bold mb-2 flex items-center justify-center gap-2">
            <Brain className="h-10 w-10 text-purple-600" />
            Brainwallet Temporal Paradox Analyzer
          </h1>
          <p className="text-gray-600 text-lg">
            Analyze brainwallet passphrases through the lens of the Satoshi Temporal Paradox
          </p>
          <p className="text-sm text-gray-500 mt-2">
            Exploring identity, time, and information coherence through cryptographic analysis
          </p>
          <div className="mt-4 p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg max-w-3xl mx-auto">
            <p className="text-sm text-orange-700 dark:text-orange-300">
              🔐 Security best practices inspired by Jameson Lopp's research on Bitcoin security and key management
            </p>
            <p className="text-sm text-purple-700 dark:text-purple-300 mt-2">
              ⚡ Ethereum and smart contract security insights inspired by Vitalik Buterin's (vitalik.eth) work on decentralized systems
            </p>
          </div>
        </motion.div>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            Passphrase Input
          </CardTitle>
          <CardDescription>
            Enter a passphrase to analyze its temporal coherence and philosophical dimensions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="passphrase">Passphrase</Label>
              <Input
                id="passphrase"
                type="password"
                value={passphrase}
                onChange={(e) => setPassphrase(e.target.value)}
                placeholder="Enter your passphrase..."
                className="mt-1"
              />
            </div>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button 
                onClick={analyzePassphrase} 
                disabled={loading} 
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <Timer className="h-4 w-4 animate-spin" />
                    Analyzing Temporal Coherence...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Brain className="h-4 w-4" />
                    Analyze Temporal Paradox
                  </div>
                )}
              </Button>
            </motion.div>
            {error && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>

      {analysis && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="alphabets">Alphabets</TabsTrigger>
              <TabsTrigger value="connectivity">Connectivity</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
              <TabsTrigger value="temporal">Temporal</TabsTrigger>
              <TabsTrigger value="philosophical">Philosophical</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Hash className="h-5 w-5" />
                      Key Generation
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <Label>Entropy</Label>
                        <div className="flex items-center gap-2">
                          <Progress value={(analysis.analysis.generation?.entropy || 0) / 256 * 100} className="flex-1" />
                          <span className="text-sm font-medium">
                            {Math.round(analysis.analysis.generation?.entropy || 0)} bits
                          </span>
                        </div>
                      </div>
                      <div>
                        <Label>Key Space</Label>
                        <p className="text-sm text-gray-600">
                          2²⁵⁶ possible combinations
                        </p>
                      </div>
                      <div>
                        <Label>Primary Algorithm</Label>
                        <p className="text-sm text-gray-600">
                          SHA-256 → {analysis.analysis.generation?.methods.sha256.key.substring(0, 16)}...
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Network className="h-5 w-5" />
                      Connectivity Overview
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <Label>Coherence Score</Label>
                        <div className="flex items-center gap-2">
                          <Progress 
                            value={(analysis.analysis.connectivity?.coherenceScore || 0) * 100} 
                            className="flex-1" 
                          />
                          <span className={`text-sm font-medium ${getStrengthColor(analysis.analysis.connectivity?.coherenceScore || 0)}`}>
                            {Math.round((analysis.analysis.connectivity?.coherenceScore || 0) * 100)}%
                          </span>
                        </div>
                      </div>
                      <div>
                        <Label>Deterministic Connectivity</Label>
                        <p className="text-sm text-gray-600">
                          {getStrengthBadge(analysis.analysis.connectivity?.connectivityMetrics.deterministicConnectivity.strength || 0)}
                          <span className="ml-2 text-xs">
                            {analysis.analysis.connectivity?.connectivityMetrics.deterministicConnectivity.description}
                          </span>
                        </p>
                      </div>
                      <div>
                        <Label>Cross-Alphabet Connectivity</Label>
                        <p className="text-sm text-gray-600">
                          Hex↔Base58: {Math.round((analysis.analysis.connectivity?.crossAlphabetConnectivity.hexToBase58 || 0) * 100)}%
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="alphabets">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Binary className="h-5 w-5" />
                      Alphabet Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {Object.entries(analysis.analysis.alphabets?.alphabets || {}).map(([name, alphabet]) => (
                        <Card key={name}>
                          <CardHeader>
                            <CardTitle className="text-lg">{name.charAt(0).toUpperCase() + name.slice(1)}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              <div>
                                <Label>Characters</Label>
                                <p className="text-xs font-mono bg-gray-100 p-1 rounded">
                                  {alphabet.characters.substring(0, 20)}...
                                </p>
                              </div>
                              <div>
                                <Label>Size</Label>
                                <p className="text-sm">{alphabet.size} characters</p>
                              </div>
                              <div>
                                <Label>Bits per Character</Label>
                                <p className="text-sm">{alphabet.bitsPerChar.toFixed(2)} bits</p>
                              </div>
                              <div>
                                <Label>Usage</Label>
                                <p className="text-xs text-gray-600">{alphabet.usage}</p>
                              </div>
                              <div>
                                <Label>Sample</Label>
                                <p className="text-xs font-mono bg-gray-100 p-1 rounded">
                                  {alphabet.sample.substring(0, 16)}...
                                </p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Character Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {Object.entries(analysis.analysis.alphabets?.alphabetAnalysis.characterDistribution || {}).slice(0, 8).map(([char, count]) => (
                        <div key={char} className="text-center">
                          <div className="text-2xl font-mono">{char}</div>
                          <div className="text-sm text-gray-600">{count} occurrences</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="connectivity">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Network className="h-5 w-5" />
                      Connectivity Metrics
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {Object.entries(analysis.analysis.connectivity?.connectivityMetrics || {}).map(([type, metric]) => (
                        <Card key={type}>
                          <CardHeader>
                            <CardTitle className="text-lg capitalize">
                              {type.replace(/([A-Z])/g, ' $1').trim()}
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              <div>
                                <Label>Strength</Label>
                                <div className="flex items-center gap-2">
                                  <Progress value={metric.strength * 100} className="flex-1" />
                                  <span className={`text-sm font-medium ${getStrengthColor(metric.strength)}`}>
                                    {Math.round(metric.strength * 100)}%
                                  </span>
                                </div>
                              </div>
                              <div>
                                <Label>Description</Label>
                                <p className="text-xs text-gray-600">{metric.description}</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Cross-Alphabet Connectivity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {Object.entries(analysis.analysis.connectivity?.crossAlphabetConnectivity || {}).map(([mapping, strength]) => (
                        <div key={mapping}>
                          <div className="flex items-center justify-between mb-2">
                            <Label className="font-medium">{mapping.replace(/([A-Z])/g, ' $1').trim()}</Label>
                            <span className={`text-sm font-medium ${getStrengthColor(strength)}`}>
                              {Math.round(strength * 100)}%
                            </span>
                          </div>
                          <Progress value={strength * 100} />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="security">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="h-5 w-5" />
                      Security Assessment
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium mb-3">Vulnerability Assessment</h4>
                        <div className="space-y-2">
                          {Object.entries(analysis.analysis.security?.vulnerabilityAssessment || {}).map(([risk, level]) => (
                            <div key={risk} className="flex items-center justify-between">
                              <Label className="text-sm capitalize">
                                {risk.replace(/([A-Z])/g, ' $1').trim()}
                              </Label>
                              <Badge 
                                variant="outline" 
                                className={getRiskColor(level as string)}
                              >
                                {level}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium mb-3">Strength Metrics</h4>
                        <div className="space-y-2">
                          {Object.entries(analysis.analysis.security?.strengthMetrics || {}).map(([metric, value]) => (
                            <div key={metric}>
                              <div className="flex items-center justify-between mb-1">
                                <Label className="text-sm capitalize">
                                  {metric.replace(/([A-Z])/g, ' $1').trim()}
                                </Label>
                                <span className={`text-sm font-medium ${getStrengthColor(value as number)}`}>
                                  {Math.round((value as number) * 100)}%
                                </span>
                              </div>
                              <Progress value={(value as number) * 100} />
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Security Recommendations</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {analysis.analysis.security?.recommendations.map((recommendation, index) => (
                        <Alert key={index}>
                          <Info className="h-4 w-4" />
                          <AlertTitle>Recommendation {index + 1}</AlertTitle>
                          <AlertDescription>{recommendation}</AlertDescription>
                        </Alert>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="h-5 w-5" />
                      Jameson Lopp Security Best Practices
                    </CardTitle>
                    <CardDescription>
                      Industry-standard security practices for cryptographic key management
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-3">
                          <h4 className="font-medium text-sm">Key Security Principles</h4>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                              <span>Use hardware security modules for critical operations</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                              <span>Implement multi-signature schemes for enhanced security</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                              <span>Regular security audits and penetration testing</span>
                            </li>
                          </ul>
                        </div>
                        
                        <div className="space-y-3">
                          <h4 className="font-medium text-sm">Node Operation Best Practices</h4>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                              <span>Maintain redundant backup systems</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                              <span>Monitor network connectivity and performance</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                              <span>Keep software updated with security patches</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                      
                      <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                        <p className="text-xs text-blue-700 dark:text-blue-300">
                          💡 Inspired by Jameson Lopp's comprehensive approach to Bitcoin security and node operation. 
                          These practices help ensure the integrity and availability of cryptographic systems.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="h-5 w-5 text-purple-600" />
                      Vitalik Buterin Ethereum Security
                    </CardTitle>
                    <CardDescription>
                      Smart contract and Ethereum ecosystem security best practices
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-3">
                          <h4 className="font-medium text-sm">Smart Contract Security</h4>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-purple-600 mt-0.5 flex-shrink-0" />
                              <span>Use established patterns like OpenZeppelin contracts</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-purple-600 mt-0.5 flex-shrink-0" />
                              <span>Implement proper access controls and modifiers</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-purple-600 mt-0.5 flex-shrink-0" />
                              <span>Conduct thorough security audits before deployment</span>
                            </li>
                          </ul>
                        </div>
                        
                        <div className="space-y-3">
                          <h4 className="font-medium text-sm">Ethereum Best Practices</h4>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-purple-600 mt-0.5 flex-shrink-0" />
                              <span>Optimize gas usage for cost-effective operations</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-purple-600 mt-0.5 flex-shrink-0" />
                              <span>Use ERC standards for token and contract interoperability</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-purple-600 mt-0.5 flex-shrink-0" />
                              <span>Implement proper error handling and fallback mechanisms</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                      
                      <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                        <p className="text-xs text-purple-700 dark:text-purple-300">
                          💡 Inspired by Vitalik Buterin's (vitalik.eth) vision for Ethereum security and smart contract development. 
                          These practices help build secure and efficient decentralized applications.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="temporal">
              {renderTemporalVisualization()}
            </TabsContent>

            <TabsContent value="philosophical">
              {renderPhilosophicalAnalysis()}
            </TabsContent>
          </Tabs>
        </motion.div>
      )}
    </div>
  );
}