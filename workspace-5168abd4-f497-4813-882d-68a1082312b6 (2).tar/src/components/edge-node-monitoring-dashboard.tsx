'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { 
  Cpu, 
  MemoryStick, 
  Monitor, 
  Thermometer, 
  Network, 
  Zap,
  Activity,
  Wifi,
  HardDrive,
  Settings,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  TrendingDown,
  Minus
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface EdgeNodeMetrics {
  timestamp: number;
  cpuUsage: number;
  memoryUsage: number;
  gpuUsage: number;
  temperature: number;
  networkLatency: number;
  inferenceSpeed: number;
  activeModels: number;
  generatedFrames: number;
  generatedAudioSamples: number;
  powerConsumption: number;
  diskUsage: number;
  networkThroughput: number;
  errorRate: number;
  uptime: number;
}

interface ModelPerformance {
  modelId: string;
  modelName: string;
  type: 'pixel' | 'audio' | 'multimodal';
  status: 'running' | 'idle' | 'error' | 'loading';
  cpuUsage: number;
  memoryUsage: number;
  inferenceTime: number;
  requestsPerSecond: number;
  lastUsed: number;
}

interface SystemAlert {
  id: string;
  type: 'warning' | 'error' | 'info' | 'success';
  message: string;
  timestamp: number;
  resolved: boolean;
}

interface ResourceUsage {
  cpu: number[];
  memory: number[];
  gpu: number[];
  network: number[];
  timestamps: number[];
}

export default function EdgeNodeMonitoringDashboard() {
  const [metrics, setMetrics] = useState<EdgeNodeMetrics>({
    timestamp: Date.now(),
    cpuUsage: 0,
    memoryUsage: 0,
    gpuUsage: 0,
    temperature: 0,
    networkLatency: 0,
    inferenceSpeed: 0,
    activeModels: 0,
    generatedFrames: 0,
    generatedAudioSamples: 0,
    powerConsumption: 0,
    diskUsage: 0,
    networkThroughput: 0,
    errorRate: 0,
    uptime: 0
  });

  const [modelPerformance, setModelPerformance] = useState<ModelPerformance[]>([
    {
      modelId: 'pixel-gen-v1',
      modelName: 'Pixel Generator v1',
      type: 'pixel',
      status: 'running',
      cpuUsage: 45,
      memoryUsage: 23,
      inferenceTime: 12,
      requestsPerSecond: 85,
      lastUsed: Date.now()
    },
    {
      modelId: 'audio-synth-v1',
      modelName: 'Audio Synthesizer v1',
      type: 'audio',
      status: 'running',
      cpuUsage: 32,
      memoryUsage: 18,
      inferenceTime: 8,
      requestsPerSecond: 120,
      lastUsed: Date.now()
    },
    {
      modelId: 'multimodal-v1',
      modelName: 'Multimodal Engine v1',
      type: 'multimodal',
      status: 'loading',
      cpuUsage: 15,
      memoryUsage: 35,
      inferenceTime: 0,
      requestsPerSecond: 0,
      lastUsed: Date.now() - 300000
    }
  ]);

  const [alerts, setAlerts] = useState<SystemAlert[]>([
    {
      id: '1',
      type: 'warning',
      message: 'High CPU usage detected on Pixel Generator',
      timestamp: Date.now() - 60000,
      resolved: false
    },
    {
      id: '2',
      type: 'info',
      message: 'Multimodal model loading completed',
      timestamp: Date.now() - 120000,
      resolved: true
    },
    {
      id: '3',
      type: 'success',
      message: 'Network latency optimized',
      timestamp: Date.now() - 180000,
      resolved: true
    }
  ]);

  const [resourceHistory, setResourceHistory] = useState<ResourceUsage>({
    cpu: [],
    memory: [],
    gpu: [],
    network: [],
    timestamps: []
  });

  const [isAutoRefresh, setIsAutoRefresh] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState(1000);

  // Simulate real-time metrics updates
  useEffect(() => {
    const interval = setInterval(() => {
      if (isAutoRefresh) {
        updateMetrics();
        updateResourceHistory();
      }
    }, refreshInterval);

    return () => clearInterval(interval);
  }, [isAutoRefresh, refreshInterval]);

  const updateMetrics = () => {
    setMetrics(prev => ({
      timestamp: Date.now(),
      cpuUsage: Math.min(100, Math.max(0, prev.cpuUsage + (Math.random() - 0.5) * 10)),
      memoryUsage: Math.min(100, Math.max(0, prev.memoryUsage + (Math.random() - 0.5) * 5)),
      gpuUsage: Math.min(100, Math.max(0, prev.gpuUsage + (Math.random() - 0.5) * 15)),
      temperature: Math.min(90, Math.max(25, prev.temperature + (Math.random() - 0.5) * 2)),
      networkLatency: Math.max(1, prev.networkLatency + (Math.random() - 0.5) * 5),
      inferenceSpeed: Math.max(10, prev.inferenceSpeed + (Math.random() - 0.5) * 20),
      activeModels: modelPerformance.filter(m => m.status === 'running').length,
      generatedFrames: prev.generatedFrames + Math.floor(Math.random() * 5),
      generatedAudioSamples: prev.generatedAudioSamples + Math.floor(Math.random() * 1000),
      powerConsumption: Math.min(500, Math.max(50, prev.powerConsumption + (Math.random() - 0.5) * 20)),
      diskUsage: Math.min(100, Math.max(0, prev.diskUsage + (Math.random() - 0.5) * 2)),
      networkThroughput: Math.max(0, prev.networkThroughput + (Math.random() - 0.5) * 10),
      errorRate: Math.max(0, Math.min(5, prev.errorRate + (Math.random() - 0.5) * 0.5)),
      uptime: prev.uptime + refreshInterval / 1000
    }));

    // Update model performance
    setModelPerformance(prev => prev.map(model => ({
      ...model,
      cpuUsage: model.status === 'running' ? 
        Math.min(100, Math.max(0, model.cpuUsage + (Math.random() - 0.5) * 5)) : 0,
      memoryUsage: model.status === 'running' ? 
        Math.min(100, Math.max(0, model.memoryUsage + (Math.random() - 0.5) * 3)) : 0,
      inferenceTime: model.status === 'running' ? 
        Math.max(1, model.inferenceTime + (Math.random() - 0.5) * 2) : 0,
      requestsPerSecond: model.status === 'running' ? 
        Math.max(0, model.requestsPerSecond + (Math.random() - 0.5) * 10) : 0,
      lastUsed: model.status === 'running' ? Date.now() : model.lastUsed
    })));
  };

  const updateResourceHistory = () => {
    setResourceHistory(prev => {
      const now = Date.now();
      const newCpu = [...prev.cpu, metrics.cpuUsage].slice(-60);
      const newMemory = [...prev.memory, metrics.memoryUsage].slice(-60);
      const newGpu = [...prev.gpu, metrics.gpuUsage].slice(-60);
      const newNetwork = [...prev.network, metrics.networkLatency].slice(-60);
      const newTimestamps = [...prev.timestamps, now].slice(-60);

      return {
        cpu: newCpu,
        memory: newMemory,
        gpu: newGpu,
        network: newNetwork,
        timestamps: newTimestamps
      };
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'text-green-600 bg-green-100';
      case 'idle': return 'text-yellow-600 bg-yellow-100';
      case 'loading': return 'text-blue-600 bg-blue-100';
      case 'error': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'error': return 'border-red-500 bg-red-50';
      case 'warning': return 'border-yellow-500 bg-yellow-50';
      case 'info': return 'border-blue-500 bg-blue-50';
      case 'success': return 'border-green-500 bg-green-50';
      default: return 'border-gray-500 bg-gray-50';
    }
  };

  const getMetricColor = (value: number, type: string) => {
    if (type === 'temperature') {
      if (value < 40) return 'text-green-600';
      if (value < 60) return 'text-yellow-600';
      return 'text-red-600';
    }
    if (type === 'usage') {
      if (value < 50) return 'text-green-600';
      if (value < 80) return 'text-yellow-600';
      return 'text-red-600';
    }
    if (type === 'latency') {
      if (value < 10) return 'text-green-600';
      if (value < 50) return 'text-yellow-600';
      return 'text-red-600';
    }
    return 'text-blue-600';
  };

  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (days > 0) return `${days}d ${hours}h ${minutes}m`;
    if (hours > 0) return `${hours}h ${minutes}m ${secs}s`;
    if (minutes > 0) return `${minutes}m ${secs}s`;
    return `${secs}s`;
  };

  const getTrendIcon = (current: number, previous: number) => {
    const diff = current - previous;
    if (Math.abs(diff) < 0.1) return <Minus className="w-4 h-4 text-gray-500" />;
    if (diff > 0) return <TrendingUp className="w-4 h-4 text-red-500" />;
    return <TrendingDown className="w-4 h-4 text-green-500" />;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Edge Node Monitoring</h2>
          <p className="text-muted-foreground">Real-time system metrics and performance monitoring</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Button
              variant={isAutoRefresh ? "default" : "outline"}
              size="sm"
              onClick={() => setIsAutoRefresh(!isAutoRefresh)}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isAutoRefresh ? 'animate-spin' : ''}`} />
              Auto Refresh
            </Button>
            <div className="text-sm text-muted-foreground">
              {formatUptime(metrics.uptime)}
            </div>
          </div>
          <Badge variant="outline" className="border-green-500 text-green-600">
            <CheckCircle className="w-3 h-3 mr-1" />
            System Online
          </Badge>
        </div>
      </div>

      {/* System Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Cpu className="w-5 h-5 text-blue-600" />
                <div>
                  <div className={`text-lg font-bold ${getMetricColor(metrics.cpuUsage, 'usage')}`}>
                    {metrics.cpuUsage.toFixed(1)}%
                  </div>
                  <div className="text-xs text-muted-foreground">CPU Usage</div>
                </div>
              </div>
              {getTrendIcon(metrics.cpuUsage, metrics.cpuUsage - 1)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <MemoryStick className="w-5 h-5 text-green-600" />
                <div>
                  <div className={`text-lg font-bold ${getMetricColor(metrics.memoryUsage, 'usage')}`}>
                    {metrics.memoryUsage.toFixed(1)}%
                  </div>
                  <div className="text-xs text-muted-foreground">Memory Usage</div>
                </div>
              </div>
              {getTrendIcon(metrics.memoryUsage, metrics.memoryUsage - 1)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Monitor className="w-5 h-5 text-purple-600" />
                <div>
                  <div className={`text-lg font-bold ${getMetricColor(metrics.gpuUsage, 'usage')}`}>
                    {metrics.gpuUsage.toFixed(1)}%
                  </div>
                  <div className="text-xs text-muted-foreground">GPU Usage</div>
                </div>
              </div>
              {getTrendIcon(metrics.gpuUsage, metrics.gpuUsage - 1)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Thermometer className="w-5 h-5 text-orange-600" />
                <div>
                  <div className={`text-lg font-bold ${getMetricColor(metrics.temperature, 'temperature')}`}>
                    {metrics.temperature.toFixed(1)}°C
                  </div>
                  <div className="text-xs text-muted-foreground">Temperature</div>
                </div>
              </div>
              {getTrendIcon(metrics.temperature, metrics.temperature - 0.5)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Metrics */}
      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="models">Model Status</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network className="w-5 h-5" />
                  Network Performance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span>Latency:</span>
                  <span className={`font-mono ${getMetricColor(metrics.networkLatency, 'latency')}`}>
                    {metrics.networkLatency.toFixed(1)}ms
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Throughput:</span>
                  <span className="font-mono text-blue-600">
                    {metrics.networkThroughput.toFixed(1)} MB/s
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Error Rate:</span>
                  <span className={`font-mono ${metrics.errorRate > 1 ? 'text-red-600' : 'text-green-600'}`}>
                    {metrics.errorRate.toFixed(2)}%
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  Inference Metrics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span>Speed:</span>
                  <span className="font-mono text-green-600">
                    {metrics.inferenceSpeed.toFixed(0)} FPS
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Active Models:</span>
                  <span className="font-mono text-purple-600">
                    {metrics.activeModels}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Power Usage:</span>
                  <span className="font-mono text-orange-600">
                    {metrics.powerConsumption.toFixed(0)}W
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  Generation Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span>Frames:</span>
                  <span className="font-mono text-blue-600">
                    {metrics.generatedFrames.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Audio Samples:</span>
                  <span className="font-mono text-green-600">
                    {metrics.generatedAudioSamples.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Disk Usage:</span>
                  <span className={`font-mono ${getMetricColor(metrics.diskUsage, 'usage')}`}>
                    {metrics.diskUsage.toFixed(1)}%
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="models" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {modelPerformance.map((model) => (
              <Card key={model.modelId}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{model.modelName}</CardTitle>
                    <Badge variant="outline" className={getStatusColor(model.status)}>
                      {model.status}
                    </Badge>
                  </div>
                  <CardDescription className="capitalize">{model.type} model</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-muted-foreground">CPU Usage</div>
                      <div className={`font-mono ${getMetricColor(model.cpuUsage, 'usage')}`}>
                        {model.cpuUsage.toFixed(1)}%
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Memory Usage</div>
                      <div className={`font-mono ${getMetricColor(model.memoryUsage, 'usage')}`}>
                        {model.memoryUsage.toFixed(1)}%
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Inference Time</div>
                      <div className="font-mono text-blue-600">
                        {model.inferenceTime.toFixed(1)}ms
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Requests/s</div>
                      <div className="font-mono text-green-600">
                        {model.requestsPerSecond.toFixed(0)}
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Last used: {new Date(model.lastUsed).toLocaleTimeString()}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <div className="space-y-3">
            {alerts.map((alert) => (
              <Card key={alert.id} className={getAlertColor(alert.type)}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <AlertTriangle className={`w-5 h-5 ${
                        alert.type === 'error' ? 'text-red-600' :
                        alert.type === 'warning' ? 'text-yellow-600' :
                        alert.type === 'info' ? 'text-blue-600' : 'text-green-600'
                      }`} />
                      <div>
                        <div className="font-medium">{alert.message}</div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(alert.timestamp).toLocaleString()}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={
                        alert.resolved ? 'border-green-500 text-green-600' : 'border-red-500 text-red-600'
                      }>
                        {alert.resolved ? 'Resolved' : 'Active'}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Resource Usage History</CardTitle>
              <CardDescription>Last 60 seconds of system metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">CPU Usage</span>
                    <span className="text-sm text-muted-foreground">
                      {metrics.cpuUsage.toFixed(1)}%
                    </span>
                  </div>
                  <div className="h-20 bg-gray-100 rounded-lg p-2">
                    <div className="flex items-end h-full gap-1">
                      {resourceHistory.cpu.map((value, index) => (
                        <div
                          key={index}
                          className="flex-1 bg-blue-500 rounded-sm"
                          style={{ height: `${value}%` }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Memory Usage</span>
                    <span className="text-sm text-muted-foreground">
                      {metrics.memoryUsage.toFixed(1)}%
                    </span>
                  </div>
                  <div className="h-20 bg-gray-100 rounded-lg p-2">
                    <div className="flex items-end h-full gap-1">
                      {resourceHistory.memory.map((value, index) => (
                        <div
                          key={index}
                          className="flex-1 bg-green-500 rounded-sm"
                          style={{ height: `${value}%` }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">GPU Usage</span>
                    <span className="text-sm text-muted-foreground">
                      {metrics.gpuUsage.toFixed(1)}%
                    </span>
                  </div>
                  <div className="h-20 bg-gray-100 rounded-lg p-2">
                    <div className="flex items-end h-full gap-1">
                      {resourceHistory.gpu.map((value, index) => (
                        <div
                          key={index}
                          className="flex-1 bg-purple-500 rounded-sm"
                          style={{ height: `${value}%` }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}