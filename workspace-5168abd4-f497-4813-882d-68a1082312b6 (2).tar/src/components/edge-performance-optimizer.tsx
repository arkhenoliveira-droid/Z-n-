'use client';

import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { 
  Zap, 
  Cpu, 
  MemoryStick, 
  Monitor, 
  Settings, 
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Activity,
  Wifi,
  HardDrive,
  CheckCircle,
  AlertTriangle,
  Play,
  Pause,
  Save,
  RotateCcw
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { EdgeOptimizer, createEdgeOptimizer, EdgeOptimizationConfig, PerformanceMetrics } from '@/lib/edge-optimization';

export default function EdgePerformanceOptimizer() {
  const [optimizer, setOptimizer] = useState<EdgeOptimizer | null>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [metrics, setMetrics] = useState<PerformanceMetrics[]>([]);
  const [currentMetrics, setCurrentMetrics] = useState<PerformanceMetrics | null>(null);
  const [config, setConfig] = useState<EdgeOptimizationConfig | null>(null);
  const [resourceAllocation, setResourceAllocation] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('overview');
  
  const metricsInterval = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Initialize edge optimizer
    const edgeOptimizer = createEdgeOptimizer({
      enableCaching: true,
      cacheSize: 1000,
      enableCompression: true,
      compressionLevel: 6,
      enableBatching: true,
      batchSize: 4,
      enableParallelProcessing: true,
      maxWorkers: navigator.hardwareConcurrency || 4,
      enableMemoryOptimization: true,
      memoryThreshold: 80,
      enableGPUScheduling: true,
      enableLazyLoading: true,
      enableAdaptiveQuality: true,
      qualityThreshold: 60
    });

    setOptimizer(edgeOptimizer);
    setConfig(edgeOptimizer.getConfig());
    setResourceAllocation(edgeOptimizer.getResourceAllocation());

    // Start metrics collection
    startMetricsCollection(edgeOptimizer);

    return () => {
      if (metricsInterval.current) {
        clearInterval(metricsInterval.current);
      }
      edgeOptimizer.destroy();
    };
  }, []);

  const startMetricsCollection = (opt: EdgeOptimizer) => {
    metricsInterval.current = setInterval(() => {
      const current = opt.getCurrentMetrics();
      const history = opt.getPerformanceMetrics();
      
      setCurrentMetrics(current);
      setMetrics(history);
    }, 1000);
  };

  const toggleOptimization = () => {
    setIsOptimizing(!isOptimizing);
    if (optimizer) {
      if (isOptimizing) {
        // Stop optimization
        optimizer.updateConfig({ enableAdaptiveQuality: false, enableMemoryOptimization: false });
      } else {
        // Start optimization
        optimizer.updateConfig({ enableAdaptiveQuality: true, enableMemoryOptimization: true });
      }
    }
  };

  const updateConfig = (newConfig: Partial<EdgeOptimizationConfig>) => {
    if (optimizer) {
      optimizer.updateConfig(newConfig);
      setConfig(optimizer.getConfig());
    }
  };

  const clearMetrics = () => {
    setMetrics([]);
  };

  const getMetricColor = (value: number, type: string) => {
    if (type === 'usage') {
      if (value < 50) return 'text-green-600';
      if (value < 80) return 'text-yellow-600';
      return 'text-red-600';
    }
    if (type === 'latency') {
      if (value < 10) return 'text-green-600';
      if (value < 50) return 'text-yellow-600';
      return 'text-red-600';
    }
    if (type === 'error') {
      if (value < 1) return 'text-green-600';
      if (value < 3) return 'text-yellow-600';
      return 'text-red-600';
    }
    return 'text-blue-600';
  };

  const getTrendIcon = (current: number, previous: number) => {
    if (!previous) return <Activity className="w-4 h-4 text-gray-500" />;
    const diff = current - previous;
    if (Math.abs(diff) < 0.1) return <Activity className="w-4 h-4 text-gray-500" />;
    if (diff > 0) return <TrendingUp className="w-4 h-4 text-red-500" />;
    return <TrendingDown className="w-4 h-4 text-green-500" />;
  };

  const formatBytes = (bytes: number) => {
    const sizes = ['B', 'KB', 'MB', 'GB'];
    if (bytes === 0) return '0 B';
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  };

  if (!optimizer || !config || !currentMetrics) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 animate-spin text-blue-600" />
        <span className="ml-2">Initializing Edge Optimizer...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Edge Performance Optimizer</h2>
          <p className="text-muted-foreground">Advanced optimization for edge computing and AI inference</p>
        </div>
        <div className="flex items-center gap-4">
          <Button
            onClick={toggleOptimization}
            className={`flex items-center gap-2 ${
              isOptimizing ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'
            }`}
          >
            {isOptimizing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {isOptimizing ? 'Stop Optimization' : 'Start Optimization'}
          </Button>
          <Badge variant="outline" className={isOptimizing ? 'border-green-500 text-green-600' : 'border-gray-500 text-gray-600'}>
            {isOptimizing ? <CheckCircle className="w-3 h-3 mr-1" /> : <AlertTriangle className="w-3 h-3 mr-1" />}
            {isOptimizing ? 'Optimizing' : 'Idle'}
          </Badge>
        </div>
      </div>

      {/* Real-time Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Cpu className="w-5 h-5 text-blue-600" />
                <div>
                  <div className={`text-lg font-bold ${getMetricColor(currentMetrics.cpuUsage, 'usage')}`}>
                    {currentMetrics.cpuUsage.toFixed(1)}%
                  </div>
                  <div className="text-xs text-muted-foreground">CPU Usage</div>
                </div>
              </div>
              {getTrendIcon(currentMetrics.cpuUsage, metrics.length > 1 ? metrics[metrics.length - 2].cpuUsage : 0)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <MemoryStick className="w-5 h-5 text-green-600" />
                <div>
                  <div className={`text-lg font-bold ${getMetricColor(currentMetrics.memoryUsage, 'usage')}`}>
                    {currentMetrics.memoryUsage.toFixed(1)}%
                  </div>
                  <div className="text-xs text-muted-foreground">Memory Usage</div>
                </div>
              </div>
              {getTrendIcon(currentMetrics.memoryUsage, metrics.length > 1 ? metrics[metrics.length - 2].memoryUsage : 0)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Monitor className="w-5 h-5 text-purple-600" />
                <div>
                  <div className={`text-lg font-bold ${getMetricColor(currentMetrics.gpuUsage, 'usage')}`}>
                    {currentMetrics.gpuUsage.toFixed(1)}%
                  </div>
                  <div className="text-xs text-muted-foreground">GPU Usage</div>
                </div>
              </div>
              {getTrendIcon(currentMetrics.gpuUsage, metrics.length > 1 ? metrics[metrics.length - 2].gpuUsage : 0)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Activity className="w-5 h-5 text-orange-600" />
                <div>
                  <div className={`text-lg font-bold ${getMetricColor(currentMetrics.latency, 'latency')}`}>
                    {currentMetrics.latency.toFixed(1)}ms
                  </div>
                  <div className="text-xs text-muted-foreground">Latency</div>
                </div>
              </div>
              {getTrendIcon(currentMetrics.latency, metrics.length > 1 ? metrics[metrics.length - 2].latency : 0)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Configuration */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="configuration">Configuration</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  Optimization Status
                </CardTitle>
                <CardDescription>Current optimization techniques and their effectiveness</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle className={`w-4 h-4 ${config.enableCaching ? 'text-green-600' : 'text-gray-400'}`} />
                      <span>Caching</span>
                    </div>
                    <Badge variant="outline" className={config.enableCaching ? 'border-green-500 text-green-600' : 'border-gray-500 text-gray-600'}>
                      {config.enableCaching ? 'Enabled' : 'Disabled'}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle className={`w-4 h-4 ${config.enableCompression ? 'text-green-600' : 'text-gray-400'}`} />
                      <span>Compression</span>
                    </div>
                    <Badge variant="outline" className={config.enableCompression ? 'border-green-500 text-green-600' : 'border-gray-500 text-gray-600'}>
                      {config.enableCompression ? 'Enabled' : 'Disabled'}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle className={`w-4 h-4 ${config.enableParallelProcessing ? 'text-green-600' : 'text-gray-400'}`} />
                      <span>Parallel Processing</span>
                    </div>
                    <Badge variant="outline" className={config.enableParallelProcessing ? 'border-green-500 text-green-600' : 'border-gray-500 text-gray-600'}>
                      {config.enableParallelProcessing ? 'Enabled' : 'Disabled'}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle className={`w-4 h-4 ${config.enableAdaptiveQuality ? 'text-green-600' : 'text-gray-400'}`} />
                      <span>Adaptive Quality</span>
                    </div>
                    <Badge variant="outline" className={config.enableAdaptiveQuality ? 'border-green-500 text-green-600' : 'border-gray-500 text-gray-600'}>
                      {config.enableAdaptiveQuality ? 'Enabled' : 'Disabled'}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle className={`w-4 h-4 ${config.enableMemoryOptimization ? 'text-green-600' : 'text-gray-400'}`} />
                      <span>Memory Optimization</span>
                    </div>
                    <Badge variant="outline" className={config.enableMemoryOptimization ? 'border-green-500 text-green-600' : 'border-gray-500 text-gray-600'}>
                      {config.enableMemoryOptimization ? 'Enabled' : 'Disabled'}
                    </Badge>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <div className="text-sm font-medium mb-2">Performance Impact</div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Cache Hit Rate:</span>
                      <span className="font-mono text-green-600">
                        {(currentMetrics.cacheHitRate * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Compression Ratio:</span>
                      <span className="font-mono text-blue-600">
                        {(currentMetrics.compressionRatio * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Error Rate:</span>
                      <span className={`font-mono ${getMetricColor(currentMetrics.errorRate, 'error')}`}>
                        {currentMetrics.errorRate.toFixed(2)}%
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  Live Metrics
                </CardTitle>
                <CardDescription>Real-time performance and resource utilization</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Inference Time</span>
                      <span className="text-sm font-mono">{currentMetrics.inferenceTime.toFixed(1)}ms</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full" 
                        style={{ width: `${Math.min(100, currentMetrics.inferenceTime / 50 * 100)}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Throughput</span>
                      <span className="text-sm font-mono">{currentMetrics.throughput.toFixed(0)} req/s</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-green-600 h-2 rounded-full" 
                        style={{ width: `${Math.min(100, currentMetrics.throughput / 1000 * 100)}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Network Latency</span>
                      <span className="text-sm font-mono">{currentMetrics.latency.toFixed(1)}ms</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-yellow-600 h-2 rounded-full" 
                        style={{ width: `${Math.min(100, currentMetrics.latency / 50 * 100)}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <div className="text-sm font-medium mb-2">System Status</div>
                  <div className="grid grid-cols-2 gap-2">
                    <Badge variant="outline" className="border-green-500 text-green-600 text-xs">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Edge Optimized
                    </Badge>
                    <Badge variant="outline" className="border-blue-500 text-blue-600 text-xs">
                      <Wifi className="w-3 h-3 mr-1" />
                      Low Latency
                    </Badge>
                    <Badge variant="outline" className="border-purple-500 text-purple-600 text-xs">
                      <Zap className="w-3 h-3 mr-1" />
                      High Performance
                    </Badge>
                    <Badge variant="outline" className="border-orange-500 text-orange-600 text-xs">
                      <Cpu className="w-3 h-3 mr-1" />
                      AI Accelerated
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="configuration" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Optimization Configuration</CardTitle>
              <CardDescription>Configure edge computing optimization parameters</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Cache Size: {config.cacheSize} entries
                  </label>
                  <Slider
                    value={[config.cacheSize]}
                    onValueChange={(value) => updateConfig({ cacheSize: value[0] })}
                    max={5000}
                    step={100}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Batch Size: {config.batchSize}
                  </label>
                  <Slider
                    value={[config.batchSize]}
                    onValueChange={(value) => updateConfig({ batchSize: value[0] })}
                    max={16}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Compression Level: {config.compressionLevel}
                  </label>
                  <Slider
                    value={[config.compressionLevel]}
                    onValueChange={(value) => updateConfig({ compressionLevel: value[0] })}
                    max={9}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Max Workers: {config.maxWorkers}
                  </label>
                  <Slider
                    value={[config.maxWorkers]}
                    onValueChange={(value) => updateConfig({ maxWorkers: value[0] })}
                    max={16}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Memory Threshold: {config.memoryThreshold}%
                  </label>
                  <Slider
                    value={[config.memoryThreshold]}
                    onValueChange={(value) => updateConfig({ memoryThreshold: value[0] })}
                    max={100}
                    step={5}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Quality Threshold: {config.qualityThreshold}%
                  </label>
                  <Slider
                    value={[config.qualityThreshold]}
                    onValueChange={(value) => updateConfig({ qualityThreshold: value[0] })}
                    max={100}
                    step={5}
                    className="w-full"
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={() => updateConfig(config)}>
                  <Save className="w-4 h-4 mr-1" />
                  Save Configuration
                </Button>
                <Button variant="outline" onClick={() => {
                  updateConfig({
                    enableCaching: true,
                    cacheSize: 1000,
                    enableCompression: true,
                    compressionLevel: 6,
                    enableBatching: true,
                    batchSize: 4,
                    enableParallelProcessing: true,
                    maxWorkers: navigator.hardwareConcurrency || 4,
                    enableMemoryOptimization: true,
                    memoryThreshold: 80,
                    enableGPUScheduling: true,
                    enableLazyLoading: true,
                    enableAdaptiveQuality: true,
                    qualityThreshold: 60
                  });
                }}>
                  <RotateCcw className="w-4 h-4 mr-1" />
                  Reset to Defaults
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="resources" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Resource Allocation</CardTitle>
              <CardDescription>System resources available for edge computing</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Cpu className="w-5 h-5 text-blue-600" />
                    <span className="font-medium">CPU Cores</span>
                  </div>
                  <div className="text-2xl font-bold text-blue-600">
                    {resourceAllocation.cpuCores}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Available for processing
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <MemoryStick className="w-5 h-5 text-green-600" />
                    <span className="font-medium">Memory</span>
                  </div>
                  <div className="text-2xl font-bold text-green-600">
                    {formatBytes(resourceAllocation.memoryMB * 1024 * 1024)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Available RAM
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Monitor className="w-5 h-5 text-purple-600" />
                    <span className="font-medium">GPU Memory</span>
                  </div>
                  <div className="text-2xl font-bold text-purple-600">
                    {formatBytes(resourceAllocation.gpuMemoryMB * 1024 * 1024)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Available VRAM
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Wifi className="w-5 h-5 text-orange-600" />
                    <span className="font-medium">Network</span>
                  </div>
                  <div className="text-2xl font-bold text-orange-600">
                    {resourceAllocation.networkBandwidthMBps} Mbps
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Available bandwidth
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <HardDrive className="w-5 h-5 text-red-600" />
                    <span className="font-medium">Disk Space</span>
                  </div>
                  <div className="text-2xl font-bold text-red-600">
                    {formatBytes(resourceAllocation.diskSpaceMB * 1024 * 1024)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Available storage
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-600" />
                    <span className="font-medium">Optimization</span>
                  </div>
                  <div className="text-2xl font-bold text-yellow-600">
                    {isOptimizing ? 'Active' : 'Idle'}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Current status
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Performance History</CardTitle>
                  <CardDescription>Historical performance metrics and trends</CardDescription>
                </div>
                <Button variant="outline" onClick={clearMetrics}>
                  <RotateCcw className="w-4 h-4 mr-1" />
                  Clear History
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">CPU Usage History</span>
                    <span className="text-sm text-muted-foreground">
                      {metrics.length} data points
                    </span>
                  </div>
                  <div className="h-32 bg-gray-100 rounded-lg p-2">
                    <div className="flex items-end h-full gap-1">
                      {metrics.slice(-30).map((metric, index) => (
                        <div
                          key={index}
                          className="flex-1 bg-blue-500 rounded-sm"
                          style={{ height: `${metric.cpuUsage}%` }}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Memory Usage History</span>
                    <span className="text-sm text-muted-foreground">
                      {metrics.length} data points
                    </span>
                  </div>
                  <div className="h-32 bg-gray-100 rounded-lg p-2">
                    <div className="flex items-end h-full gap-1">
                      {metrics.slice(-30).map((metric, index) => (
                        <div
                          key={index}
                          className="flex-1 bg-green-500 rounded-sm"
                          style={{ height: `${metric.memoryUsage}%` }}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Latency History</span>
                    <span className="text-sm text-muted-foreground">
                      {metrics.length} data points
                    </span>
                  </div>
                  <div className="h-32 bg-gray-100 rounded-lg p-2">
                    <div className="flex items-end h-full gap-1">
                      {metrics.slice(-30).map((metric, index) => (
                        <div
                          key={index}
                          className="flex-1 bg-yellow-500 rounded-sm"
                          style={{ height: `${Math.min(100, metric.latency * 2)}%` }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}