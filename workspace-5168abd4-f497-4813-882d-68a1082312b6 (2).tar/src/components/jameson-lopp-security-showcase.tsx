'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Shield, 
  Network, 
  Code, 
  BarChart3, 
  CheckCircle, 
  AlertTriangle,
  TrendingUp,
  Users,
  Database,
  Zap,
  Lock,
  Eye,
  Settings,
  Activity
} from 'lucide-react';
import { motion } from 'framer-motion';

interface Contribution {
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  category: string;
  year: string;
}

interface SecurityMetric {
  name: string;
  value: string;
  change: string;
  status: 'excellent' | 'good' | 'warning';
}

const contributions: Contribution[] = [
  {
    title: "Bitcoin Node Infrastructure",
    description: "Pioneering work in Bitcoin node operation and maintenance best practices",
    impact: "high",
    category: "Infrastructure",
    year: "2015-Present"
  },
  {
    title: "Security Monitoring Tools",
    description: "Development of comprehensive security monitoring and alerting systems",
    impact: "high",
    category: "Security",
    year: "2016-Present"
  },
  {
    title: "Node Performance Analytics",
    description: "Advanced analytics for measuring and optimizing Bitcoin node performance",
    impact: "medium",
    category: "Analytics",
    year: "2017-Present"
  },
  {
    title: "Network Health Monitoring",
    description: "Real-time monitoring of Bitcoin network health and connectivity",
    impact: "high",
    category: "Network",
    year: "2018-Present"
  },
  {
    title: "Security Best Practices",
    description: "Documentation and advocacy for Bitcoin security best practices",
    impact: "medium",
    category: "Education",
    year: "2015-Present"
  },
  {
    title: "Multi-Signature Solutions",
    description: "Promotion and implementation of multi-signature security solutions",
    impact: "medium",
    category: "Security",
    year: "2019-Present"
  }
];

const securityMetrics: SecurityMetric[] = [
  {
    name: "Node Uptime",
    value: "99.9%",
    change: "+0.1%",
    status: "excellent"
  },
  {
    name: "Security Score",
    value: "94/100",
    change: "+2",
    status: "excellent"
  },
  {
    name: "Network Health",
    value: "Excellent",
    change: "Stable",
    status: "excellent"
  },
  {
    name: "Threat Detection",
    value: "Active",
    change: "Improved",
    status: "good"
  },
  {
    name: "Response Time",
    value: "145ms",
    change: "-12ms",
    status: "excellent"
  },
  {
    name: "System Reliability",
    value: "99.8%",
    change: "+0.2%",
    status: "excellent"
  }
];

const bestPractices = [
  {
    icon: <Shield className="h-5 w-5" />,
    title: "Hardware Security",
    description: "Use hardware security modules for critical cryptographic operations"
  },
  {
    icon: <Lock className="h-5 w-5" />,
    title: "Multi-Signature",
    description: "Implement multi-signature schemes for enhanced security"
  },
  {
    icon: <Eye className="h-5 w-5" />,
    title: "Regular Audits",
    description: "Conduct regular security audits and penetration testing"
  },
  {
    icon: <Database className="h-5 w-5" />,
    title: "Backup Systems",
    description: "Maintain redundant backup systems and disaster recovery plans"
  },
  {
    icon: <Activity className="h-5 w-5" />,
    title: "Network Monitoring",
    description: "Continuous monitoring of network connectivity and performance"
  },
  {
    icon: <Settings className="h-5 w-5" />,
    title: "Software Updates",
    description: "Keep all software updated with latest security patches"
  }
];

export default function JamesonLoppSecurityShowcase() {
  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'text-green-600';
      case 'good': return 'text-blue-600';
      case 'warning': return 'text-yellow-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-2xl">
            <Shield className="h-8 w-8 text-blue-600" />
            Jameson Lopp's Bitcoin Security Contributions
          </CardTitle>
          <CardDescription className="text-base">
            A comprehensive overview of Jameson Lopp's significant contributions to Bitcoin security, 
            node operation, and network infrastructure. His work has been instrumental in establishing 
            best practices for Bitcoin node operation and security monitoring.
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="contributions" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="contributions">Key Contributions</TabsTrigger>
          <TabsTrigger value="metrics">Security Metrics</TabsTrigger>
          <TabsTrigger value="practices">Best Practices</TabsTrigger>
          <TabsTrigger value="impact">Industry Impact</TabsTrigger>
        </TabsList>

        <TabsContent value="contributions" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {contributions.map((contribution, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <CardTitle className="text-lg">{contribution.title}</CardTitle>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{contribution.category}</Badge>
                          <Badge className={getImpactColor(contribution.impact)}>
                            {contribution.impact} impact
                          </Badge>
                        </div>
                      </div>
                      <span className="text-sm text-muted-foreground">{contribution.year}</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      {contribution.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="metrics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {securityMetrics.map((metric, index) => (
              <Card key={index}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">{metric.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className={`text-2xl font-bold ${getStatusColor(metric.status)}`}>
                        {metric.value}
                      </span>
                      <TrendingUp className={`h-4 w-4 ${getStatusColor(metric.status)}`} />
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Change: {metric.change}
                    </div>
                    <Badge 
                      variant="outline" 
                      className={getStatusColor(metric.status)}
                    >
                      {metric.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="practices" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {bestPractices.map((practice, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                      {practice.icon}
                    </div>
                    {practice.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    {practice.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="impact" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Community Impact
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Educated thousands of node operators</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Improved network security standards</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Advanced monitoring practices</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Security tooling development</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Technical Impact
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Enhanced node reliability</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Improved security monitoring</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Network health optimization</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Performance metrics standardization</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-yellow-600" />
                Security Philosophy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm max-w-none">
                <p className="text-sm text-muted-foreground mb-3">
                  Jameson Lopp's approach to Bitcoin security emphasizes:
                </p>
                <ul className="space-y-2 text-sm">
                  <li><strong>Proactive Monitoring:</strong> Continuous surveillance of systems and networks</li>
                  <li><strong>Redundancy:</strong> Multiple layers of backup and failover systems</li>
                  <li><strong>Transparency:</strong> Open sharing of security findings and best practices</li>
                  <li><strong>Education:</strong> Empowering the community with security knowledge</li>
                  <li><strong>Innovation:</strong> Developing new tools and techniques for security enhancement</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}