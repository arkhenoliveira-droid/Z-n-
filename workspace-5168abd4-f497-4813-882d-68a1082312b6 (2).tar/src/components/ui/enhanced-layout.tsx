'use client'

import * as React from 'react'
import { cn } from '@/lib/utils'
import { designSystem } from '@/lib/design-system'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Menu, 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Home, 
  Settings, 
  User,
  Bell,
  Search,
  Moon,
  Sun
} from 'lucide-react'
import { Button } from '@/components/ui/enhanced-button'
import { Badge } from '@/components/ui/badge'

export interface EnhancedLayoutProps {
  children: React.ReactNode
  className?: string
  
  // Header
  header?: React.ReactNode
  headerHeight?: string
  headerSticky?: boolean
  
  // Sidebar
  sidebar?: React.ReactNode
  sidebarWidth?: string
  sidebarCollapsed?: boolean
  sidebarCollapsible?: boolean
  onSidebarCollapse?: (collapsed: boolean) => void
  
  // Footer
  footer?: React.ReactNode
  footerHeight?: string
  footerSticky?: boolean
  
  // Navigation
  navigation?: NavigationItem[]
  activeNavigation?: string
  onNavigationChange?: (item: string) => void
  
  // User menu
  user?: {
    name: string
    email: string
    avatar?: string
    menu?: React.ReactNode
  }
  
  // Notifications
  notifications?: NotificationItem[]
  unreadNotifications?: number
  
  // Search
  search?: {
    placeholder?: string
    onSearch?: (query: string) => void
  }
  
  // Theme
  theme?: 'light' | 'dark' | 'system'
  onThemeChange?: (theme: 'light' | 'dark' | 'system') => void
  
  // Loading
  loading?: boolean
  loadingContent?: React.ReactNode
  
  // Error
  error?: React.ReactNode
  
  // Layout variants
  variant?: 'default' | 'minimal' | 'dashboard' | 'auth'
  
  // Responsive
  responsive?: boolean
  mobileMenuOpen?: boolean
  onMobileMenuToggle?: (open: boolean) => void
}

export interface NavigationItem {
  id: string
  label: string
  icon?: React.ReactNode
  href?: string
  badge?: string | number
  children?: NavigationItem[]
  disabled?: boolean
}

export interface NotificationItem {
  id: string
  title: string
  message: string
  timestamp: Date
  read: boolean
  type?: 'info' | 'success' | 'warning' | 'error'
}

const layoutVariants = {
  default: 'bg-background text-foreground',
  minimal: 'bg-background text-foreground',
  dashboard: 'bg-slate-50 dark:bg-slate-900 text-foreground',
  auth: 'bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800 text-foreground'
}

export const EnhancedLayout: React.FC<EnhancedLayoutProps> = ({
  children,
  className,
  header,
  headerHeight = '64px',
  headerSticky = true,
  sidebar,
  sidebarWidth = '280px',
  sidebarCollapsed = false,
  sidebarCollapsible = true,
  onSidebarCollapse,
  navigation,
  activeNavigation,
  onNavigationChange,
  user,
  notifications = [],
  unreadNotifications = 0,
  search,
  theme = 'system',
  onThemeChange,
  loading = false,
  loadingContent,
  error,
  footer,
  footerHeight = '48px',
  footerSticky = false,
  variant = 'default',
  responsive = true,
  mobileMenuOpen = false,
  onMobileMenuToggle,
  ...props
}) => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = React.useState(sidebarCollapsed)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(mobileMenuOpen)
  const [currentTheme, setCurrentTheme] = React.useState(theme)
  const [showNotifications, setShowNotifications] = React.useState(false)
  const [showUserMenu, setShowUserMenu] = React.useState(false)

  React.useEffect(() => {
    setIsSidebarCollapsed(sidebarCollapsed)
  }, [sidebarCollapsed])

  React.useEffect(() => {
    setIsMobileMenuOpen(mobileMenuOpen)
  }, [mobileMenuOpen])

  React.useEffect(() => {
    setCurrentTheme(theme)
  }, [theme])

  const handleSidebarCollapse = (collapsed: boolean) => {
    setIsSidebarCollapsed(collapsed)
    onSidebarCollapse?.(collapsed)
  }

  const handleMobileMenuToggle = (open: boolean) => {
    setIsMobileMenuOpen(open)
    onMobileMenuToggle?.(open)
  }

  const handleThemeChange = (newTheme: 'light' | 'dark' | 'system') => {
    setCurrentTheme(newTheme)
    onThemeChange?.(newTheme)
  }

  const renderNavigation = (items: NavigationItem[], level = 0) => {
    return (
      <nav className={level === 0 ? 'space-y-1' : 'ml-4 space-y-1'}>
        {items.map((item) => (
          <div key={item.id}>
            <Button
              variant={activeNavigation === item.id ? 'default' : 'ghost'}
              className={cn(
                'w-full justify-start',
                activeNavigation === item.id && 'bg-primary text-primary-foreground',
                item.disabled && 'opacity-50 cursor-not-allowed'
              )}
              onClick={() => {
                if (!item.disabled && item.href) {
                  onNavigationChange?.(item.id)
                }
              }}
              disabled={item.disabled}
            >
              {item.icon && (
                <span className="mr-2">
                  {item.icon}
                </span>
              )}
              <span className="flex-1 text-left">{item.label}</span>
              {item.badge && (
                <Badge variant="secondary" className="ml-2">
                  {item.badge}
                </Badge>
              )}
            </Button>
            
            {item.children && (
              <div className="mt-1">
                {renderNavigation(item.children, level + 1)}
              </div>
            )}
          </div>
        ))}
      </nav>
    )
  }

  const renderHeader = () => {
    if (header) return header

    return (
      <header className={cn(
        'border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60',
        headerSticky && 'sticky top-0 z-40'
      )} style={{ height: headerHeight }}>
        <div className="flex items-center justify-between h-full px-4">
          {/* Left side */}
          <div className="flex items-center gap-4">
            {/* Mobile menu toggle */}
            {responsive && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleMobileMenuToggle(!isMobileMenuOpen)}
                className="md:hidden"
              >
                {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
              </Button>
            )}
            
            {/* Sidebar toggle */}
            {sidebar && sidebarCollapsible && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSidebarCollapse(!isSidebarCollapsed)}
                className="hidden md:flex"
              >
                {isSidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
              </Button>
            )}
            
            {/* Logo/Brand */}
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">Z</span>
              </div>
              <span className="font-semibold text-lg">Z.ai Code</span>
            </div>
          </div>
          
          {/* Center - Search */}
          <div className="flex-1 max-w-md mx-4">
            {search && (
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <input
                  type="text"
                  placeholder={search.placeholder || 'Search...'}
                  className="w-full pl-10 pr-4 py-2 rounded-md border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                  onChange={(e) => search.onSearch?.(e.target.value)}
                />
              </div>
            )}
          </div>
          
          {/* Right side */}
          <div className="flex items-center gap-2">
            {/* Theme toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleThemeChange(currentTheme === 'light' ? 'dark' : 'light')}
            >
              {currentTheme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </Button>
            
            {/* Notifications */}
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                <Bell className="w-4 h-4" />
                {unreadNotifications > 0 && (
                  <Badge variant="destructive" className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center text-xs">
                    {unreadNotifications}
                  </Badge>
                )}
              </Button>
              
              {/* Notifications dropdown */}
              <AnimatePresence>
                {showNotifications && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="absolute right-0 top-full mt-2 w-80 bg-background border border-border rounded-lg shadow-lg z-50"
                  >
                    <div className="p-4 border-b border-border">
                      <h3 className="font-semibold">Notifications</h3>
                    </div>
                    <div className="max-h-64 overflow-y-auto">
                      {notifications.length === 0 ? (
                        <div className="p-4 text-center text-muted-foreground">
                          No notifications
                        </div>
                      ) : (
                        notifications.map((notification) => (
                          <div
                            key={notification.id}
                            className={cn(
                              'p-4 border-b border-border hover:bg-muted/50 cursor-pointer',
                              !notification.read && 'bg-muted/30'
                            )}
                          >
                            <div className="flex items-start gap-2">
                              <div className="flex-1">
                                <h4 className="font-medium text-sm">{notification.title}</h4>
                                <p className="text-xs text-muted-foreground mt-1">{notification.message}</p>
                                <p className="text-xs text-muted-foreground mt-2">
                                  {new Date(notification.timestamp).toLocaleDateString()}
                                </p>
                              </div>
                              {!notification.read && (
                                <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0 mt-1" />
                              )}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            
            {/* User menu */}
            {user && (
              <div className="relative">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-2"
                >
                  {user.avatar ? (
                    <img src={user.avatar} alt={user.name} className="w-6 h-6 rounded-full" />
                  ) : (
                    <User className="w-4 h-4" />
                  )}
                  <span className="hidden md:inline text-sm">{user.name}</span>
                </Button>
                
                {/* User menu dropdown */}
                <AnimatePresence>
                  {showUserMenu && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="absolute right-0 top-full mt-2 w-64 bg-background border border-border rounded-lg shadow-lg z-50"
                    >
                      <div className="p-4 border-b border-border">
                        <div className="flex items-center gap-3">
                          {user.avatar ? (
                            <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full" />
                          ) : (
                            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                              <span className="text-primary-foreground font-bold">
                                {user.name.charAt(0).toUpperCase()}
                              </span>
                            </div>
                          )}
                          <div>
                            <h3 className="font-medium">{user.name}</h3>
                            <p className="text-sm text-muted-foreground">{user.email}</p>
                          </div>
                        </div>
                      </div>
                      {user.menu}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>
      </header>
    )
  }

  const renderSidebar = () => {
    if (!sidebar) return null

    return (
      <aside
        className={cn(
          'border-r border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60',
          'hidden md:block transition-all duration-200',
          isSidebarCollapsed ? 'w-16' : `w-[${sidebarWidth}]`
        )}
      >
        <div className="h-full flex flex-col">
          {/* Sidebar content */}
          <div className="flex-1 overflow-y-auto p-4">
            {navigation && renderNavigation(navigation)}
            {sidebar}
          </div>
          
          {/* Sidebar footer */}
          <div className="p-4 border-t border-border">
            <Button
              variant="ghost"
              size="sm"
              className="w-full justify-start"
            >
              <Settings className="w-4 h-4 mr-2" />
              {!isSidebarCollapsed && <span>Settings</span>}
            </Button>
          </div>
        </div>
      </aside>
    )
  }

  const renderMobileSidebar = () => {
    if (!sidebar || !responsive) return null

    return (
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-40 md:hidden"
              onClick={() => handleMobileMenuToggle(false)}
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              className="fixed left-0 top-0 bottom-0 w-64 bg-background border-r border-border z-50 md:hidden"
            >
              <div className="h-full flex flex-col">
                {/* Mobile sidebar header */}
                <div className="p-4 border-b border-border flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                      <span className="text-primary-foreground font-bold text-sm">Z</span>
                    </div>
                    <span className="font-semibold">Z.ai Code</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleMobileMenuToggle(false)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                
                {/* Mobile sidebar content */}
                <div className="flex-1 overflow-y-auto p-4">
                  {navigation && renderNavigation(navigation)}
                  {sidebar}
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    )
  }

  const renderFooter = () => {
    if (footer) return footer

    return (
      <footer className={cn(
        'border-t border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60',
        footerSticky && 'sticky bottom-0'
      )} style={{ height: footerHeight }}>
        <div className="flex items-center justify-between h-full px-4 text-sm text-muted-foreground">
          <div>© 2024 Z.ai Code. All rights reserved.</div>
          <div className="flex items-center gap-4">
            <a href="#" className="hover:text-foreground">Privacy</a>
            <a href="#" className="hover:text-foreground">Terms</a>
            <a href="#" className="hover:text-foreground">Contact</a>
          </div>
        </div>
      </footer>
    )
  }

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
            <p className="text-muted-foreground">
              {loadingContent || 'Loading...'}
            </p>
          </div>
        </div>
      )
    }

    if (error) {
      return (
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="text-4xl mb-2">⚠️</div>
            <h3 className="text-lg font-semibold mb-2">Something went wrong</h3>
            <p className="text-muted-foreground mb-4">{error}</p>
            <Button onClick={() => window.location.reload()}>
              Try Again
            </Button>
          </div>
        </div>
      )
    }

    return children
  }

  return (
    <div className={cn(
      'min-h-screen flex flex-col',
      layoutVariants[variant],
      className
    )} {...props}>
      {/* Header */}
      {renderHeader()}
      
      {/* Mobile sidebar */}
      {renderMobileSidebar()}
      
      {/* Main content area */}
      <div className="flex flex-1">
        {/* Desktop sidebar */}
        {renderSidebar()}
        
        {/* Main content */}
        <main className="flex-1 overflow-hidden">
          <div className="h-full overflow-y-auto">
            {renderContent()}
          </div>
        </main>
      </div>
      
      {/* Footer */}
      {renderFooter()}
    </div>
  )
}

EnhancedLayout.displayName = 'EnhancedLayout'

export default EnhancedLayout