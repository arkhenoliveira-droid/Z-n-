'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Loader2, Zap, Star, Heart, Sparkles } from 'lucide-react';

export interface PulsingButtonProps extends Omit<React.ComponentProps<"button">, 'children'> {
  children: React.ReactNode;
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  pulseVariant?: 'scale' | 'glow' | 'bounce' | 'rotate' | 'wave';
  pulseColor?: string;
  pulseIntensity?: 'subtle' | 'medium' | 'strong';
  pulseSpeed?: 'slow' | 'normal' | 'fast';
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  continuous?: boolean;
  pulseOnHover?: boolean;
}

const PulsingButton: React.FC<PulsingButtonProps> = ({
  children,
  pulseVariant = 'scale',
  pulseColor = 'rgba(0, 123, 255, 0.7)',
  pulseIntensity = 'medium',
  pulseSpeed = 'normal',
  icon,
  iconPosition = 'left',
  continuous = true,
  pulseOnHover = false,
  className,
  disabled,
  ...props
}) => {
  // Get animation keyframes based on variant
  const getAnimationKeyframes = () => {
    switch (pulseVariant) {
      case 'scale':
        return `
          @keyframes pulse-scale {
            0% { transform: scale(1); ${pulseIntensity === 'strong' ? 'box-shadow: 0 0 0 0 ' + pulseColor : ''}; }
            50% { transform: scale(${pulseIntensity === 'subtle' ? '1.02' : pulseIntensity === 'medium' ? '1.05' : '1.1'}); ${pulseIntensity === 'strong' ? 'box-shadow: 0 0 20px 10px rgba(0, 123, 255, 0)' : ''}; }
            100% { transform: scale(1); ${pulseIntensity === 'strong' ? 'box-shadow: 0 0 0 0 ' + pulseColor : ''}; }
          }
        `;
      case 'glow':
        return `
          @keyframes pulse-glow {
            0% { box-shadow: 0 0 5px 0 ${pulseColor}; }
            50% { box-shadow: 0 0 ${pulseIntensity === 'subtle' ? '10px' : pulseIntensity === 'medium' ? '20px' : '30px'} ${pulseIntensity === 'subtle' ? '2px' : pulseIntensity === 'medium' ? '5px' : '10px'} ${pulseColor}; }
            100% { box-shadow: 0 0 5px 0 ${pulseColor}; }
          }
        `;
      case 'bounce':
        return `
          @keyframes pulse-bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(${pulseIntensity === 'subtle' ? '-2px' : pulseIntensity === 'medium' ? '-5px' : '-10px'}); }
          }
        `;
      case 'rotate':
        return `
          @keyframes pulse-rotate {
            0% { transform: rotate(0deg); }
            25% { transform: rotate(${pulseIntensity === 'subtle' ? '1deg' : pulseIntensity === 'medium' ? '3deg' : '5deg'}); }
            75% { transform: rotate(${pulseIntensity === 'subtle' ? '-1deg' : pulseIntensity === 'medium' ? '-3deg' : '-5deg'}); }
            100% { transform: rotate(0deg); }
          }
        `;
      case 'wave':
        return `
          @keyframes pulse-wave {
            0% { border-radius: 5px; }
            25% { border-radius: ${pulseIntensity === 'subtle' ? '10px' : pulseIntensity === 'medium' ? '20px' : '30px'}; }
            50% { border-radius: 5px; }
            75% { border-radius: ${pulseIntensity === 'subtle' ? '10px' : pulseIntensity === 'medium' ? '20px' : '30px'}; }
            100% { border-radius: 5px; }
          }
        `;
      default:
        return '';
    }
  };

  // Get animation duration based on speed
  const getAnimationDuration = () => {
    switch (pulseSpeed) {
      case 'slow': return '3s';
      case 'fast': return '1s';
      default: return '2s';
    }
  };

  // Get animation class
  const getAnimationClass = () => {
    if (disabled) return '';
    
    const baseClass = continuous ? 'animate-infinite' : '';
    const animationName = `pulse-${pulseVariant}`;
    const duration = getAnimationDuration();
    
    return `${baseClass} ${animationName}`;
  };

  // Inject keyframes into the document
  React.useEffect(() => {
    const styleId = 'pulsing-button-animations';
    let styleElement = document.getElementById(styleId) as HTMLStyleElement;
    
    if (!styleElement) {
      styleElement = document.createElement('style');
      styleElement.id = styleId;
      document.head.appendChild(styleElement);
    }
    
    styleElement.textContent = getAnimationKeyframes();
    
    return () => {
      if (styleElement) {
        styleElement.remove();
      }
    };
  }, [pulseVariant, pulseColor, pulseIntensity]);

  const animationClass = getAnimationClass();
  const hoverClass = pulseOnHover ? 'hover:scale-105 hover:shadow-lg transition-all duration-200' : '';

  return (
    <>
      <style jsx>{`
        .${animationClass} {
          animation-duration: ${getAnimationDuration()};
          animation-timing-function: ease-in-out;
        }
      `}</style>
      
      <Button
        className={cn(
          animationClass,
          hoverClass,
          'relative overflow-hidden',
          className
        )}
        disabled={disabled}
        {...props}
      >
        {icon && iconPosition === 'left' && (
          <span className="mr-2">{icon}</span>
        )}
        {children}
        {icon && iconPosition === 'right' && (
          <span className="ml-2">{icon}</span>
        )}
      </Button>
    </>
  );
};

// Preset configurations for common use cases
export const PrimaryPulseButton: React.FC<Omit<PulsingButtonProps, 'pulseVariant' | 'pulseColor'>> = (props) => (
  <PulsingButton
    pulseVariant="scale"
    pulseColor="rgba(59, 130, 246, 0.5)"
    {...props}
  />
);

export const SuccessPulseButton: React.FC<Omit<PulsingButtonProps, 'pulseVariant' | 'pulseColor'>> = (props) => (
  <PulsingButton
    pulseVariant="glow"
    pulseColor="rgba(34, 197, 94, 0.5)"
    {...props}
  />
);

export const WarningPulseButton: React.FC<Omit<PulsingButtonProps, 'pulseVariant' | 'pulseColor'>> = (props) => (
  <PulsingButton
    pulseVariant="bounce"
    pulseColor="rgba(251, 191, 36, 0.5)"
    {...props}
  />
);

export const DangerPulseButton: React.FC<Omit<PulsingButtonProps, 'pulseVariant' | 'pulseColor'>> = (props) => (
  <PulsingButton
    pulseVariant="glow"
    pulseColor="rgba(239, 68, 68, 0.5)"
    {...props}
  />
);

export const MagicPulseButton: React.FC<Omit<PulsingButtonProps, 'pulseVariant' | 'pulseColor'>> = (props) => (
  <PulsingButton
    pulseVariant="wave"
    pulseColor="rgba(168, 85, 247, 0.5)"
    icon={<Sparkles className="w-4 h-4" />}
    {...props}
  />
);

export default PulsingButton;