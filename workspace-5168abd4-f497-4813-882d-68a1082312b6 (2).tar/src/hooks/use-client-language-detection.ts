'use client';

import { useState, useEffect } from 'react';
import { Language, supportedLanguages, defaultLanguage, languageNames, detectClientLanguage, getLanguageFromAcceptLanguage } from '../lib/language-detector-client';

export function useClientLanguageDetection() {
  const [currentLanguage, setCurrentLanguage] = useState<Language>(defaultLanguage);
  const [isDetecting, setIsDetecting] = useState(true);

  // Initialize language detection
  useEffect(() => {
    const detectedLanguage = detectClientLanguage();
    setCurrentLanguage(detectedLanguage);
    setIsDetecting(false);
  }, []);

  // Language preference management
  const setLanguagePreference = (language: Language): void => {
    try {
      localStorage.setItem('preferred-language', language);
      setCurrentLanguage(language);
    } catch (error) {
      console.warn('Failed to save language preference:', error);
    }
  };

  const getLanguagePreference = (): Language | null => {
    try {
      const stored = localStorage.getItem('preferred-language');
      return stored && supportedLanguages.includes(stored as Language) 
        ? stored as Language 
        : null;
    } catch (error) {
      console.warn('Failed to get language preference:', error);
      return null;
    }
  };

  const removeLanguagePreference = (): void => {
    try {
      localStorage.removeItem('preferred-language');
    } catch (error) {
      console.warn('Failed to remove language preference:', error);
    }
  };

  return {
    currentLanguage,
    isDetecting,
    setLanguage: setCurrentLanguage,
    setLanguagePreference,
    getLanguagePreference,
    removeLanguagePreference,
    languageNames,
    supportedLanguages,
    defaultLanguage
  };
}