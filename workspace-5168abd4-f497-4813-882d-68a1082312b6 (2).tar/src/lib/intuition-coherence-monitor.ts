/**
 * Intuition Coherence Monitoring System
 * 
 * This system provides comprehensive monitoring and analysis of intuition coherence
 * across multiple dimensions including quantum, neural, temporal, and spatial coherence.
 * 
 * Key Features:
 * - Real-time coherence monitoring
 * - Multi-dimensional coherence analysis
 * - Coherence trend prediction
 * - Coherence optimization recommendations
 * - Intuition quality assessment
 */

export interface IntuitionCoherenceState {
  quantumCoherence: number;
  neuralCoherence: number;
  temporalCoherence: number;
  spatialCoherence: number;
  emotionalCoherence: number;
  cognitiveCoherence: number;
  intuitiveCoherence: number;
  overallCoherence: number;
  coherenceStability: number;
  coherenceTrend: 'improving' | 'declining' | 'stable' | 'fluctuating';
}

export interface CoherenceDimension {
  name: string;
  value: number;
  target: number;
  threshold: number;
  stability: number;
  trend: 'improving' | 'declining' | 'stable';
  importance: number;
  description: string;
}

export interface CoherenceAlert {
  id: string;
  type: 'warning' | 'critical' | 'optimal' | 'improving';
  dimension: string;
  message: string;
  severity: number;
  timestamp: number;
  recommendation: string;
}

export interface CoherencePrediction {
  timeframe: string;
  predictedCoherence: number;
  confidence: number;
  factors: string[];
  recommendations: string[];
}

export interface IntuitionQualityMetrics {
  clarity: number;
  accuracy: number;
  reliability: number;
  depth: number;
  speed: number;
  adaptability: number;
  overallQuality: number;
}

export class IntuitionCoherenceMonitor {
  private coherenceState: IntuitionCoherenceState;
  private coherenceHistory: IntuitionCoherenceState[];
  private coherenceDimensions: Map<string, CoherenceDimension>;
  private activeAlerts: Map<string, CoherenceAlert>;
  private predictionModel: CoherencePredictionModel;
  private optimizationEngine: CoherenceOptimizationEngine;
  private qualityAssessor: IntuitionQualityAssessor;

  constructor() {
    this.coherenceState = this.initializeCoherenceState();
    this.coherenceHistory = [];
    this.coherenceDimensions = this.initializeCoherenceDimensions();
    this.activeAlerts = new Map();
    this.predictionModel = new CoherencePredictionModel();
    this.optimizationEngine = new CoherenceOptimizationEngine();
    this.qualityAssessor = new IntuitionQualityAssessor();
  }

  private initializeCoherenceState(): IntuitionCoherenceState {
    return {
      quantumCoherence: 0.75,
      neuralCoherence: 0.82,
      temporalCoherence: 0.68,
      spatialCoherence: 0.79,
      emotionalCoherence: 0.71,
      cognitiveCoherence: 0.85,
      intuitiveCoherence: 0.77,
      overallCoherence: 0.76,
      coherenceStability: 0.73,
      coherenceTrend: 'stable'
    };
  }

  private initializeCoherenceDimensions(): Map<string, CoherenceDimension> {
    const dimensions = new Map<string, CoherenceDimension>();

    dimensions.set('quantum', {
      name: 'Quantum Coherence',
      value: 0.75,
      target: 0.85,
      threshold: 0.65,
      stability: 0.8,
      trend: 'stable',
      importance: 0.9,
      description: 'Coherence of quantum intuition amplification systems'
    });

    dimensions.set('neural', {
      name: 'Neural Coherence',
      value: 0.82,
      target: 0.88,
      threshold: 0.70,
      stability: 0.85,
      trend: 'improving',
      importance: 0.95,
      description: 'Synchronization and coherence of neural intuition networks'
    });

    dimensions.set('temporal', {
      name: 'Temporal Coherence',
      value: 0.68,
      target: 0.80,
      threshold: 0.60,
      stability: 0.72,
      trend: 'stable',
      importance: 0.8,
      description: 'Consistency of intuition over time'
    });

    dimensions.set('spatial', {
      name: 'Spatial Coherence',
      value: 0.79,
      target: 0.85,
      threshold: 0.70,
      stability: 0.78,
      trend: 'improving',
      importance: 0.75,
      description: 'Spatial distribution and coherence of intuition patterns'
    });

    dimensions.set('emotional', {
      name: 'Emotional Coherence',
      value: 0.71,
      target: 0.82,
      threshold: 0.65,
      stability: 0.69,
      trend: 'stable',
      importance: 0.85,
      description: 'Emotional alignment and coherence in intuition processing'
    });

    dimensions.set('cognitive', {
      name: 'Cognitive Coherence',
      value: 0.85,
      target: 0.90,
      threshold: 0.75,
      stability: 0.88,
      trend: 'improving',
      importance: 0.9,
      description: 'Cognitive processing coherence and logical consistency'
    });

    dimensions.set('intuitive', {
      name: 'Intuitive Coherence',
      value: 0.77,
      target: 0.87,
      threshold: 0.68,
      stability: 0.75,
      trend: 'stable',
      importance: 1.0,
      description: 'Core intuitive coherence and insight quality'
    });

    return dimensions;
  }

  /**
   * Monitor intuition coherence in real-time
   */
  public monitorCoherence(): IntuitionCoherenceState {
    // Update coherence dimensions
    this.updateCoherenceDimensions();
    
    // Calculate overall coherence
    this.calculateOverallCoherence();
    
    // Analyze coherence trends
    this.analyzeCoherenceTrends();
    
    // Check for coherence alerts
    this.checkCoherenceAlerts();
    
    // Store in history
    this.storeCoherenceHistory();
    
    return this.coherenceState;
  }

  private updateCoherenceDimensions(): void {
    // Update each coherence dimension based on current state
    for (const [key, dimension] of this.coherenceDimensions) {
      // Simulate real-time coherence updates
      const fluctuation = (Math.random() - 0.5) * 0.02;
      const newValue = Math.max(0, Math.min(1, dimension.value + fluctuation));
      
      // Apply trend influence
      const trendInfluence = this.calculateTrendInfluence(dimension.trend);
      const finalValue = Math.max(0, Math.min(1, newValue + trendInfluence));
      
      // Update dimension
      dimension.value = finalValue;
      dimension.stability = this.calculateStability(dimension);
      
      // Update corresponding state field
      this.updateCoherenceStateField(key, finalValue);
    }
  }

  private calculateTrendInfluence(trend: string): number {
    switch (trend) {
      case 'improving': return 0.005;
      case 'declining': return -0.005;
      default: return 0;
    }
  }

  private calculateStability(dimension: CoherenceDimension): number {
    // Calculate stability based on recent value variations
    const historyLength = Math.min(10, this.coherenceHistory.length);
    if (historyLength < 2) return dimension.stability;
    
    let totalVariation = 0;
    for (let i = 1; i < historyLength; i++) {
      const current = this.coherenceHistory[i];
      const previous = this.coherenceHistory[i - 1];
      const variation = Math.abs(this.getCoherenceFieldValue(current, dimension.name) - 
                                 this.getCoherenceFieldValue(previous, dimension.name));
      totalVariation += variation;
    }
    
    const averageVariation = totalVariation / historyLength;
    const stability = Math.max(0, Math.min(1, 1 - averageVariation * 10));
    
    // Smooth stability changes
    return dimension.stability * 0.9 + stability * 0.1;
  }

  private getCoherenceFieldValue(state: IntuitionCoherenceState, dimensionName: string): number {
    switch (dimensionName) {
      case 'quantum': return state.quantumCoherence;
      case 'neural': return state.neuralCoherence;
      case 'temporal': return state.temporalCoherence;
      case 'spatial': return state.spatialCoherence;
      case 'emotional': return state.emotionalCoherence;
      case 'cognitive': return state.cognitiveCoherence;
      case 'intuitive': return state.intuitiveCoherence;
      default: return state.overallCoherence;
    }
  }

  private updateCoherenceStateField(key: string, value: number): void {
    switch (key) {
      case 'quantum': this.coherenceState.quantumCoherence = value; break;
      case 'neural': this.coherenceState.neuralCoherence = value; break;
      case 'temporal': this.coherenceState.temporalCoherence = value; break;
      case 'spatial': this.coherenceState.spatialCoherence = value; break;
      case 'emotional': this.coherenceState.emotionalCoherence = value; break;
      case 'cognitive': this.coherenceState.cognitiveCoherence = value; break;
      case 'intuitive': this.coherenceState.intuitiveCoherence = value; break;
    }
  }

  private calculateOverallCoherence(): void {
    // Calculate weighted overall coherence
    let weightedSum = 0;
    let totalWeight = 0;
    
    for (const [key, dimension] of this.coherenceDimensions) {
      weightedSum += dimension.value * dimension.importance;
      totalWeight += dimension.importance;
    }
    
    this.coherenceState.overallCoherence = totalWeight > 0 ? weightedSum / totalWeight : 0;
  }

  private analyzeCoherenceTrends(): void {
    if (this.coherenceHistory.length < 3) {
      this.coherenceState.coherenceTrend = 'stable';
      return;
    }
    
    // Analyze recent coherence values
    const recent = this.coherenceHistory.slice(-3);
    const values = recent.map(state => state.overallCoherence);
    
    // Calculate trend
    const trend = this.calculateTrend(values);
    this.coherenceState.coherenceTrend = trend;
    
    // Update dimension trends
    this.updateDimensionTrends();
    
    // Calculate stability
    this.coherenceState.coherenceStability = this.calculateOverallStability(values);
  }

  private calculateTrend(values: number[]): 'improving' | 'declining' | 'stable' | 'fluctuating' {
    if (values.length < 2) return 'stable';
    
    let improvements = 0;
    let declines = 0;
    
    for (let i = 1; i < values.length; i++) {
      if (values[i] > values[i - 1]) improvements++;
      else if (values[i] < values[i - 1]) declines++;
    }
    
    if (improvements > declines * 2) return 'improving';
    if (declines > improvements * 2) return 'declining';
    if (improvements === declines) return 'fluctuating';
    return 'stable';
  }

  private updateDimensionTrends(): void {
    for (const [key, dimension] of this.coherenceDimensions) {
      const historyValues = this.coherenceHistory.slice(-5).map(state => 
        this.getCoherenceFieldValue(state, dimension.name));
      
      if (historyValues.length >= 2) {
        dimension.trend = this.calculateTrend(historyValues);
      }
    }
  }

  private calculateOverallStability(values: number[]): number {
    if (values.length < 2) return 1;
    
    let totalVariation = 0;
    for (let i = 1; i < values.length; i++) {
      totalVariation += Math.abs(values[i] - values[i - 1]);
    }
    
    const averageVariation = totalVariation / (values.length - 1);
    return Math.max(0, Math.min(1, 1 - averageVariation * 5));
  }

  private checkCoherenceAlerts(): void {
    // Clear expired alerts
    this.clearExpiredAlerts();
    
    // Check each dimension for alerts
    for (const [key, dimension] of this.coherenceDimensions) {
      this.checkDimensionAlerts(key, dimension);
    }
    
    // Check overall coherence alerts
    this.checkOverallCoherenceAlerts();
  }

  private clearExpiredAlerts(): void {
    const currentTime = Date.now();
    const alertLifetime = 300000; // 5 minutes
    
    for (const [id, alert] of this.activeAlerts) {
      if (currentTime - alert.timestamp > alertLifetime) {
        this.activeAlerts.delete(id);
      }
    }
  }

  private checkDimensionAlerts(key: string, dimension: CoherenceDimension): void {
    const alertId = `dimension_${key}_${Date.now()}`;
    
    // Check for critical alerts
    if (dimension.value < dimension.threshold) {
      this.createAlert(alertId, 'critical', dimension.name, 
        `${dimension.name} is below threshold (${dimension.value.toFixed(2)} < ${dimension.threshold})`,
        0.9, `Consider immediate intervention for ${dimension.name.toLowerCase()}`);
    }
    
    // Check for warning alerts
    else if (dimension.value < dimension.threshold + 0.1) {
      this.createAlert(alertId, 'warning', dimension.name,
        `${dimension.name} is approaching threshold (${dimension.value.toFixed(2)})`,
        0.7, `Monitor ${dimension.name.toLowerCase()} closely and consider optimization`);
    }
    
    // Check for optimal performance
    else if (dimension.value > dimension.target) {
      this.createAlert(alertId, 'optimal', dimension.name,
        `${dimension.name} is performing optimally (${dimension.value.toFixed(2)})`,
        0.3, `Maintain current conditions for ${dimension.name.toLowerCase()}`);
    }
    
    // Check for improvement alerts
    else if (dimension.trend === 'improving' && dimension.stability > 0.8) {
      this.createAlert(alertId, 'improving', dimension.name,
        `${dimension.name} is showing consistent improvement`,
        0.2, `Continue current practices for ${dimension.name.toLowerCase()}`);
    }
  }

  private checkOverallCoherenceAlerts(): void {
    const alertId = `overall_${Date.now()}`;
    const overall = this.coherenceState.overallCoherence;
    
    if (overall < 0.6) {
      this.createAlert(alertId, 'critical', 'Overall Coherence',
        `Overall intuition coherence is critically low (${overall.toFixed(2)})`,
        1.0, 'Immediate system-wide coherence optimization required');
    } else if (overall < 0.7) {
      this.createAlert(alertId, 'warning', 'Overall Coherence',
        `Overall intuition coherence is below optimal (${overall.toFixed(2)})`,
        0.8, 'Consider comprehensive coherence optimization');
    } else if (overall > 0.9) {
      this.createAlert(alertId, 'optimal', 'Overall Coherence',
        `Overall intuition coherence is excellent (${overall.toFixed(2)})`,
        0.1, 'Maintain current optimal conditions');
    }
  }

  private createAlert(id: string, type: CoherenceAlert['type'], dimension: string, 
                      message: string, severity: number, recommendation: string): void {
    const alert: CoherenceAlert = {
      id,
      type,
      dimension,
      message,
      severity,
      timestamp: Date.now(),
      recommendation
    };
    
    this.activeAlerts.set(id, alert);
  }

  private storeCoherenceHistory(): void {
    this.coherenceHistory.push({ ...this.coherenceState });
    
    // Limit history size
    if (this.coherenceHistory.length > 100) {
      this.coherenceHistory.shift();
    }
  }

  /**
   * Get coherence predictions
   */
  public getCoherencePredictions(timeframe: string): CoherencePrediction {
    return this.predictionModel.predict(this.coherenceState, this.coherenceHistory, timeframe);
  }

  /**
   * Get coherence optimization recommendations
   */
  public getOptimizationRecommendations(): string[] {
    return this.optimizationEngine.getRecommendations(this.coherenceState, this.coherenceDimensions);
  }

  /**
   * Assess intuition quality
   */
  public assessIntuitionQuality(): IntuitionQualityMetrics {
    return this.qualityAssessor.assess(this.coherenceState, this.coherenceDimensions);
  }

  /**
   * Get current coherence state
   */
  public getCoherenceState(): IntuitionCoherenceState {
    return { ...this.coherenceState };
  }

  /**
   * Get coherence dimensions
   */
  public getCoherenceDimensions(): CoherenceDimension[] {
    return Array.from(this.coherenceDimensions.values());
  }

  /**
   * Get active alerts
   */
  public getActiveAlerts(): CoherenceAlert[] {
    return Array.from(this.activeAlerts.values());
  }

  /**
   * Get coherence history
   */
  public getCoherenceHistory(): IntuitionCoherenceState[] {
    return [...this.coherenceHistory];
  }

  /**
   * Reset coherence monitor
   */
  public reset(): void {
    this.coherenceState = this.initializeCoherenceState();
    this.coherenceHistory = [];
    this.coherenceDimensions = this.initializeCoherenceDimensions();
    this.activeAlerts.clear();
  }
}

/**
 * Coherence Prediction Model
 */
class CoherencePredictionModel {
  public predict(currentState: IntuitionCoherenceState, 
                history: IntuitionCoherenceState[], 
                timeframe: string): CoherencePrediction {
    
    // Calculate prediction based on historical trends
    const trend = this.analyzeHistoricalTrend(history);
    const seasonality = this.calculateSeasonality();
    const factors = this.identifyInfluencingFactors(currentState, history);
    
    // Calculate predicted coherence
    const basePrediction = currentState.overallCoherence + trend;
    const seasonalAdjustment = seasonality * 0.1;
    const factorAdjustment = factors.reduce((sum, factor) => sum + factor.impact, 0) * 0.05;
    
    const predictedCoherence = Math.max(0, Math.min(1, 
      basePrediction + seasonalAdjustment + factorAdjustment));
    
    // Calculate confidence based on trend stability
    const confidence = this.calculateConfidence(history, trend);
    
    // Generate recommendations
    const recommendations = this.generateRecommendations(predictedCoherence, factors);
    
    return {
      timeframe,
      predictedCoherence,
      confidence,
      factors: factors.map(f => f.name),
      recommendations
    };
  }

  private analyzeHistoricalTrend(history: IntuitionCoherenceState[]): number {
    if (history.length < 2) return 0;
    
    const recent = history.slice(-10);
    let totalChange = 0;
    
    for (let i = 1; i < recent.length; i++) {
      totalChange += recent[i].overallCoherence - recent[i - 1].overallCoherence;
    }
    
    return totalChange / (recent.length - 1);
  }

  private calculateSeasonality(): number {
    // Simple seasonality based on time of day
    const hour = new Date().getHours();
    if (hour >= 9 && hour <= 11) return 0.1; // Morning peak
    if (hour >= 14 && hour <= 16) return 0.08; // Afternoon peak
    if (hour >= 22 || hour <= 6) return -0.05; // Night dip
    return 0;
  }

  private identifyInfluencingFactors(currentState: IntuitionCoherenceState, 
                                    history: IntuitionCoherenceState[]): Array<{name: string, impact: number}> {
    const factors: Array<{name: string, impact: number}> = [];
    
    // Analyze each dimension's influence
    const dimensions = ['quantumCoherence', 'neuralCoherence', 'temporalCoherence', 
                       'spatialCoherence', 'emotionalCoherence', 'cognitiveCoherence', 'intuitiveCoherence'];
    
    for (const dim of dimensions) {
      const currentValue = currentState[dim as keyof IntuitionCoherenceState] as number;
      const target = 0.85; // General target
      const impact = (currentValue - target) * 0.1;
      
      factors.push({
        name: dim.replace('Coherence', '').replace(/([A-Z])/g, ' $1').trim(),
        impact
      });
    }
    
    return factors;
  }

  private calculateConfidence(history: IntuitionCoherenceState[], trend: number): number {
    if (history.length < 5) return 0.5;
    
    const recent = history.slice(-10);
    const variations: number[] = [];
    
    for (let i = 1; i < recent.length; i++) {
      variations.push(Math.abs(recent[i].overallCoherence - recent[i - 1].overallCoherence));
    }
    
    const averageVariation = variations.reduce((sum, v) => sum + v, 0) / variations.length;
    const stability = Math.max(0, 1 - averageVariation * 5);
    
    // Higher confidence for stable trends
    const trendConfidence = Math.abs(trend) < 0.01 ? 0.9 : 0.7;
    
    return (stability + trendConfidence) / 2;
  }

  private generateRecommendations(predictedCoherence: number, factors: Array<{name: string, impact: number}>): string[] {
    const recommendations: string[] = [];
    
    if (predictedCoherence < 0.7) {
      recommendations.push('Implement comprehensive coherence optimization');
      recommendations.push('Focus on dimensions with negative impact');
    } else if (predictedCoherence < 0.8) {
      recommendations.push('Continue current coherence practices');
      recommendations.push('Monitor dimensions showing declining trends');
    } else {
      recommendations.push('Maintain current optimal conditions');
      recommendations.push('Consider advanced coherence enhancement techniques');
    }
    
    // Add specific recommendations based on factors
    const negativeFactors = factors.filter(f => f.impact < 0);
    if (negativeFactors.length > 0) {
      recommendations.push(`Address declining ${negativeFactors.map(f => f.name).join(', ')} coherence`);
    }
    
    return recommendations;
  }
}

/**
 * Coherence Optimization Engine
 */
class CoherenceOptimizationEngine {
  public getRecommendations(state: IntuitionCoherenceState, 
                          dimensions: Map<string, CoherenceDimension>): string[] {
    const recommendations: string[] = [];
    
    // Analyze each dimension
    for (const [key, dimension] of dimensions) {
      const recs = this.getDimensionRecommendations(key, dimension);
      recommendations.push(...recs);
    }
    
    // Add overall coherence recommendations
    const overallRecs = this.getOverallRecommendations(state);
    recommendations.push(...overallRecs);
    
    // Prioritize recommendations
    return this.prioritizeRecommendations(recommendations);
  }

  private getDimensionRecommendations(key: string, dimension: CoherenceDimension): string[] {
    const recommendations: string[] = [];
    
    if (dimension.value < dimension.threshold) {
      recommendations.push(`Critical: Immediate intervention needed for ${dimension.name.toLowerCase()}`);
    } else if (dimension.value < dimension.target) {
      recommendations.push(`Optimize ${dimension.name.toLowerCase()} to reach target level`);
    }
    
    if (dimension.stability < 0.6) {
      recommendations.push(`Improve stability of ${dimension.name.toLowerCase()}`);
    }
    
    if (dimension.trend === 'declining') {
      recommendations.push(`Reverse declining trend in ${dimension.name.toLowerCase()}`);
    }
    
    return recommendations;
  }

  private getOverallRecommendations(state: IntuitionCoherenceState): string[] {
    const recommendations: string[] = [];
    
    if (state.overallCoherence < 0.7) {
      recommendations.push('Implement system-wide coherence optimization');
    } else if (state.overallCoherence < 0.8) {
      recommendations.push('Continue current coherence enhancement practices');
    } else {
      recommendations.push('Maintain optimal coherence conditions');
    }
    
    if (state.coherenceStability < 0.7) {
      recommendations.push('Improve overall coherence stability');
    }
    
    if (state.coherenceTrend === 'declining') {
      recommendations.push('Address declining coherence trend immediately');
    }
    
    return recommendations;
  }

  private prioritizeRecommendations(recommendations: string[]): string[] {
    // Simple prioritization based on keywords
    const priorityOrder = [
      'Critical:', 'Immediate', 'system-wide', 'declining', 'Optimize', 'Improve', 'Continue', 'Maintain'
    ];
    
    return recommendations.sort((a, b) => {
      const aPriority = priorityOrder.findIndex(keyword => a.includes(keyword));
      const bPriority = priorityOrder.findIndex(keyword => b.includes(keyword));
      
      if (aPriority === -1 && bPriority === -1) return 0;
      if (aPriority === -1) return 1;
      if (bPriority === -1) return -1;
      
      return aPriority - bPriority;
    });
  }
}

/**
 * Intuition Quality Assessor
 */
class IntuitionQualityAssessor {
  public assess(state: IntuitionCoherenceState, 
                dimensions: Map<string, CoherenceDimension>): IntuitionQualityMetrics {
    
    const clarity = this.calculateClarity(state, dimensions);
    const accuracy = this.calculateAccuracy(state, dimensions);
    const reliability = this.calculateReliability(state, dimensions);
    const depth = this.calculateDepth(state, dimensions);
    const speed = this.calculateSpeed(state, dimensions);
    const adaptability = this.calculateAdaptability(state, dimensions);
    
    const overallQuality = (clarity + accuracy + reliability + depth + speed + adaptability) / 6;
    
    return {
      clarity,
      accuracy,
      reliability,
      depth,
      speed,
      adaptability,
      overallQuality
    };
  }

  private calculateClarity(state: IntuitionCoherenceState, dimensions: Map<string, CoherenceDimension>): number {
    const cognitive = dimensions.get('cognitive')?.value || 0;
    const neural = dimensions.get('neural')?.value || 0;
    return (cognitive + neural) / 2;
  }

  private calculateAccuracy(state: IntuitionCoherenceState, dimensions: Map<string, CoherenceDimension>): number {
    const quantum = dimensions.get('quantum')?.value || 0;
    const temporal = dimensions.get('temporal')?.value || 0;
    return (quantum + temporal) / 2;
  }

  private calculateReliability(state: IntuitionCoherenceState, dimensions: Map<string, CoherenceDimension>): number {
    const spatial = dimensions.get('spatial')?.value || 0;
    const intuitive = dimensions.get('intuitive')?.value || 0;
    return (spatial + intuitive) / 2;
  }

  private calculateDepth(state: IntuitionCoherenceState, dimensions: Map<string, CoherenceDimension>): number {
    const emotional = dimensions.get('emotional')?.value || 0;
    const cognitive = dimensions.get('cognitive')?.value || 0;
    return (emotional + cognitive) / 2;
  }

  private calculateSpeed(state: IntuitionCoherenceState, dimensions: Map<string, CoherenceDimension>): number {
    const neural = dimensions.get('neural')?.value || 0;
    const quantum = dimensions.get('quantum')?.value || 0;
    return (neural + quantum) / 2;
  }

  private calculateAdaptability(state: IntuitionCoherenceState, dimensions: Map<string, CoherenceDimension>): number {
    const temporal = dimensions.get('temporal')?.value || 0;
    const spatial = dimensions.get('spatial')?.value || 0;
    return (temporal + spatial) / 2;
  }
}