'use client';

import { useState, useEffect } from 'react';

export type Language = 'pt' | 'en' | 'es';

export const supportedLanguages: Language[] = ['pt', 'en', 'es'];

export const defaultLanguage: Language = 'en';

export const languageNames = {
  pt: 'Português',
  en: 'English',
  es: 'Español'
};

// Enhanced language detection with better parsing
export function getLanguageFromAcceptLanguage(acceptLanguage: string | null): Language {
  if (!acceptLanguage) return defaultLanguage;
  
  try {
    const languages = acceptLanguage
      .split(',')
      .map(lang => {
        const [language, quality] = lang.trim().split(';');
        const q = quality ? parseFloat(quality.replace('q=', '')) : 1.0;
        const normalizedLanguage = language.toLowerCase();
        return { language: normalizedLanguage, quality: q };
      })
      .sort((a, b) => b.quality - a.quality);

    for (const { language } of languages) {
      // Check exact match first
      if (supportedLanguages.includes(language as Language)) {
        return language as Language;
      }
      
      // Check primary language (e.g., 'en' from 'en-US')
      const primaryLanguage = language.split('-')[0];
      if (supportedLanguages.includes(primaryLanguage as Language)) {
        return primaryLanguage as Language;
      }
      
      // Check for specific dialects
      if (language.startsWith('pt-')) return 'pt';
      if (language.startsWith('es-')) return 'es';
      if (language.startsWith('en-')) return 'en';
    }
  } catch (error) {
    console.warn('Error parsing Accept-Language header:', error);
  }
  
  return defaultLanguage;
}

// Client-side language detection
export function detectClientLanguage(): Language {
  try {
    const browserLanguage = navigator.language || navigator.languages?.[0];
    if (browserLanguage) {
      return getLanguageFromAcceptLanguage(browserLanguage);
    }
    
    // Try navigator.languages array
    if (navigator.languages && navigator.languages.length > 0) {
      for (const lang of navigator.languages) {
        const detected = getLanguageFromAcceptLanguage(lang);
        if (detected !== defaultLanguage) {
          return detected;
        }
      }
    }
    
    return defaultLanguage;
  } catch (error) {
    console.warn('Client language detection failed:', error);
    return defaultLanguage;
  }
}

// URL language extraction with validation
export function getLanguageFromURL(pathname: string): Language | null {
  try {
    const segments = pathname.split('/').filter(Boolean);
    if (segments.length > 0 && supportedLanguages.includes(segments[0] as Language)) {
      return segments[0] as Language;
    }
  } catch (error) {
    console.warn('Error extracting language from URL:', error);
  }
  return null;
}

// URL generation with validation
export function createLocalizedUrl(pathname: string, language: Language): string {
  try {
    const segments = pathname.split('/').filter(Boolean);
    
    // Remove existing language prefix if present
    if (segments.length > 0 && supportedLanguages.includes(segments[0] as Language)) {
      segments.shift();
    }
    
    // Validate language
    if (!supportedLanguages.includes(language)) {
      language = defaultLanguage;
    }
    
    // Add new language prefix
    return `/${language}/${segments.join('/')}`;
  } catch (error) {
    console.warn('Error creating localized URL:', error);
    return pathname;
  }
}

// Path manipulation with error handling
export function removeLanguageFromPath(pathname: string): string {
  try {
    const segments = pathname.split('/').filter(Boolean);
    if (segments.length > 0 && supportedLanguages.includes(segments[0] as Language)) {
      segments.shift();
    }
    return `/${segments.join('/')}`;
  } catch (error) {
    console.warn('Error removing language from path:', error);
    return pathname;
  }
}

// Language validation utilities
export const languageUtils = {
  isValid: (lang: string): lang is Language => {
    return supportedLanguages.includes(lang as Language);
  },
  
  normalize: (lang: string): Language => {
    return languageUtils.isValid(lang) ? lang : defaultLanguage;
  },
  
  getFallback: (requested: string): Language => {
    const primary = requested.split('-')[0];
    return languageUtils.isValid(primary) ? primary : defaultLanguage;
  },
  
  getAll: (): Array<{ code: Language; name: string }> => {
    return supportedLanguages.map(code => ({
      code,
      name: languageNames[code]
    }));
  }
};

// Language preference management (client-side only)
export const languagePreferences = {
  set: (language: Language): void => {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('preferred-language', language);
      } catch (error) {
        console.warn('Failed to save language preference:', error);
      }
    }
  },
  
  get: (): Language | null => {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem('preferred-language');
        return stored && supportedLanguages.includes(stored as Language) 
          ? stored as Language 
          : null;
      } catch (error) {
        console.warn('Failed to get language preference:', error);
      }
    }
    return null;
  },
  
  remove: (): void => {
    if (typeof window !== 'undefined') {
      try {
        localStorage.removeItem('preferred-language');
      } catch (error) {
        console.warn('Failed to remove language preference:', error);
      }
    }
  }
};

// React hook for language detection
export function useLanguageDetection() {
  const [currentLanguage, setCurrentLanguage] = useState<Language>(defaultLanguage);
  const [isDetecting, setIsDetecting] = useState(true);

  useEffect(() => {
    const detectLanguage = async () => {
      setIsDetecting(true);
      
      try {
        // Check URL first
        const urlLanguage = getLanguageFromURL(window.location.pathname);
        if (urlLanguage) {
          setCurrentLanguage(urlLanguage);
          setIsDetecting(false);
          return;
        }

        // Check localStorage preference
        const preferredLanguage = languagePreferences.get();
        if (preferredLanguage) {
          setCurrentLanguage(preferredLanguage);
          setIsDetecting(false);
          return;
        }

        // Detect from browser
        const detectedLanguage = detectClientLanguage();
        setCurrentLanguage(detectedLanguage);
        
        // Save as preference
        languagePreferences.set(detectedLanguage);
      } catch (error) {
        console.warn('Language detection failed:', error);
        setCurrentLanguage(defaultLanguage);
      } finally {
        setIsDetecting(false);
      }
    };

    detectLanguage();
  }, []);

  return {
    currentLanguage,
    isDetecting,
    setLanguage: (language: Language) => {
      setCurrentLanguage(language);
      languagePreferences.set(language);
    }
  };
}