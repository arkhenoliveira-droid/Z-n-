// Server-side language constants and utilities
// This file contains only server-compatible code (no client-side dependencies)

export type Language = 'pt' | 'en' | 'es';

export const supportedLanguages: Language[] = ['pt', 'en', 'es'];

export const defaultLanguage: Language = 'en';

export const languageNames = {
  pt: 'Português',
  en: 'English',
  es: 'Español'
};

// Server-side language validation utilities
export const languageUtils = {
  isValid: (lang: string): lang is Language => {
    return supportedLanguages.includes(lang as Language);
  },
  
  normalize: (lang: string): Language => {
    return languageUtils.isValid(lang) ? lang : defaultLanguage;
  },
  
  getFallback: (requested: string): Language => {
    const primary = requested.split('-')[0];
    return languageUtils.isValid(primary) ? primary : defaultLanguage;
  },
  
  getAll: (): Array<{ code: Language; name: string }> => {
    return supportedLanguages.map(code => ({
      code,
      name: languageNames[code]
    }));
  }
};

// Server-side URL utilities (no window/document dependencies)
export function getLanguageFromURL(pathname: string): Language | null {
  try {
    const segments = pathname.split('/').filter(Boolean);
    if (segments.length > 0 && supportedLanguages.includes(segments[0] as Language)) {
      return segments[0] as Language;
    }
  } catch (error) {
    console.warn('Error extracting language from URL:', error);
  }
  return null;
}

export function removeLanguageFromPath(pathname: string): string {
  try {
    const segments = pathname.split('/').filter(Boolean);
    if (segments.length > 0 && supportedLanguages.includes(segments[0] as Language)) {
      segments.shift();
    }
    return `/${segments.join('/')}`;
  } catch (error) {
    console.warn('Error removing language from path:', error);
    return pathname;
  }
}

export function createLocalizedUrl(pathname: string, language: Language): string {
  try {
    const segments = pathname.split('/').filter(Boolean);
    
    // Remove existing language prefix if present
    if (segments.length > 0 && supportedLanguages.includes(segments[0] as Language)) {
      segments.shift();
    }
    
    // Validate language
    if (!supportedLanguages.includes(language)) {
      language = defaultLanguage;
    }
    
    // Add new language prefix
    return `/${language}/${segments.join('/')}`;
  } catch (error) {
    console.warn('Error creating localized URL:', error);
    return pathname;
  }
}