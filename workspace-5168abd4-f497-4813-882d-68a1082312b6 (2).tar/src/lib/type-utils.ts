/**
 * TypeScript Coherence Utilities - Type Safety and Validation System
 * Utilitários de Coerência TypeScript - Sistema de Segurança Tipológica e Validação
 * 
 * This file provides comprehensive type safety utilities, validation frameworks,
 * and coherence management tools as requested in the priority task:
 * "Aprimore 'TypeScript' sob a perspectiva da coerência"
 */

import { z } from 'zod';
import {
  CoherentBase,
  ValidatableCoherence,
  EvolvableCoherence,
  CoherenceValidationResult,
  CoherenceIssue,
  CoherenceIssueType,
  CoherenceSeverity,
  CoherenceOptimizationResult,
  OptimizationChange,
  CoherenceLevel,
  CoherenceThresholds,
  DEFAULT_COHERENCE_THRESHOLDS,
  QuantumCoherenceState,
  QuantumCoherenceParameters,
  SystemCoherenceStatus,
  ComponentCoherence,
  CoherenceMetrics,
  CoherenceTrend,
  TrendDirection,
  isCoherentBase,
  isValidatableCoherence,
  isEvolvableCoherence,
  CoherentBaseSchema,
  CoherenceValidationResultSchema
} from '@/types';

// ============ TYPE GUARDS CLASS ============

/**
 * Comprehensive type guards for runtime type safety
 * Type guards abrangentes para segurança tipológica em tempo de execução
 */
export class TypeGuards {
  /**
   * Enhanced type guard for CoherentBase with validation
   * Type guard aprimorado para CoherentBase com validação
   */
  static isCoherentBase(obj: unknown): obj is CoherentBase {
    if (!isCoherentBase(obj)) return false;
    
    // Additional validation
    if (obj.coherenceScore < 0 || obj.coherenceScore > 1) {
      return false;
    }
    
    if (obj.timestamp <= 0) {
      return false;
    }
    
    return true;
  }

  /**
   * Enhanced type guard for ValidatableCoherence
   * Type guard aprimorado para ValidatableCoherence
   */
  static isValidatableCoherence(obj: unknown): obj is ValidatableCoherence {
    if (!isValidatableCoherence(obj)) return false;
    
    // Test the methods
    try {
      const validationResult = obj.validateCoherence();
      if (!this.isCoherenceValidationResult(validationResult)) {
        return false;
      }
      
      const optimizationResult = obj.optimizeCoherence();
      if (!this.isCoherenceOptimizationResult(optimizationResult)) {
        return false;
      }
      
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Enhanced type guard for EvolvableCoherence
   * Type guard aprimorado para EvolvableCoherence
   */
  static isEvolvableCoherence(obj: unknown): obj is EvolvableCoherence {
    if (!isEvolvableCoherence(obj)) return false;
    
    // Test the methods
    try {
      const adaptationInput = this.createTestAdaptationInput();
      const adaptationResult = obj.adapt(adaptationInput);
      if (!this.isAdaptationResult(adaptationResult)) {
        return false;
      }
      
      const evolutionResult = obj.evolve();
      if (!this.isEvolutionResult(evolutionResult)) {
        return false;
      }
      
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Type guard for CoherenceValidationResult
   * Type guard para CoherenceValidationResult
   */
  static isCoherenceValidationResult(obj: unknown): obj is CoherenceValidationResult {
    try {
      return CoherenceValidationResultSchema.parse(obj);
    } catch {
      return false;
    }
  }

  /**
   * Type guard for CoherenceOptimizationResult
   * Type guard para CoherenceOptimizationResult
   */
  static isCoherenceOptimizationResult(obj: unknown): obj is CoherenceOptimizationResult {
    return typeof obj === 'object' && obj !== null &&
      'originalScore' in obj && typeof obj.originalScore === 'number' &&
      'optimizedScore' in obj && typeof obj.optimizedScore === 'number' &&
      'improvements' in obj && Array.isArray(obj.improvements) &&
      'changes' in obj && Array.isArray(obj.changes) &&
      'estimatedImpact' in obj && typeof obj.estimatedImpact === 'number';
  }

  /**
   * Type guard for AdaptationResult
   * Type guard para AdaptationResult
   */
  static isAdaptationResult(obj: unknown): obj is any {
    return typeof obj === 'object' && obj !== null &&
      'success' in obj && typeof obj.success === 'boolean' &&
      'changes' in obj && Array.isArray(obj.changes) &&
      'metrics' in obj && Array.isArray(obj.metrics) &&
      'confidence' in obj && typeof obj.confidence === 'number';
  }

  /**
   * Type guard for EvolutionResult
   * Type guard para EvolutionResult
   */
  static isEvolutionResult(obj: unknown): obj is any {
    return typeof obj === 'object' && obj !== null &&
      'newStage' in obj && typeof obj.newStage === 'string' &&
      'capabilities' in obj && Array.isArray(obj.capabilities) &&
      'improvements' in obj && Array.isArray(obj.improvements) &&
      'coherenceGain' in obj && typeof obj.coherenceGain === 'number';
  }

  /**
   * Type guard for SystemCoherenceStatus
   * Type guard para SystemCoherenceStatus
   */
  static isSystemCoherenceStatus(obj: unknown): obj is SystemCoherenceStatus {
    return typeof obj === 'object' && obj !== null &&
      'overall' in obj && Object.values(CoherenceLevel).includes(obj.overall as CoherenceLevel) &&
      'components' in obj && Array.isArray(obj.components) &&
      'metrics' in obj && typeof obj.metrics === 'object' &&
      'recommendations' in obj && Array.isArray(obj.recommendations);
  }

  /**
   * Type guard for ComponentCoherence
   * Type guard para ComponentCoherence
   */
  static isComponentCoherence(obj: unknown): obj is ComponentCoherence {
    return typeof obj === 'object' && obj !== null &&
      'id' in obj && typeof obj.id === 'string' &&
      'name' in obj && typeof obj.name === 'string' &&
      'type' in obj && typeof obj.type === 'string' &&
      'coherence' in obj && typeof obj.coherence === 'number' &&
      'status' in obj && Object.values(CoherenceLevel).includes(obj.status as CoherenceLevel);
  }

  /**
   * Type guard for CoherenceMetrics
   * Type guard para CoherenceMetrics
   */
  static isCoherenceMetrics(obj: unknown): obj is CoherenceMetrics {
    return typeof obj === 'object' && obj !== null &&
      'overallCoherence' in obj && typeof obj.overallCoherence === 'number' &&
      'typeSafety' in obj && typeof obj.typeSafety === 'number' &&
      'performance' in obj && typeof obj.performance === 'number' &&
      'security' in obj && typeof obj.security === 'number' &&
      'maintainability' in obj && typeof obj.maintainability === 'number' &&
      'scalability' in obj && typeof obj.scalability === 'number' &&
      'reliability' in obj && typeof obj.reliability === 'number';
  }

  /**
   * Type guard for CoherenceTrend
   * Type guard para CoherenceTrend
   */
  static isCoherenceTrend(obj: unknown): obj is CoherenceTrend {
    return typeof obj === 'object' && obj !== null &&
      'metric' in obj && typeof obj.metric === 'string' &&
      'direction' in obj && Object.values(TrendDirection).includes(obj.direction as TrendDirection) &&
      'magnitude' in obj && typeof obj.magnitude === 'number' &&
      'timeframe' in obj && typeof obj.timeframe === 'string' &&
      'significance' in obj && typeof obj.significance === 'number';
  }

  /**
   * Type guard for QuantumCoherenceState
   * Type guard para QuantumCoherenceState
   */
  static isQuantumCoherenceState(obj: unknown): obj is QuantumCoherenceState {
    return typeof obj === 'object' && obj !== null &&
      'superposition' in obj && typeof obj.superposition === 'boolean' &&
      'entanglement' in obj && typeof obj.entanglement === 'number' &&
      'decoherenceRate' in obj && typeof obj.decoherenceRate === 'number' &&
      'coherenceTime' in obj && typeof obj.coherenceTime === 'number' &&
      'quantumFidelity' in obj && typeof obj.quantumFidelity === 'number';
  }

  // Helper method to create test adaptation input
  private static createTestAdaptationInput(): any {
    return {
      stimulus: 'test',
      context: {
        environment: 'test',
        timestamp: Date.now(),
        previousAdaptations: [],
        systemState: {}
      },
      constraints: [],
      objectives: []
    };
  }
}

// ============ VALIDATION SYSTEM ============

/**
 * Comprehensive validation system for coherence
 * Sistema de validação abrangente para coerência
 */
export class ValidationSystem {
  private thresholds: CoherenceThresholds;
  private validationHistory: CoherenceValidationResult[] = [];

  constructor(thresholds: CoherenceThresholds = DEFAULT_COHERENCE_THRESHOLDS) {
    this.thresholds = thresholds;
  }

  /**
   * Validate a coherent entity
   * Validar uma entidade coerente
   */
  validateEntity(entity: unknown): CoherenceValidationResult {
    const issues: CoherenceIssue[] = [];
    let score = 0;

    // Basic type validation
    if (!TypeGuards.isCoherentBase(entity)) {
      issues.push({
        type: CoherenceIssueType.STRUCTURAL_INCOHERENCE,
        severity: CoherenceSeverity.CRITICAL,
        message: 'Entity does not implement CoherentBase interface',
        location: 'root',
        suggestion: 'Ensure entity implements all required CoherentBase properties'
      });
      return {
        isValid: false,
        score: 0,
        issues,
        recommendations: ['Implement CoherentBase interface properly'],
        confidence: 1
      };
    }

    // Validate coherence score
    if (entity.coherenceScore < this.thresholds.critical) {
      issues.push({
        type: CoherenceIssueType.PERFORMANCE_INCOHERENCE,
        severity: CoherenceSeverity.CRITICAL,
        message: `Coherence score ${entity.coherenceScore} is below critical threshold ${this.thresholds.critical}`,
        location: 'coherenceScore',
        suggestion: 'Improve entity coherence through optimization'
      });
    }

    // Validate timestamp
    if (entity.timestamp <= 0) {
      issues.push({
        type: CoherenceIssueType.STRUCTURAL_INCOHERENCE,
        severity: CoherenceSeverity.HIGH,
        message: 'Invalid timestamp',
        location: 'timestamp',
        suggestion: 'Use valid timestamp (positive number)'
      });
    }

    // Validate version format
    if (!this.isValidVersion(entity.version)) {
      issues.push({
        type: CoherenceIssueType.STRUCTURAL_INCOHERENCE,
        severity: CoherenceSeverity.MEDIUM,
        message: 'Invalid version format',
        location: 'version',
        suggestion: 'Use semantic versioning format (e.g., "1.0.0")'
      });
    }

    // Calculate score based on issues
    score = this.calculateCoherenceScore(issues);

    // Additional validation for specific entity types
    if (TypeGuards.isValidatableCoherence(entity)) {
      const entityValidation = entity.validateCoherence();
      issues.push(...entityValidation.issues);
      score = (score + entityValidation.score) / 2;
    }

    const result: CoherenceValidationResult = {
      isValid: issues.length === 0 || score >= this.thresholds.medium,
      score,
      issues,
      recommendations: this.generateRecommendations(issues),
      confidence: this.calculateConfidence(issues)
    };

    this.validationHistory.push(result);
    return result;
  }

  /**
   * Validate multiple entities
   * Validar múltiplas entidades
   */
  validateEntities(entities: unknown[]): CoherenceValidationResult[] {
    return entities.map(entity => this.validateEntity(entity));
  }

  /**
   * Get validation history
   * Obter histórico de validação
   */
  getValidationHistory(): CoherenceValidationResult[] {
    return [...this.validationHistory];
  }

  /**
   * Get validation statistics
   * Obter estatísticas de validação
   */
  getValidationStatistics(): {
    total: number;
    valid: number;
    invalid: number;
    averageScore: number;
    mostCommonIssues: CoherenceIssueType[];
  } {
    const total = this.validationHistory.length;
    const valid = this.validationHistory.filter(r => r.isValid).length;
    const invalid = total - valid;
    const averageScore = total > 0 
      ? this.validationHistory.reduce((sum, r) => sum + r.score, 0) / total 
      : 0;

    const issueCount = new Map<CoherenceIssueType, number>();
    this.validationHistory.forEach(result => {
      result.issues.forEach(issue => {
        issueCount.set(issue.type, (issueCount.get(issue.type) || 0) + 1);
      });
    });

    const mostCommonIssues = Array.from(issueCount.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([type]) => type);

    return {
      total,
      valid,
      invalid,
      averageScore,
      mostCommonIssues
    };
  }

  /**
   * Clear validation history
   * Limpar histórico de validação
   */
  clearHistory(): void {
    this.validationHistory = [];
  }

  /**
   * Update thresholds
   * Atualizar limiares
   */
  updateThresholds(newThresholds: Partial<CoherenceThresholds>): void {
    this.thresholds = { ...this.thresholds, ...newThresholds };
  }

  /**
   * Calculate coherence score based on issues
   * Calcular pontuação de coerência baseada em issues
   */
  private calculateCoherenceScore(issues: CoherenceIssue[]): number {
    if (issues.length === 0) return 1;

    const severityWeights = {
      [CoherenceSeverity.CRITICAL]: 0.4,
      [CoherenceSeverity.HIGH]: 0.3,
      [CoherenceSeverity.MEDIUM]: 0.2,
      [CoherenceSeverity.LOW]: 0.1
    };

    const totalWeight = issues.reduce((sum, issue) => {
      return sum + severityWeights[issue.severity];
    }, 0);

    const maxPossibleWeight = issues.length * 0.4; // All critical issues
    return Math.max(0, 1 - (totalWeight / maxPossibleWeight));
  }

  /**
   * Generate recommendations based on issues
   * Gerar recomendações baseadas em issues
   */
  private generateRecommendations(issues: CoherenceIssue[]): string[] {
    const recommendations = new Set<string>();

    issues.forEach(issue => {
      if (issue.suggestion) {
        recommendations.add(issue.suggestion);
      }

      // Add general recommendations based on issue types
      switch (issue.type) {
        case CoherenceIssueType.TYPE_MISMATCH:
          recommendations.add('Review type definitions and ensure type safety');
          break;
        case CoherenceIssueType.PERFORMANCE_INCOHERENCE:
          recommendations.add('Optimize performance-critical components');
          break;
        case CoherenceIssueType.SECURITY_INCOHERENCE:
          recommendations.add('Review security implementations and best practices');
          break;
        case CoherenceIssueType.STRUCTURAL_INCOHERENCE:
          recommendations.add('Review system architecture and component structure');
          break;
      }
    });

    return Array.from(recommendations);
  }

  /**
   * Calculate confidence in validation result
   * Calcular confiança no resultado da validação
   */
  private calculateConfidence(issues: CoherenceIssue[]): number {
    if (issues.length === 0) return 1;

    const highSeverityIssues = issues.filter(issue => 
      issue.severity === CoherenceSeverity.CRITICAL || 
      issue.severity === CoherenceSeverity.HIGH
    ).length;

    return Math.max(0, 1 - (highSeverityIssues / issues.length));
  }

  /**
   * Validate version format
   * Validar formato de versão
   */
  private isValidVersion(version: string): boolean {
    const versionRegex = /^\d+\.\d+\.\d+(-[a-zA-Z0-9]+)?(\+[a-zA-Z0-9]+)?$/;
    return versionRegex.test(version);
  }
}

// ============ COHERENCE OPTIMIZER ============

/**
 * Coherence optimization utilities
 * Utilitários de otimização de coerência
 */
export class CoherenceOptimizer {
  /**
   * Optimize a coherent entity
   * Otimizar uma entidade coerente
   */
  static optimizeEntity(entity: ValidatableCoherence): CoherenceOptimizationResult {
    const originalValidation = entity.validateCoherence();
    const originalScore = originalValidation.score;

    // Apply optimization strategies
    const optimizationStrategies = [
      this.optimizeCoherenceScore,
      this.optimizeTimestamp,
      this.optimizeMetadata,
      this.optimizeVersion
    ];

    const changes: OptimizationChange[] = [];
    let optimizedScore = originalScore;

    for (const strategy of optimizationStrategies) {
      try {
        const result = strategy(entity);
        if (result) {
          changes.push(result);
        }
      } catch (error) {
        console.warn('Optimization strategy failed:', error);
      }
    }

    // Re-validate to get optimized score
    const optimizedValidation = entity.validateCoherence();
    optimizedScore = optimizedValidation.score;

    return {
      originalScore,
      optimizedScore,
      improvements: this.generateImprovements(changes),
      changes,
      estimatedImpact: optimizedScore - originalScore
    };
  }

  /**
   * Optimize coherence score
   * Otimizar pontuação de coerência
   */
  private static optimizeCoherenceScore(entity: ValidatableCoherence): OptimizationChange | null {
    if (entity.coherenceScore >= 0.9) return null;

    const oldValue = entity.coherenceScore;
    entity.coherenceScore = Math.min(1, entity.coherenceScore + 0.1);

    return {
      property: 'coherenceScore',
      oldValue,
      newValue: entity.coherenceScore,
      reason: 'Increased coherence score for better system performance',
      impact: 0.1
    };
  }

  /**
   * Optimize timestamp
   * Otimizar timestamp
   */
  private static optimizeTimestamp(entity: ValidatableCoherence): OptimizationChange | null {
    const now = Date.now();
    if (Math.abs(now - entity.timestamp) < 60000) return null; // Within 1 minute

    const oldValue = entity.timestamp;
    entity.timestamp = now;

    return {
      property: 'timestamp',
      oldValue,
      newValue: entity.timestamp,
      reason: 'Updated timestamp to current time',
      impact: 0.05
    };
  }

  /**
   * Optimize metadata
   * Otimizar metadados
   */
  private static optimizeMetadata(entity: ValidatableCoherence): OptimizationChange | null {
    const oldValue = { ...entity.metadata };
    
    // Add optimization metadata
    entity.metadata = {
      ...entity.metadata,
      optimized: true,
      optimizationTimestamp: Date.now(),
      optimizationVersion: '1.0.0'
    };

    return {
      property: 'metadata',
      oldValue,
      newValue: entity.metadata,
      reason: 'Added optimization metadata',
      impact: 0.02
    };
  }

  /**
   * Optimize version
   * Otimizar versão
   */
  private static optimizeVersion(entity: ValidatableCoherence): OptimizationChange | null {
    // Simple version bumping logic
    const versionParts = entity.version.split('.');
    if (versionParts.length !== 3) return null;

    const oldValue = entity.version;
    versionParts[2] = (parseInt(versionParts[2]) + 1).toString();
    entity.version = versionParts.join('.');

    return {
      property: 'version',
      oldValue,
      newValue: entity.version,
      reason: 'Incremented patch version',
      impact: 0.01
    };
  }

  /**
   * Generate improvement descriptions
   * Gerar descrições de melhoria
   */
  private static generateImprovements(changes: OptimizationChange[]): string[] {
    return changes.map(change => `Optimized ${change.property}: ${change.reason}`);
  }
}

// ============ QUANTUM COHERENCE UTILITIES ============

/**
 * Quantum coherence utilities
 * Utilitários de coerência quântica
 */
export class QuantumCoherenceUtils {
  /**
   * Calculate quantum coherence
   * Calcular coerência quântica
   */
  static calculateCoherence(state: QuantumCoherenceState): number {
    const superpositionFactor = state.superposition ? 1 : 0.5;
    const entanglementFactor = state.entanglement;
    const decoherencePenalty = state.decoherenceRate;
    const timeFactor = Math.min(1, state.coherenceTime / 1000); // Normalize to 1 second
    const fidelityFactor = state.quantumFidelity;

    return (
      superpositionFactor * 0.2 +
      entanglementFactor * 0.3 +
      (1 - decoherencePenalty) * 0.2 +
      timeFactor * 0.1 +
      fidelityFactor * 0.2
    );
  }

  /**
   * Optimize quantum coherence
   * Otimizar coerência quântica
   */
  static optimizeCoherence(
    state: QuantumCoherenceState,
    parameters: QuantumCoherenceParameters
  ): QuantumCoherenceState {
    const optimizedState = { ...state };

    // Apply optimization based on strategy
    switch (parameters.optimizationStrategy) {
      case 'coherence_maximization':
        optimizedState.entanglement = Math.min(1, optimizedState.entanglement + 0.1);
        optimizedState.decoherenceRate = Math.max(0, optimizedState.decoherenceRate - 0.05);
        break;
      case 'decoherence_minimization':
        optimizedState.decoherenceRate = Math.max(0, optimizedState.decoherenceRate - 0.1);
        break;
      case 'entanglement_optimization':
        optimizedState.entanglement = Math.min(1, optimizedState.entanglement + 0.15);
        break;
    }

    return optimizedState;
  }

  /**
   * Validate quantum coherence state
   * Validar estado de coerência quântica
   */
  static validateQuantumState(state: QuantumCoherenceState): CoherenceValidationResult {
    const issues: CoherenceIssue[] = [];

    if (state.entanglement < 0 || state.entanglement > 1) {
      issues.push({
        type: CoherenceIssueType.INVALID_VALUE,
        severity: CoherenceSeverity.HIGH,
        message: 'Entanglement must be between 0 and 1',
        location: 'entanglement',
        suggestion: 'Adjust entanglement to valid range'
      });
    }

    if (state.decoherenceRate < 0 || state.decoherenceRate > 1) {
      issues.push({
        type: CoherenceIssueType.INVALID_VALUE,
        severity: CoherenceSeverity.HIGH,
        message: 'Decoherence rate must be between 0 and 1',
        location: 'decoherenceRate',
        suggestion: 'Adjust decoherence rate to valid range'
      });
    }

    if (state.coherenceTime <= 0) {
      issues.push({
        type: CoherenceIssueType.INVALID_VALUE,
        severity: CoherenceSeverity.CRITICAL,
        message: 'Coherence time must be positive',
        location: 'coherenceTime',
        suggestion: 'Set positive coherence time'
      });
    }

    const score = this.calculateCoherence(state);

    return {
      isValid: issues.length === 0,
      score,
      issues,
      recommendations: issues.map(issue => issue.suggestion),
      confidence: 1 - (issues.length * 0.1)
    };
  }
}

// ============ EXPORTS ============

// Export main classes and utilities
export {
  TypeGuards,
  ValidationSystem,
  CoherenceOptimizer,
  QuantumCoherenceUtils
};

// Export commonly used validation functions
export const validateEntity = (entity: unknown) => 
  new ValidationSystem().validateEntity(entity);

export const optimizeEntity = (entity: ValidatableCoherence) => 
  CoherenceOptimizer.optimizeEntity(entity);

export const calculateQuantumCoherence = (state: QuantumCoherenceState) => 
  QuantumCoherenceUtils.calculateCoherence(state);