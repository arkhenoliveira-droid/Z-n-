/**
 * Sistema de Ajuste Automático de Coerência
 * 
 * Implementa ações automáticas baseadas nos vetores de detecção
 * para promover ajustes proativos e reativos de coerência
 */

import { CoherenceAdjustment, IncoherencePattern } from './coherence-vectors';
import { eventBus, SystemEvents } from './events';
import { vibeCache } from './cache';

export interface AdjustmentAction {
  id: string;
  execute: () => Promise<void>;
  rollback?: () => Promise<void>;
  timeout?: number;
}

export interface AdjustmentResult {
  id: string;
  success: boolean;
  impact: number;
  duration: number;
  message: string;
  timestamp: number;
}

export class AutoAdjustmentSystem {
  private actions = new Map<string, AdjustmentAction>();
  private results: AdjustmentResult[] = [];
  private isActive = false;
  private adjustmentHistory: Map<string, number[]> = new Map();
  
  constructor() {
    this.initializeActions();
    this.startAutoAdjustment();
  }
  
  private initializeActions(): void {
    // Ações de ajuste fisiológico
    this.actions.set('breathing_exercise', {
      id: 'breathing_exercise',
      execute: async () => {
        console.log('🧘 Starting breathing exercise...');
        // Simular exercício de respiração
        await this.delay(180000); // 3 minutos
        console.log('✅ Breathing exercise completed');
        eventBus.emit('adjustment:completed', {
          type: 'breathing_exercise',
          impact: 20
        });
      },
      timeout: 180000
    });
    
    this.actions.set('hydrate_stretch', {
      id: 'hydrate_stretch',
      execute: async () => {
        console.log('💧 Hydration and stretch reminder...');
        // Simular hidratação e alongamento
        await this.delay(120000); // 2 minutos
        console.log('✅ Hydration and stretch completed');
        eventBus.emit('adjustment:completed', {
          type: 'hydrate_stretch',
          impact: 8
        });
      },
      timeout: 120000
    });
    
    // Ações de ajuste ambiental
    this.actions.set('dim_lights_noise', {
      id: 'dim_lights_noise',
      execute: async () => {
        console.log('🔆 Reducing environmental stimuli...');
        // Simular ajuste de luz e som
        await this.delay(60000); // 1 minuto
        console.log('✅ Environmental stimuli reduced');
        eventBus.emit('adjustment:completed', {
          type: 'dim_lights_noise',
          impact: 12
        });
      },
      timeout: 60000
    });
    
    // Ações de ajuste cognitivo
    this.actions.set('pause_work', {
      id: 'pause_work',
      execute: async () => {
        console.log('⏸️ Pausing work for recovery...');
        // Simular pausa no trabalho
        await this.delay(300000); // 5 minutos
        console.log('✅ Work pause completed');
        eventBus.emit('adjustment:completed', {
          type: 'pause_work',
          impact: 15
        });
      },
      timeout: 300000
    });
    
    this.actions.set('preventive_break', {
      id: 'preventive_break',
      execute: async () => {
        console.log('🛡️ Taking preventive break...');
        // Simular pausa preventiva
        await this.delay(180000); // 3 minutos
        console.log('✅ Preventive break completed');
        eventBus.emit('adjustment:completed', {
          type: 'preventive_break',
          impact: 10
        });
      },
      timeout: 180000
    });
    
    // Ações de ajuste temporal
    this.actions.set('reschedule_tasks', {
      id: 'reschedule_tasks',
      execute: async () => {
        console.log('📅 Rescheduling tasks for optimal timing...');
        // Simular reorganização de tarefas
        await this.delay(600000); // 10 minutos
        console.log('✅ Tasks rescheduled');
        eventBus.emit('adjustment:completed', {
          type: 'reschedule_tasks',
          impact: 18
        });
      },
      timeout: 600000
    });
    
    this.actions.set('schedule_optimization', {
      id: 'schedule_optimization',
      execute: async () => {
        console.log('⏰ Optimizing work schedule...');
        // Simular otimização de cronograma
        await this.delay(300000); // 5 minutos
        console.log('✅ Schedule optimized');
        eventBus.emit('adjustment:completed', {
          type: 'schedule_optimization',
          impact: 15
        });
      },
      timeout: 300000
    });
  }
  
  /**
   * Executa ajustes automáticos baseados em padrões detectados
   */
  async executeAdjustments(adjustments: CoherenceAdjustment[]): Promise<AdjustmentResult[]> {
    const results: AdjustmentResult[] = [];
    
    for (const adjustment of adjustments) {
      if (!adjustment.autoApply) continue;
      
      const action = this.actions.get(adjustment.action);
      if (!action) {
        results.push({
          id: adjustment.id,
          success: false,
          impact: 0,
          duration: 0,
          message: `Action not found: ${adjustment.action}`,
          timestamp: Date.now()
        });
        continue;
      }
      
      try {
        const startTime = Date.now();
        
        // Executar ação com timeout
        await Promise.race([
          action.execute(),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout')), action.timeout)
          )
        ]);
        
        const duration = Date.now() - startTime;
        
        results.push({
          id: adjustment.id,
          success: true,
          impact: adjustment.expectedImpact,
          duration,
          message: `Successfully executed ${adjustment.description}`,
          timestamp: Date.now()
        });
        
        // Registrar histórico de ajustes
        this.recordAdjustment(adjustment.id, adjustment.expectedImpact);
        
        // Emitir evento de sucesso
        eventBus.emit('adjustment:success', {
          adjustmentId: adjustment.id,
          impact: adjustment.expectedImpact,
          duration
        });
        
      } catch (error) {
        results.push({
          id: adjustment.id,
          success: false,
          impact: 0,
          duration: 0,
          message: `Failed to execute ${adjustment.description}: ${error}`,
          timestamp: Date.now()
        });
        
        // Emitir evento de falha
        eventBus.emit('adjustment:failed', {
          adjustmentId: adjustment.id,
          error: error
        });
      }
    }
    
    // Armazenar resultados
    this.results.push(...results);
    
    // Manter apenas resultados recentes
    if (this.results.length > 100) {
      this.results = this.results.slice(-100);
    }
    
    return results;
  }
  
  /**
   * Sistema de ajuste automático contínuo
   */
  private startAutoAdjustment(): void {
    if (this.isActive) return;
    
    this.isActive = true;
    
    const autoAdjust = async () => {
      if (!this.isActive) return;
      
      try {
        // Obter recomendações do cache
        const recommendations = vibeCache.get('coherence_recommendations');
        
        if (recommendations && recommendations.length > 0) {
          // Filtrar apenas ajustes automáticos
          const autoAdjustments = recommendations.filter(adj => adj.autoApply);
          
          if (autoAdjustments.length > 0) {
            console.log(`🤖 Executing ${autoAdjustments.length} automatic adjustments...`);
            await this.executeAdjustments(autoAdjustments);
          }
        }
        
      } catch (error) {
        console.error('Error in auto-adjustment system:', error);
        eventBus.emit('adjustment:error', { error });
      }
      
      // Próximo ciclo de ajuste
      setTimeout(autoAdjust, 30000); // Verificar a cada 30 segundos
    };
    
    // Iniciar ciclo
    autoAdjust();
  }
  
  /**
   * Registra histórico de ajustes para aprendizado
   */
  private recordAdjustment(adjustmentId: string, impact: number): void {
    if (!this.adjustmentHistory.has(adjustmentId)) {
      this.adjustmentHistory.set(adjustmentId, []);
    }
    
    const history = this.adjustmentHistory.get(adjustmentId)!;
    history.push(impact);
    
    // Manter apenas histórico recente
    if (history.length > 20) {
      history.shift();
    }
    
    // Atualizar cache
    vibeCache.set(`adjustment_history_${adjustmentId}`, history, 3600000); // 1 hora
  }
  
  /**
   * Calcula eficácia média de um ajuste
   */
  getAdjustmentEfficacy(adjustmentId: string): number {
    const history = this.adjustmentHistory.get(adjustmentId) || [];
    
    if (history.length === 0) return 0;
    
    const average = history.reduce((sum, impact) => sum + impact, 0) / history.length;
    
    // Normalizar para 0-100
    return Math.min(100, Math.max(0, average));
  }
  
  /**
   * Obtém estatísticas do sistema de ajuste
   */
  getStats() {
    const totalAdjustments = this.results.length;
    const successfulAdjustments = this.results.filter(r => r.success).length;
    const successRate = totalAdjustments > 0 ? (successfulAdjustments / totalAdjustments) * 100 : 0;
    
    const averageImpact = this.results
      .filter(r => r.success)
      .reduce((sum, r) => sum + r.impact, 0) / Math.max(1, successfulAdjustments);
    
    const averageDuration = this.results
      .filter(r => r.success)
      .reduce((sum, r) => sum + r.duration, 0) / Math.max(1, successfulAdjustments);
    
    return {
      totalAdjustments,
      successfulAdjustments,
      successRate,
      averageImpact,
      averageDuration,
      isActive: this.isActive,
      availableActions: this.actions.size,
      adjustmentEfficacy: Object.fromEntries(
        Array.from(this.adjustmentHistory.entries()).map(([id, history]) => [
          id,
          this.getAdjustmentEfficacy(id)
        ])
      )
    };
  }
  
  /**
   * Para o sistema de ajuste automático
   */
  stop(): void {
    this.isActive = false;
  }
  
  /**
   * Reinicia o sistema de ajuste automático
   */
  restart(): void {
    this.stop();
    this.startAutoAdjustment();
  }
  
  /**
   * Limpa histórico de resultados
   */
  clearHistory(): void {
    this.results = [];
    this.adjustmentHistory.clear();
  }
  
  /**
   * Obtém resultados recentes
   */
  getRecentResults(limit: number = 10): AdjustmentResult[] {
    return this.results.slice(-limit);
  }
  
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Instância global para uso no sistema
export const autoAdjustmentSystem = new AutoAdjustmentSystem();