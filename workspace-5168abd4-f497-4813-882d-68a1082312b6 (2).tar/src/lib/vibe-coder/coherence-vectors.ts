/**
 * Vetores Avançados de Detecção e Ajuste de Coerência
 * 
 * Sistema especializado em detectar padrões de incoerência e
 * promover ajustes automáticos para otimização contínua
 */

export interface CoherenceVector {
  id: string;
  name: string;
  description: string;
  value: number;
  threshold: number;
  weight: number;
  trend: 'improving' | 'declining' | 'stable';
  lastUpdated: number;
  adjustments: CoherenceAdjustment[];
}

export interface CoherenceAdjustment {
  id: string;
  type: 'environmental' | 'cognitive' | 'physiological' | 'temporal' | 'social';
  priority: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  action: string;
  expectedImpact: number;
  estimatedTime: number; // in seconds
  autoApply: boolean;
}

export interface IncoherencePattern {
  id: string;
  pattern: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  vectors: string[];
  detectedAt: number;
  suggestedActions: CoherenceAdjustment[];
  confidence: number;
}

export interface CoherenceOptimizer {
  vectors: Map<string, CoherenceVector>;
  patterns: IncoherencePattern[];
  adjustments: CoherenceAdjustment[];
  isOptimizing: boolean;
  lastOptimization: number;
}

/**
 * Vetor de Coerência Fisiológica Avançada
 */
export class PhysiologicalCoherenceVector {
  private data: number[] = [];
  private maxSamples = 100;
  
  addSample(heartRate: number, hrv: number, stress: number): void {
    const coherence = this.calculatePhysiologicalCoherence(heartRate, hrv, stress);
    this.data.push(coherence);
    
    if (this.data.length > this.maxSamples) {
      this.data.shift();
    }
  }
  
  private calculatePhysiologicalCoherence(hr: number, hrv: number, stress: number): number {
    // Coerência baseada na relação entre HRV e stress
    const optimalHRV = 70;
    const optimalStress = 15;
    
    const hrvCoherence = Math.max(0, 100 - Math.abs(hrv - optimalHRV) * 2);
    const stressCoherence = Math.max(0, 100 - stress * 2);
    const hrCoherence = Math.max(0, 100 - Math.abs(hr - 72) * 1.5);
    
    return (hrvCoherence * 0.4 + stressCoherence * 0.4 + hrCoherence * 0.2);
  }
  
  getCurrentValue(): number {
    if (this.data.length === 0) return 50;
    return this.data[this.data.length - 1];
  }
  
  getTrend(): 'improving' | 'declining' | 'stable' {
    if (this.data.length < 5) return 'stable';
    
    const recent = this.data.slice(-5);
    const older = this.data.slice(-10, -5);
    
    if (older.length === 0) return 'stable';
    
    const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
    const olderAvg = older.reduce((a, b) => a + b, 0) / older.length;
    
    const difference = recentAvg - olderAvg;
    
    if (difference > 3) return 'improving';
    if (difference < -3) return 'declining';
    return 'stable';
  }
  
  detectAnomalies(): boolean {
    if (this.data.length < 10) return false;
    
    const recent = this.data.slice(-5);
    const average = recent.reduce((a, b) => a + b, 0) / recent.length;
    
    // Detectar variações anormais
    const variance = recent.reduce((sum, val) => sum + Math.pow(val - average, 2), 0) / recent.length;
    
    return variance > 100; // Limiar de anomalia
  }
}

/**
 * Vetor de Coerência Cognitiva Avançada
 */
export class CognitiveCoherenceVector {
  private focusHistory: number[] = [];
  private energyHistory: number[] = [];
  private stressHistory: number[] = [];
  private maxSamples = 50;
  
  addSample(focus: number, energy: number, stress: number): void {
    this.focusHistory.push(focus);
    this.energyHistory.push(energy);
    this.stressHistory.push(stress);
    
    if (this.focusHistory.length > this.maxSamples) {
      this.focusHistory.shift();
      this.energyHistory.shift();
      this.stressHistory.shift();
    }
  }
  
  calculateCognitiveCoherence(): number {
    if (this.focusHistory.length === 0) return 50;
    
    const focus = this.focusHistory[this.focusHistory.length - 1];
    const energy = this.energyHistory[this.energyHistory.length - 1];
    const stress = this.stressHistory[this.stressHistory.length - 1];
    
    // Coerência baseada no equilíbrio cognitivo
    const focusWeight = focus * 0.5;
    const stressWeight = (100 - stress) * 0.3;
    const energyWeight = Math.min(energy, 90) * 0.2; // Energia ótima não é máxima
    
    return Math.min(100, focusWeight + stressWeight + energyWeight);
  }
  
  detectCognitiveFatigue(): boolean {
    if (this.focusHistory.length < 10) return false;
    
    const recentFocus = this.focusHistory.slice(-5);
    const recentEnergy = this.energyHistory.slice(-5);
    
    const avgFocus = recentFocus.reduce((a, b) => a + b, 0) / recentFocus.length;
    const avgEnergy = recentEnergy.reduce((a, b) => a + b, 0) / recentEnergy.length;
    
    return avgFocus < 60 && avgEnergy < 50;
  }
  
  detectStressOverload(): boolean {
    if (this.stressHistory.length < 5) return false;
    
    const recentStress = this.stressHistory.slice(-3);
    const avgStress = recentStress.reduce((a, b) => a + b, 0) / recentStress.length;
    
    return avgStress > 35;
  }
  
  getOptimalBreakTime(): number {
    if (this.focusHistory.length < 10) return 0;
    
    const focusTrend = this.calculateTrend(this.focusHistory);
    const energyTrend = this.calculateTrend(this.energyHistory);
    
    if (focusTrend === 'declining' && energyTrend === 'declining') {
      return 300; // 5 minutos
    }
    
    return 0;
  }
  
  private calculateTrend(data: number[]): 'improving' | 'declining' | 'stable' {
    if (data.length < 3) return 'stable';
    
    const recent = data.slice(-3);
    const older = data.slice(-6, -3);
    
    if (older.length === 0) return 'stable';
    
    const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
    const olderAvg = older.reduce((a, b) => a + b, 0) / older.length;
    
    const difference = recentAvg - olderAvg;
    
    if (difference > 5) return 'improving';
    if (difference < -5) return 'declining';
    return 'stable';
  }
}

/**
 * Vetor de Coerência Temporal Avançada
 */
export class TemporalCoherenceVector {
  private coherenceHistory: { timestamp: number; coherence: number }[] = [];
  private maxSamples = 200;
  
  addSample(coherence: number): void {
    this.coherenceHistory.push({
      timestamp: Date.now(),
      coherence
    });
    
    if (this.coherenceHistory.length > this.maxSamples) {
      this.coherenceHistory.shift();
    }
  }
  
  calculateCircadianAlignment(): number {
    const currentHour = new Date().getHours();
    
    // Padrões circadianos ótimos
    const optimalWindows = [
      { start: 9, end: 11, weight: 1.0 },   // Pico matinal
      { start: 14, end: 16, weight: 0.9 },  // Pico vespertino
      { start: 10, end: 12, weight: 0.8 },  // Manhã tardia
      { start: 15, end: 17, weight: 0.7 }   // Tarde tardia
    ];
    
    for (const window of optimalWindows) {
      if (currentHour >= window.start && currentHour <= window.end) {
        return 100 * window.weight;
      }
    }
    
    // Horários subótimos
    if (currentHour >= 6 && currentHour <= 8) return 60;  // Manhã cedo
    if (currentHour >= 13 && currentHour <= 14) return 50; // Início da tarde
    if (currentHour >= 18 && currentHour <= 22) return 70; // Noite
    
    return 40; // Outros horários
  }
  
  detectPatternDisruption(): boolean {
    if (this.coherenceHistory.length < 20) return false;
    
    const recent = this.coherenceHistory.slice(-10);
    const older = this.coherenceHistory.slice(-20, -10);
    
    const recentAvg = recent.reduce((sum, item) => sum + item.coherence, 0) / recent.length;
    const olderAvg = older.reduce((sum, item) => sum + item.coherence, 0) / older.length;
    
    // Detectar quebra de padrão significativa
    return Math.abs(recentAvg - olderAvg) > 20;
  }
  
  getOptimalWorkDuration(): number {
    const currentHour = new Date().getHours();
    
    // Durações ótimas baseadas no horário
    if (currentHour >= 9 && currentHour <= 11) return 90;   // 1.5 horas
    if (currentHour >= 14 && currentHour <= 16) return 75;  // 1.25 horas
    if (currentHour >= 10 && currentHour <= 12) return 60;  // 1 hora
    
    return 45; // 45 minutos para outros horários
  }
  
  predictNextOptimalWindow(): { start: number; end: number; confidence: number } {
    const currentHour = new Date().getHours();
    
    // Próxima janela ótima
    if (currentHour < 9) {
      return { start: 9, end: 11, confidence: 0.9 };
    }
    if (currentHour < 14) {
      return { start: 14, end: 16, confidence: 0.8 };
    }
    if (currentHour < 18) {
      return { start: 15, end: 17, confidence: 0.7 };
    }
    
    // Próximo dia
    return { start: 9, end: 11, confidence: 0.6 };
  }
}

/**
 * Detector de Padrões de Incoerência
 */
export class IncoherencePatternDetector {
  private patterns: IncoherencePattern[] = [];
  
  detectPatterns(vectors: Map<string, CoherenceVector>): IncoherencePattern[] {
    const detectedPatterns: IncoherencePattern[] = [];
    
    // Padrão 1: Fadiga Cognitiva
    if (this.detectCognitiveFatiguePattern(vectors)) {
      detectedPatterns.push({
        id: 'cognitive_fatigue',
        pattern: 'Cognitive Fatigue Pattern',
        severity: 'high',
        vectors: ['cognitive', 'energy', 'focus'],
        detectedAt: Date.now(),
        suggestedActions: [
          {
            id: 'break_5min',
            type: 'cognitive',
            priority: 'high',
            description: 'Take a 5-minute break',
            action: 'pause_work',
            expectedImpact: 15,
            estimatedTime: 300,
            autoApply: false
          },
          {
            id: 'hydrate',
            type: 'physiological',
            priority: 'medium',
            description: 'Drink water and stretch',
            action: 'hydrate_stretch',
            expectedImpact: 8,
            estimatedTime: 120,
            autoApply: true
          }
        ],
        confidence: 0.85
      });
    }
    
    // Padrão 2: Sobrecarga de Estresse
    if (this.detectStressOverloadPattern(vectors)) {
      detectedPatterns.push({
        id: 'stress_overload',
        pattern: 'Stress Overload Pattern',
        severity: 'critical',
        vectors: ['stress', 'physiological', 'coherence'],
        detectedAt: Date.now(),
        suggestedActions: [
          {
            id: 'breathing_exercise',
            type: 'physiological',
            priority: 'critical',
            description: 'Perform breathing exercise',
            action: 'breathing_exercise',
            expectedImpact: 20,
            estimatedTime: 180,
            autoApply: true
          },
          {
            id: 'reduce_stimuli',
            type: 'environmental',
            priority: 'high',
            description: 'Reduce environmental stimuli',
            action: 'dim_lights_noise',
            expectedImpact: 12,
            estimatedTime: 60,
            autoApply: true
          }
        ],
        confidence: 0.92
      });
    }
    
    // Padrão 3: Desalinhamento Temporal
    if (this.detectTemporalMisalignment(vectors)) {
      detectedPatterns.push({
        id: 'temporal_misalignment',
        pattern: 'Temporal Misalignment Pattern',
        severity: 'medium',
        vectors: ['temporal', 'circadian', 'energy'],
        detectedAt: Date.now(),
        suggestedActions: [
          {
            id: 'adjust_schedule',
            type: 'temporal',
            priority: 'medium',
            description: 'Adjust work schedule to circadian rhythm',
            action: 'reschedule_tasks',
            expectedImpact: 18,
            estimatedTime: 600,
            autoApply: false
          }
        ],
        confidence: 0.78
      });
    }
    
    return detectedPatterns;
  }
  
  private detectCognitiveFatiguePattern(vectors: Map<string, CoherenceVector>): boolean {
    const cognitive = vectors.get('cognitive');
    const energy = vectors.get('energy');
    const focus = vectors.get('focus');
    
    return cognitive?.value < 60 && energy?.value < 50 && focus?.value < 65;
  }
  
  private detectStressOverloadPattern(vectors: Map<string, CoherenceVector>): boolean {
    const stress = vectors.get('stress');
    const physiological = vectors.get('physiological');
    
    return stress?.value > 35 && physiological?.value < 50;
  }
  
  private detectTemporalMisalignment(vectors: Map<string, CoherenceVector>): boolean {
    const temporal = vectors.get('temporal');
    const currentHour = new Date().getHours();
    
    // Verificar se está trabalhando em horário subótimo
    const suboptimalHours = [0, 1, 2, 3, 4, 5, 6, 23];
    return suboptimalHours.includes(currentHour) && temporal?.value < 50;
  }
}

/**
 * Sistema Principal de Otimização de Coerência
 */
export class CoherenceOptimizationEngine {
  private physiologicalVector: PhysiologicalCoherenceVector;
  private cognitiveVector: CognitiveCoherenceVector;
  private temporalVector: TemporalCoherenceVector;
  private patternDetector: IncoherencePatternDetector;
  private vectors: Map<string, CoherenceVector>;
  private isActive = false;
  
  constructor() {
    this.physiologicalVector = new PhysiologicalCoherenceVector();
    this.cognitiveVector = new CognitiveCoherenceVector();
    this.temporalVector = new TemporalCoherenceVector();
    this.patternDetector = new IncoherencePatternDetector();
    this.vectors = new Map();
    
    this.initializeVectors();
  }
  
  private initializeVectors(): void {
    // Inicializar vetores principais
    this.vectors.set('physiological', {
      id: 'physiological',
      name: 'Physiological Coherence',
      description: 'Heart rate variability and stress balance',
      value: 75,
      threshold: 60,
      weight: 0.3,
      trend: 'stable',
      lastUpdated: Date.now(),
      adjustments: []
    });
    
    this.vectors.set('cognitive', {
      id: 'cognitive',
      name: 'Cognitive Coherence',
      description: 'Focus, energy and stress balance',
      value: 80,
      threshold: 65,
      weight: 0.35,
      trend: 'stable',
      lastUpdated: Date.now(),
      adjustments: []
    });
    
    this.vectors.set('temporal', {
      id: 'temporal',
      name: 'Temporal Coherence',
      description: 'Circadian rhythm alignment',
      value: 85,
      threshold: 70,
      weight: 0.25,
      trend: 'stable',
      lastUpdated: Date.now(),
      adjustments: []
    });
    
    this.vectors.set('environmental', {
      id: 'environmental',
      name: 'Environmental Coherence',
      description: 'Light, sound and temperature harmony',
      value: 78,
      threshold: 65,
      weight: 0.1,
      trend: 'stable',
      lastUpdated: Date.now(),
      adjustments: []
    });
  }
  
  updatePhysiologicalData(heartRate: number, hrv: number, stress: number): void {
    this.physiologicalVector.addSample(heartRate, hrv, stress);
    
    const physiological = this.vectors.get('physiological');
    if (physiological) {
      physiological.value = this.physiologicalVector.getCurrentValue();
      physiological.trend = this.physiologicalVector.getTrend();
      physiological.lastUpdated = Date.now();
    }
  }
  
  updateCognitiveData(focus: number, energy: number, stress: number): void {
    this.cognitiveVector.addSample(focus, energy, stress);
    
    const cognitive = this.vectors.get('cognitive');
    if (cognitive) {
      cognitive.value = this.cognitiveVector.calculateCognitiveCoherence();
      cognitive.lastUpdated = Date.now();
    }
  }
  
  updateTemporalData(coherence: number): void {
    this.temporalVector.addSample(coherence);
    
    const temporal = this.vectors.get('temporal');
    if (temporal) {
      temporal.value = this.temporalVector.calculateCircadianAlignment();
      temporal.lastUpdated = Date.now();
    }
  }
  
  detectIncoherencePatterns(): IncoherencePattern[] {
    return this.patternDetector.detectPatterns(this.vectors);
  }
  
  generateOptimizationRecommendations(): CoherenceAdjustment[] {
    const patterns = this.detectIncoherencePatterns();
    const recommendations: CoherenceAdjustment[] = [];
    
    patterns.forEach(pattern => {
      recommendations.push(...pattern.suggestedActions);
    });
    
    // Adicionar recomendações proativas baseadas em vetores
    this.addProactiveRecommendations(recommendations);
    
    return recommendations.sort((a, b) => {
      const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 };
      return priorityOrder[b.priority] - priorityOrder[a.priority];
    });
  }
  
  private addProactiveRecommendations(recommendations: CoherenceAdjustment[]): void {
    const cognitive = this.vectors.get('cognitive');
    const temporal = this.vectors.get('temporal');
    
    // Recomendação para pausa preventiva
    if (cognitive && cognitive.value < 70) {
      const breakTime = this.cognitiveVector.getOptimalBreakTime();
      if (breakTime > 0) {
        recommendations.push({
          id: 'preventive_break',
          type: 'cognitive',
          priority: 'medium',
          description: 'Take preventive break to maintain coherence',
          action: 'preventive_break',
          expectedImpact: 10,
          estimatedTime: breakTime,
          autoApply: true
        });
      }
    }
    
    // Recomendação de ajuste de horário
    if (temporal && temporal.value < 60) {
      const nextWindow = this.temporalVector.predictNextOptimalWindow();
      recommendations.push({
        id: 'schedule_optimization',
        type: 'temporal',
        priority: 'medium',
        description: `Optimize schedule for next optimal window (${nextWindow.start}:00-${nextWindow.end}:00)`,
        action: 'schedule_optimization',
        expectedImpact: 15,
        estimatedTime: 300,
        autoApply: false
      });
    }
  }
  
  calculateOverallCoherence(): number {
    let totalWeight = 0;
    let weightedSum = 0;
    
    for (const vector of this.vectors.values()) {
      weightedSum += vector.value * vector.weight;
      totalWeight += vector.weight;
    }
    
    return totalWeight > 0 ? weightedSum / totalWeight : 50;
  }
  
  getCoherenceStatus(): {
    overall: number;
    status: 'optimal' | 'good' | 'fair' | 'poor' | 'critical';
    vectors: CoherenceVector[];
    recommendations: CoherenceAdjustment[];
    patterns: IncoherencePattern[];
  } {
    const overall = this.calculateOverallCoherence();
    const recommendations = this.generateOptimizationRecommendations();
    const patterns = this.detectIncoherencePatterns();
    
    let status: 'optimal' | 'good' | 'fair' | 'poor' | 'critical';
    if (overall >= 90) status = 'optimal';
    else if (overall >= 80) status = 'good';
    else if (overall >= 70) status = 'fair';
    else if (overall >= 60) status = 'poor';
    else status = 'critical';
    
    return {
      overall,
      status,
      vectors: Array.from(this.vectors.values()),
      recommendations,
      patterns
    };
  }
  
  start(): void {
    this.isActive = true;
  }
  
  stop(): void {
    this.isActive = false;
  }
  
  isRunning(): boolean {
    return this.isActive;
  }
}