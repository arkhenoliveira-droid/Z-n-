/**
 * Sistema de Eventos para Vibe-Coder
 * 
 * Implementa um sistema de eventos desacoplado para melhorar
 * a comunicação entre componentes do sistema
 */

export type EventHandler<T = any> = (data: T) => void | Promise<void>;

export interface EventSubscription {
  id: string;
  event: string;
  handler: EventHandler;
  once?: boolean;
}

export class EventBus {
  private events = new Map<string, EventHandler[]>();
  private subscriptions = new Map<string, EventSubscription>();
  private subscriptionId = 0;
  
  /**
   * Registra um listener para um evento
   */
  on<T = any>(event: string, handler: EventHandler<T>): string {
    const id = `sub_${this.subscriptionId++}`;
    
    if (!this.events.has(event)) {
      this.events.set(event, []);
    }
    
    this.events.get(event)!.push(handler);
    
    this.subscriptions.set(id, {
      id,
      event,
      handler
    });
    
    return id;
  }
  
  /**
   * Registra um listener que executa apenas uma vez
   */
  once<T = any>(event: string, handler: EventHandler<T>): string {
    const id = `sub_${this.subscriptionId++}`;
    
    if (!this.events.has(event)) {
      this.events.set(event, []);
    }
    
    const onceHandler: EventHandler<T> = (data: T) => {
      handler(data);
      this.off(id);
    };
    
    this.events.get(event)!.push(onceHandler);
    
    this.subscriptions.set(id, {
      id,
      event,
      handler: onceHandler,
      once: true
    });
    
    return id;
  }
  
  /**
   * Remove um listener
   */
  off(subscriptionId: string): boolean {
    const subscription = this.subscriptions.get(subscriptionId);
    if (!subscription) return false;
    
    const handlers = this.events.get(subscription.event);
    if (handlers) {
      const index = handlers.indexOf(subscription.handler);
      if (index > -1) {
        handlers.splice(index, 1);
      }
    }
    
    this.subscriptions.delete(subscriptionId);
    return true;
  }
  
  /**
   * Emite um evento para todos os listeners
   */
  async emit<T = any>(event: string, data?: T): Promise<void> {
    const handlers = this.events.get(event);
    if (!handlers || handlers.length === 0) return;
    
    // Executar handlers em paralelo para melhor performance
    const promises = handlers.map(handler => {
      try {
        return Promise.resolve(handler(data));
      } catch (error) {
        console.error(`Error in event handler for ${event}:`, error);
        return Promise.resolve();
      }
    });
    
    await Promise.all(promises);
  }
  
  /**
   * Remove todos os listeners de um evento específico
   */
  removeAllListeners(event: string): number {
    const handlers = this.events.get(event);
    if (!handlers) return 0;
    
    const count = handlers.length;
    
    // Remover subscriptions
    for (const [id, subscription] of this.subscriptions.entries()) {
      if (subscription.event === event) {
        this.subscriptions.delete(id);
      }
    }
    
    // Limpar handlers
    this.events.delete(event);
    
    return count;
  }
  
  /**
   * Obtém estatísticas do sistema de eventos
   */
  getStats() {
    return {
      totalEvents: this.events.size,
      totalSubscriptions: this.subscriptions.size,
      eventCounts: Array.from(this.events.entries()).map(([event, handlers]) => ({
        event,
        handlerCount: handlers.length
      }))
    };
  }
  
  /**
   * Limpa todos os eventos e subscriptions
   */
  clear(): void {
    this.events.clear();
    this.subscriptions.clear();
  }
}

// Instância global para uso no sistema
export const eventBus = new EventBus();

// Eventos padrão do sistema
export const SystemEvents = {
  COHERENCE_UPDATED: 'coherence:updated',
  EVOLUTION_TRIGGERED: 'evolution:triggered',
  PHASE_COMPLETED: 'phase:completed',
  STATE_CHANGED: 'state:changed',
  METRICS_UPDATED: 'metrics:updated',
  ERROR_OCCURRED: 'error:occurred'
} as const;