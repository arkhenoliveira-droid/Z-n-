/**
 * TypeScript Coherence System - Comprehensive Type Definitions
 * Sistema de Coerência TypeScript - Definições de Tipos Abrangentes
 * 
 * This file establishes the foundational type system for the entire project,
 * implementing the coherence principles requested in the priority task:
 * "Aprimore 'TypeScript' sob a perspectiva da coerência"
 */

import { z } from 'zod';

// ============ BASE COHERENCE INTERFACES ============

/**
 * Base interface for all coherent entities in the system
 * Interface base para todas as entidades coerentes no sistema
 */
export interface CoherentBase {
  id: string;
  timestamp: number;
  coherenceScore: number;
  metadata: Record<string, unknown>;
  version: string;
}

/**
 * Interface for entities that can be validated for coherence
 * Interface para entidades que podem ser validadas para coerência
 */
export interface ValidatableCoherence extends CoherentBase {
  validateCoherence(): CoherenceValidationResult;
  optimizeCoherence(): CoherenceOptimizationResult;
}

/**
 * Interface for entities that can evolve and adapt
 * Interface para entidades que podem evoluir e adaptar
 */
export interface EvolvableCoherence extends CoherentBase {
  evolutionStage: EvolutionStage;
  adapt(input: AdaptationInput): AdaptationResult;
  evolve(): EvolutionResult;
}

// ============ COHERENCE VALIDATION TYPES ============

/**
 * Result of coherence validation
 * Resultado da validação de coerência
 */
export interface CoherenceValidationResult {
  isValid: boolean;
  score: number;
  issues: CoherenceIssue[];
  recommendations: string[];
  confidence: number;
}

/**
 * Individual coherence issue
 * Issue individual de coerência
 */
export interface CoherenceIssue {
  type: CoherenceIssueType;
  severity: CoherenceSeverity;
  message: string;
  location: string;
  suggestion: string;
}

/**
 * Types of coherence issues
 * Tipos de issues de coerência
 */
export enum CoherenceIssueType {
  TYPE_MISMATCH = 'type_mismatch',
  MISSING_PROPERTY = 'missing_property',
  INVALID_VALUE = 'invalid_value',
  STRUCTURAL_INCOHERENCE = 'structural_incoherence',
  LOGICAL_INCOHERENCE = 'logical_incoherence',
  PERFORMANCE_INCOHERENCE = 'performance_incoherence',
  SECURITY_INCOHERENCE = 'security_incoherence'
}

/**
 * Severity levels for coherence issues
 * Níveis de severidade para issues de coerência
 */
export enum CoherenceSeverity {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical'
}

/**
 * Result of coherence optimization
 * Resultado da otimização de coerência
 */
export interface CoherenceOptimizationResult {
  originalScore: number;
  optimizedScore: number;
  improvements: string[];
  changes: OptimizationChange[];
  estimatedImpact: number;
}

/**
 * Individual optimization change
 * Mudança individual de otimização
 */
export interface OptimizationChange {
  property: string;
  oldValue: unknown;
  newValue: unknown;
  reason: string;
  impact: number;
}

// ============ EVOLUTION AND ADAPTATION TYPES ============

/**
 * Evolution stages for coherent entities
 * Estágios de evolução para entidades coerentes
 */
export enum EvolutionStage {
  PRIMITIVE = 'primitive',
  DEVELOPING = 'developing',
  MATURE = 'mature',
  ADVANCED = 'advanced',
  TRANSCENDENT = 'transcendent'
}

/**
 * Input for adaptation process
 * Input para processo de adaptação
 */
export interface AdaptationInput {
  stimulus: unknown;
  context: AdaptationContext;
  constraints: AdaptationConstraint[];
  objectives: AdaptationObjective[];
}

/**
 * Context for adaptation
 * Contexto para adaptação
 */
export interface AdaptationContext {
  environment: string;
  timestamp: number;
  previousAdaptations: AdaptationResult[];
  systemState: Record<string, unknown>;
}

/**
 * Constraints for adaptation
 * Restrições para adaptação
 */
export interface AdaptationConstraint {
  type: ConstraintType;
  parameter: string;
  condition: string;
  priority: number;
}

/**
 * Types of adaptation constraints
 * Tipos de restrições de adaptação
 */
export enum ConstraintType {
  PERFORMANCE = 'performance',
  SECURITY = 'security',
  RESOURCE = 'resource',
  FUNCTIONAL = 'functional',
  TEMPORAL = 'temporal'
}

/**
 * Objectives for adaptation
 * Objetivos para adaptação
 */
export interface AdaptationObjective {
  metric: string;
  target: number;
  weight: number;
  tolerance: number;
}

/**
 * Result of adaptation process
 * Resultado do processo de adaptação
 */
export interface AdaptationResult {
  success: boolean;
  changes: AdaptationChange[];
  metrics: AdaptationMetric[];
  confidence: number;
  sideEffects: string[];
}

/**
 * Individual adaptation change
 * Mudança individual de adaptação
 */
export interface AdaptationChange {
  component: string;
  modification: string;
  reason: string;
  impact: number;
}

/**
 * Metrics for adaptation evaluation
 * Métricas para avaliação de adaptação
 */
export interface AdaptationMetric {
  name: string;
  value: number;
  target: number;
  improvement: number;
}

/**
 * Result of evolution process
 * Resultado do processo de evolução
 */
export interface EvolutionResult {
  newStage: EvolutionStage;
  capabilities: string[];
  improvements: string[];
  coherenceGain: number;
  adaptationEfficiency: number;
}

// ============ QUANTUM COHERENCE TYPES ============

/**
 * Quantum coherence state
 * Estado de coerência quântica
 */
export interface QuantumCoherenceState {
  superposition: boolean;
  entanglement: number;
  decoherenceRate: number;
  coherenceTime: number;
  quantumFidelity: number;
}

/**
 * Quantum coherence parameters
 * Parâmetros de coerência quântica
 */
export interface QuantumCoherenceParameters {
  targetCoherence: number;
  tolerance: number;
  optimizationStrategy: QuantumOptimizationStrategy;
  errorCorrection: boolean;
  faultTolerance: boolean;
}

/**
 * Quantum optimization strategies
 * Estratégias de otimização quântica
 */
export enum QuantumOptimizationStrategy {
  COHERENCE_MAXIMIZATION = 'coherence_maximization',
  DECOHERENCE_MINIMIZATION = 'decoherence_minimization',
  ENTANGLEMENT_OPTIMIZATION = 'entanglement_optimization',
  FAULT_TOLERANT = 'fault_tolerant',
  ADAPTIVE = 'adaptive'
}

/**
 * Quantum coherence measurement
 * Medição de coerência quântica
 */
export interface QuantumCoherenceMeasurement {
  timestamp: number;
  coherence: number;
  fidelity: number;
  entanglement: number;
  purity: number;
  confidence: number;
}

// ============ SYSTEM COHERENCE TYPES ============

/**
 * System coherence status
 * Status de coerência do sistema
 */
export interface SystemCoherenceStatus {
  overall: CoherenceLevel;
  components: ComponentCoherence[];
  metrics: CoherenceMetrics;
  trends: CoherenceTrend[];
  recommendations: string[];
}

/**
 * Coherence levels
 * Níveis de coerência
 */
export enum CoherenceLevel {
  CRITICAL = 'critical',
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  OPTIMAL = 'optimal'
}

/**
 * Component coherence
 * Coerência de componente
 */
export interface ComponentCoherence {
  id: string;
  name: string;
  type: string;
  coherence: number;
  status: CoherenceLevel;
  issues: CoherenceIssue[];
  lastUpdated: number;
}

/**
 * Coherence metrics
 * Métricas de coerência
 */
export interface CoherenceMetrics {
  overallCoherence: number;
  typeSafety: number;
  performance: number;
  security: number;
  maintainability: number;
  scalability: number;
  reliability: number;
}

/**
 * Coherence trend
 * Tendência de coerência
 */
export interface CoherenceTrend {
  metric: string;
  direction: TrendDirection;
  magnitude: number;
  timeframe: string;
  significance: number;
}

/**
 * Trend directions
 * Direções de tendência
 */
export enum TrendDirection {
  IMPROVING = 'improving',
  STABLE = 'stable',
  DECLINING = 'declining',
  FLUCTUATING = 'fluctuating'
}

// ============ TYPE SAFETY UTILITIES ============

/**
 * Type guard for coherent base
 * Type guard para base coerente
 */
export function isCoherentBase(obj: unknown): obj is CoherentBase {
  return typeof obj === 'object' && obj !== null &&
    'id' in obj && typeof obj.id === 'string' &&
    'timestamp' in obj && typeof obj.timestamp === 'number' &&
    'coherenceScore' in obj && typeof obj.coherenceScore === 'number' &&
    'version' in obj && typeof obj.version === 'string';
}

/**
 * Type guard for validatable coherence
 * Type guard para coerência validável
 */
export function isValidatableCoherence(obj: unknown): obj is ValidatableCoherence {
  return isCoherentBase(obj) &&
    'validateCoherence' in obj && typeof obj.validateCoherence === 'function' &&
    'optimizeCoherence' in obj && typeof obj.optimizeCoherence === 'function';
}

/**
 * Type guard for evolvable coherence
 * Type guard para coerência evoluível
 */
export function isEvolvableCoherence(obj: unknown): obj is EvolvableCoherence {
  return isCoherentBase(obj) &&
    'evolutionStage' in obj && Object.values(EvolutionStage).includes(obj.evolutionStage as EvolutionStage) &&
    'adapt' in obj && typeof obj.adapt === 'function' &&
    'evolve' in obj && typeof obj.evolve === 'function';
}

// ============ ZOD SCHEMAS FOR VALIDATION ============

/**
 * Zod schema for CoherentBase
 * Schema Zod para CoherentBase
 */
export const CoherentBaseSchema = z.object({
  id: z.string(),
  timestamp: z.number(),
  coherenceScore: z.number().min(0).max(1),
  metadata: z.record(z.unknown()),
  version: z.string()
});

/**
 * Zod schema for CoherenceIssue
 * Schema Zod para CoherenceIssue
 */
export const CoherenceIssueSchema = z.object({
  type: z.nativeEnum(CoherenceIssueType),
  severity: z.nativeEnum(CoherenceSeverity),
  message: z.string(),
  location: z.string(),
  suggestion: z.string()
});

/**
 * Zod schema for CoherenceValidationResult
 * Schema Zod para CoherenceValidationResult
 */
export const CoherenceValidationResultSchema = z.object({
  isValid: z.boolean(),
  score: z.number().min(0).max(1),
  issues: z.array(CoherenceIssueSchema),
  recommendations: z.array(z.string()),
  confidence: z.number().min(0).max(1)
});

/**
 * Zod schema for QuantumCoherenceState
 * Schema Zod para QuantumCoherenceState
 */
export const QuantumCoherenceStateSchema = z.object({
  superposition: z.boolean(),
  entanglement: z.number().min(0).max(1),
  decoherenceRate: z.number().min(0).max(1),
  coherenceTime: z.number().positive(),
  quantumFidelity: z.number().min(0).max(1)
});

// ============ UTILITY TYPES ============

/**
 * Deep partial type for nested objects
 * Tipo partial profundo para objetos aninhados
 */
export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

/**
 * Required fields from T
 * Campos obrigatórios de T
 */
export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;

/**
 * Optional fields from T
 * Campos opcionais de T
 */
export type OptionalFields<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

/**
 * Extract coherent entities from an array
 * Extrair entidades coerentes de um array
 */
export type CoherentEntities<T> = T extends CoherentBase ? T : never;

/**
 * Coherence score range
 * Intervalo de pontuação de coerência
 */
export type CoherenceScoreRange = [min: number, max: number];

/**
 * Coherence threshold levels
 * Níveis de limiar de coerência
 */
export interface CoherenceThresholds {
  critical: number;
  low: number;
  medium: number;
  high: number;
  optimal: number;
}

// ============ DEFAULT CONSTANTS ============

/**
 * Default coherence thresholds
 * Limiares de coerência padrão
 */
export const DEFAULT_COHERENCE_THRESHOLDS: CoherenceThresholds = {
  critical: 0.2,
  low: 0.4,
  medium: 0.6,
  high: 0.8,
  optimal: 0.95
};

/**
 * Default quantum coherence parameters
 * Parâmetros de coerência quântica padrão
 */
export const DEFAULT_QUANTUM_COHERENCE_PARAMETERS: QuantumCoherenceParameters = {
  targetCoherence: 0.85,
  tolerance: 0.1,
  optimizationStrategy: QuantumOptimizationStrategy.ADAPTIVE,
  errorCorrection: true,
  faultTolerance: true
};

/**
 * System version
 * Versão do sistema
 */
export const SYSTEM_VERSION = '1.0.0-coherent';

// ============ EXPORTS ============

// Re-export commonly used types and enums
// Re-exportar tipos e enums comumente usados
export type {
  CoherentBase,
  ValidatableCoherence,
  EvolvableCoherence,
  CoherenceValidationResult,
  CoherenceIssue,
  CoherenceOptimizationResult,
  OptimizationChange,
  AdaptationInput,
  AdaptationContext,
  AdaptationConstraint,
  AdaptationObjective,
  AdaptationResult,
  AdaptationChange,
  AdaptationMetric,
  EvolutionResult,
  QuantumCoherenceState,
  QuantumCoherenceParameters,
  QuantumCoherenceMeasurement,
  SystemCoherenceStatus,
  ComponentCoherence,
  CoherenceMetrics,
  CoherenceTrend,
  DeepPartial,
  RequiredFields,
  OptionalFields,
  CoherentEntities,
  CoherenceScoreRange,
  CoherenceThresholds
};

export {
  CoherentBaseSchema,
  CoherenceIssueSchema,
  CoherenceValidationResultSchema,
  QuantumCoherenceStateSchema,
  DEFAULT_COHERENCE_THRESHOLDS,
  DEFAULT_QUANTUM_COHERENCE_PARAMETERS,
  SYSTEM_VERSION
};