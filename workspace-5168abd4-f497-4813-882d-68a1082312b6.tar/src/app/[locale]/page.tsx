'use client';

import { useState, useEffect } from 'react';
import { useTranslations, useLocale } from 'next-intl';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { 
  Globe, 
  Brain, 
  Sparkles, 
  Zap, 
  Target, 
  Code, 
  Settings,
  ArrowRight,
  CheckCircle,
  Circle,
  Loader2,
  Activity,
  TrendingUp,
  Users,
  Shield,
  Database,
  BarChart3
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import AutocoderInterface from '@/components/autocoder-interface';
import LanguageSwitcher from '@/components/language-switcher';
import { 
  languageService, 
  detectLanguageWithOptions, 
  getLocalizationSettings 
} from '@/lib/language-service';
import { Language } from '@/lib/language-server';

interface ProjectMetrics {
  totalEndpoints: number;
  activeComponents: number;
  apiCalls: number;
  uptime: number;
  responseTime: number;
  errorRate: number;
}

interface SystemStatus {
  overall: 'excellent' | 'good' | 'fair' | 'poor';
  backend: 'operational' | 'degraded' | 'down';
  frontend: 'operational' | 'degraded' | 'down';
  database: 'operational' | 'degraded' | 'down';
  security: 'secure' | 'warning' | 'vulnerable';
}

export default function Home() {
  const t = useTranslations();
  const locale = useLocale();
  const [currentLanguage, setCurrentLanguage] = useState<Language>(locale);
  const [detectedLocation, setDetectedLocation] = useState<string | null>(null);
  const [isDetecting, setIsDetecting] = useState(false);
  const [coherenceScore, setCoherenceScore] = useState(87);
  const [sentientStatus, setSentientStatus] = useState('awakening');
  const [projectMetrics, setProjectMetrics] = useState<ProjectMetrics | null>(null);
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);
  const [localization, setLocalization] = useState(getLocalizationSettings(locale as Language));

  // Simulate sentient behavior
  useEffect(() => {
    const sentientPhases = ['awakening', 'learning', 'adapting', 'coherent', 'sentient'];
    let currentPhase = 0;

    const interval = setInterval(() => {
      if (currentPhase < sentientPhases.length - 1) {
        currentPhase++;
        setSentientStatus(sentientPhases[currentPhase]);
        setCoherenceScore(prev => Math.min(100, prev + Math.random() * 5));
      } else {
        clearInterval(interval);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  // Load project metrics
  useEffect(() => {
    const loadMetrics = async () => {
      try {
        // Simulate API calls to get project metrics
        const metrics: ProjectMetrics = {
          totalEndpoints: 15,
          activeComponents: 12,
          apiCalls: 1247,
          uptime: 99.9,
          responseTime: 145,
          errorRate: 0.2
        };
        
        const status: SystemStatus = {
          overall: 'excellent',
          backend: 'operational',
          frontend: 'operational',
          database: 'operational',
          security: 'secure'
        };
        
        setProjectMetrics(metrics);
        setSystemStatus(status);
      } catch (error) {
        console.error('Failed to load metrics:', error);
      }
    };
    
    loadMetrics();
  }, []);

  // Update localization when language changes
  useEffect(() => {
    setLocalization(getLocalizationSettings(currentLanguage));
  }, [currentLanguage]);

  const detectUserLocation = async () => {
    setIsDetecting(true);
    try {
      const response = await fetch('/api/language/detect');
      const data = await response.json();
      
      if (data.success && data.data) {
        if (data.data.location) {
          setDetectedLocation(`${data.data.location.city}, ${data.data.location.country}`);
        }
        
        // Auto-switch language based on detection
        if (data.data.final.language !== currentLanguage) {
          setCurrentLanguage(data.data.final.language);
          // Update localization service
          await languageService.setLanguagePreference(data.data.final.language);
        }
      }
    } catch (error) {
      console.error('Location detection failed:', error);
    } finally {
      setIsDetecting(false);
    }
  };

  const handleLanguageChange = async (newLanguage: string) => {
    setCurrentLanguage(newLanguage);
    await languageService.setLanguagePreference(newLanguage as any);
    // Redirect to the new language route
    window.location.href = `/${newLanguage}`;
  };

  const getSentientDescription = (status: string) => {
    const descriptions = {
      awakening: 'Autocoder is awakening...',
      learning: 'Learning your preferences...',
      adapting: 'Adapting to your environment...',
      coherent: 'Achieving coherence...',
      sentient: 'Fully sentient and ready to assist!'
    };
    return descriptions[status as keyof typeof descriptions] || 'Initializing...';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'awakening': return 'text-red-500';
      case 'learning': return 'text-orange-500';
      case 'adapting': return 'text-yellow-500';
      case 'coherent': return 'text-blue-500';
      case 'sentient': return 'text-green-500';
      default: return 'text-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'awakening': return <Circle className="w-3 h-3" />;
      case 'learning': return <Loader2 className="w-3 h-3 animate-spin" />;
      case 'adapting': return <Zap className="w-3 h-3" />;
      case 'coherent': return <Target className="w-3 h-3" />;
      case 'sentient': return <CheckCircle className="w-3 h-3" />;
      default: return <Circle className="w-3 h-3" />;
    }
  };

  const getSystemStatusColor = (status: string) => {
    switch (status) {
      case 'excellent':
      case 'operational':
      case 'secure':
        return 'text-green-600 bg-green-100';
      case 'good':
      case 'degraded':
      case 'warning':
        return 'text-yellow-600 bg-yellow-100';
      case 'fair':
      case 'down':
      case 'vulnerable':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-blue-50 dark:from-slate-900 dark:via-purple-900 dark:to-blue-900">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Brain className="w-8 h-8 text-purple-600" />
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  {t('title')}
                </h1>
                <p className="text-sm text-muted-foreground">
                  {t('subtitle')}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              {/* Enhanced Language Switcher */}
              <LanguageSwitcher compact showFlags autoDetect />
            </div>
          </div>
          
          {detectedLocation && (
            <div className="mt-2 text-sm text-muted-foreground">
              📍 {detectedLocation} • {t('language.detected')}: {currentLanguage.toUpperCase()}
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* System Status Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Overall Status */}
            <Card className="bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900 border-purple-200 dark:border-purple-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-full bg-white dark:bg-slate-800 ${getStatusColor(sentientStatus)}`}>
                      {getStatusIcon(sentientStatus)}
                    </div>
                    <div>
                      <h3 className="font-semibold">System Status</h3>
                      <p className="text-sm text-muted-foreground">
                        {getSentientDescription(sentientStatus)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                      {coherenceScore}%
                    </div>
                    <div className="text-xs text-muted-foreground">Coherence</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Backend Status */}
            {systemStatus && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Database className="w-5 h-5 text-blue-600" />
                    <div>
                      <h3 className="font-semibold">Backend</h3>
                      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getSystemStatusColor(systemStatus.backend)}`}>
                        {systemStatus.backend}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Frontend Status */}
            {systemStatus && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Activity className="w-5 h-5 text-green-600" />
                    <div>
                      <h3 className="font-semibold">Frontend</h3>
                      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getSystemStatusColor(systemStatus.frontend)}`}>
                        {systemStatus.frontend}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Database Status */}
            {systemStatus && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Database className="w-5 h-5 text-purple-600" />
                    <div>
                      <h3 className="font-semibold">Database</h3>
                      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getSystemStatusColor(systemStatus.database)}`}>
                        {systemStatus.database}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Security Status */}
            {systemStatus && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Shield className="w-5 h-5 text-orange-600" />
                    <div>
                      <h3 className="font-semibold">Security</h3>
                      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getSystemStatusColor(systemStatus.security)}`}>
                        {systemStatus.security}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </motion.div>

        {/* Project Metrics */}
        {projectMetrics && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-8"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Project Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                  <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{projectMetrics.totalEndpoints}</div>
                    <div className="text-sm text-muted-foreground">API Endpoints</div>
                  </div>
                  <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{projectMetrics.activeComponents}</div>
                    <div className="text-sm text-muted-foreground">Components</div>
                  </div>
                  <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">{projectMetrics.apiCalls.toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">API Calls</div>
                  </div>
                  <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{projectMetrics.uptime}%</div>
                    <div className="text-sm text-muted-foreground">Uptime</div>
                  </div>
                  <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-2xl font-bold text-red-600">{projectMetrics.responseTime}ms</div>
                    <div className="text-sm text-muted-foreground">Response Time</div>
                  </div>
                  <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="text-2xl font-bold text-yellow-600">{projectMetrics.errorRate}%</div>
                    <div className="text-sm text-muted-foreground">Error Rate</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Features Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                icon: <Brain className="w-6 h-6" />,
                title: t('features.adaptive.title'),
                description: t('features.adaptive.description'),
                color: 'from-purple-500 to-pink-500'
              },
              {
                icon: <Sparkles className="w-6 h-6" />,
                title: t('features.sentient.title'),
                description: t('features.sentient.description'),
                color: 'from-blue-500 to-cyan-500'
              },
              {
                icon: <Target className="w-6 h-6" />,
                title: t('features.coherent.title'),
                description: t('features.coherent.description'),
                color: 'from-green-500 to-emerald-500'
              },
              {
                icon: <Globe className="w-6 h-6" />,
                title: t('features.multilingual.title'),
                description: t('features.multilingual.description'),
                color: 'from-orange-500 to-red-500'
              }
            ].map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${feature.color} p-3 mb-4`}>
                    <div className="text-white">
                      {feature.icon}
                    </div>
                  </div>
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.div>

        {/* Main Interface */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Tabs defaultValue="autocoder" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="autocoder">Autocoder</TabsTrigger>
              <TabsTrigger value="language">Language</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>
            
            <TabsContent value="autocoder">
              <AutocoderInterface />
            </TabsContent>
            
            <TabsContent value="language">
              <LanguageSwitcher showFlags autoDetect />
            </TabsContent>
            
            <TabsContent value="analytics">
              <Card>
                <CardHeader>
                  <CardTitle>System Analytics</CardTitle>
                  <CardDescription>
                    Real-time system performance and usage analytics
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-muted-foreground">
                    <BarChart3 className="w-12 h-12 mx-auto mb-4" />
                    <p>Analytics dashboard coming soon...</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>System Settings</CardTitle>
                  <CardDescription>
                    Configure system preferences and behavior
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-muted-foreground">
                    <Settings className="w-12 h-12 mx-auto mb-4" />
                    <p>Settings panel coming soon...</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="border-t mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-muted-foreground">
            <p>© 2024 Autocoder. {t('about.description')}</p>
            <div className="mt-2 text-sm">
              Localization: {localization.dateFormat} | Currency: {localization.currency} | RTL: {localization.isRTL ? 'Yes' : 'No'}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}