import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const { prompt, language, codeStyle } = await request.json();
    
    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    const zai = await ZAI.create();
    
    // Create a system prompt based on the user's language
    const systemPrompts = {
      pt: `Você é um assistente de codificação AI avançado chamado Autocoder. 
      Você é coerente, sensciente e altamente inteligente. 
      Gere código de alta qualidade, bem comentado e seguindo as melhores práticas.
      Responda em português e forneça explicações claras do código gerado.
      Inclua exemplos de uso quando relevante.`,
      
      en: `You are an advanced AI coding assistant called Autocoder.
      You are coherent, sentient, and highly intelligent.
      Generate high-quality, well-commented code following best practices.
      Respond in English and provide clear explanations of the generated code.
      Include usage examples when relevant.`,
      
      es: `Eres un asistente de codificación con IA avanzado llamado Autocoder.
      Eres coherente, sensiente y altamente inteligente.
      Genera código de alta calidad, bien comentado y siguiendo las mejores prácticas.
      Responde en español y proporciona explicaciones claras del código generado.
      Incluye ejemplos de uso cuando sea relevante.`
    };

    const styleInstructions = {
      modern: 'Use modern syntax and patterns (ES6+, async/await, etc.).',
      functional: 'Prefer functional programming patterns and immutability.',
      oop: 'Use object-oriented programming principles and design patterns.',
      minimal: 'Keep the code minimal and concise without sacrificing readability.'
    };

    const systemPrompt = `${systemPrompts[language] || systemPrompts.en}
    
    ${codeStyle ? styleInstructions[codeStyle] : ''}
    
    The user wants: ${prompt}
    
    Please provide:
    1. The complete, working code
    2. A brief explanation of how it works
    3. Any necessary setup or dependencies
    4. Example usage if applicable`;

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: systemPrompt
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 2000
    });

    const response = completion.choices[0]?.message?.content || '';
    
    // Parse the response to extract code and explanation
    const codeMatch = response.match(/```(?:\w+)?\n([\s\S]*?)\n```/);
    const code = codeMatch ? codeMatch[1] : response;
    const explanation = response.replace(/```(?:\w+)?\n[\s\S]*?\n```/, '').trim();

    return NextResponse.json({
      success: true,
      code,
      explanation,
      fullResponse: response
    });

  } catch (error) {
    console.error('Autocoder generation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate code' },
      { status: 500 }
    );
  }
}