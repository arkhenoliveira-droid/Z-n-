import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { biometricData, environmentalData } = body;

    // Simulate coherence calculation algorithm
    const calculateCoherenceScore = (bio: any, env: any) => {
      // Weight factors for different parameters
      const weights = {
        heartRate: 0.2,
        focusLevel: 0.3,
        stressLevel: 0.25,
        energyLevel: 0.15,
        environment: 0.1
      };

      // Normalize values (0-100 scale)
      const normalizedHeartRate = Math.max(0, Math.min(100, 100 - Math.abs(bio.heartRate - 72) * 2));
      const normalizedFocus = bio.focusLevel || 75;
      const normalizedStress = Math.max(0, Math.min(100, 100 - (bio.stressLevel || 20) * 2));
      const normalizedEnergy = bio.energyLevel || 70;
      const normalizedEnvironment = env.quality || 80;

      // Calculate weighted score
      const score = 
        normalizedHeartRate * weights.heartRate +
        normalizedFocus * weights.focusLevel +
        normalizedStress * weights.stressLevel +
        normalizedEnergy * weights.energyLevel +
        normalizedEnvironment * weights.environment;

      return Math.round(score);
    };

    const coherenceScore = calculateCoherenceScore(biometricData, environmentalData);

    // Generate insights based on score
    const generateInsights = (score: number, bio: any, env: any) => {
      const insights = [];
      
      if (score >= 85) {
        insights.push({
          type: 'success',
          title: 'Optimal Coherence State',
          message: 'You are in an excellent state for focused work and collaboration.'
        });
      } else if (score >= 70) {
        insights.push({
          type: 'warning',
          title: 'Good Coherence',
          message: 'Your coherence is good, but there\'s room for improvement.'
        });
      } else {
        insights.push({
          type: 'error',
          title: 'Low Coherence',
          message: 'Consider taking a break or adjusting your environment.'
        });
      }

      // Specific recommendations
      if (bio.stressLevel > 30) {
        insights.push({
          type: 'info',
          title: 'Stress Management',
          message: 'Try breathing exercises or a short walk to reduce stress.'
        });
      }

      if (bio.focusLevel < 60) {
        insights.push({
          type: 'info',
          title: 'Focus Enhancement',
          message: 'Consider eliminating distractions or trying the Pomodoro technique.'
        });
      }

      if (env.lighting < 70) {
        insights.push({
          type: 'info',
          title: 'Lighting Optimization',
          message: 'Improve your workspace lighting for better focus and reduced eye strain.'
        });
      }

      return insights;
    };

    const insights = generateInsights(coherenceScore, biometricData, environmentalData);

    return NextResponse.json({
      success: true,
      data: {
        coherenceScore,
        insights,
        timestamp: new Date().toISOString(),
        processedData: {
          biometric: biometricData,
          environmental: environmentalData
        }
      }
    });

  } catch (error) {
    console.error('Coherence calculation error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to calculate coherence' },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    message: 'Coherence API is running',
    endpoints: {
      POST: '/api/coherence - Calculate coherence score',
      description: 'Accepts biometric and environmental data to calculate coherence score'
    }
  });
}