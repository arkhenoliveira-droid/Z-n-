import { redirect } from 'next/navigation';
import { defaultLanguage } from '@/lib/language-server';

export default async function Home() {
  // Redirect to default language
  redirect(`/${defaultLanguage}`);
}