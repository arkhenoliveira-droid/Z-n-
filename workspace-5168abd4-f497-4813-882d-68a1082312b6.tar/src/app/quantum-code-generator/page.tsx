'use client';

import { QuantumCodeGenerator } from '@/components/quantum-code-generator';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Code, Zap, Shield, Brain } from 'lucide-react';

export default function QuantumCodeGeneratorPage() {
  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Quantum Code Generator</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Advanced AI-powered code generation for quantum systems and applications
        </p>
        <div className="flex justify-center gap-2">
          <Badge variant="secondary">
            <Zap className="w-3 h-3 mr-1" />
            Quantum Ready
          </Badge>
          <Badge variant="secondary">
            <Shield className="w-3 h-3 mr-1" />
            Secure Generation
          </Badge>
          <Badge variant="secondary">
            <Brain className="w-3 h-3 mr-1" />
            AI Enhanced
          </Badge>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <QuantumCodeGenerator />
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5" />
                Features
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-sm space-y-2">
                <p>• Quantum algorithm generation</p>
                <p>• System architecture design</p>
                <p>• Security protocol implementation</p>
                <p>• Performance optimization</p>
                <p>• Error handling patterns</p>
                <p>• Documentation generation</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Example Prompts</CardTitle>
              <CardDescription>
                Try these example requests to see the generator in action
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Tabs defaultValue="quantum" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="quantum">Quantum</TabsTrigger>
                  <TabsTrigger value="system">System</TabsTrigger>
                  <TabsTrigger value="security">Security</TabsTrigger>
                </TabsList>
                <TabsContent value="quantum" className="space-y-2">
                  <div className="text-sm space-y-1">
                    <p className="font-medium">Quantum Circuit Implementation:</p>
                    <p className="text-muted-foreground">
                      "Create a quantum circuit for Grover's search algorithm with 4 qubits"
                    </p>
                  </div>
                </TabsContent>
                <TabsContent value="system" className="space-y-2">
                  <div className="text-sm space-y-1">
                    <p className="font-medium">System Architecture:</p>
                    <p className="text-muted-foreground">
                      "Design a distributed quantum computing system with load balancing"
                    </p>
                  </div>
                </TabsContent>
                <TabsContent value="security" className="space-y-2">
                  <div className="text-sm space-y-1">
                    <p className="font-medium">Security Protocol:</p>
                    <p className="text-muted-foreground">
                      "Implement quantum key distribution protocol with error correction"
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}