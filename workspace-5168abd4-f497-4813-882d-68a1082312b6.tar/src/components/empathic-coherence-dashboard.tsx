'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { 
  Brain, 
  Zap, 
  Activity, 
  Monitor, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Settings,
  RefreshCw,
  Play,
  Pause,
  Target
} from 'lucide-react';

interface CoherenceMetrics {
  overallCoherence: number;
  neuralSynchronization: number;
  quantumEntanglement: number;
  harmonicResonance: number;
  adaptiveLearning: number;
  environmentalFactors: number;
  timestamp: string;
}

interface SystemStatus {
  overallCoherence: number;
  quantumSystem: {
    active: boolean;
    coherenceLevel: number;
    entanglementStrength: number;
  };
  neuralSystem: {
    active: boolean;
    synchronizationLevel: number;
    phaseCoherence: number;
  };
  optimization: {
    active: boolean;
    currentStrategy: string;
    progress: number;
  };
  monitoring: {
    active: boolean;
    alerts: any[];
    lastUpdate: string;
  };
}

interface Alert {
  id: string;
  type: 'warning' | 'critical' | 'info';
  message: string;
  timestamp: string;
  resolved: boolean;
  coherenceLevel: number;
}

interface OptimizationResult {
  id: string;
  type: 'quantum' | 'neural' | 'harmonic' | 'adaptive';
  startTime: string;
  endTime: string;
  initialCoherence: number;
  finalCoherence: number;
  success: boolean;
  methods: string[];
  processingTime: number;
}

export function EmpathicCoherenceDashboard() {
  const [metrics, setMetrics] = useState<CoherenceMetrics | null>(null);
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [optimizationHistory, setOptimizationHistory] = useState<OptimizationResult[]>([]);
  const [recommendations, setRecommendations] = useState<string[]>([]);
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchInitialData();
    const interval = setInterval(fetchMetrics, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchInitialData = async () => {
    try {
      await Promise.all([
        fetchMetrics(),
        fetchStatus(),
        fetchAlerts(),
        fetchOptimizationHistory(),
        fetchRecommendations()
      ]);
    } catch (error) {
      console.error('Error fetching initial data:', error);
    }
  };

  const fetchMetrics = async () => {
    try {
      const response = await fetch('/api/empathic-coherence?action=analyze');
      const data = await response.json();
      if (data.success) {
        setMetrics(data.metrics);
      }
    } catch (error) {
      console.error('Error fetching metrics:', error);
    }
  };

  const fetchStatus = async () => {
    try {
      const response = await fetch('/api/empathic-coherence?action=monitoring-status');
      const data = await response.json();
      if (data.success) {
        setStatus(data.status);
        setIsMonitoring(data.status.monitoring.active);
      }
    } catch (error) {
      console.error('Error fetching status:', error);
    }
  };

  const fetchAlerts = async () => {
    try {
      const response = await fetch('/api/empathic-coherence?action=alerts');
      const data = await response.json();
      if (data.success) {
        setAlerts(data.alerts);
      }
    } catch (error) {
      console.error('Error fetching alerts:', error);
    }
  };

  const fetchOptimizationHistory = async () => {
    try {
      const response = await fetch('/api/empathic-coherence?action=optimization-history');
      const data = await response.json();
      if (data.success) {
        setOptimizationHistory(data.history);
      }
    } catch (error) {
      console.error('Error fetching optimization history:', error);
    }
  };

  const fetchRecommendations = async () => {
    try {
      const response = await fetch('/api/empathic-coherence?action=recommendations');
      const data = await response.json();
      if (data.success) {
        setRecommendations(data.recommendations);
      }
    } catch (error) {
      console.error('Error fetching recommendations:', error);
    }
  };

  const toggleMonitoring = async () => {
    setLoading(true);
    try {
      const action = isMonitoring ? 'stop-monitoring' : 'start-monitoring';
      const response = await fetch('/api/empathic-coherence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      });
      
      if (response.ok) {
        setIsMonitoring(!isMonitoring);
        await fetchStatus();
      }
    } catch (error) {
      console.error('Error toggling monitoring:', error);
    } finally {
      setLoading(false);
    }
  };

  const optimizeFor99Percent = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/empathic-coherence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'achieve-99-percent' })
      });
      
      if (response.ok) {
        await fetchInitialData();
      }
    } catch (error) {
      console.error('Error optimizing for 99%:', error);
    } finally {
      setLoading(false);
    }
  };

  const resolveAlert = async (alertId: string) => {
    try {
      const response = await fetch('/api/empathic-coherence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'resolve-alert', alertId })
      });
      
      if (response.ok) {
        await fetchAlerts();
      }
    } catch (error) {
      console.error('Error resolving alert:', error);
    }
  };

  const getCoherenceColor = (coherence: number): string => {
    if (coherence >= 0.99) return 'text-green-600';
    if (coherence >= 0.95) return 'text-blue-600';
    if (coherence >= 0.85) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getCoherenceLabel = (coherence: number): string => {
    if (coherence >= 0.99) return 'Perfect';
    if (coherence >= 0.95) return 'Excellent';
    if (coherence >= 0.85) return 'Good';
    if (coherence >= 0.75) return 'Fair';
    return 'Poor';
  };

  const formatTimestamp = (timestamp: string): string => {
    return new Date(timestamp).toLocaleTimeString();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Empathic Coherence Dashboard</h1>
          <p className="text-muted-foreground">
            Monitor and optimize empathic coherence levels above 99%
          </p>
        </div>
        <div className="flex space-x-2">
          <Button
            onClick={toggleMonitoring}
            disabled={loading}
            variant={isMonitoring ? "destructive" : "default"}
          >
            {isMonitoring ? <Pause className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}
            {isMonitoring ? 'Stop Monitoring' : 'Start Monitoring'}
          </Button>
          <Button
            onClick={optimizeFor99Percent}
            disabled={loading}
            variant="outline"
          >
            <Target className="mr-2 h-4 w-4" />
            Achieve 99%
          </Button>
          <Button
            onClick={fetchInitialData}
            disabled={loading}
            variant="outline"
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Main Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Coherence</CardTitle>
            <Brain className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics ? `${(metrics.overallCoherence * 100).toFixed(1)}%` : 'N/A'}
            </div>
            {metrics && (
              <>
                <p className={`text-xs ${getCoherenceColor(metrics.overallCoherence)}`}>
                  {getCoherenceLabel(metrics.overallCoherence)}
                </p>
                <Progress value={metrics.overallCoherence * 100} className="mt-2" />
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Quantum System</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {status ? `${(status.quantumSystem.coherenceLevel * 100).toFixed(1)}%` : 'N/A'}
            </div>
            {status && (
              <>
                <p className="text-xs text-muted-foreground">
                  {status.quantumSystem.active ? 'Active' : 'Inactive'}
                </p>
                <Progress value={status.quantumSystem.coherenceLevel * 100} className="mt-2" />
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Neural System</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {status ? `${(status.neuralSystem.synchronizationLevel * 100).toFixed(1)}%` : 'N/A'}
            </div>
            {status && (
              <>
                <p className="text-xs text-muted-foreground">
                  {status.neuralSystem.active ? 'Active' : 'Inactive'}
                </p>
                <Progress value={status.neuralSystem.synchronizationLevel * 100} className="mt-2" />
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monitoring Status</CardTitle>
            <Monitor className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {isMonitoring ? 'Active' : 'Inactive'}
            </div>
            <p className="text-xs text-muted-foreground">
              {status?.monitoring.lastUpdate ? 
                `Updated: ${formatTimestamp(status.monitoring.lastUpdate)}` : 
                'Not started'
              }
            </p>
            <Badge variant={isMonitoring ? "default" : "secondary"} className="mt-2">
              {isMonitoring ? 'Running' : 'Stopped'}
            </Badge>
          </CardContent>
        </Card>
      </div>

      {/* Alerts Section */}
      {alerts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="mr-2 h-5 w-5" />
              Active Alerts ({alerts.filter(a => !a.resolved).length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {alerts.filter(a => !a.resolved).map((alert) => (
                <Alert key={alert.id} className={alert.type === 'critical' ? 'border-red-200' : ''}>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="flex items-center justify-between">
                    <span>{alert.message}</span>
                    <div className="flex items-center space-x-2">
                      <Badge variant={alert.type === 'critical' ? 'destructive' : 'secondary'}>
                        {alert.type}
                      </Badge>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => resolveAlert(alert.id)}
                      >
                        Resolve
                      </Button>
                    </div>
                  </AlertDescription>
                </Alert>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Content Tabs */}
      <Tabs defaultValue="metrics" className="space-y-4">
        <TabsList>
          <TabsTrigger value="metrics">Detailed Metrics</TabsTrigger>
          <TabsTrigger value="optimization">Optimization</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="metrics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Coherence Components</CardTitle>
                <CardDescription>
                  Breakdown of coherence contributing factors
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {metrics && (
                  <>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Neural Synchronization</span>
                        <span>{(metrics.neuralSynchronization * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.neuralSynchronization * 100} />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Quantum Entanglement</span>
                        <span>{(metrics.quantumEntanglement * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.quantumEntanglement * 100} />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Harmonic Resonance</span>
                        <span>{(metrics.harmonicResonance * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.harmonicResonance * 100} />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Adaptive Learning</span>
                        <span>{(metrics.adaptiveLearning * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.adaptiveLearning * 100} />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Environmental Factors</span>
                        <span>{(metrics.environmentalFactors * 100).toFixed(1)}%</span>
                      </div>
                      <Progress value={metrics.environmentalFactors * 100} />
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>System Status</CardTitle>
                <CardDescription>
                  Current state of quantum and neural systems
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {status && (
                  <>
                    <div className="space-y-2">
                      <h4 className="font-semibold">Quantum System</h4>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Status: {status.quantumSystem.active ? 'Active' : 'Inactive'}</div>
                        <div>Coherence: {(status.quantumSystem.coherenceLevel * 100).toFixed(1)}%</div>
                        <div>Entanglement: {(status.quantumSystem.entanglementStrength * 100).toFixed(1)}%</div>
                      </div>
                    </div>
                    <Separator />
                    <div className="space-y-2">
                      <h4 className="font-semibold">Neural System</h4>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Status: {status.neuralSystem.active ? 'Active' : 'Inactive'}</div>
                        <div>Sync: {(status.neuralSystem.synchronizationLevel * 100).toFixed(1)}%</div>
                        <div>Phase: {(status.neuralSystem.phaseCoherence * 100).toFixed(1)}%</div>
                      </div>
                    </div>
                    <Separator />
                    <div className="space-y-2">
                      <h4 className="font-semibold">Optimization</h4>
                      <div className="text-sm">
                        <div>Status: {status.optimization.active ? 'Active' : 'Inactive'}</div>
                        {status.optimization.active && (
                          <div className="mt-2">
                            <div className="flex justify-between text-xs mb-1">
                              <span>{status.optimization.currentStrategy}</span>
                              <span>{status.optimization.progress.toFixed(0)}%</span>
                            </div>
                            <Progress value={status.optimization.progress} />
                          </div>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="optimization" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Optimization Controls</CardTitle>
              <CardDescription>
                Advanced optimization for achieving 99%+ coherence
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button
                  onClick={optimizeFor99Percent}
                  disabled={loading}
                  className="w-full"
                >
                  <Target className="mr-2 h-4 w-4" />
                  Optimize to 99%
                </Button>
                <Button
                  variant="outline"
                  className="w-full"
                  disabled={loading}
                >
                  <Zap className="mr-2 h-4 w-4" />
                  Quantum Boost
                </Button>
                <Button
                  variant="outline"
                  className="w-full"
                  disabled={loading}
                >
                  <Activity className="mr-2 h-4 w-4" />
                  Neural Sync
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Optimizations</CardTitle>
              <CardDescription>
                History of optimization attempts and results
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {optimizationHistory.slice(-5).map((opt) => (
                  <div key={opt.id} className="flex items-center justify-between p-2 border rounded">
                    <div className="flex items-center space-x-2">
                      {opt.success ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                      )}
                      <span className="text-sm font-medium">{opt.type}</span>
                    </div>
                    <div className="text-right text-sm">
                      <div className="font-medium">
                        {(opt.initialCoherence * 100).toFixed(1)}% → {(opt.finalCoherence * 100).toFixed(1)}%
                      </div>
                      <div className="text-muted-foreground">
                        {opt.processingTime}ms
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>System Recommendations</CardTitle>
              <CardDescription>
                AI-powered recommendations for improving coherence
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {recommendations.map((rec, index) => (
                  <Alert key={index}>
                    <TrendingUp className="h-4 w-4" />
                    <AlertDescription>{rec}</AlertDescription>
                  </Alert>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Full Optimization History</CardTitle>
              <CardDescription>
                Complete history of all optimization operations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {optimizationHistory.map((opt) => (
                  <div key={opt.id} className="p-3 border rounded">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        {opt.success ? (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        ) : (
                          <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        )}
                        <span className="font-medium">{opt.type}</span>
                        <Badge variant={opt.success ? "default" : "secondary"}>
                          {opt.success ? 'Success' : 'Partial'}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {formatTimestamp(opt.startTime)}
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="font-medium">Initial</div>
                        <div>{(opt.initialCoherence * 100).toFixed(1)}%</div>
                      </div>
                      <div>
                        <div className="font-medium">Final</div>
                        <div>{(opt.finalCoherence * 100).toFixed(1)}%</div>
                      </div>
                      <div>
                        <div className="font-medium">Duration</div>
                        <div>{opt.processingTime}ms</div>
                      </div>
                    </div>
                    <div className="mt-2">
                      <div className="text-xs text-muted-foreground">Methods:</div>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {opt.methods.map((method, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {method}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default EmpathicCoherenceDashboard;