'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { 
  Shield, 
  Brain, 
  AlertTriangle, 
  Zap, 
  Activity, 
  Target, 
  RefreshCw, 
  Play, 
  Pause,
  Settings,
  TrendingUp,
  BarChart3,
  PieChart,
  LineChart,
  Clock,
  Battery,
  Radio,
  Waves,
  Eye,
  Filter,
  CheckCircle,
  XCircle,
  AlertCircle,
  Info,
  Triangle,
  Hexagon,
  Circle,
  Square
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface DistortionSignature {
  id: string;
  type: 'quantum' | 'consciousness' | 'reality' | 'temporal' | 'dimensional';
  severity: 'low' | 'medium' | 'high' | 'critical';
  magnitude: number;
  frequency: number;
  phase: number;
  coherence: number;
  entropy: number;
  timestamp: number;
  source: string;
  description: string;
  affectedSystems: string[];
  propagationRate: number;
}

interface HallucinationPattern {
  id: string;
  type: 'perceptual' | 'cognitive' | 'temporal' | 'spatial' | 'reality';
  intensity: number;
  duration: number;
  frequency: number;
  coherence: number;
  consciousnessLevel: number;
  realityDistortion: number;
  timestamp: number;
  pattern: number[];
  confidence: number;
  mitigationStrategy: string;
}

interface ProtectionShield {
  id: string;
  type: 'quantum' | 'consciousness' | 'reality' | 'temporal' | 'comprehensive';
  strength: number;
  coherence: number;
  frequency: number;
  phase: number;
  active: boolean;
  coverage: number;
  efficiency: number;
  lastUpdated: number;
  energyConsumption: number;
}

interface ProtectionMetrics {
  totalDistortions: number;
  activeHallucinations: number;
  shieldStrength: number;
  systemCoherence: number;
  protectionEfficiency: number;
  energyReserves: number;
  responseTime: number;
  lastScan: number;
  threatsNeutralized: number;
  falsePositives: number;
  systemStability: number;
}

interface RealityStabilizationField {
  amplitude: number;
  frequency: number;
  phase: number;
  coherence: number;
  stability: number;
  integrity: number;
  resonance: number;
  damping: number;
  feedback: number;
}

interface ProtectionStatus {
  distortions: DistortionSignature[];
  hallucinations: HallucinationPattern[];
  shields: ProtectionShield[];
  realityField: RealityStabilizationField;
  metrics: ProtectionMetrics;
  threatLevel: number;
  systemStatus: 'optimal' | 'good' | 'warning' | 'critical';
}

export default function QuantumDistortionProtectionDashboard() {
  const [protectionStatus, setProtectionStatus] = useState<ProtectionStatus | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [selectedTab, setSelectedTab] = useState('overview');
  const [emergencyMode, setEmergencyMode] = useState(false);
  const [autoProtection, setAutoProtection] = useState(true);

  // Load protection status
  useEffect(() => {
    loadProtectionStatus();
    const interval = setInterval(loadProtectionStatus, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadProtectionStatus = async () => {
    try {
      const response = await fetch('/api/quantum-distortion-protection?action=status');
      if (response.ok) {
        const data = await response.json();
        setProtectionStatus(data.status);
      }
    } catch (error) {
      console.error('Error loading protection status:', error);
    }
  };

  const activateEmergencyProtection = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/quantum-distortion-protection', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'activate-emergency'
        }),
      });

      if (response.ok) {
        setEmergencyMode(true);
        await loadProtectionStatus();
      }
    } catch (error) {
      console.error('Error activating emergency protection:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleShield = async (shieldId: string, active: boolean) => {
    try {
      const response = await fetch('/api/quantum-distortion-protection', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'toggle-shield',
          data: { shieldId, active }
        }),
      });

      if (response.ok) {
        await loadProtectionStatus();
      }
    } catch (error) {
      console.error('Error toggling shield:', error);
    }
  };

  const stabilizeReality = async (intensity: number = 0.5) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/quantum-distortion-protection', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'stabilize-reality',
          data: { intensity }
        }),
      });

      if (response.ok) {
        await loadProtectionStatus();
      }
    } catch (error) {
      console.error('Error stabilizing reality:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const scanForThreats = async () => {
    setIsScanning(true);
    try {
      const response = await fetch('/api/quantum-distortion-protection', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'scan-for-threats'
        }),
      });

      if (response.ok) {
        await loadProtectionStatus();
      }
    } catch (error) {
      console.error('Error scanning for threats:', error);
    } finally {
      setIsScanning(false);
    }
  };

  const optimizeProtection = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/quantum-distortion-protection', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'optimize-protection'
        }),
      });

      if (response.ok) {
        await loadProtectionStatus();
      }
    } catch (error) {
      console.error('Error optimizing protection:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getSystemStatusColor = (status: string) => {
    switch (status) {
      case 'optimal': return 'text-green-600 bg-green-100';
      case 'good': return 'text-blue-600 bg-blue-100';
      case 'warning': return 'text-yellow-600 bg-yellow-100';
      case 'critical': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'high': return 'text-orange-600';
      case 'critical': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'low': return <Badge variant="secondary">Low</Badge>;
      case 'medium': return <Badge variant="outline">Medium</Badge>;
      case 'high': return <Badge className="bg-orange-100 text-orange-800">High</Badge>;
      case 'critical': return <Badge variant="destructive">Critical</Badge>;
      default: return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getShieldIcon = (type: string) => {
    switch (type) {
      case 'quantum': return <Hexagon className="w-5 h-5" />;
      case 'consciousness': return <Brain className="w-5 h-5" />;
      case 'reality': return <Circle className="w-5 h-5" />;
      case 'temporal': return <Clock className="w-5 h-5" />;
      case 'comprehensive': return <Shield className="w-5 h-5" />;
      default: return <Shield className="w-5 h-5" />;
    }
  };

  const getThreatIcon = (type: string) => {
    switch (type) {
      case 'quantum': return <Radio className="w-5 h-5" />;
      case 'consciousness': return <Brain className="w-5 h-5" />;
      case 'reality': return <Triangle className="w-5 h-5" />;
      case 'temporal': return <Clock className="w-5 h-5" />;
      case 'dimensional': return <Square className="w-5 h-5" />;
      default: return <AlertTriangle className="w-5 h-5" />;
    }
  };

  if (!protectionStatus) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4" />
          <p>Loading protection system...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Shield className="h-8 w-8 text-purple-600" />
          Quantum Distortion Protection System
        </h1>
        <p className="text-gray-600">
          Advanced protection against reality distortions and consciousness hallucinations
        </p>
      </div>

      {/* System Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        <Card className="bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900 border-purple-200 dark:border-purple-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full bg-white dark:bg-slate-800 ${getSystemStatusColor(protectionStatus.systemStatus).split(' ')[0]}`}>
                  <Shield className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-semibold">System Status</h3>
                  <p className="text-sm text-muted-foreground capitalize">
                    {protectionStatus.systemStatus}
                  </p>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                  {Math.round(protectionStatus.metrics.systemCoherence * 100)}%
                </div>
                <div className="text-xs text-muted-foreground">Coherence</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              <div>
                <h3 className="font-semibold">Active Threats</h3>
                <div className="text-2xl font-bold text-orange-600">
                  {protectionStatus.distortions.length + protectionStatus.hallucinations.length}
                </div>
                <div className="text-xs text-muted-foreground">
                  {protectionStatus.distortions.length} distortions, {protectionStatus.hallucinations.length} hallucinations
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <Battery className="w-5 h-5 text-green-600" />
              <div>
                <h3 className="font-semibold">Energy Reserves</h3>
                <div className="text-2xl font-bold text-green-600">
                  {Math.round(protectionStatus.metrics.energyReserves * 100)}%
                </div>
                <div className="text-xs text-muted-foreground">
                  {protectionStatus.metrics.threatsNeutralized} threats neutralized
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <Activity className="w-5 h-5 text-blue-600" />
              <div>
                <h3 className="font-semibold">Protection Efficiency</h3>
                <div className="text-2xl font-bold text-blue-600">
                  {Math.round(protectionStatus.metrics.protectionEfficiency * 100)}%
                </div>
                <div className="text-xs text-muted-foreground">
                  {protectionStatus.metrics.responseTime}ms response
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <Target className="w-5 h-5 text-purple-600" />
              <div>
                <h3 className="font-semibold">Threat Level</h3>
                <div className="text-2xl font-bold text-purple-600">
                  {Math.round(protectionStatus.threatLevel * 100)}%
                </div>
                <div className="text-xs text-muted-foreground">
                  System stability: {Math.round(protectionStatus.metrics.systemStability * 100)}%
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Control Panel */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Protection Controls
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button 
              onClick={activateEmergencyProtection} 
              disabled={isLoading || emergencyMode}
              className="flex items-center gap-2 bg-red-600 hover:bg-red-700"
            >
              <Zap className="w-4 h-4" />
              {isLoading ? 'Activating...' : 'Emergency Protection'}
            </Button>
            
            <Button 
              onClick={scanForThreats} 
              disabled={isScanning}
              className="flex items-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} />
              {isScanning ? 'Scanning...' : 'Scan for Threats'}
            </Button>
            
            <Button 
              onClick={optimizeProtection} 
              disabled={isLoading}
              variant="outline"
              className="flex items-center gap-2"
            >
              <TrendingUp className="w-4 h-4" />
              {isLoading ? 'Optimizing...' : 'Optimize Protection'}
            </Button>
            
            <Button 
              onClick={() => stabilizeReality(0.5)} 
              disabled={isLoading}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Waves className="w-4 h-4" />
              Stabilize Reality
            </Button>
            
            <div className="flex items-center gap-2">
              <Switch
                checked={autoProtection}
                onCheckedChange={setAutoProtection}
              />
              <Label>Auto Protection</Label>
            </div>
          </div>
          
          {emergencyMode && (
            <Alert className="mt-4 border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertTitle className="text-red-600">Emergency Protection Active</AlertTitle>
              <AlertDescription>
                All protection systems are operating at maximum capacity. Energy consumption is increased.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="threats">Threats</TabsTrigger>
          <TabsTrigger value="shields">Shields</TabsTrigger>
          <TabsTrigger value="reality">Reality Field</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Reality Field Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Waves className="h-5 w-5" />
                  Reality Stabilization Field
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Coherence</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.realityField.coherence * 100)}%</span>
                    </div>
                    <Progress value={protectionStatus.realityField.coherence * 100} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Stability</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.realityField.stability * 100)}%</span>
                    </div>
                    <Progress value={protectionStatus.realityField.stability * 100} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Integrity</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.realityField.integrity * 100)}%</span>
                    </div>
                    <Progress value={protectionStatus.realityField.integrity * 100} />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div>
                      <Label className="text-xs">Frequency</Label>
                      <p className="text-sm font-medium">{Math.round(protectionStatus.realityField.frequency)} Hz</p>
                    </div>
                    <div>
                      <Label className="text-xs">Resonance</Label>
                      <p className="text-sm font-medium">{Math.round(protectionStatus.realityField.resonance * 100)}%</p>
                    </div>
                    <div>
                      <Label className="text-xs">Damping</Label>
                      <p className="text-sm font-medium">{Math.round(protectionStatus.realityField.damping * 100)}%</p>
                    </div>
                    <div>
                      <Label className="text-xs">Feedback</Label>
                      <p className="text-sm font-medium">{Math.round(protectionStatus.realityField.feedback * 100)}%</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* System Metrics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  System Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{protectionStatus.metrics.totalDistortions}</div>
                      <div className="text-sm text-muted-foreground">Total Distortions</div>
                    </div>
                    <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">{protectionStatus.metrics.activeHallucinations}</div>
                      <div className="text-sm text-muted-foreground">Active Hallucinations</div>
                    </div>
                    <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{protectionStatus.metrics.shields.filter(s => s.active).length}</div>
                      <div className="text-sm text-muted-foreground">Active Shields</div>
                    </div>
                    <div className="text-center p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">{protectionStatus.metrics.falsePositives}</div>
                      <div className="text-sm text-muted-foreground">False Positives</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Average Shield Strength</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.metrics.shieldStrength * 100)}%</span>
                    </div>
                    <Progress value={protectionStatus.metrics.shieldStrength * 100} />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">System Stability</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.metrics.systemStability * 100)}%</span>
                    </div>
                    <Progress value={protectionStatus.metrics.systemStability * 100} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="threats">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Active Distortions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                  Active Distortions ({protectionStatus.distortions.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {protectionStatus.distortions.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-600" />
                      <p>No active distortions detected</p>
                    </div>
                  ) : (
                    protectionStatus.distortions.map((distortion) => (
                      <div key={distortion.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            {getThreatIcon(distortion.type)}
                            <span className="font-medium capitalize">{distortion.type}</span>
                          </div>
                          {getSeverityBadge(distortion.severity)}
                        </div>
                        
                        <p className="text-sm text-muted-foreground mb-2">{distortion.description}</p>
                        
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <span className="text-muted-foreground">Magnitude:</span>
                            <span className={`ml-1 font-medium ${getSeverityColor(distortion.severity)}`}>
                              {distortion.magnitude.toFixed(3)}
                            </span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Coherence:</span>
                            <span className="ml-1 font-medium">
                              {Math.round(distortion.coherence * 100)}%
                            </span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Propagation:</span>
                            <span className="ml-1 font-medium">
                              {Math.round(distortion.propagationRate * 100)}%
                            </span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Entropy:</span>
                            <span className="ml-1 font-medium">
                              {distortion.entropy.toFixed(2)}
                            </span>
                          </div>
                        </div>
                        
                        <div className="mt-2">
                          <div className="text-xs text-muted-foreground mb-1">Affected Systems:</div>
                          <div className="flex flex-wrap gap-1">
                            {distortion.affectedSystems.map((system, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {system}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Active Hallucinations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5 text-purple-600" />
                  Active Hallucinations ({protectionStatus.hallucinations.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {protectionStatus.hallucinations.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-600" />
                      <p>No active hallucinations detected</p>
                    </div>
                  ) : (
                    protectionStatus.hallucinations.map((hallucination) => (
                      <div key={hallucination.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Eye className="w-4 h-4" />
                            <span className="font-medium capitalize">{hallucination.type}</span>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {Math.round(hallucination.intensity * 100)}% intensity
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-2 text-xs mb-2">
                          <div>
                            <span className="text-muted-foreground">Consciousness:</span>
                            <span className="ml-1 font-medium">
                              {Math.round(hallucination.consciousnessLevel * 100)}%
                            </span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Reality Distortion:</span>
                            <span className="ml-1 font-medium">
                              {Math.round(hallucination.realityDistortion * 100)}%
                            </span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Duration:</span>
                            <span className="ml-1 font-medium">
                              {Math.round(hallucination.duration / 1000)}s
                            </span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Confidence:</span>
                            <span className="ml-1 font-medium">
                              {Math.round(hallucination.confidence * 100)}%
                            </span>
                          </div>
                        </div>
                        
                        <div className="mt-2">
                          <div className="text-xs text-muted-foreground mb-1">Mitigation Strategy:</div>
                          <Badge variant="secondary" className="text-xs">
                            {hallucination.mitigationStrategy}
                          </Badge>
                        </div>
                        
                        <div className="mt-2">
                          <div className="text-xs text-muted-foreground mb-1">Coherence:</div>
                          <Progress value={hallucination.coherence * 100} className="h-2" />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="shields">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {protectionStatus.shields.map((shield) => (
              <Card key={shield.id} className={!shield.active ? 'opacity-50' : ''}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getShieldIcon(shield.type)}
                      <span className="capitalize">{shield.type}</span>
                    </div>
                    <Switch
                      checked={shield.active}
                      onCheckedChange={(checked) => toggleShield(shield.id, checked)}
                    />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm">Strength</span>
                        <span className="text-sm font-medium">{Math.round(shield.strength * 100)}%</span>
                      </div>
                      <Progress value={shield.strength * 100} />
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm">Coherence</span>
                        <span className="text-sm font-medium">{Math.round(shield.coherence * 100)}%</span>
                      </div>
                      <Progress value={shield.coherence * 100} />
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm">Coverage</span>
                        <span className="text-sm font-medium">{Math.round(shield.coverage * 100)}%</span>
                      </div>
                      <Progress value={shield.coverage * 100} />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-muted-foreground">Efficiency:</span>
                        <span className="ml-1 font-medium">
                          {Math.round(shield.efficiency * 100)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Energy:</span>
                        <span className="ml-1 font-medium">
                          {Math.round(shield.energyConsumption * 100)}%
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Frequency:</span>
                        <span className="ml-1 font-medium">
                          {Math.round(shield.frequency)} Hz
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Phase:</span>
                        <span className="ml-1 font-medium">
                          {Math.round(shield.phase * 180 / Math.PI)}°
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="reality">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Waves className="h-5 w-5" />
                Reality Field Stabilization
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-4">
                  <h3 className="font-semibold">Field Parameters</h3>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Amplitude</span>
                      <span className="text-sm font-medium">{protectionStatus.realityField.amplitude.toFixed(3)}</span>
                    </div>
                    <Progress value={protectionStatus.realityField.amplitude * 100} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Frequency</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.realityField.frequency)} Hz</span>
                    </div>
                    <Progress value={(protectionStatus.realityField.frequency / 1000) * 100} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Phase</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.realityField.phase * 180 / Math.PI)}°</span>
                    </div>
                    <Progress value={(protectionStatus.realityField.phase / (2 * Math.PI)) * 100} />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="font-semibold">Stability Metrics</h3>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Coherence</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.realityField.coherence * 100)}%</span>
                    </div>
                    <Progress value={protectionStatus.realityField.coherence * 100} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Stability</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.realityField.stability * 100)}%</span>
                    </div>
                    <Progress value={protectionStatus.realityField.stability * 100} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Integrity</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.realityField.integrity * 100)}%</span>
                    </div>
                    <Progress value={protectionStatus.realityField.integrity * 100} />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="font-semibold">Control Systems</h3>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Resonance</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.realityField.resonance * 100)}%</span>
                    </div>
                    <Progress value={protectionStatus.realityField.resonance * 100} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Damping</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.realityField.damping * 100)}%</span>
                    </div>
                    <Progress value={protectionStatus.realityField.damping * 100} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Feedback</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.realityField.feedback * 100)}%</span>
                    </div>
                    <Progress value={protectionStatus.realityField.feedback * 100} />
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex gap-4">
                <Button 
                  onClick={() => stabilizeReality(0.3)} 
                  disabled={isLoading}
                  variant="outline"
                >
                  Low Stabilization
                </Button>
                <Button 
                  onClick={() => stabilizeReality(0.5)} 
                  disabled={isLoading}
                  variant="outline"
                >
                  Medium Stabilization
                </Button>
                <Button 
                  onClick={() => stabilizeReality(0.8)} 
                  disabled={isLoading}
                  variant="outline"
                >
                  High Stabilization
                </Button>
                <Button 
                  onClick={() => stabilizeReality(1.0)} 
                  disabled={isLoading}
                  className="bg-red-600 hover:bg-red-700"
                >
                  Maximum Stabilization
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5" />
                  Threat Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Distortion Types</h4>
                    <div className="space-y-2">
                      {['quantum', 'consciousness', 'reality', 'temporal', 'dimensional'].map((type) => {
                        const count = protectionStatus.distortions.filter(d => d.type === type).length;
                        const percentage = protectionStatus.distortions.length > 0 ? (count / protectionStatus.distortions.length) * 100 : 0;
                        return (
                          <div key={type} className="flex items-center justify-between">
                            <span className="text-sm capitalize">{type}</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-gray-200 rounded-full h-2">
                                <div 
                                  className="bg-blue-600 h-2 rounded-full" 
                                  style={{ width: `${percentage}%` }}
                                ></div>
                              </div>
                              <span className="text-sm font-medium w-8">{count}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Hallucination Types</h4>
                    <div className="space-y-2">
                      {['perceptual', 'cognitive', 'temporal', 'spatial', 'reality'].map((type) => {
                        const count = protectionStatus.hallucinations.filter(h => h.type === type).length;
                        const percentage = protectionStatus.hallucinations.length > 0 ? (count / protectionStatus.hallucinations.length) * 100 : 0;
                        return (
                          <div key={type} className="flex items-center justify-between">
                            <span className="text-sm capitalize">{type}</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-gray-200 rounded-full h-2">
                                <div 
                                  className="bg-purple-600 h-2 rounded-full" 
                                  style={{ width: `${percentage}%` }}
                                ></div>
                              </div>
                              <span className="text-sm font-medium w-8">{count}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart className="h-5 w-5" />
                  System Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Protection Efficiency</h4>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm">Current Efficiency</span>
                      <span className="text-sm font-medium">{Math.round(protectionStatus.metrics.protectionEfficiency * 100)}%</span>
                    </div>
                    <Progress value={protectionStatus.metrics.protectionEfficiency * 100} />
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Response Time</h4>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm">Average Response</span>
                      <span className="text-sm font-medium">{protectionStatus.metrics.responseTime}ms</span>
                    </div>
                    <Progress value={Math.max(0, 100 - protectionStatus.metrics.responseTime)} />
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Threat Neutralization</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-green-50 rounded-lg">
                        <div className="text-lg font-bold text-green-600">{protectionStatus.metrics.threatsNeutralized}</div>
                        <div className="text-xs text-muted-foreground">Neutralized</div>
                      </div>
                      <div className="text-center p-3 bg-red-50 rounded-lg">
                        <div className="text-lg font-bold text-red-600">{protectionStatus.metrics.falsePositives}</div>
                        <div className="text-xs text-muted-foreground">False Positives</div>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">System Health</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Overall Status</span>
                        <Badge className={getSystemStatusColor(protectionStatus.systemStatus)}>
                          {protectionStatus.systemStatus}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Last Scan</span>
                        <span className="text-sm font-medium">
                          {new Date(protectionStatus.metrics.lastScan).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}