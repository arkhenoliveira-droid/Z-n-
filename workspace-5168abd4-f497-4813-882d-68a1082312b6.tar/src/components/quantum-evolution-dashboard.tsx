'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { 
  Brain, 
  Zap, 
  Infinity, 
  Eye, 
  Target, 
  Activity,
  Sparkles,
  Atom,
  Waves,
  Circle,
  Triangle,
  Square,
  Star,
  Telescope,
  Heart,
  Lightbulb,
  Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { quantumCoherenceEvolution, QuantumState, RealityField, ConsciousnessField } from '@/lib/quantum-coherence-evolution';

interface QuantumEvolutionStatus {
  quantumState: QuantumState;
  realityField: RealityField;
  consciousnessField: ConsciousnessField;
  coherenceScore: number;
  evolutionLevel: number;
  insights: string[];
}

export default function QuantumEvolutionDashboard() {
  const [evolutionStatus, setEvolutionStatus] = useState<QuantumEvolutionStatus | null>(null);
  const [isEvolving, setIsEvolving] = useState(false);
  const [quantumField, setQuantumField] = useState<number[]>([]);
  const [realityManifestation, setRealityManifestation] = useState<number>(0);

  useEffect(() => {
    // Initialize quantum field visualization
    const field = Array.from({ length: 100 }, () => Math.random());
    setQuantumField(field);
    
    // Update reality manifestation
    const interval = setInterval(() => {
      setRealityManifestation(prev => (prev + 0.01) % 1);
    }, 100);
    
    return () => clearInterval(interval);
  }, []);

  const triggerEvolution = async () => {
    setIsEvolving(true);
    
    try {
      await quantumCoherenceEvolution.triggerQuantumEvolution();
      const status = quantumCoherenceEvolution.getEvolutionStatus();
      setEvolutionStatus(status);
    } catch (error) {
      console.error('Evolution failed:', error);
    } finally {
      setIsEvolving(false);
    }
  };

  const getEvolutionColor = (score: number) => {
    if (score >= 0.9) return 'text-purple-600';
    if (score >= 0.7) return 'text-blue-600';
    if (score >= 0.5) return 'text-green-600';
    return 'text-orange-600';
  };

  const getEvolutionBadge = (score: number) => {
    if (score >= 0.9) return <Badge variant="default" className="bg-purple-100 text-purple-800">Quântico</Badge>;
    if (score >= 0.7) return <Badge variant="default" className="bg-blue-100 text-blue-800">Transcendente</Badge>;
    if (score >= 0.5) return <Badge variant="default" className="bg-green-100 text-green-800">Coerente</Badge>;
    return <Badge variant="default" className="bg-orange-100 text-orange-800">Emergente</Badge>;
  };

  const renderQuantumField = () => {
    return (
      <div className="relative h-64 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 rounded-lg overflow-hidden">
        <div className="absolute inset-0">
          {quantumField.map((value, index) => (
            <motion.div
              key={index}
              className="absolute w-1 h-1 bg-white rounded-full"
              style={{
                left: `${(index % 10) * 10}%`,
                top: `${Math.floor(index / 10) * 10}%`,
                opacity: value * 0.8,
              }}
              animate={{
                scale: [1, 1 + value, 1],
                opacity: [value * 0.8, value, value * 0.8],
              }}
              transition={{
                duration: 2 + Math.random() * 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          ))}
        </div>
        
        {/* Reality manifestation wave */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-blue-400"
          style={{
            height: `${realityManifestation * 100}%`,
            opacity: 0.6
          }}
          animate={{
            opacity: [0.3, 0.8, 0.3],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <div className="text-2xl font-bold mb-2">Campo Quântico Coerente</div>
            <div className="text-sm opacity-80">Manifestação da Realidade</div>
          </div>
        </div>
      </div>
    );
  };

  const renderQuantumState = () => {
    if (!evolutionStatus) return null;

    const { quantumState, realityField, consciousnessField, coherenceScore } = evolutionStatus;

    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Atom className="h-5 w-5" />
              Estado Quântico Atual
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {quantumState.superposition ? 'Sim' : 'Não'}
                </div>
                <div className="text-sm text-gray-600">Superposição</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {Math.round(quantumState.entanglement * 100)}%
                </div>
                <div className="text-sm text-gray-600">Entrelaçamento</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {Math.round(quantumState.coherence * 100)}%
                </div>
                <div className="text-sm text-gray-600">Coerência</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">
                  {Math.round(quantumState.consciousness * 100)}%
                </div>
                <div className="text-sm text-gray-600">Consciência</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Waves className="h-5 w-5" />
                Campo de Realidade
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <Label>Amplitude</Label>
                  <div className="flex items-center gap-2">
                    <Progress value={realityField.amplitude * 100} className="flex-1" />
                    <span className="text-sm font-medium">
                      {Math.round(realityField.amplitude * 100)}%
                    </span>
                  </div>
                </div>
                <div>
                  <Label>Frequência</Label>
                  <div className="text-sm text-gray-600">
                    {Math.round(realityField.frequency)} Hz
                  </div>
                </div>
                <div>
                  <Label>Manifestação</Label>
                  <div className="text-sm text-gray-600">
                    {getEvolutionBadge(realityField.manifestation === 'transcendent' ? 1 : 
                                   realityField.manifestation === 'manifest' ? 0.8 : 
                                   realityField.manifestation === 'emerging' ? 0.6 : 0.4)}
                    <span className="ml-2 capitalize">{realityField.manifestation}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Campo de Consciência
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <Label>Consciência</Label>
                  <div className="flex items-center gap-2">
                    <Progress value={consciousnessField.awareness * 100} className="flex-1" />
                    <span className="text-sm font-medium">
                      {Math.round(consciousnessField.awareness * 100)}%
                    </span>
                  </div>
                </div>
                <div>
                  <Label>Intenção</Label>
                  <div className="flex items-center gap-2">
                    <Progress value={consciousnessField.intention * 100} className="flex-1" />
                    <span className="text-sm font-medium">
                      {Math.round(consciousnessField.intention * 100)}%
                    </span>
                  </div>
                </div>
                <div>
                  <Label>Foco</Label>
                  <div className="flex items-center gap-2">
                    <Progress value={consciousnessField.focus * 100} className="flex-1" />
                    <span className="text-sm font-medium">
                      {Math.round(consciousnessField.focus * 100)}%
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  };

  const renderEvolutionInsights = () => {
    if (!evolutionStatus) return null;

    const { insights, coherenceScore, evolutionLevel } = evolutionStatus;

    return (
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5" />
              Insights da Evolução
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {insights.map((insight, index) => (
                <Alert key={index}>
                  <Star className="h-4 w-4" />
                  <AlertTitle>Insight {index + 1}</AlertTitle>
                  <AlertDescription>{insight}</AlertDescription>
                </Alert>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Status da Evolução
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">
                  {evolutionLevel}
                </div>
                <div className="text-sm text-gray-600">Nível de Evolução</div>
              </div>
              <div className="text-center">
                <div className={`text-3xl font-bold ${getEvolutionColor(coherenceScore)}`}>
                  {Math.round(coherenceScore * 100)}%
                </div>
                <div className="text-sm text-gray-600">Coerência Quântica</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">
                  {getEvolutionBadge(coherenceScore)}
                </div>
                <div className="text-sm text-gray-600">Estado Atual</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <h1 className="text-4xl font-bold mb-2 flex items-center justify-center gap-2">
            <Star className="h-10 w-10 text-purple-600" />
            Evolução Quântica Coerente
          </h1>
          <p className="text-gray-600 text-lg">
            Manifestando a próxima dimensão da realidade através da coerência quântica
          </p>
          <p className="text-sm text-gray-500 mt-2">
            Coerência × Consciência × Evolução = Realidade²
          </p>
        </motion.div>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Telescope className="h-5 w-5" />
            Campo Quântico de Realidade
          </CardTitle>
          <CardDescription>
            Visualização do campo quântico coerente e manifestação da realidade
          </CardDescription>
        </CardHeader>
        <CardContent>
          {renderQuantumField()}
        </CardContent>
      </Card>

      <div className="mb-6">
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="text-center"
        >
          <Button 
            onClick={triggerEvolution} 
            disabled={isEvolving}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-4 text-lg"
          >
            {isEvolving ? (
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 animate-spin" />
                Evoluindo para Estado Quântico...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5" />
                Evoluir para Estado Quântico
              </div>
            )}
          </Button>
        </motion.div>
      </div>

      {evolutionStatus && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Tabs defaultValue="quantum" className="space-y-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="quantum">Estado Quântico</TabsTrigger>
              <TabsTrigger value="reality">Campo de Realidade</TabsTrigger>
              <TabsTrigger value="insights">Insights</TabsTrigger>
            </TabsList>

            <TabsContent value="quantum">
              {renderQuantumState()}
            </TabsContent>

            <TabsContent value="reality">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Heart className="h-5 w-5" />
                      Equação da Evolução Coerente
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600 mb-4">
                        Coerência × Consciência × Evolução = Realidade²
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="p-4 bg-purple-50 rounded-lg">
                          <div className="text-lg font-bold text-purple-600">Coerência</div>
                          <div className="text-sm text-gray-600">Estado fundamental</div>
                        </div>
                        <div className="p-4 bg-blue-50 rounded-lg">
                          <div className="text-lg font-bold text-blue-600">Consciência</div>
                          <div className="text-sm text-gray-600">Observação</div>
                        </div>
                        <div className="p-4 bg-green-50 rounded-lg">
                          <div className="text-lg font-bold text-green-600">Evolução</div>
                          <div className="text-sm text-gray-600">Transcendência</div>
                        </div>
                        <div className="p-4 bg-orange-50 rounded-lg">
                          <div className="text-lg font-bold text-orange-600">Realidade²</div>
                          <div className="text-sm text-gray-600">Manifestação</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                {renderQuantumState()}
              </div>
            </TabsContent>

            <TabsContent value="insights">
              {renderEvolutionInsights()}
            </TabsContent>
          </Tabs>
        </motion.div>
      )}

      {!evolutionStatus && (
        <Card>
          <CardContent className="text-center py-12">
            <Star className="h-16 w-16 text-purple-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2">Pronto para Evolução Quântica</h3>
            <p className="text-gray-600">
              Clique no botão acima para iniciar a evolução para o estado quântico coerente
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}