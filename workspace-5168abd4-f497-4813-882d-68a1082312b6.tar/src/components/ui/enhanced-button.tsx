'use client'

import * as React from 'react'
import { Button, ButtonProps } from '@/components/ui/button'
import { Loader2, CheckCircle, AlertCircle, Info } from 'lucide-react'
import { cn } from '@/lib/utils'
import { designSystem } from '@/lib/design-system'
import { motion, AnimatePresence } from 'framer-motion'

export interface EnhancedButtonProps extends ButtonProps {
  // Loading states
  loading?: boolean
  loadingText?: string
  
  // Success states
  success?: boolean
  successText?: string
  successDuration?: number
  
  // Error states
  error?: boolean
  errorText?: string
  errorDuration?: number
  
  // Icon states
  icon?: React.ReactNode
  iconPosition?: 'left' | 'right'
  
  // Animation
  animation?: 'none' | 'scale' | 'bounce' | 'pulse'
  
  // Size variants
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  
  // Custom styling
  gradient?: string
  glow?: boolean
  
  // Accessibility
  ariaLabel?: string
  ariaDescribedBy?: string
  
  // Callbacks
  onSuccess?: () => void
  onError?: () => void
  onComplete?: () => void
}

const sizeClasses = {
  xs: 'h-6 px-2 text-xs',
  sm: 'h-8 px-3 text-sm',
  md: 'h-9 px-4 py-2',
  lg: 'h-10 px-6',
  xl: 'h-11 px-8 text-lg'
}

const iconSizeClasses = {
  xs: 'w-3 h-3',
  sm: 'w-4 h-4',
  md: 'w-4 h-4',
  lg: 'w-5 h-5',
  xl: 'w-6 h-6'
}

const animationVariants = {
  scale: {
    whileHover: { scale: 1.05 },
    whileTap: { scale: 0.95 }
  },
  bounce: {
    whileHover: { y: -2 },
    whileTap: { y: 0 }
  },
  pulse: {
    whileHover: { scale: [1, 1.05, 1] },
    transition: { duration: 0.3, repeat: Infinity }
  },
  none: {}
}

export const EnhancedButton = React.forwardRef<HTMLButtonElement, EnhancedButtonProps>(
  ({
    children,
    loading = false,
    loadingText = 'Loading...',
    success = false,
    successText = 'Success!',
    successDuration = 2000,
    error = false,
    errorText = 'Error!',
    errorDuration = 3000,
    icon,
    iconPosition = 'left',
    animation = 'scale',
    size = 'md',
    gradient,
    glow = false,
    ariaLabel,
    ariaDescribedBy,
    onSuccess,
    onError,
    onComplete,
    className,
    disabled,
    variant = 'default',
    ...props
  }, ref) => {
    const [internalState, setInternalState] = React.useState<'idle' | 'loading' | 'success' | 'error'>('idle')
    const timeoutRef = React.useRef<NodeJS.Timeout>()

    React.useEffect(() => {
      if (loading && internalState !== 'loading') {
        setInternalState('loading')
      } else if (success && internalState !== 'success') {
        setInternalState('success')
        onSuccess?.()
        
        if (timeoutRef.current) clearTimeout(timeoutRef.current)
        timeoutRef.current = setTimeout(() => {
          setInternalState('idle')
          onComplete?.()
        }, successDuration)
      } else if (error && internalState !== 'error') {
        setInternalState('error')
        onError?.()
        
        if (timeoutRef.current) clearTimeout(timeoutRef.current)
        timeoutRef.current = setTimeout(() => {
          setInternalState('idle')
          onComplete?.()
        }, errorDuration)
      }
    }, [loading, success, error, internalState, successDuration, errorDuration, onSuccess, onError, onComplete])

    React.useEffect(() => {
      return () => {
        if (timeoutRef.current) {
          clearTimeout(timeoutRef.current)
        }
      }
    }, [])

    const isDisabled = disabled || loading || internalState === 'loading'
    const currentState = loading || success || error ? internalState : 'idle'

    const getStateContent = () => {
      switch (currentState) {
        case 'loading':
          return (
            <>
              <Loader2 className={cn(iconSizeClasses[size], 'animate-spin')} />
              <span>{loadingText}</span>
            </>
          )
        case 'success':
          return (
            <>
              <CheckCircle className={cn(iconSizeClasses[size], 'text-green-500')} />
              <span>{successText}</span>
            </>
          )
        case 'error':
          return (
            <>
              <AlertCircle className={cn(iconSizeClasses[size], 'text-red-500')} />
              <span>{errorText}</span>
            </>
          )
        default:
          return (
            <>
              {icon && iconPosition === 'left' && (
                <span className={cn(iconSizeClasses[size], 'mr-2')}>
                  {icon}
                </span>
              )}
              {children}
              {icon && iconPosition === 'right' && (
                <span className={cn(iconSizeClasses[size], 'ml-2')}>
                  {icon}
                </span>
              )}
            </>
          )
      }
    }

    const getButtonClasses = () => {
      const baseClasses = cn(
        sizeClasses[size],
        'relative overflow-hidden',
        'transition-all duration-200',
        'disabled:opacity-50 disabled:cursor-not-allowed',
        'focus:outline-none focus:ring-2 focus:ring-offset-2',
        glow && 'shadow-lg hover:shadow-xl',
        className
      )

      const gradientClasses = gradient 
        ? `bg-gradient-to-r ${gradient} text-white border-0 hover:opacity-90`
        : ''

      return cn(baseClasses, gradientClasses)
    }

    const MotionButton = motion(Button)

    return (
      <MotionButton
        ref={ref}
        className={getButtonClasses()}
        disabled={isDisabled}
        variant={gradient ? 'default' : variant}
        {...animationVariants[animation]}
        aria-label={ariaLabel}
        aria-describedby={ariaDescribedBy}
        {...props}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={currentState}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="flex items-center justify-center gap-2"
          >
            {getStateContent()}
          </motion.div>
        </AnimatePresence>
        
        {/* Ripple effect */}
        <span className="absolute inset-0 overflow-hidden rounded-md">
          <span className="absolute inset-0 bg-white/20 opacity-0 hover:opacity-100 transition-opacity duration-300" />
        </span>
      </MotionButton>
    )
  }
)

EnhancedButton.displayName = 'EnhancedButton'

// Button Group Component
export interface ButtonGroupProps {
  children: React.ReactNode
  orientation?: 'horizontal' | 'vertical'
  spacing?: 'none' | 'sm' | 'md' | 'lg'
  className?: string
}

export const ButtonGroup: React.FC<ButtonGroupProps> = ({
  children,
  orientation = 'horizontal',
  spacing = 'sm',
  className
}) => {
  const spacingClasses = {
    none: '',
    sm: orientation === 'horizontal' ? 'space-x-1' : 'space-y-1',
    md: orientation === 'horizontal' ? 'space-x-2' : 'space-y-2',
    lg: orientation === 'horizontal' ? 'space-x-3' : 'space-y-3'
  }

  return (
    <div className={cn(
      'flex',
      orientation === 'horizontal' ? 'flex-row' : 'flex-col',
      spacingClasses[spacing],
      className
    )}>
      {React.Children.map(children, (child, index) => {
        if (React.isValidElement(child) && child.type === EnhancedButton) {
          return React.cloneElement(child, {
            ...child.props,
            className: cn(
              index === 0 && orientation === 'horizontal' && 'rounded-l-none rounded-r-md',
              index === React.Children.count(children) - 1 && orientation === 'horizontal' && 'rounded-r-none rounded-l-md',
              index > 0 && index < React.Children.count(children) - 1 && orientation === 'horizontal' && 'rounded-none',
              index === 0 && orientation === 'vertical' && 'rounded-t-none rounded-b-md',
              index === React.Children.count(children) - 1 && orientation === 'vertical' && 'rounded-b-none rounded-t-md',
              index > 0 && index < React.Children.count(children) - 1 && orientation === 'vertical' && 'rounded-none',
              child.props.className
            )
          })
        }
        return child
      })}
    </div>
  )
}

ButtonGroup.displayName = 'ButtonGroup'

// Loading Button Component
export interface LoadingButtonProps extends Omit<EnhancedButtonProps, 'loading'> {
  onClick?: () => Promise<void> | void
  loadingOnClick?: boolean
}

export const LoadingButton: React.FC<LoadingButtonProps> = ({
  onClick,
  loadingOnClick = true,
  ...props
}) => {
  const [loading, setLoading] = React.useState(false)
  const [error, setError] = React.useState(false)
  const [success, setSuccess] = React.useState(false)

  const handleClick = async (e: React.MouseEvent<HTMLButtonElement>) => {
    if (!onClick) return

    if (loadingOnClick) {
      setLoading(true)
      setError(false)
      setSuccess(false)
    }

    try {
      await onClick()
      if (loadingOnClick) {
        setSuccess(true)
      }
    } catch (err) {
      if (loadingOnClick) {
        setError(true)
      }
      console.error('Button click error:', err)
    } finally {
      if (loadingOnClick) {
        setLoading(false)
      }
    }
  }

  return (
    <EnhancedButton
      {...props}
      loading={loading}
      success={success}
      error={error}
      onClick={handleClick}
    />
  )
}

LoadingButton.displayName = 'LoadingButton'

// Icon Button Component
export interface IconButtonProps extends Omit<EnhancedButtonProps, 'children' | 'icon'> {
  icon: React.ReactNode
  tooltip?: string
  tooltipPosition?: 'top' | 'bottom' | 'left' | 'right'
}

export const IconButton: React.FC<IconButtonProps> = ({
  icon,
  tooltip,
  tooltipPosition = 'top',
  size = 'md',
  className,
  ...props
}) => {
  const [showTooltip, setShowTooltip] = React.useState(false)

  const button = (
    <EnhancedButton
      {...props}
      size={size}
      className={cn(
        'p-0',
        size === 'xs' && 'w-6 h-6',
        size === 'sm' && 'w-8 h-8',
        size === 'md' && 'w-9 h-9',
        size === 'lg' && 'w-10 h-10',
        size === 'xl' && 'w-11 h-11',
        className
      )}
    >
      {React.cloneElement(icon as React.ReactElement, {
        className: cn(iconSizeClasses[size], (icon as React.ReactElement).props.className)
      })}
    </EnhancedButton>
  )

  if (!tooltip) return button

  return (
    <div className="relative inline-block">
      {button}
      <AnimatePresence>
        {showTooltip && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className={cn(
              'absolute z-50 px-2 py-1 text-xs text-white bg-gray-900 rounded-md whitespace-nowrap',
              tooltipPosition === 'top' && 'bottom-full left-1/2 transform -translate-x-1/2 mb-1',
              tooltipPosition === 'bottom' && 'top-full left-1/2 transform -translate-x-1/2 mt-1',
              tooltipPosition === 'left' && 'right-full top-1/2 transform -translate-y-1/2 mr-1',
              tooltipPosition === 'right' && 'left-full top-1/2 transform -translate-y-1/2 ml-1'
            )}
          >
            {tooltip}
            <div className={cn(
              'absolute w-2 h-2 bg-gray-900 transform rotate-45',
              tooltipPosition === 'top' && 'bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2',
              tooltipPosition === 'bottom' && 'top-0 left-1/2 -translate-x-1/2 -translate-y-1/2',
              tooltipPosition === 'left' && 'right-0 top-1/2 -translate-y-1/2 translate-x-1/2',
              tooltipPosition === 'right' && 'left-0 top-1/2 -translate-y-1/2 -translate-x-1/2'
            )} />
          </motion.div>
        )}
      </AnimatePresence>
      <div
        className="absolute inset-0"
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
      />
    </div>
  )
}

IconButton.displayName = 'IconButton'

export { EnhancedButton as Button }
export default EnhancedButton