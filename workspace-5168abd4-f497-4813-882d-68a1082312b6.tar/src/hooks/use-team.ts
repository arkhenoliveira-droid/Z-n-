import { useState, useEffect } from 'react';

interface TeamMember {
  id: number;
  name: string;
  role: string;
  status: 'online' | 'away' | 'offline';
  coherence: number;
}

interface Discussion {
  id: number;
  title: string;
  type: 'code-review' | 'planning' | 'meeting';
  comments: number;
  lastActivity: string;
  participants: string[];
}

interface TeamMetrics {
  totalMembers: number;
  onlineMembers: number;
  averageCoherence: number;
  synchronizationRate: number;
  flowState: string;
  empathyLevel: number;
}

export const useTeam = () => {
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [activeDiscussions, setActiveDiscussions] = useState<Discussion[]>([]);
  const [teamMetrics, setTeamMetrics] = useState<TeamMetrics | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchTeamData();
    
    // Set up real-time updates simulation
    const interval = setInterval(() => {
      fetchTeamData();
    }, 15000); // Update every 15 seconds

    return () => clearInterval(interval);
  }, []);

  const fetchTeamData = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/team');
      const result = await response.json();

      if (result.success) {
        setTeamMembers(result.data.teamMembers);
        setActiveDiscussions(result.data.activeDiscussions);
        setTeamMetrics(result.data.teamMetrics);
      } else {
        setError(result.error || 'Failed to fetch team data');
      }
    } catch (err) {
      setError('Network error while fetching team data');
    } finally {
      setIsLoading(false);
    }
  };

  const startTeamSync = async () => {
    try {
      const response = await fetch('/api/team', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'start_sync'
        }),
      });

      const result = await response.json();

      if (result.success) {
        return result;
      } else {
        throw new Error(result.error || 'Failed to start team sync');
      }
    } catch (err) {
      setError('Failed to start team synchronization');
      throw err;
    }
  };

  const startPairProgramming = async (initiator: string, partner: string) => {
    try {
      const response = await fetch('/api/team', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'pair_programming',
          data: { initiator, partner }
        }),
      });

      const result = await response.json();

      if (result.success) {
        return result;
      } else {
        throw new Error(result.error || 'Failed to start pair programming');
      }
    } catch (err) {
      setError('Failed to start pair programming session');
      throw err;
    }
  };

  const updateMemberStatus = async (memberId: number, status: string, coherence: number) => {
    try {
      const response = await fetch('/api/team', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'update_status',
          data: { memberId, status, coherence }
        }),
      });

      const result = await response.json();

      if (result.success) {
        // Update local state
        setTeamMembers(prev => 
          prev.map(member => 
            member.id === memberId 
              ? { ...member, status: status as any, coherence }
              : member
          )
        );
        return result;
      } else {
        throw new Error(result.error || 'Failed to update member status');
      }
    } catch (err) {
      setError('Failed to update member status');
      throw err;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'bg-green-500';
      case 'away':
        return 'bg-yellow-500';
      case 'offline':
        return 'bg-gray-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'online':
        return 'Available';
      case 'away':
        return 'Away';
      case 'offline':
        return 'Offline';
      default:
        return 'Unknown';
    }
  };

  const getCoherenceColor = (coherence: number) => {
    if (coherence >= 85) return 'text-green-600';
    if (coherence >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getDiscussionTypeColor = (type: string) => {
    switch (type) {
      case 'code-review':
        return 'bg-blue-100 text-blue-800';
      case 'planning':
        return 'bg-purple-100 text-purple-800';
      case 'meeting':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return {
    teamMembers,
    activeDiscussions,
    teamMetrics,
    isLoading,
    error,
    fetchTeamData,
    startTeamSync,
    startPairProgramming,
    updateMemberStatus,
    getStatusColor,
    getStatusText,
    getCoherenceColor,
    getDiscussionTypeColor
  };
};