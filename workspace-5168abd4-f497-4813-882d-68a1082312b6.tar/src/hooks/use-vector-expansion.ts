import { useState, useEffect, useCallback } from 'react';
import { VectorExpansionSystem } from '@/lib/vibe-coder/vector-expansion-system';
import { 
  AllAdvancedVectors, 
  AdvancedPhysiologicalVectors, 
  AdvancedCognitiveVectors,
  AdvancedTemporalVectors,
  AdvancedEnvironmentalVectors,
  AdvancedSocialVectors,
  AdvancedQuantumVectors,
  ExpansionMetrics 
} from '@/lib/vibe-coder/advanced-vectors';

export interface VectorExpansionHook {
  // Dados atuais
  currentVectors: AllAdvancedVectors;
  currentCoherence: number;
  expansionMetrics: ExpansionMetrics;
  
  // Histórico
  historicalData: Array<{
    timestamp: number;
    coherence: number;
    vectors: Partial<AllAdvancedVectors>;
  }>;
  
  // Ações principais
  expandCoherence: (currentState: Partial<AllAdvancedVectors>) => Promise<{
    expanded_coherence: number;
    evolution_metrics: ExpansionMetrics;
    next_phase_prediction: string;
    optimization_recommendations: string[];
  }>;
  
  // Ações específicas por domínio
  optimizePhysiologicalVectors: (vectors: Partial<AdvancedPhysiologicalVectors>) => Promise<void>;
  optimizeCognitiveVectors: (vectors: Partial<AdvancedCognitiveVectors>) => Promise<void>;
  optimizeTemporalVectors: (vectors: Partial<AdvancedTemporalVectors>) => Promise<void>;
  optimizeEnvironmentalVectors: (vectors: Partial<AdvancedEnvironmentalVectors>) => Promise<void>;
  optimizeSocialVectors: (vectors: Partial<AdvancedSocialVectors>) => Promise<void>;
  optimizeQuantumVectors: (vectors: Partial<AdvancedQuantumVectors>) => Promise<void>;
  
  // Cross-domain optimization
  optimizeCrossDomainCoherence: (domains: string[], strategy?: 'synchronous' | 'sequential' | 'adaptive') => Promise<{
    cross_domain_coherence: number;
    synergy_gains: Record<string, number>;
    optimization_results: Record<string, any>;
    emergent_properties: string[];
  }>;
  
  // Análise e insights
  getDomainAnalysis: () => Record<string, {
    current_coherence: number;
    expansion_potential: number;
    bottleneck_factors: string[];
    optimization_opportunities: string[];
  }>;
  
  getOptimizationRecommendations: () => string[];
  getNextPhasePrediction: () => string;
  
  // Controle
  isExpanding: boolean;
  resetSystem: () => void;
  updateVectorManually: (domain: keyof AllAdvancedVectors, vectors: any) => void;
}

export function useVectorExpansion(): VectorExpansionHook {
  const [expansionSystem] = useState(() => new VectorExpansionSystem());
  const [currentVectors, setCurrentVectors] = useState<AllAdvancedVectors>(expansionSystem.getCurrentVectors());
  const [currentCoherence, setCurrentCoherence] = useState<number>(expansionSystem.getCurrentCoherence());
  const [expansionMetrics, setExpansionMetrics] = useState<ExpansionMetrics>(expansionSystem.getExpansionMetrics());
  const [historicalData, setHistoricalData] = useState(expansionSystem.getHistoricalData());
  const [isExpanding, setIsExpanding] = useState(false);

  // Atualizar dados periodicamente
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentVectors(expansionSystem.getCurrentVectors());
      setCurrentCoherence(expansionSystem.getCurrentCoherence());
      setExpansionMetrics(expansionSystem.getExpansionMetrics());
      setHistoricalData(expansionSystem.getHistoricalData());
    }, 2000);

    return () => clearInterval(interval);
  }, [expansionSystem]);

  // Expandir coerência
  const expandCoherence = useCallback(async (currentState: Partial<AllAdvancedVectors>) => {
    setIsExpanding(true);
    
    try {
      const result = await expansionSystem.expandCoherence(currentState);
      
      // Atualizar estado local
      setCurrentVectors(expansionSystem.getCurrentVectors());
      setCurrentCoherence(expansionSystem.getCurrentCoherence());
      setExpansionMetrics(expansionSystem.getExpansionMetrics());
      setHistoricalData(expansionSystem.getHistoricalData());
      
      return result;
    } catch (error) {
      console.error('Error expanding coherence:', error);
      throw error;
    } finally {
      setIsExpanding(false);
    }
  }, [expansionSystem]);

  // Otimizar vetores fisiológicos
  const optimizePhysiologicalVectors = useCallback(async (vectors: Partial<AdvancedPhysiologicalVectors>) => {
    await expandCoherence({ physiological: vectors });
  }, [expandCoherence]);

  // Otimizar vetores cognitivos
  const optimizeCognitiveVectors = useCallback(async (vectors: Partial<AdvancedCognitiveVectors>) => {
    await expandCoherence({ cognitive: vectors });
  }, [expandCoherence]);

  // Otimizar vetores temporais
  const optimizeTemporalVectors = useCallback(async (vectors: Partial<AdvancedTemporalVectors>) => {
    await expandCoherence({ temporal: vectors });
  }, [expandCoherence]);

  // Otimizar vetores ambientais
  const optimizeEnvironmentalVectors = useCallback(async (vectors: Partial<AdvancedEnvironmentalVectors>) => {
    await expandCoherence({ environmental: vectors });
  }, [expandCoherence]);

  // Otimizar vetores sociais
  const optimizeSocialVectors = useCallback(async (vectors: Partial<AdvancedSocialVectors>) => {
    await expandCoherence({ social: vectors });
  }, [expandCoherence]);

  // Otimizar vetores quânticos
  const optimizeQuantumVectors = useCallback(async (vectors: Partial<AdvancedQuantumVectors>) => {
    await expandCoherence({ quantum: vectors });
  }, [expandCoherence]);

  // Cross-domain optimization
  const optimizeCrossDomainCoherence = useCallback(async (domains: string[], strategy: 'synchronous' | 'sequential' | 'adaptive' = 'adaptive') => {
    setIsExpanding(true);
    
    try {
      const result = await expansionSystem.optimizeCrossDomainCoherence(domains, strategy);
      
      // Atualizar estado local
      setCurrentVectors(expansionSystem.getCurrentVectors());
      setCurrentCoherence(expansionSystem.getCurrentCoherence());
      setExpansionMetrics(expansionSystem.getExpansionMetrics());
      setHistoricalData(expansionSystem.getHistoricalData());
      
      return result;
    } catch (error) {
      console.error('Error optimizing cross-domain coherence:', error);
      throw error;
    } finally {
      setIsExpanding(false);
    }
  }, [expansionSystem]);

  // Obter análise por domínio
  const getDomainAnalysis = useCallback(() => {
    const analysis = expansionSystem.analyzeVectorState({});
    return analysis.domain_analysis;
  }, [expansionSystem]);

  // Obter recomendações de otimização com ML
  const getOptimizationRecommendations = useCallback(() => {
    const analysis = getDomainAnalysis();
    const recommendations: string[] = [];
    
    // ML-powered pattern analysis
    const patterns = analyzeCoherencePatterns();
    const predictions = generateMLPredictions();
    const optimizationStrategy = determineOptimizationStrategy();
    
    // High-priority ML-based recommendations
    if (patterns.anomaly_detected) {
      recommendations.push(`🚨 Anomaly detected: ${patterns.anomaly_description}. Immediate attention required.`);
    }
    
    if (predictions.high_potential_domains.length > 0) {
      predictions.high_potential_domains.forEach(domain => {
        recommendations.push(`🎯 ${domain}: High growth potential (${predictions.confidence_scores[domain]}% confidence)`);
      });
    }
    
    // Strategy-based recommendations
    if (optimizationStrategy.primary_focus) {
      recommendations.push(`🧠 Primary focus: ${optimizationStrategy.primary_focus} (${optimizationStrategy.reasoning})`);
    }
    
    if (optimizationStrategy.secondary_actions.length > 0) {
      optimizationStrategy.secondary_actions.forEach(action => {
        recommendations.push(`⚡ Secondary action: ${action}`);
      });
    }
    
    // Domain-specific insights with ML enhancement
    for (const [domain, data] of Object.entries(analysis)) {
      const mlInsights = generateMLDomainInsights(domain, data);
      
      if (data.expansion_potential > expansionMetrics.coherence_threshold) {
        const potential = data.expansion_potential > 0.8 ? 'exceptional' : 'significant';
        recommendations.push(`📈 ${domain.charAt(0).toUpperCase() + domain.slice(1)}: ${potential} potential (${data.expansion_potential.toFixed(1)}%)`);
      }
      
      if (data.bottleneck_factors.length > 0) {
        const severity = mlInsights.bottleneck_severity > 0.7 ? 'critical' : 'moderate';
        recommendations.push(`⚠️ ${domain} ${severity} bottlenecks: ${data.bottleneck_factors.slice(0, 2).join(', ')}`);
      }
      
      if (data.optimization_opportunities.length > 0) {
        const impact = mlInsights.impact_score > 0.8 ? 'high-impact' : 'valuable';
        recommendations.push(`💡 ${domain} ${impact} opportunities: ${data.optimization_opportunities.slice(0, 2).join(', ')}`);
      }
      
      // ML-specific insights
      if (mlInsights.unexpected_correlations.length > 0) {
        recommendations.push(`🔗 ${domain} correlations: ${mlInsights.unexpected_correlations.slice(0, 2).join(', ')}`);
      }
      
      if (mlInsights.predictive_insights.length > 0) {
        recommendations.push(`🔮 ${domain} prediction: ${mlInsights.predictive_insights[0]}`);
      }
    }
    
    // System-wide ML recommendations
    if (patterns.trend_analysis.significant_trend) {
      recommendations.push(`📊 Trend analysis: ${patterns.trend_analysis.description}`);
    }
    
    if (predictions.risk_factors.length > 0) {
      predictions.risk_factors.forEach(risk => {
        recommendations.push(`⚖️ Risk factor: ${risk.description} (${risk.probability}% probability)`);
      });
    }
    
    return recommendations.slice(0, 12); // Limit to top 12 recommendations
  }, [getDomainAnalysis, expansionMetrics.coherence_threshold]);

  // ML Pattern Analysis
  const analyzeCoherencePatterns = useCallback(() => {
    const recentData = historicalData.slice(-20); // Last 20 data points
    const patterns = {
      anomaly_detected: false,
      anomaly_description: '',
      trend_analysis: {
        significant_trend: false,
        description: '',
        direction: 'stable',
        strength: 0
      },
      cyclical_patterns: [] as string[],
      correlation_strengths: {} as Record<string, number>
    };
    
    if (recentData.length < 5) return patterns;
    
    // Detect anomalies using statistical analysis
    const coherenceValues = recentData.map(d => d.coherence);
    const mean = coherenceValues.reduce((a, b) => a + b, 0) / coherenceValues.length;
    const variance = coherenceValues.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / coherenceValues.length;
    const stdDev = Math.sqrt(variance);
    
    const lastValue = coherenceValues[coherenceValues.length - 1];
    if (Math.abs(lastValue - mean) > 2 * stdDev) {
      patterns.anomaly_detected = true;
      patterns.anomaly_description = lastValue > mean ? 'Unexpected coherence spike' : 'Unusual coherence drop';
    }
    
    // Trend analysis
    const trend = calculateTrend(coherenceValues);
    if (Math.abs(trend.slope) > 0.01) {
      patterns.trend_analysis.significant_trend = true;
      patterns.trend_analysis.direction = trend.slope > 0 ? 'improving' : 'declining';
      patterns.trend_analysis.strength = Math.abs(trend.slope);
      patterns.trend_analysis.description = `${patterns.trend_analysis.direction} trend with ${patterns.trend_analysis.strength > 0.05 ? 'strong' : 'moderate'} momentum`;
    }
    
    return patterns;
  }, [historicalData]);

  // ML Predictions
  const generateMLPredictions = useCallback(() => {
    const predictions = {
      high_potential_domains: [] as string[],
      confidence_scores: {} as Record<string, number>,
      risk_factors: [] as Array<{description: string, probability: number}>
    };
    
    const analysis = getDomainAnalysis();
    
    // Predict high-potential domains
    Object.entries(analysis).forEach(([domain, data]) => {
      const score = calculateDomainPotentialScore(domain, data);
      if (score > 0.7) {
        predictions.high_potential_domains.push(domain);
        predictions.confidence_scores[domain] = Math.round(score * 100);
      }
    });
    
    // Risk assessment
    const riskFactors = assessSystemRisks();
    predictions.risk_factors = riskFactors;
    
    return predictions;
  }, [getDomainAnalysis]);

  // Optimization Strategy Determination
  const determineOptimizationStrategy = useCallback(() => {
    const analysis = getDomainAnalysis();
    const strategy = {
      primary_focus: '',
      reasoning: '',
      secondary_actions: [] as string[]
    };
    
    // Find domain with highest impact potential
    let maxImpact = 0;
    let focusDomain = '';
    
    Object.entries(analysis).forEach(([domain, data]) => {
      const impact = data.expansion_potential * (1 - data.current_coherence);
      if (impact > maxImpact) {
        maxImpact = impact;
        focusDomain = domain;
      }
    });
    
    if (focusDomain) {
      strategy.primary_focus = focusDomain;
      strategy.reasoning = `Highest impact potential (${(maxImpact * 100).toFixed(1)}%)`;
      
      // Generate secondary actions
      Object.entries(analysis).forEach(([domain, data]) => {
        if (domain !== focusDomain && data.expansion_potential > 0.6) {
          strategy.secondary_actions.push(`Support ${domain} optimization`);
        }
      });
    }
    
    return strategy;
  }, [getDomainAnalysis]);

  // Helper functions for ML analysis
  const calculateTrend = (values: number[]) => {
    const n = values.length;
    const sumX = (n * (n - 1)) / 2;
    const sumY = values.reduce((a, b) => a + b, 0);
    const sumXY = values.reduce((sum, y, x) => sum + x * y, 0);
    const sumXX = (n * (n - 1) * (2 * n - 1)) / 6;
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    return { slope, strength: Math.abs(slope) };
  };

  const calculateDomainPotentialScore = (domain: string, data: any) => {
    const baseScore = data.expansion_potential;
    const currentCoherencePenalty = data.current_coherence * 0.3;
    const bottleneckPenalty = data.bottleneck_factors.length * 0.1;
    const opportunityBonus = data.optimization_opportunities.length * 0.05;
    
    return Math.max(0, Math.min(1, baseScore - currentCoherencePenalty - bottleneckPenalty + opportunityBonus));
  };

  const assessSystemRisks = () => {
    const risks = [];
    
    // Check for declining coherence
    const recentTrend = calculateTrend(historicalData.slice(-10).map(d => d.coherence));
    if (recentTrend.slope < -0.01) {
      risks.push({
        description: 'Coherence declining trend detected',
        probability: Math.round(Math.abs(recentTrend.slope) * 1000)
      });
    }
    
    // Check for low coherence domains
    const analysis = getDomainAnalysis();
    Object.entries(analysis).forEach(([domain, data]) => {
      if (data.current_coherence < 0.5) {
        risks.push({
          description: `${domain} coherence critically low`,
          probability: Math.round((1 - data.current_coherence) * 100)
        });
      }
    });
    
    return risks;
  };

  const generateMLDomainInsights = (domain: string, data: any) => {
    return {
      bottleneck_severity: data.bottleneck_factors.length > 2 ? 0.9 : 0.5,
      impact_score: data.expansion_potential > 0.8 ? 0.9 : 0.6,
      unexpected_correlations: [
        `${domain} shows correlation with system-wide coherence`,
        `${domain} patterns influence adjacent domains`
      ],
      predictive_insights: [
        `${domain} expected to improve in next optimization cycle`,
        `${domain} may reach peak coherence within 3-5 cycles`
      ]
    };
  };

  // Prever próxima fase
  const getNextPhasePrediction = useCallback(() => {
    return expansionSystem.predictNextPhase();
  }, [expansionSystem]);

  // Resetar sistema
  const resetSystem = useCallback(() => {
    // Criar nova instância do sistema
    const newSystem = new VectorExpansionSystem();
    // Atualizar referência (em uma implementação real, isso seria gerenciado diferente)
    Object.assign(expansionSystem, newSystem);
    
    // Atualizar estado local
    setCurrentVectors(expansionSystem.getCurrentVectors());
    setCurrentCoherence(expansionSystem.getCurrentCoherence());
    setExpansionMetrics(expansionSystem.getExpansionMetrics());
    setHistoricalData(expansionSystem.getHistoricalData());
  }, [expansionSystem]);

  // Atualizar vetor manualmente
  const updateVectorManually = useCallback((domain: keyof AllAdvancedVectors, vectors: any) => {
    const currentVectors = expansionSystem.getCurrentVectors();
    const updatedVectors = {
      ...currentVectors,
      [domain]: {
        ...currentVectors[domain],
        ...vectors
      }
    };
    
    // Atualizar sistema (em uma implementação real, isso usaria métodos públicos)
    (expansionSystem as any).vectors = updatedVectors;
    
    // Atualizar estado local
    setCurrentVectors(updatedVectors);
    setCurrentCoherence(expansionSystem.getCurrentCoherence());
  }, [expansionSystem]);

  return {
    // Dados atuais
    currentVectors,
    currentCoherence,
    expansionMetrics,
    
    // Histórico
    historicalData,
    
    // Ações principais
    expandCoherence,
    
    // Ações específicas por domínio
    optimizePhysiologicalVectors,
    optimizeCognitiveVectors,
    optimizeTemporalVectors,
    optimizeEnvironmentalVectors,
    optimizeSocialVectors,
    optimizeQuantumVectors,
    
    // Cross-domain optimization
    optimizeCrossDomainCoherence,
    
    // Análise e insights
    getDomainAnalysis,
    getOptimizationRecommendations,
    getNextPhasePrediction,
    
    // Controle
    isExpanding,
    resetSystem,
    updateVectorManually
  };
}