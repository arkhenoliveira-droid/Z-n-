import ZAI from 'z-ai-web-dev-sdk';

/**
 * Function to generate code using ZAI SDK.
 * @param {string} prompt - The user's input prompt for code generation.
 * @returns {Promise<string>} - The generated code.
 */
async function generateCode(prompt: string): Promise<string> {
  try {
    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an expert code assistant. Generate clean, efficient, and well-commented code based on the user\'s request.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      max_tokens: 150,
      temperature: 0.5,
    });

    // Extract the message content from the first choice
    const messageContent = completion.choices[0]?.message?.content;
    if (messageContent) {
      return messageContent.trim();
    } else {
      throw new Error('No content generated');
    }
  } catch (error) {
    console.error('Error generating code:', error);
    throw error;
  }
}

// Example usage
(async () => {
  const userPrompt = "Write a function to add two numbers in JavaScript";
  try {
    const generatedCode = await generateCode(userPrompt);
    console.log('Generated Code:');
    console.log(generatedCode);
  } catch (error) {
    console.error('Failed to generate code:', error);
  }
})();

export { generateCode };