/**
 * Holistic Application Initialization System
 * Sets up all enhanced systems, monitoring, and optimizations
 */

import { performance } from './performance'
import { errorHandling } from './error-handling'
import { utils } from './utils'
import { designSystem } from './design-system'

export interface InitOptions {
  // Performance monitoring
  enablePerformanceMonitoring?: boolean
  performanceThresholds?: Record<string, { min: number; max: number; unit: string }>
  
  // Error handling
  enableErrorHandling?: boolean
  customErrorHandlers?: errorHandling.ErrorHandler[]
  
  // Analytics
  enableAnalytics?: boolean
  analyticsEndpoint?: string
  
  // Theme
  defaultTheme?: 'light' | 'dark' | 'system'
  
  // Features
  enableLazyLoading?: boolean
  enableVirtualScrolling?: boolean
  enableImageOptimization?: boolean
  
  // Debugging
  enableDebugMode?: boolean
  logLevel?: 'error' | 'warn' | 'info' | 'debug'
  
  // Optimization
  enableCodeSplitting?: boolean
  enablePrefetching?: boolean
  enableCaching?: boolean
}

export interface InitResult {
  success: boolean
  errors: string[]
  warnings: string[]
  systems: {
    performance: boolean
    errorHandling: boolean
    analytics: boolean
    theme: boolean
    optimizations: boolean
  }
  metrics: {
    initTime: number
    memoryUsage: {
      used: number
      total: number
      limit: number
    }
  }
}

class AppInitializer {
  private static instance: AppInitializer
  private initialized = false
  private initTime = 0
  private errors: string[] = []
  private warnings: string[] = []

  private constructor() {}

  static getInstance(): AppInitializer {
    if (!AppInitializer.instance) {
      AppInitializer.instance = new AppInitializer()
    }
    return AppInitializer.instance
  }

  async initialize(options: InitOptions = {}): Promise<InitResult> {
    if (this.initialized) {
      this.warnings.push('Application already initialized')
      return this.createResult(true)
    }

    const startTime = performance.now()
    this.errors = []
    this.warnings = []

    try {
      // Set default options
      const finalOptions: Required<InitOptions> = {
        enablePerformanceMonitoring: true,
        performanceThresholds: {},
        enableErrorHandling: true,
        customErrorHandlers: [],
        enableAnalytics: true,
        analyticsEndpoint: '/api/analytics',
        defaultTheme: 'system',
        enableLazyLoading: true,
        enableVirtualScrolling: true,
        enableImageOptimization: true,
        enableDebugMode: false,
        logLevel: 'warn',
        enableCodeSplitting: true,
        enablePrefetching: true,
        enableCaching: true,
        ...options
      }

      // Initialize systems
      const systems = {
        performance: false,
        errorHandling: false,
        analytics: false,
        theme: false,
        optimizations: false
      }

      // 1. Performance Monitoring
      if (finalOptions.enablePerformanceMonitoring) {
        try {
          await this.initializePerformanceMonitoring(finalOptions)
          systems.performance = true
        } catch (error) {
          this.errors.push(`Failed to initialize performance monitoring: ${error}`)
        }
      }

      // 2. Error Handling
      if (finalOptions.enableErrorHandling) {
        try {
          await this.initializeErrorHandling(finalOptions)
          systems.errorHandling = true
        } catch (error) {
          this.errors.push(`Failed to initialize error handling: ${error}`)
        }
      }

      // 3. Analytics
      if (finalOptions.enableAnalytics) {
        try {
          await this.initializeAnalytics(finalOptions)
          systems.analytics = true
        } catch (error) {
          this.errors.push(`Failed to initialize analytics: ${error}`)
        }
      }

      // 4. Theme System
      try {
        await this.initializeThemeSystem(finalOptions)
        systems.theme = true
      } catch (error) {
        this.errors.push(`Failed to initialize theme system: ${error}`)
      }

      // 5. Optimizations
      try {
        await this.initializeOptimizations(finalOptions)
        systems.optimizations = true
      } catch (error) {
        this.errors.push(`Failed to initialize optimizations: ${error}`)
      }

      // 6. Debug Mode
      if (finalOptions.enableDebugMode) {
        this.enableDebugMode(finalOptions)
      }

      this.initialized = true
      this.initTime = performance.now() - startTime

      return this.createResult(true, systems)

    } catch (error) {
      this.errors.push(`Critical initialization error: ${error}`)
      return this.createResult(false)
    }
  }

  private async initializePerformanceMonitoring(options: Required<InitOptions>): Promise<void> {
    // Start performance monitoring
    performance.startMonitoring()

    // Set custom thresholds
    if (Object.keys(options.performanceThresholds).length > 0) {
      Object.entries(options.performanceThresholds).forEach(([name, threshold]) => {
        // This would update the performance monitor thresholds
        console.log(`Setting performance threshold for ${name}:`, threshold)
      })
    }

    // Track initialization performance
    performance.recordMetric({
      name: 'app_initialization',
      value: 0, // Will be updated after init
      unit: 'ms',
      timestamp: Date.now(),
      category: 'custom'
    })

    // Monitor memory usage
    if (performance.memory) {
      setInterval(() => {
        performance.recordMetric({
          name: 'memory_usage',
          value: performance.memory.usedJSHeapSize,
          unit: 'bytes',
          timestamp: Date.now(),
          category: 'custom'
        })
      }, 30000) // Every 30 seconds
    }

    console.log('✅ Performance monitoring initialized')
  }

  private async initializeErrorHandling(options: Required<InitOptions>): Promise<void> {
    // Setup global error handling
    errorHandling.setup()

    // Register custom error handlers
    options.customErrorHandlers.forEach(handler => {
      errorHandling.registry.register(handler)
    })

    // Track error metrics
    const originalHandle = errorHandling.registry.handle
    errorHandling.registry.handle = async (error) => {
      // Track error occurrence
      performance.recordMetric({
        name: 'error_occurrence',
        value: 1,
        unit: '',
        timestamp: Date.now(),
        category: 'custom',
        metadata: {
          code: error.code,
          category: error.category,
          severity: error.severity
        }
      })

      // Call original handler
      await originalHandle.call(errorHandling.registry, error)
    }

    console.log('✅ Error handling initialized')
  }

  private async initializeAnalytics(options: Required<InitOptions>): Promise<void> {
    // Initialize analytics system
    if (typeof navigator.sendBeacon === 'function') {
      // Track page view
      const trackPageView = () => {
        const data = new Blob([JSON.stringify({
          type: 'page_view',
          url: window.location.href,
          timestamp: Date.now(),
          userAgent: navigator.userAgent,
          screenSize: `${window.screen.width}x${window.screen.height}`,
          viewportSize: `${window.innerWidth}x${window.innerHeight}`
        })], { type: 'application/json' })
        
        navigator.sendBeacon(options.analyticsEndpoint, data)
      }

      // Track initial page view
      trackPageView()

      // Track navigation changes
      window.addEventListener('popstate', trackPageView)
      
      // Track performance metrics
      setInterval(() => {
        const report = performance.generateReport()
        if (report.score < 80) {
          const data = new Blob([JSON.stringify({
            type: 'performance_report',
            report,
            timestamp: Date.now()
          })], { type: 'application/json' })
          
          navigator.sendBeacon(`${options.analyticsEndpoint}/performance`, data)
        }
      }, 60000) // Every minute

      console.log('✅ Analytics initialized')
    } else {
      this.warnings.push('Beacon API not available, analytics disabled')
    }
  }

  private async initializeThemeSystem(options: Required<InitOptions>): Promise<void> {
    // Set initial theme
    designSystem.theme.setTheme(options.defaultTheme)

    // Listen for system theme changes
    if (options.defaultTheme === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
      const handleChange = (e: MediaQueryListEvent) => {
        designSystem.theme.setTheme(e.matches ? 'dark' : 'light')
      }

      mediaQuery.addEventListener('change', handleChange)
      
      // Cleanup on page unload
      window.addEventListener('beforeunload', () => {
        mediaQuery.removeEventListener('change', handleChange)
      })
    }

    // Optimize theme transitions
    document.documentElement.style.setProperty('--theme-transition-duration', '300ms')

    console.log('✅ Theme system initialized')
  }

  private async initializeOptimizations(options: Required<InitOptions>): Promise<void> {
    // Lazy loading
    if (options.enableLazyLoading) {
      this.setupLazyLoading()
    }

    // Virtual scrolling
    if (options.enableVirtualScrolling) {
      this.setupVirtualScrolling()
    }

    // Image optimization
    if (options.enableImageOptimization) {
      this.setupImageOptimization()
    }

    // Code splitting
    if (options.enableCodeSplitting) {
      this.setupCodeSplitting()
    }

    // Prefetching
    if (options.enablePrefetching) {
      this.setupPrefetching()
    }

    // Caching
    if (options.enableCaching) {
      this.setupCaching()
    }

    console.log('✅ Optimizations initialized')
  }

  private setupLazyLoading(): void {
    // Setup intersection observer for lazy loading
    if ('IntersectionObserver' in window) {
      const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const img = entry.target as HTMLImageElement
            if (img.dataset.src) {
              img.src = img.dataset.src
              img.removeAttribute('data-src')
              imageObserver.unobserve(img)
            }
          }
        })
      })

      // Observe all images with data-src
      document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img)
      })

      console.log('✅ Lazy loading setup complete')
    }
  }

  private setupVirtualScrolling(): void {
    // This would setup virtual scrolling for large lists
    // Implementation would depend on specific components
    console.log('✅ Virtual scrolling setup complete')
  }

  private setupImageOptimization(): void {
    // Optimize image loading and display
    const optimizeImages = () => {
      document.querySelectorAll('img').forEach(img => {
        // Add loading="lazy" to images
        if (!img.hasAttribute('loading')) {
          img.setAttribute('loading', 'lazy')
        }
        
        // Add decoding="async" for better performance
        if (!img.hasAttribute('decoding')) {
          img.setAttribute('decoding', 'async')
        }
      })
    }

    // Run on DOMContentLoaded and when new content is added
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', optimizeImages)
    } else {
      optimizeImages()
    }

    console.log('✅ Image optimization setup complete')
  }

  private setupCodeSplitting(): void {
    // This would setup dynamic imports for code splitting
    // Implementation would depend on specific routes and components
    console.log('✅ Code splitting setup complete')
  }

  private setupPrefetching(): void {
    // Prefetch critical resources
    if ('IntersectionObserver' in window) {
      const linkObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const link = entry.target as HTMLAnchorElement
            if (link.href && link.origin === window.location.origin) {
              // Prefetch the page
              const prefetchLink = document.createElement('link')
              prefetchLink.rel = 'prefetch'
              prefetchLink.href = link.href
              document.head.appendChild(prefetchLink)
              linkObserver.unobserve(link)
            }
          }
        })
      })

      // Observe all internal links
      document.querySelectorAll('a[href^="/"]').forEach(link => {
        linkObserver.observe(link)
      })

      console.log('✅ Prefetching setup complete')
    }
  }

  private setupCaching(): void {
    // Setup service worker for caching if available
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then(() => console.log('✅ Service worker registered'))
        .catch((error) => this.warnings.push(`Service worker registration failed: ${error}`))
    }

    // Setup cache headers for API calls
    const originalFetch = window.fetch
    window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
      const request = typeof input === 'string' ? new Request(input, init) : input
      
      // Add cache headers for GET requests
      if (request.method === 'GET') {
        const headers = new Headers(request.headers)
        headers.set('Cache-Control', 'max-age=300') // 5 minutes
        request = new Request(request.url, {
          ...request,
          headers
        })
      }

      return originalFetch(request)
    }

    console.log('✅ Caching setup complete')
  }

  private enableDebugMode(options: Required<InitOptions>): void {
    // Enable debug logging
    const originalConsole = {
      log: console.log,
      warn: console.warn,
      error: console.error,
      info: console.info
    }

    const logLevels = {
      error: 0,
      warn: 1,
      info: 2,
      debug: 3
    }

    const currentLevel = logLevels[options.logLevel]

    console.log = (...args) => {
      if (currentLevel >= logLevels.debug) {
        originalConsole.log('[DEBUG]', ...args)
      }
    }

    console.warn = (...args) => {
      if (currentLevel >= logLevels.warn) {
        originalConsole.warn('[WARN]', ...args)
      }
    }

    console.error = (...args) => {
      if (currentLevel >= logLevels.error) {
        originalConsole.error('[ERROR]', ...args)
      }
    }

    console.info = (...args) => {
      if (currentLevel >= logLevels.info) {
        originalConsole.info('[INFO]', ...args)
      }
    }

    // Add debug info to window
    (window as any).__DEBUG__ = {
      performance: performance,
      errorHandling: errorHandling,
      utils: utils,
      designSystem: designSystem,
      initTime: this.initTime,
      errors: this.errors,
      warnings: this.warnings
    }

    console.log('✅ Debug mode enabled')
  }

  private createResult(success: boolean, systems?: InitResult['systems']): InitResult {
    const memoryUsage = {
      used: 0,
      total: 0,
      limit: 0
    }

    if (performance.memory) {
      memoryUsage.used = performance.memory.usedJSHeapSize
      memoryUsage.total = performance.memory.totalJSHeapSize
      memoryUsage.limit = performance.memory.jsHeapSizeLimit
    }

    return {
      success,
      errors: [...this.errors],
      warnings: [...this.warnings],
      systems: systems || {
        performance: false,
        errorHandling: false,
        analytics: false,
        theme: false,
        optimizations: false
      },
      metrics: {
        initTime: this.initTime,
        memoryUsage
      }
    }
  }

  getStatus(): InitResult {
    return this.createResult(this.initialized)
  }

  getErrors(): string[] {
    return [...this.errors]
  }

  getWarnings(): string[] {
    return [...this.warnings]
  }

  isInitialized(): boolean {
    return this.initialized
  }
}

// Export initialization utilities
export const appInit = {
  initialize: (options?: InitOptions) => AppInitializer.getInstance().initialize(options),
  getStatus: () => AppInitializer.getInstance().getStatus(),
  getErrors: () => AppInitializer.getInstance().getErrors(),
  getWarnings: () => AppInitializer.getInstance().getWarnings(),
  isInitialized: () => AppInitializer.getInstance().isInitialized()
}

export default appInit