/**
 * Sistema de Cache Inteligente para Vibe-Coder
 * 
 * Implementa cache com invalidação baseada em tempo e relevância
 * para otimizar performance do sistema evolutivo
 */

export interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number; // Time to live in milliseconds
  relevance: number; // 0-1, higher means more relevant
  accessCount: number;
  lastAccess: number;
}

export class IntelligentCache<T> {
  private cache = new Map<string, CacheEntry<T>>();
  private maxSize: number;
  private defaultTTL: number;
  
  constructor(maxSize: number = 1000, defaultTTL: number = 30000) {
    this.maxSize = maxSize;
    this.defaultTTL = defaultTTL;
    
    // Iniciar limpeza periódica
    setInterval(() => this.cleanup(), 10000);
  }
  
  /**
   * Obtém item do cache
   */
  get(key: string): T | null {
    const entry = this.cache.get(key);
    
    if (!entry) return null;
    
    // Verificar se expirou
    if (Date.now() - entry.timestamp > entry.ttl) {
      this.cache.delete(key);
      return null;
    }
    
    // Atualizar estatísticas de acesso
    entry.accessCount++;
    entry.lastAccess = Date.now();
    
    return entry.data;
  }
  
  /**
   * Define item no cache
   */
  set(key: string, data: T, ttl?: number, relevance?: number): void {
    // Se cache está cheio, remover menos relevante
    if (this.cache.size >= this.maxSize) {
      this.evictLeastRelevant();
    }
    
    const entry: CacheEntry<T> = {
      data,
      timestamp: Date.now(),
      ttl: ttl || this.defaultTTL,
      relevance: relevance || 0.5,
      accessCount: 1,
      lastAccess: Date.now()
    };
    
    this.cache.set(key, entry);
  }
  
  /**
   * Remove item menos relevante do cache
   */
  private evictLeastRelevant(): void {
    let leastRelevantKey: string | null = null;
    let lowestScore = Infinity;
    
    for (const [key, entry] of this.cache.entries()) {
      // Calcular score baseado em relevância, acesso e idade
      const age = Date.now() - entry.timestamp;
      const accessScore = entry.accessCount / Math.max(1, age / 1000);
      const relevanceScore = entry.relevance * (entry.lastAccess / Date.now());
      const totalScore = accessScore + relevanceScore;
      
      if (totalScore < lowestScore) {
        lowestScore = totalScore;
        leastRelevantKey = key;
      }
    }
    
    if (leastRelevantKey) {
      this.cache.delete(leastRelevantKey);
    }
  }
  
  /**
   * Limpa entradas expiradas
   */
  private cleanup(): void {
    const now = Date.now();
    
    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp > entry.ttl) {
        this.cache.delete(key);
      }
    }
  }
  
  /**
   * Limpa todo o cache
   */
  clear(): void {
    this.cache.clear();
  }
  
  /**
   * Obtém estatísticas do cache
   */
  getStats() {
    return {
      size: this.cache.size,
      maxSize: this.maxSize,
      hitRate: this.calculateHitRate(),
      averageAge: this.calculateAverageAge()
    };
  }
  
  private calculateHitRate(): number {
    // Implementar tracking de hits/misses para cálculo real
    return 0.85; // Placeholder
  }
  
  private calculateAverageAge(): number {
    if (this.cache.size === 0) return 0;
    
    const now = Date.now();
    let totalAge = 0;
    
    for (const entry of this.cache.values()) {
      totalAge += now - entry.timestamp;
    }
    
    return totalAge / this.cache.size;
  }
}

// Instância global para uso no sistema
export const vibeCache = new IntelligentCache<any>(500, 60000);