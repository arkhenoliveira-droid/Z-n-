/**
 * Algoritmos de Correção Preditiva
 * 
 * Implementa análise preditiva e correção proativa de incoerências
 * baseada em padrões históricos e machine learning simplificado
 */

import { CoherenceVector, IncoherencePattern, CoherenceAdjustment } from './coherence-vectors';
import { vibeCache } from './cache';
import { eventBus, SystemEvents } from './events';

export interface Prediction {
  id: string;
  type: 'coherence_decline' | 'pattern_emergence' | 'optimal_window' | 'risk_factor';
  confidence: number;
  timeframe: number; // seconds until prediction
  description: string;
  suggestedActions: CoherenceAdjustment[];
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export interface PatternModel {
  id: string;
  name: string;
  accuracy: number;
  lastTrained: number;
  features: string[];
  predictions: Prediction[];
}

export interface TimeSeriesData {
  timestamp: number;
  value: number;
  metadata?: Record<string, any>;
}

export class PredictiveAnalyzer {
  private models: Map<string, PatternModel> = new Map();
  private historicalData: Map<string, TimeSeriesData[]> = new Map();
  private predictions: Prediction[] = [];
  private isAnalyzing = false;
  
  constructor() {
    this.initializeModels();
    this.startPredictiveAnalysis();
  }
  
  private initializeModels(): void {
    // Modelo de predição de declínio de coerência
    this.models.set('coherence_decline', {
      id: 'coherence_decline',
      name: 'Coherence Decline Predictor',
      accuracy: 0.82,
      lastTrained: Date.now(),
      features: ['coherence', 'stress', 'energy', 'focus', 'hrv'],
      predictions: []
    });
    
    // Modelo de detecção de padrões emergentes
    this.models.set('pattern_emergence', {
      id: 'pattern_emergence',
      name: 'Pattern Emergence Detector',
      accuracy: 0.75,
      lastTrained: Date.now(),
      features: ['cognitive_fatigue', 'stress_overload', 'temporal_misalignment'],
      predictions: []
    });
    
    // Modelo de janelas ótimas
    this.models.set('optimal_window', {
      id: 'optimal_window',
      name: 'Optimal Window Predictor',
      accuracy: 0.88,
      lastTrained: Date.now(),
      features: ['circadian_rhythm', 'historical_performance', 'energy_levels'],
      predictions: []
    });
    
    // Modelo de fatores de risco
    this.models.set('risk_factor', {
      id: 'risk_factor',
      name: 'Risk Factor Analyzer',
      accuracy: 0.79,
      lastTrained: Date.now(),
      features: ['stress_trend', 'energy_decline', 'focus_variance', 'environmental_factors'],
      predictions: []
    });
  }
  
  /**
   * Adiciona dados históricos para análise
   */
  addHistoricalData(metric: string, value: number, metadata?: Record<string, any>): void {
    if (!this.historicalData.has(metric)) {
      this.historicalData.set(metric, []);
    }
    
    const data = this.historicalData.get(metric)!;
    data.push({
      timestamp: Date.now(),
      value,
      metadata
    });
    
    // Manter apenas dados recentes (últimas 24 horas)
    const cutoff = Date.now() - 24 * 60 * 60 * 1000;
    const filtered = data.filter(d => d.timestamp > cutoff);
    this.historicalData.set(metric, filtered);
    
    // Atualizar cache
    vibeCache.set(`historical_${metric}`, filtered, 3600000); // 1 hora
  }
  
  /**
   * Analisa tendências e prediz declínio de coerência
   */
  predictCoherenceDecline(): Prediction | null {
    const coherenceData = this.historicalData.get('coherence') || [];
    
    if (coherenceData.length < 10) return null;
    
    // Calcular tendência usando regressão linear simples
    const trend = this.calculateLinearTrend(coherenceData);
    
    // Se tendência é negativa e significativa
    if (trend.slope < -0.5 && trend.rSquared > 0.7) {
      // Prever quando atingirá limiar crítico
      const currentCoherence = coherenceData[coherenceData.length - 1].value;
      const timeToCritical = Math.max(0, (currentCoherence - 60) / Math.abs(trend.slope));
      
      return {
        id: `decline_${Date.now()}`,
        type: 'coherence_decline',
        confidence: Math.min(0.95, trend.rSquared),
        timeframe: timeToCritical * 60, // converter para segundos
        description: `Coherence declining at ${trend.slope.toFixed(2)} units/hour. Critical level expected in ${Math.floor(timeToCritical)} minutes.`,
        suggestedActions: [
          {
            id: 'preventive_intervention',
            type: 'cognitive',
            priority: 'high',
            description: 'Implement preventive coherence interventions',
            action: 'preventive_intervention',
            expectedImpact: 15,
            estimatedTime: 600,
            autoApply: true
          }
        ],
        severity: timeToCritical < 30 ? 'critical' : timeToCritical < 60 ? 'high' : 'medium'
      };
    }
    
    return null;
  }
  
  /**
   * Prediz emergência de padrões de incoerência
   */
  predictPatternEmergence(): Prediction | null {
    const stressData = this.historicalData.get('stress') || [];
    const energyData = this.historicalData.get('energy') || [];
    const focusData = this.historicalData.get('focus') || [];
    
    if (stressData.length < 5 || energyData.length < 5 || focusData.length < 5) {
      return null;
    }
    
    // Detectar padrões que levam à fadiga cognitiva
    const recentStress = stressData.slice(-3).map(d => d.value);
    const recentEnergy = energyData.slice(-3).map(d => d.value);
    const recentFocus = focusData.slice(-3).map(d => d.value);
    
    const avgStress = recentStress.reduce((a, b) => a + b, 0) / recentStress.length;
    const avgEnergy = recentEnergy.reduce((a, b) => a + b, 0) / recentEnergy.length;
    const avgFocus = recentFocus.reduce((a, b) => a + b, 0) / recentFocus.length;
    
    // Calcular probabilidade de emergência de padrão
    const fatigueProbability = this.calculateFatigueProbability(avgStress, avgEnergy, avgFocus);
    
    if (fatigueProbability > 0.7) {
      return {
        id: `fatigue_pattern_${Date.now()}`,
        type: 'pattern_emergence',
        confidence: fatigueProbability,
        timeframe: 1800, // 30 minutos
        description: `High probability (${(fatigueProbability * 100).toFixed(1)}%) of cognitive fatigue pattern emergence.`,
        suggestedActions: [
          {
            id: 'fatigue_prevention',
            type: 'cognitive',
            priority: 'high',
            description: 'Implement fatigue prevention measures',
            action: 'fatigue_prevention',
            expectedImpact: 20,
            estimatedTime: 900,
            autoApply: true
          }
        ],
        severity: fatigueProbability > 0.9 ? 'critical' : 'high'
      };
    }
    
    return null;
  }
  
  /**
   * Prediz próximas janelas ótimas de coerência
   */
  predictOptimalWindows(): Prediction[] {
    const predictions: Prediction[] = [];
    const currentHour = new Date().getHours();
    
    // Analisar dados históricos de desempenho por hora
    const performanceByHour = this.analyzePerformanceByHour();
    
    // Encontrar próximas janelas ótimas
    for (let hour = currentHour + 1; hour <= 24; hour++) {
      const actualHour = hour > 24 ? hour - 24 : hour;
      const performance = performanceByHour[actualHour];
      
      if (performance && performance.average > 75) {
        const timeToWindow = this.calculateTimeToHour(actualHour);
        
        predictions.push({
          id: `optimal_window_${actualHour}`,
          type: 'optimal_window',
          confidence: Math.min(0.9, performance.average / 100),
          timeframe: timeToWindow,
          description: `Optimal performance window at ${actualHour}:00 with historical average of ${performance.average.toFixed(1)}%.`,
          suggestedActions: [
            {
              id: `schedule_for_${actualHour}`,
              type: 'temporal',
              priority: 'medium',
              description: `Schedule important tasks for ${actualHour}:00`,
              action: 'schedule_optimal_tasks',
              expectedImpact: performance.average - 70,
              estimatedTime: 300,
              autoApply: false
            }
          ],
          severity: 'low'
        });
      }
    }
    
    return predictions.slice(0, 3); // Retornar até 3 previsões
  }
  
  /**
   * Analisa fatores de risco e prediz problemas potenciais
   */
  predictRiskFactors(): Prediction[] {
    const predictions: Prediction[] = [];
    
    // Analisar tendência de estresse
    const stressTrend = this.analyzeTrend('stress');
    if (stressTrend && stressTrend.slope > 1.0) {
      predictions.push({
        id: `stress_risk_${Date.now()}`,
        type: 'risk_factor',
        confidence: Math.min(0.9, stressTrend.rSquared),
        timeframe: 3600, // 1 hora
        description: `Stress levels increasing rapidly (${stressTrend.slope.toFixed(2)} units/hour).`,
        suggestedActions: [
          {
            id: 'stress_intervention',
            type: 'physiological',
            priority: 'high',
            description: 'Implement stress reduction techniques',
            action: 'stress_reduction',
            expectedImpact: 15,
            estimatedTime: 600,
            autoApply: true
          }
        ],
        severity: stressTrend.slope > 2.0 ? 'critical' : 'high'
      });
    }
    
    // Analisar declínio de energia
    const energyTrend = this.analyzeTrend('energy');
    if (energyTrend && energyTrend.slope < -1.0) {
      predictions.push({
        id: `energy_risk_${Date.now()}`,
        type: 'risk_factor',
        confidence: Math.min(0.9, energyTrend.rSquared),
        timeframe: 1800, // 30 minutos
        description: `Energy levels declining rapidly (${energyTrend.slope.toFixed(2)} units/hour).`,
        suggestedActions: [
          {
            id: 'energy_restoration',
            type: 'physiological',
            priority: 'medium',
            description: 'Implement energy restoration measures',
            action: 'energy_boost',
            expectedImpact: 12,
            estimatedTime: 900,
            autoApply: true
          }
        ],
        severity: energyTrend.slope < -2.0 ? 'high' : 'medium'
      });
    }
    
    return predictions;
  }
  
  /**
   * Executa análise preditiva completa
   */
  runPredictiveAnalysis(): Prediction[] {
    const allPredictions: Prediction[] = [];
    
    // Executar todos os modelos preditivos
    const declinePrediction = this.predictCoherenceDecline();
    if (declinePrediction) allPredictions.push(declinePrediction);
    
    const patternPrediction = this.predictPatternEmergence();
    if (patternPrediction) allPredictions.push(patternPrediction);
    
    const windowPredictions = this.predictOptimalWindows();
    allPredictions.push(...windowPredictions);
    
    const riskPredictions = this.predictRiskFactors();
    allPredictions.push(...riskPredictions);
    
    // Armazenar previsões
    this.predictions = allPredictions;
    
    // Atualizar cache
    vibeCache.set('predictions', allPredictions, 300000); // 5 minutos
    
    // Emitir evento de novas previsões
    eventBus.emit(SystemEvents.COHERENCE_UPDATED, {
      type: 'predictions_updated',
      predictions: allPredictions,
      timestamp: Date.now()
    });
    
    return allPredictions;
  }
  
  /**
   * Inicia análise preditiva contínua
   */
  private startPredictiveAnalysis(): void {
    if (this.isAnalyzing) return;
    
    this.isAnalyzing = true;
    
    const analyze = () => {
      if (!this.isAnalyzing) return;
      
      try {
        this.runPredictiveAnalysis();
      } catch (error) {
        console.error('Error in predictive analysis:', error);
        eventBus.emit('prediction:error', { error });
      }
      
      // Próxima análise em 2 minutos
      setTimeout(analyze, 120000);
    };
    
    // Iniciar análise
    analyze();
  }
  
  /**
   * Calcula tendência linear usando regressão simples
   */
  private calculateLinearTrend(data: TimeSeriesData[]): { slope: number; rSquared: number } {
    const n = data.length;
    if (n < 2) return { slope: 0, rSquared: 0 };
    
    const x = data.map((_, i) => i);
    const y = data.map(d => d.value);
    
    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = y.reduce((a, b) => a + b, 0);
    const sumXY = x.reduce((sum, xi, i) => sum + xi * y[i], 0);
    const sumX2 = x.reduce((sum, xi) => sum + xi * xi, 0);
    const sumY2 = y.reduce((sum, yi) => sum + yi * yi, 0);
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    
    // Calcular R²
    const meanY = sumY / n;
    const totalSumSquares = y.reduce((sum, yi) => sum + Math.pow(yi - meanY, 2), 0);
    const residualSumSquares = y.reduce((sum, yi, i) => {
      const predicted = slope * x[i] + intercept;
      return sum + Math.pow(yi - predicted, 2);
    }, 0);
    
    const rSquared = totalSumSquares > 0 ? 1 - (residualSumSquares / totalSumSquares) : 0;
    
    return { slope, rSquared };
  }
  
  /**
   * Calcula probabilidade de fadiga cognitiva
   */
  private calculateFatigueProbability(stress: number, energy: number, focus: number): number {
    // Fatores de risco normalizados
    const stressRisk = Math.max(0, (stress - 25) / 50);
    const energyRisk = Math.max(0, (50 - energy) / 50);
    const focusRisk = Math.max(0, (65 - focus) / 50);
    
    // Combinação ponderada de riscos
    const totalRisk = (stressRisk * 0.4 + energyRisk * 0.35 + focusRisk * 0.25);
    
    return Math.min(1, Math.max(0, totalRisk));
  }
  
  /**
   * Analisa desempenho histórico por hora do dia
   */
  private analyzePerformanceByHour(): Record<number, { average: number; count: number }> {
    const coherenceData = this.historicalData.get('coherence') || [];
    const hourlyData: Record<number, number[]> = {};
    
    // Agrupar dados por hora
    coherenceData.forEach(data => {
      const hour = new Date(data.timestamp).getHours();
      if (!hourlyData[hour]) {
        hourlyData[hour] = [];
      }
      hourlyData[hour].push(data.value);
    });
    
    // Calcular médias por hora
    const result: Record<number, { average: number; count: number }> = {};
    
    for (const [hour, values] of Object.entries(hourlyData)) {
      const average = values.reduce((sum, val) => sum + val, 0) / values.length;
      result[parseInt(hour)] = {
        average,
        count: values.length
      };
    }
    
    return result;
  }
  
  /**
   * Calcula tempo até uma determinada hora
   */
  private calculateTimeToHour(targetHour: number): number {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    
    let hoursUntil = targetHour - currentHour;
    if (hoursUntil <= 0) {
      hoursUntil += 24;
    }
    
    return (hoursUntil * 60 - currentMinute) * 60; // converter para segundos
  }
  
  /**
   * Analisa tendência de uma métrica específica
   */
  private analyzeTrend(metric: string): { slope: number; rSquared: number } | null {
    const data = this.historicalData.get(metric) || [];
    
    if (data.length < 5) return null;
    
    return this.calculateLinearTrend(data.slice(-10)); // Usar últimos 10 pontos
  }
  
  /**
   * Obtém previsões atuais
   */
  getCurrentPredictions(): Prediction[] {
    return this.predictions;
  }
  
  /**
   * Obtém estatísticas dos modelos preditivos
   */
  getStats() {
    const totalPredictions = this.predictions.length;
    const highConfidencePredictions = this.predictions.filter(p => p.confidence > 0.8).length;
    const criticalPredictions = this.predictions.filter(p => p.severity === 'critical').length;
    
    return {
      isAnalyzing: this.isAnalyzing,
      totalPredictions,
      highConfidencePredictions,
      criticalPredictions,
      modelsCount: this.models.size,
      historicalMetrics: this.historicalData.size,
      averageModelAccuracy: Array.from(this.models.values())
        .reduce((sum, model) => sum + model.accuracy, 0) / this.models.size
    };
  }
  
  /**
   * Para análise preditiva
   */
  stop(): void {
    this.isAnalyzing = false;
  }
  
  /**
   * Reinicia análise preditiva
   */
  restart(): void {
    this.stop();
    this.startPredictiveAnalysis();
  }
  
  /**
   * Limpa dados históricos
   */
  clearHistoricalData(): void {
    this.historicalData.clear();
    this.predictions = [];
  }
}

// Instância global para uso no sistema
export const predictiveAnalyzer = new PredictiveAnalyzer();