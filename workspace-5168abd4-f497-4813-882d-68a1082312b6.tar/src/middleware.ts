import createMiddleware from 'next-intl/middleware';
import { supportedLanguages } from './lib/language-server';

export default createMiddleware({
  // A list of all locales that are supported
  locales: supportedLanguages,
  
  // Used when no locale matches
  defaultLocale: 'en',
  
  // Custom locale detection
  localeDetection: true
});

export const config = {
  // Match only internationalized pathnames
  matcher: ['/', '/(pt|en|es)/:path*']
};