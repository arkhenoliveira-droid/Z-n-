'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Plus, 
  Settings, 
  Copy, 
  Trash2, 
  Edit, 
  Activity, 
  Send, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  TrendingUp,
  Users,
  Zap,
  BarChart3,
  Bell,
  Search,
  Filter,
  MoreVertical,
  Play,
  Pause,
  RefreshCw,
  Eye,
  Download,
  Calendar,
  Globe
} from 'lucide-react'
import { toast } from 'sonner'
import RealTimeStats from '@/components/RealTimeStats'
import AdvancedAnalytics from '@/components/AdvancedAnalytics'
import Pagination from '@/components/Pagination'
import { useRealTimeUpdates } from '@/hooks/useRealTimeUpdates'

interface Webhook {
  id: string
  name: string
  description?: string
  endpoint: string
  secretKey: string
  isActive: boolean
  createdAt: string
  updatedAt: string
  author: {
    id: string
    name?: string
    email: string
  }
  channels: {
    id: string
    isActive: boolean
    channel: {
      id: string
      name: string
      type: 'TELEGRAM' | 'DISCORD' | 'SLACK' | 'EMAIL' | 'TWITTER' | 'WHATSAPP'
    }
  }[]
  _count: {
    alerts: number
  }
}

interface AlertChannel {
  id: string
  name: string
  type: 'TELEGRAM' | 'DISCORD' | 'SLACK' | 'EMAIL' | 'TWITTER' | 'WHATSAPP'
  config: string
  isActive: boolean
  createdAt: string
  updatedAt: string
  author: {
    id: string
    name?: string
    email: string
  }
  _count: {
    deliveries: number
  }
}

interface Alert {
  id: string
  webhookId: string
  message: string
  rawData: string
  status: 'RECEIVED' | 'PROCESSING' | 'DELIVERED' | 'FAILED'
  sentAt?: string
  createdAt: string
  webhook: {
    id: string
    name: string
    endpoint: string
  }
  author: {
    id: string
    name?: string
    email: string
  }
  deliveries: {
    id: string
    status: 'PENDING' | 'SENT' | 'FAILED'
    response?: string
    sentAt?: string
    channel: {
      id: string
      name: string
      type: 'TELEGRAM' | 'DISCORD' | 'SLACK' | 'EMAIL' | 'TWITTER' | 'WHATSAPP'
    }
  }[]
}

interface DashboardStats {
  totalWebhooks: number
  activeWebhooks: number
  totalChannels: number
  activeChannels: number
  totalAlerts: number
  recentAlerts: number
  successRate: number
}

const channelTypeIcons = {
  TELEGRAM: '📱',
  DISCORD: '💬',
  SLACK: '🔔',
  EMAIL: '📧',
  TWITTER: '🐦',
  WHATSAPP: '💚'
}

const channelTypeColors = {
  TELEGRAM: 'bg-blue-100 text-blue-800 border-blue-200',
  DISCORD: 'bg-indigo-100 text-indigo-800 border-indigo-200',
  SLACK: 'bg-purple-100 text-purple-800 border-purple-200',
  EMAIL: 'bg-green-100 text-green-800 border-green-200',
  TWITTER: 'bg-sky-100 text-sky-800 border-sky-200',
  WHATSAPP: 'bg-emerald-100 text-emerald-800 border-emerald-200'
}

const statusColors = {
  RECEIVED: 'bg-yellow-100 text-yellow-800',
  PROCESSING: 'bg-blue-100 text-blue-800',
  DELIVERED: 'bg-green-100 text-green-800',
  FAILED: 'bg-red-100 text-red-800'
}

export default function Home() {
  const [webhooks, setWebhooks] = useState<Webhook[]>([])
  const [channels, setChannels] = useState<AlertChannel[]>([])
  const [stats, setStats] = useState<DashboardStats>({
    totalWebhooks: 0,
    activeWebhooks: 0,
    totalChannels: 0,
    activeChannels: 0,
    totalAlerts: 0,
    recentAlerts: 0,
    successRate: 0
  })
  const [isLoading, setIsLoading] = useState(true)
  const [isCreateWebhookDialogOpen, setIsCreateWebhookDialogOpen] = useState(false)
  const [isCreateChannelDialogOpen, setIsCreateChannelDialogOpen] = useState(false)
  const [isEditWebhookDialogOpen, setIsEditWebhookDialogOpen] = useState(false)
  const [selectedWebhook, setSelectedWebhook] = useState<Webhook | null>(null)
  const [selectedWebhooks, setSelectedWebhooks] = useState<string[]>([])
  const [activeTab, setActiveTab] = useState('dashboard')
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [isLoadingAlerts, setIsLoadingAlerts] = useState(false)
  
  // Pagination state
  const [webhooksPagination, setWebhooksPagination] = useState({
    page: 1,
    totalPages: 1,
    totalItems: 0,
    itemsPerPage: 20
  })
  const [channelsPagination, setChannelsPagination] = useState({
    page: 1,
    totalPages: 1,
    totalItems: 0,
    itemsPerPage: 20
  })
  const [alertsPagination, setAlertsPagination] = useState({
    page: 1,
    totalPages: 1,
    totalItems: 0,
    itemsPerPage: 20
  })
  
  // Form states
  const [webhookForm, setWebhookForm] = useState({
    name: '',
    description: '',
    authorId: 'default-user'
  })
  
  const [editWebhookForm, setEditWebhookForm] = useState({
    name: '',
    description: '',
    isActive: true
  })
  
  const [channelForm, setChannelForm] = useState({
    name: '',
    type: 'TELEGRAM' as 'TELEGRAM' | 'DISCORD' | 'SLACK' | 'EMAIL' | 'TWITTER' | 'WHATSAPP',
    config: '',
    authorId: 'default-user'
  })

  // Real-time updates
  const { isConnected, lastEvent, emitEvent } = useRealTimeUpdates()

  useEffect(() => {
    fetchData()
    if (activeTab === 'alerts') {
      fetchAlerts()
    }
  }, [activeTab])

  // Handle real-time events
  useEffect(() => {
    if (lastEvent) {
      switch (lastEvent.type) {
        case 'webhook':
          if (lastEvent.action === 'created') {
            setWebhooks(prev => [lastEvent.data, ...prev])
          } else if (lastEvent.action === 'updated') {
            setWebhooks(prev => prev.map(w => w.id === lastEvent.data.id ? lastEvent.data : w))
          } else if (lastEvent.action === 'deleted') {
            setWebhooks(prev => prev.filter(w => w.id !== lastEvent.data.id))
          }
          break
        case 'channel':
          if (lastEvent.action === 'created') {
            setChannels(prev => [lastEvent.data, ...prev])
          } else if (lastEvent.action === 'updated') {
            setChannels(prev => prev.map(c => c.id === lastEvent.data.id ? lastEvent.data : c))
          } else if (lastEvent.action === 'deleted') {
            setChannels(prev => prev.filter(c => c.id !== lastEvent.data.id))
          }
          break
        case 'alert':
          if (lastEvent.action === 'received' && activeTab === 'alerts') {
            setAlerts(prev => [lastEvent.data, ...prev])
          }
          break
      }
    }
  }, [lastEvent, activeTab])

  const fetchData = async () => {
    try {
      const [webhooksRes, channelsRes, statsRes] = await Promise.all([
        fetch(`/api/webhooks?page=${webhooksPagination.page}&limit=${webhooksPagination.itemsPerPage}&search=${searchTerm}&status=${statusFilter}`),
        fetch(`/api/channels?page=${channelsPagination.page}&limit=${channelsPagination.itemsPerPage}&search=${searchTerm}&status=${statusFilter}`),
        fetch('/api/alerts/statistics')
      ])

      if (webhooksRes.ok) {
        const webhooksData = await webhooksRes.json()
        setWebhooks(webhooksData.data || [])
        setWebhooksPagination(prev => ({
          ...prev,
          page: webhooksData.page || 1,
          totalPages: webhooksData.totalPages || 1,
          totalItems: webhooksData.total || 0
        }))
      }

      if (channelsRes.ok) {
        const channelsData = await channelsRes.json()
        setChannels(channelsData.data || [])
        setChannelsPagination(prev => ({
          ...prev,
          page: channelsData.page || 1,
          totalPages: channelsData.totalPages || 1,
          totalItems: channelsData.total || 0
        }))
      }

      if (statsRes.ok) {
        const statsData = await statsRes.json()
        setStats(statsData)
      }
    } catch (error) {
      toast.error('Error fetching data')
    } finally {
      setIsLoading(false)
    }
  }

  const fetchAlerts = async () => {
    setIsLoadingAlerts(true)
    try {
      const response = await fetch(`/api/alerts?page=${alertsPagination.page}&limit=${alertsPagination.itemsPerPage}&search=${searchTerm}&status=${statusFilter}`)
      if (response.ok) {
        const data = await response.json()
        setAlerts(data.data || [])
        setAlertsPagination(prev => ({
          ...prev,
          page: data.page || 1,
          totalPages: data.totalPages || 1,
          totalItems: data.total || 0
        }))
      }
    } catch (error) {
      toast.error('Error fetching alerts')
    } finally {
      setIsLoadingAlerts(false)
    }
  }

  // Pagination handlers
  const handleWebhooksPageChange = (page: number) => {
    setWebhooksPagination(prev => ({ ...prev, page }))
    fetchData()
  }

  const handleWebhooksItemsPerPageChange = (itemsPerPage: number) => {
    setWebhooksPagination(prev => ({ ...prev, itemsPerPage, page: 1 }))
    fetchData()
  }

  const handleChannelsPageChange = (page: number) => {
    setChannelsPagination(prev => ({ ...prev, page }))
    fetchData()
  }

  const handleChannelsItemsPerPageChange = (itemsPerPage: number) => {
    setChannelsPagination(prev => ({ ...prev, itemsPerPage, page: 1 }))
    fetchData()
  }

  const handleAlertsPageChange = (page: number) => {
    setAlertsPagination(prev => ({ ...prev, page }))
    fetchAlerts()
  }

  const handleAlertsItemsPerPageChange = (itemsPerPage: number) => {
    setAlertsPagination(prev => ({ ...prev, itemsPerPage, page: 1 }))
    fetchAlerts()
  }

  const handleCreateWebhook = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const response = await fetch('/api/webhooks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(webhookForm),
      })

      if (response.ok) {
        const newWebhook = await response.json()
        toast.success('Webhook created successfully')
        
        // Emit real-time event
        emitEvent('webhook:created', newWebhook)
        
        fetchData()
        setWebhookForm({ name: '', description: '', authorId: 'default-user' })
        setIsCreateWebhookDialogOpen(false)
      } else {
        const error = await response.json()
        toast.error(error.error || 'Failed to create webhook')
      }
    } catch (error) {
      toast.error('Error creating webhook')
    }
  }

  const handleCreateChannel = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const response = await fetch('/api/channels', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(channelForm),
      })

      if (response.ok) {
        const newChannel = await response.json()
        toast.success('Channel created successfully')
        
        // Emit real-time event
        emitEvent('channel:created', newChannel)
        
        fetchData()
        setChannelForm({ name: '', type: 'TELEGRAM', config: '', authorId: 'default-user' })
        setIsCreateChannelDialogOpen(false)
      } else {
        const error = await response.json()
        toast.error(error.error || 'Failed to create channel')
      }
    } catch (error) {
      toast.error('Error creating channel')
    }
  }

  const handleCopyEndpoint = (endpoint: string) => {
    const fullUrl = `${window.location.origin}${endpoint}`
    navigator.clipboard.writeText(fullUrl)
    toast.success('Webhook URL copied to clipboard')
  }

  const handleCopySecretKey = (secretKey: string) => {
    navigator.clipboard.writeText(secretKey)
    toast.success('Secret key copied to clipboard')
  }

  const handleEditWebhook = (webhook: Webhook) => {
    setSelectedWebhook(webhook)
    setEditWebhookForm({
      name: webhook.name,
      description: webhook.description || '',
      isActive: webhook.isActive
    })
    setIsEditWebhookDialogOpen(true)
  }

  const handleUpdateWebhook = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!selectedWebhook) return
    
    try {
      const response = await fetch(`/api/webhooks/${selectedWebhook.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editWebhookForm),
      })

      if (response.ok) {
        const updatedWebhook = await response.json()
        toast.success('Webhook updated successfully')
        
        // Emit real-time event
        emitEvent('webhook:updated', updatedWebhook)
        
        fetchData()
        setIsEditWebhookDialogOpen(false)
        setSelectedWebhook(null)
      } else {
        const error = await response.json()
        toast.error(error.error || 'Failed to update webhook')
      }
    } catch (error) {
      toast.error('Error updating webhook')
    }
  }

  const handleDeleteWebhook = async (webhookId: string) => {
    if (!confirm('Are you sure you want to delete this webhook? This action cannot be undone.')) {
      return
    }
    
    try {
      const response = await fetch(`/api/webhooks/${webhookId}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        const deletedWebhook = await response.json()
        toast.success('Webhook deleted successfully')
        
        // Emit real-time event
        emitEvent('webhook:deleted', deletedWebhook)
        
        fetchData()
      } else {
        const error = await response.json()
        toast.error(error.error || 'Failed to delete webhook')
      }
    } catch (error) {
      toast.error('Error deleting webhook')
    }
  }

  const handleRegenerateSecretKey = async (webhookId: string) => {
    if (!confirm('Are you sure you want to regenerate the secret key? This will invalidate any existing integrations using the current key.')) {
      return
    }
    
    try {
      const response = await fetch(`/api/webhooks/${webhookId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ regenerateSecret: true }),
      })

      if (response.ok) {
        toast.success('Secret key regenerated successfully')
        fetchData()
      } else {
        const error = await response.json()
        toast.error(error.error || 'Failed to regenerate secret key')
      }
    } catch (error) {
      toast.error('Error regenerating secret key')
    }
  }

  const handleWebhookSelection = (webhookId: string, checked: boolean) => {
    if (checked) {
      setSelectedWebhooks([...selectedWebhooks, webhookId])
    } else {
      setSelectedWebhooks(selectedWebhooks.filter(id => id !== webhookId))
    }
  }

  const handleSelectAllWebhooks = (checked: boolean) => {
    if (checked) {
      setSelectedWebhooks(filteredWebhooks.map(w => w.id))
    } else {
      setSelectedWebhooks([])
    }
  }

  const handleBulkAction = async (action: 'activate' | 'deactivate' | 'delete') => {
    if (selectedWebhooks.length === 0) {
      toast.error('No webhooks selected')
      return
    }

    const actionMessages = {
      activate: 'activate selected webhooks',
      deactivate: 'deactivate selected webhooks',
      delete: 'delete selected webhooks'
    }

    if (!confirm(`Are you sure you want to ${actionMessages[action]}?`)) {
      return
    }

    try {
      const response = await fetch('/api/webhooks/bulk', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action,
          webhookIds: selectedWebhooks
        }),
      })

      if (response.ok) {
        const result = await response.json()
        toast.success(`${actionMessages[action]} completed successfully (${result.affectedCount} affected)`)        
        fetchData()
        setSelectedWebhooks([])
      } else {
        const error = await response.json()
        toast.error(error.error || `Failed to ${actionMessages[action]}`)
      }
    } catch (error) {
      toast.error(`Error performing bulk ${action}`)
    }
  }

  const toggleWebhookStatus = async (webhookId: string, currentStatus: boolean) => {
    try {
      const response = await fetch(`/api/webhooks/${webhookId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isActive: !currentStatus }),
      })

      if (response.ok) {
        toast.success(`Webhook ${!currentStatus ? 'activated' : 'deactivated'} successfully`)
        fetchData()
      } else {
        toast.error('Failed to update webhook status')
      }
    } catch (error) {
      toast.error('Error updating webhook status')
    }
  }

  const getChannelConfigTemplate = (type: string) => {
    switch (type) {
      case 'TELEGRAM':
        return JSON.stringify({
          botToken: "YOUR_BOT_TOKEN",
          chatId: "YOUR_CHAT_ID"
        }, null, 2)
      case 'DISCORD':
        return JSON.stringify({
          webhookUrl: "YOUR_DISCORD_WEBHOOK_URL"
        }, null, 2)
      case 'SLACK':
        return JSON.stringify({
          webhookUrl: "YOUR_SLACK_WEBHOOK_URL"
        }, null, 2)
      case 'EMAIL':
        return JSON.stringify({
          smtp: {
            host: "smtp.gmail.com",
            port: 587,
            username: "your_email@gmail.com",
            password: "your_password"
          },
          to: "recipient@example.com",
          from: "your_email@gmail.com"
        }, null, 2)
      case 'TWITTER':
        return JSON.stringify({
          apiKey: "YOUR_API_KEY",
          apiSecret: "YOUR_API_SECRET",
          accessToken: "YOUR_ACCESS_TOKEN",
          accessTokenSecret: "YOUR_ACCESS_TOKEN_SECRET"
        }, null, 2)
      case 'WHATSAPP':
        return JSON.stringify({
          apiKey: "YOUR_WHATSAPP_API_KEY",
          phoneNumberId: "YOUR_PHONE_NUMBER_ID",
          businessAccountId: "YOUR_BUSINESS_ACCOUNT_ID",
          recipientNumber: "1234567890"
        }, null, 2)
      default:
        return '{}'
    }
  }

  const filteredWebhooks = webhooks.filter(webhook => {
    const matchesSearch = webhook.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         webhook.description?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || 
                          (statusFilter === 'active' && webhook.isActive) ||
                          (statusFilter === 'inactive' && !webhook.isActive)
    return matchesSearch && matchesStatus
  })

  const filteredChannels = channels.filter(channel => {
    const matchesSearch = channel.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || 
                          (statusFilter === 'active' && channel.isActive) ||
                          (statusFilter === 'inactive' && !channel.isActive)
    return matchesSearch && matchesStatus
  })

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-slate-900 dark:via-blue-900 dark:to-indigo-900">
        <div className="text-center max-w-md mx-auto">
          <div className="relative">
            <div className="animate-spin rounded-full h-20 w-20 border-4 border-blue-200 dark:border-blue-800 mx-auto mb-6"></div>
            <div className="animate-spin rounded-full h-20 w-20 border-4 border-blue-600 dark:border-blue-400 border-t-transparent mx-auto mb-6 absolute top-0 left-1/2 transform -translate-x-1/2"></div>
          </div>
          <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
            Loading Dashboard
          </h2>
          <p className="text-muted-foreground text-lg">
            Please wait while we fetch your data...
          </p>
          <div className="mt-6 space-y-2">
            <div className="h-2 bg-blue-200 dark:bg-blue-800 rounded-full overflow-hidden">
              <div className="h-full bg-blue-600 dark:bg-blue-400 rounded-full animate-pulse w-3/4"></div>
            </div>
            <div className="h-2 bg-blue-200 dark:bg-blue-800 rounded-full overflow-hidden">
              <div className="h-full bg-blue-600 dark:bg-blue-400 rounded-full animate-pulse w-1/2"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-slate-900 dark:via-blue-900 dark:to-indigo-900">
      <div className="container mx-auto p-4 md:p-6 max-w-7xl">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 space-y-4 md:space-y-0">
          <div className="text-center md:text-left">
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent mb-2">
              TradingView Webhook Manager
            </h1>
            <p className="text-muted-foreground text-lg md:text-xl">
              Manage TradingView alerts and notification channels with ease
            </p>
          </div>
          <div className="flex flex-wrap gap-2 justify-center md:justify-start">
            <Button variant="outline" onClick={fetchData} className="hover:bg-blue-50 dark:hover:bg-blue-950">
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh
            </Button>
            {activeTab === 'webhooks' && (
              <Dialog open={isCreateWebhookDialogOpen} onOpenChange={setIsCreateWebhookDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                    <Plus className="mr-2 h-4 w-4" />
                    New Webhook
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle>Create New Webhook</DialogTitle>
                    <DialogDescription>
                      Create a new webhook endpoint to receive TradingView alerts
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateWebhook}>
                    <div className="grid gap-4 py-4">
                      <div>
                        <Label htmlFor="webhook-name">Name</Label>
                        <Input
                          id="webhook-name"
                          value={webhookForm.name}
                          onChange={(e) => setWebhookForm({ ...webhookForm, name: e.target.value })}
                          required
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="webhook-description">Description</Label>
                        <Textarea
                          id="webhook-description"
                          value={webhookForm.description}
                          onChange={(e) => setWebhookForm({ ...webhookForm, description: e.target.value })}
                          placeholder="Optional description"
                          className="mt-1"
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setIsCreateWebhookDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button type="submit">Create Webhook</Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            )}

            {/* Edit Webhook Dialog */}
            <Dialog open={isEditWebhookDialogOpen} onOpenChange={setIsEditWebhookDialogOpen}>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Edit Webhook</DialogTitle>
                  <DialogDescription>
                    Update webhook configuration and settings
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleUpdateWebhook}>
                  <div className="grid gap-4 py-4">
                    <div>
                      <Label htmlFor="edit-webhook-name">Name</Label>
                      <Input
                        id="edit-webhook-name"
                        value={editWebhookForm.name}
                        onChange={(e) => setEditWebhookForm({ ...editWebhookForm, name: e.target.value })}
                        required
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="edit-webhook-description">Description</Label>
                      <Textarea
                        id="edit-webhook-description"
                        value={editWebhookForm.description}
                        onChange={(e) => setEditWebhookForm({ ...editWebhookForm, description: e.target.value })}
                        placeholder="Optional description"
                        className="mt-1"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="edit-webhook-active"
                        checked={editWebhookForm.isActive}
                        onCheckedChange={(checked) => setEditWebhookForm({ ...editWebhookForm, isActive: checked })}
                      />
                      <Label htmlFor="edit-webhook-active">Active</Label>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setIsEditWebhookDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">Update Webhook</Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
            {activeTab === 'channels' && (
              <Dialog open={isCreateChannelDialogOpen} onOpenChange={setIsCreateChannelDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700">
                    <Plus className="mr-2 h-4 w-4" />
                    New Channel
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Create New Channel</DialogTitle>
                    <DialogDescription>
                      Add a new notification channel for alerts
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateChannel}>
                    <div className="grid gap-4 py-4">
                      <div>
                        <Label htmlFor="channel-name">Name</Label>
                        <Input
                          id="channel-name"
                          value={channelForm.name}
                          onChange={(e) => setChannelForm({ ...channelForm, name: e.target.value })}
                          required
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="channel-type">Type</Label>
                        <Select
                          value={channelForm.type}
                          onValueChange={(value: any) => {
                            setChannelForm({ 
                              ...channelForm, 
                              type: value,
                              config: getChannelConfigTemplate(value)
                            })
                          }}
                        >
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="TELEGRAM">📱 Telegram</SelectItem>
                            <SelectItem value="DISCORD">💬 Discord</SelectItem>
                            <SelectItem value="SLACK">🔔 Slack</SelectItem>
                            <SelectItem value="EMAIL">📧 Email</SelectItem>
                            <SelectItem value="TWITTER">🐦 Twitter</SelectItem>
                            <SelectItem value="WHATSAPP">💚 WhatsApp</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="channel-config">Configuration</Label>
                        <Textarea
                          id="channel-config"
                          value={channelForm.config}
                          onChange={(e) => setChannelForm({ ...channelForm, config: e.target.value })}
                          placeholder={getChannelConfigTemplate(channelForm.type)}
                          rows={8}
                          required
                          className="mt-1 font-mono text-sm"
                        />
                        <p className="text-sm text-muted-foreground mt-2">
                          Enter configuration as JSON
                        </p>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setIsCreateChannelDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button type="submit">Create Channel</Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 mb-8 bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm p-1 rounded-lg">
            <TabsTrigger value="dashboard" className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Dashboard</span>
              <span className="sm:hidden">Stats</span>
            </TabsTrigger>
            <TabsTrigger value="webhooks" className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800">
              <Zap className="h-4 w-4" />
              <span className="hidden sm:inline">Webhooks</span>
              <span className="sm:hidden">Hooks</span>
            </TabsTrigger>
            <TabsTrigger value="channels" className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800">
              <Bell className="h-4 w-4" />
              <span className="hidden sm:inline">Channels</span>
              <span className="sm:hidden">Alerts</span>
            </TabsTrigger>
            <TabsTrigger value="alerts" className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800">
              <Activity className="h-4 w-4" />
              <span className="hidden sm:inline">Alerts</span>
              <span className="sm:hidden">Logs</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800">
              <TrendingUp className="h-4 w-4" />
              <span className="hidden sm:inline">Analytics</span>
              <span className="sm:hidden">Data</span>
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <RealTimeStats initialStats={stats} />
            
            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="shadow-md hover:shadow-lg transition-shadow duration-300">
                <CardHeader className="pb-4">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-lg">
                      <Activity className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    Recent Webhooks
                  </CardTitle>
                  <CardDescription className="text-sm">
                    Your recently created webhook endpoints
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {webhooks.slice(0, 5).map((webhook) => (
                      <div key={webhook.id} className="flex items-center justify-between p-3 bg-muted/30 hover:bg-muted/50 rounded-lg transition-colors duration-200">
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 rounded-full ${webhook.isActive ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{webhook.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(webhook.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <Badge variant={webhook.isActive ? "default" : "secondary"} className="text-xs">
                          {webhook.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                    ))}
                    {webhooks.length === 0 && (
                      <div className="text-center py-8">
                        <Zap className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
                        <p className="text-muted-foreground text-sm">
                          No webhooks created yet
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-md hover:shadow-lg transition-shadow duration-300">
                <CardHeader className="pb-4">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <div className="bg-green-100 dark:bg-green-900 p-2 rounded-lg">
                      <Bell className="h-5 w-5 text-green-600 dark:text-green-400" />
                    </div>
                    Recent Channels
                  </CardTitle>
                  <CardDescription className="text-sm">
                    Your recently configured notification channels
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {channels.slice(0, 5).map((channel) => (
                      <div key={channel.id} className="flex items-center justify-between p-3 bg-muted/30 hover:bg-muted/50 rounded-lg transition-colors duration-200">
                        <div className="flex items-center gap-3">
                          <span className="text-lg">{channelTypeIcons[channel.type]}</span>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{channel.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {channel.type} • {channel._count.deliveries} deliveries
                            </p>
                          </div>
                        </div>
                        <Badge variant={channel.isActive ? "default" : "secondary"} className="text-xs">
                          {channel.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                    ))}
                    {channels.length === 0 && (
                      <div className="text-center py-8">
                        <Bell className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
                        <p className="text-muted-foreground text-sm">
                          No channels configured yet
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Webhooks Tab */}
          <TabsContent value="webhooks" className="space-y-6">
            {/* Bulk Actions */}
            {selectedWebhooks.length > 0 && (
              <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950 dark:border-blue-800 shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-blue-800 dark:text-blue-200">
                        {selectedWebhooks.length} webhook{selectedWebhooks.length !== 1 ? 's' : ''} selected
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleBulkAction('activate')}
                        className="hover:bg-green-50 hover:text-green-700 hover:border-green-300"
                      >
                        <Play className="mr-1 h-3 w-3" />
                        <span className="hidden sm:inline">Activate</span>
                        <span className="sm:hidden">On</span>
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleBulkAction('deactivate')}
                        className="hover:bg-orange-50 hover:text-orange-700 hover:border-orange-300"
                      >
                        <Pause className="mr-1 h-3 w-3" />
                        <span className="hidden sm:inline">Deactivate</span>
                        <span className="sm:hidden">Off</span>
                      </Button>
                      <Button 
                        size="sm" 
                        variant="destructive"
                        onClick={() => handleBulkAction('delete')}
                        className="hover:bg-red-600"
                      >
                        <Trash2 className="mr-1 h-3 w-3" />
                        <span className="hidden sm:inline">Delete</span>
                        <span className="sm:hidden">Del</span>
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={() => setSelectedWebhooks([])}
                        className="hover:bg-gray-100 dark:hover:bg-gray-800"
                      >
                        Clear
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Search and Filter */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search webhooks..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-[180px] h-10">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">🔍 All Status</SelectItem>
                  <SelectItem value="active">✅ Active</SelectItem>
                  <SelectItem value="inactive">⏸️ Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Select All */}
            {filteredWebhooks.length > 0 && (
              <div className="flex items-center gap-2 text-sm p-3 bg-muted/30 rounded-lg">
                <input
                  type="checkbox"
                  id="select-all"
                  checked={selectedWebhooks.length === filteredWebhooks.length && filteredWebhooks.length > 0}
                  onChange={(e) => handleSelectAllWebhooks(e.target.checked)}
                  className="rounded border-gray-300 h-4 w-4 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="select-all" className="text-muted-foreground cursor-pointer">
                  Select all ({filteredWebhooks.length} webhook{filteredWebhooks.length !== 1 ? 's' : ''})
                </label>
              </div>
            )}

            {/* Webhooks Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
              {filteredWebhooks.map((webhook) => (
                <Card key={webhook.id} className="h-fit hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 relative group">
                  {/* Selection Checkbox */}
                  <div className="absolute top-2 left-2 z-10">
                    <input
                      type="checkbox"
                      checked={selectedWebhooks.includes(webhook.id)}
                      onChange={(e) => handleWebhookSelection(webhook.id, e.target.checked)}
                      className="rounded border-gray-300 bg-white/90 backdrop-blur-sm h-4 w-4 text-blue-600 focus:ring-blue-500"
                    />
                  </div>
                  
                  <CardHeader className="pb-3 pl-8 pr-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-base md:text-lg flex items-center gap-2 flex-wrap">
                          <span className="truncate">{webhook.name}</span>
                          <Badge variant={webhook.isActive ? "default" : "secondary"} className="text-xs shrink-0">
                            {webhook.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </CardTitle>
                        {webhook.description && (
                          <CardDescription className="mt-1 text-sm line-clamp-2">
                            {webhook.description}
                          </CardDescription>
                        )}
                      </div>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopyEndpoint(webhook.endpoint)}
                          className="h-8 w-8 p-0"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditWebhook(webhook)}
                          className="h-8 w-8 p-0"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleWebhookStatus(webhook.id, webhook.isActive)}
                          className="h-8 w-8 p-0"
                        >
                          {webhook.isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm font-medium mb-1 text-muted-foreground">Endpoint</p>
                        <code className="text-xs bg-muted p-2 rounded block overflow-x-auto font-mono">
                          {webhook.endpoint}
                        </code>
                      </div>
                      <div>
                        <p className="text-sm font-medium mb-1 text-muted-foreground">Secret Key</p>
                        <div className="flex items-start gap-2">
                          <code className="text-xs bg-muted p-2 rounded block overflow-x-auto flex-1 font-mono">
                            {webhook.secretKey}
                          </code>
                          <div className="flex flex-col gap-1 shrink-0">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleCopySecretKey(webhook.secretKey)}
                              className="h-6 w-6 p-0"
                              title="Copy secret key"
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRegenerateSecretKey(webhook.id)}
                              className="h-6 w-6 p-0 text-orange-600 hover:text-orange-700"
                              title="Regenerate secret key"
                            >
                              <RefreshCw className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-medium mb-1 text-muted-foreground">Channels</p>
                        <div className="flex flex-wrap gap-1">
                          {webhook.channels.length > 0 ? (
                            webhook.channels.map((wc) => (
                              <Badge
                                key={wc.id}
                                variant="outline"
                                className={`text-xs ${channelTypeColors[wc.channel.type]}`}
                              >
                                {channelTypeIcons[wc.channel.type]} {wc.channel.name}
                              </Badge>
                            ))
                          ) : (
                            <span className="text-xs text-muted-foreground">No channels configured</span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center justify-between text-sm pt-2 border-t">
                        <span className="text-muted-foreground">
                          {webhook._count.alerts} alert{webhook._count.alerts !== 1 ? 's' : ''}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">
                            {new Date(webhook.updatedAt).toLocaleDateString()}
                          </span>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteWebhook(webhook.id)}
                            className="h-6 w-6 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            title="Delete webhook"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Pagination */}
            {filteredWebhooks.length > 0 && (
              <Pagination
                currentPage={webhooksPagination.page}
                totalPages={webhooksPagination.totalPages}
                totalItems={webhooksPagination.totalItems}
                itemsPerPage={webhooksPagination.itemsPerPage}
                onPageChange={handleWebhooksPageChange}
                onItemsPerPageChange={handleWebhooksItemsPerPageChange}
              />
            )}

            {filteredWebhooks.length === 0 && (
              <div className="text-center py-12">
                <Zap className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No webhooks found</h3>
                <p className="text-muted-foreground mb-4">
                  {searchTerm || statusFilter !== 'all' 
                    ? 'Try adjusting your search or filters'
                    : 'Get started by creating your first webhook endpoint'
                  }
                </p>
                {(!searchTerm && statusFilter === 'all') && (
                  <Button onClick={() => setIsCreateWebhookDialogOpen(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Create Webhook
                  </Button>
                )}
              </div>
            )}
          </TabsContent>

          {/* Channels Tab */}
          <TabsContent value="channels" className="space-y-6">
            {/* Search and Filter */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search channels..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-[180px] h-10">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">🔍 All Status</SelectItem>
                  <SelectItem value="active">✅ Active</SelectItem>
                  <SelectItem value="inactive">⏸️ Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Channels Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
              {filteredChannels.map((channel) => (
                <Card key={channel.id} className="h-fit hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 group">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-base md:text-lg flex items-center gap-2 flex-wrap">
                          <span className="text-lg md:text-xl">{channelTypeIcons[channel.type]}</span>
                          <span className="truncate">{channel.name}</span>
                          <Badge variant={channel.isActive ? "default" : "secondary"} className="text-xs shrink-0">
                            {channel.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </CardTitle>
                      </div>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm font-medium mb-1 text-muted-foreground">Type</p>
                        <Badge className={`${channelTypeColors[channel.type]} text-xs`}>
                          {channelTypeIcons[channel.type]} {channel.type}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-sm font-medium mb-1 text-muted-foreground">Configuration</p>
                        <pre className="text-xs bg-muted p-2 rounded overflow-x-auto max-h-24 font-mono">
                          {channel.config.substring(0, 200)}{channel.config.length > 200 ? '...' : ''}
                        </pre>
                      </div>
                      <div className="flex items-center justify-between text-sm pt-2 border-t">
                        <span className="text-muted-foreground flex items-center gap-1">
                          <Send className="h-3 w-3" />
                          {channel._count.deliveries} deliver{channel._count.deliveries !== 1 ? 'ies' : 'y'}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {new Date(channel.updatedAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Pagination */}
            {filteredChannels.length > 0 && (
              <Pagination
                currentPage={channelsPagination.page}
                totalPages={channelsPagination.totalPages}
                totalItems={channelsPagination.totalItems}
                itemsPerPage={channelsPagination.itemsPerPage}
                onPageChange={handleChannelsPageChange}
                onItemsPerPageChange={handleChannelsItemsPerPageChange}
              />
            )}

            {filteredChannels.length === 0 && (
              <div className="text-center py-12">
                <div className="bg-green-100 dark:bg-green-900 p-4 rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                  <Bell className="h-10 w-10 text-green-600 dark:text-green-400" />
                </div>
                <h3 className="text-xl font-semibold mb-2">No channels found</h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  {searchTerm || statusFilter !== 'all' 
                    ? 'Try adjusting your search or filters to find what you\'re looking for'
                    : 'Get started by creating your first notification channel'
                  }
                </p>
                {(!searchTerm && statusFilter === 'all') && (
                  <Button onClick={() => setIsCreateChannelDialogOpen(true)} className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700">
                    <Plus className="mr-2 h-4 w-4" />
                    Create Channel
                  </Button>
                )}
              </div>
            )}
          </TabsContent>

          {/* Alerts Tab */}
          <TabsContent value="alerts" className="space-y-6">
            {/* Alert Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Alerts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalAlerts}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {stats.recentAlerts} in last 24h
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{stats.successRate}%</div>
                  <Progress value={stats.successRate} className="mt-2 h-2" />
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Active Webhooks</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.activeWebhooks}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {stats.totalWebhooks} total
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Active Channels</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.activeChannels}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {stats.totalChannels} total
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Filters */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search alerts..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-[180px] h-10">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">🔍 All Status</SelectItem>
                  <SelectItem value="RECEIVED">📥 Received</SelectItem>
                  <SelectItem value="PROCESSING">⚙️ Processing</SelectItem>
                  <SelectItem value="DELIVERED">✅ Delivered</SelectItem>
                  <SelectItem value="FAILED">❌ Failed</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" onClick={fetchAlerts} className="h-10">
                <RefreshCw className="mr-2 h-4 w-4" />
                Refresh
              </Button>
            </div>

            {/* Alerts List */}
            <div className="space-y-4">
              {isLoadingAlerts ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <div className="relative mb-4">
                    <div className="animate-spin rounded-full h-12 w-12 border-4 border-orange-200 dark:border-orange-800"></div>
                    <div className="animate-spin rounded-full h-12 w-12 border-4 border-orange-600 dark:border-orange-400 border-t-transparent absolute top-0 left-0"></div>
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Loading Alerts</h3>
                  <p className="text-muted-foreground text-sm">
                    Fetching your alert history...
                  </p>
                </div>
              ) : alerts.length > 0 ? (
                alerts.map((alert) => (
                  <Card key={alert.id} className="hover:shadow-md transition-shadow duration-200">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={statusColors[alert.status]}>
                              {alert.status}
                            </Badge>
                            <span className="text-sm text-muted-foreground">
                              {new Date(alert.createdAt).toLocaleString()}
                            </span>
                          </div>
                          <CardTitle className="text-base flex items-center gap-2">
                            <Zap className="h-4 w-4" />
                            {alert.webhook.name}
                          </CardTitle>
                          <CardDescription className="mt-1">
                            {alert.message}
                          </CardDescription>
                        </div>
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <p className="text-sm font-medium mb-1">Endpoint</p>
                          <code className="text-xs bg-muted p-2 rounded block overflow-x-auto">
                            {alert.webhook.endpoint}
                          </code>
                        </div>
                        
                        {alert.deliveries.length > 0 && (
                          <div>
                            <p className="text-sm font-medium mb-2">Deliveries</p>
                            <div className="space-y-2">
                              {alert.deliveries.map((delivery) => (
                                <div key={delivery.id} className="flex items-center justify-between p-2 bg-muted/50 rounded">
                                  <div className="flex items-center gap-2">
                                    <span className="text-sm">{channelTypeIcons[delivery.channel.type]}</span>
                                    <span className="text-sm font-medium">{delivery.channel.name}</span>
                                    <Badge 
                                      variant="outline" 
                                      className={`text-xs ${
                                        delivery.status === 'SENT' ? 'border-green-200 text-green-700' :
                                        delivery.status === 'FAILED' ? 'border-red-200 text-red-700' :
                                        'border-yellow-200 text-yellow-700'
                                      }`}
                                    >
                                      {delivery.status}
                                    </Badge>
                                  </div>
                                  {delivery.sentAt && (
                                    <span className="text-xs text-muted-foreground">
                                      {new Date(delivery.sentAt).toLocaleTimeString()}
                                    </span>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>ID: {alert.id}</span>
                          <span>By: {alert.author.name || alert.author.email}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-12">
                  <Activity className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No alerts found</h3>
                  <p className="text-muted-foreground mb-4">
                    {searchTerm || statusFilter !== 'all' 
                      ? 'Try adjusting your search or filters'
                      : 'Alerts will appear here when webhooks receive data'
                    }
                  </p>
                </div>
              )}
            </div>

            {/* Pagination */}
            {alerts.length > 0 && (
              <Pagination
                currentPage={alertsPagination.page}
                totalPages={alertsPagination.totalPages}
                totalItems={alertsPagination.totalItems}
                itemsPerPage={alertsPagination.itemsPerPage}
                onPageChange={handleAlertsPageChange}
                onItemsPerPageChange={handleAlertsItemsPerPageChange}
              />
            )}
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <AdvancedAnalytics />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}