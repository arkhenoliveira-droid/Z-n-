'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Zap, Bell, Activity, TrendingUp, Clock, Users } from 'lucide-react'
import { useRealTimeUpdates } from '@/hooks/useRealTimeUpdates'

interface DashboardStats {
  totalWebhooks: number
  activeWebhooks: number
  totalChannels: number
  activeChannels: number
  totalAlerts: number
  recentAlerts: number
  successRate: number
}

interface RealTimeStatsProps {
  initialStats: DashboardStats
}

export default function RealTimeStats({ initialStats }: RealTimeStatsProps) {
  const [stats, setStats] = useState<DashboardStats>(initialStats)
  const [recentActivity, setRecentActivity] = useState<Array<{
    type: string
    action: string
    message: string
    timestamp: string
  }>>([])
  const { isConnected, lastEvent } = useRealTimeUpdates()

  useEffect(() => {
    if (lastEvent) {
      // Update stats based on the event
      setStats(prevStats => {
        const newStats = { ...prevStats }
        
        switch (lastEvent.type) {
          case 'webhook':
            if (lastEvent.action === 'created') {
              newStats.totalWebhooks++
              newStats.activeWebhooks++
            } else if (lastEvent.action === 'deleted') {
              newStats.totalWebhooks--
              if (lastEvent.data.isActive) {
                newStats.activeWebhooks--
              }
            } else if (lastEvent.action === 'updated') {
              if (lastEvent.data.isActive !== undefined) {
                if (lastEvent.data.isActive) {
                  newStats.activeWebhooks++
                } else {
                  newStats.activeWebhooks--
                }
              }
            }
            break
            
          case 'channel':
            if (lastEvent.action === 'created') {
              newStats.totalChannels++
              newStats.activeChannels++
            } else if (lastEvent.action === 'deleted') {
              newStats.totalChannels--
              if (lastEvent.data.isActive) {
                newStats.activeChannels--
              }
            } else if (lastEvent.action === 'updated') {
              if (lastEvent.data.isActive !== undefined) {
                if (lastEvent.data.isActive) {
                  newStats.activeChannels++
                } else {
                  newStats.activeChannels--
                }
              }
            }
            break
            
          case 'alert':
            if (lastEvent.action === 'received') {
              newStats.totalAlerts++
              newStats.recentAlerts++
            } else if (lastEvent.action === 'delivered') {
              // Update success rate
              const successRate = Math.min(100, newStats.successRate + 1)
              newStats.successRate = successRate
            } else if (lastEvent.action === 'failed') {
              // Update success rate
              const successRate = Math.max(0, newStats.successRate - 2)
              newStats.successRate = successRate
            }
            break
            
          case 'stats':
            if (lastEvent.data) {
              Object.assign(newStats, lastEvent.data)
            }
            break
        }
        
        return newStats
      })

      // Add to recent activity
      setRecentActivity(prev => {
        const activity = {
          type: lastEvent.type,
          action: lastEvent.action,
          message: getActivityMessage(lastEvent),
          timestamp: lastEvent.timestamp
        }
        
        // Keep only last 10 activities
        return [activity, ...prev].slice(0, 10)
      })
    }
  }, [lastEvent])

  const getActivityMessage = (event: any) => {
    switch (event.type) {
      case 'webhook':
        return `Webhook "${event.data.name}" ${event.action}`
      case 'channel':
        return `Channel "${event.data.name}" ${event.action}`
      case 'alert':
        return `Alert ${event.action} for webhook "${event.data.webhookName}"`
      default:
        return `${event.type} ${event.action}`
    }
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'webhook': return <Zap className="h-3 w-3" />
      case 'channel': return <Bell className="h-3 w-3" />
      case 'alert': return <Activity className="h-3 w-3" />
      default: return <TrendingUp className="h-3 w-3" />
    }
  }

  const getActivityColor = (action: string) => {
    switch (action) {
      case 'created': return 'bg-green-100 text-green-800 border-green-200'
      case 'updated': return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'deleted': return 'bg-red-100 text-red-800 border-red-200'
      case 'received': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'delivered': return 'bg-green-100 text-green-800 border-green-200'
      case 'failed': return 'bg-red-100 text-red-800 border-red-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  return (
    <div className="space-y-6">
      {/* Connection Status */}
      <Card className="border-l-4 border-l-blue-500">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className="text-sm font-medium">
                Real-time Updates {isConnected ? 'Active' : 'Disconnected'}
              </span>
            </div>
            {recentActivity.length > 0 && (
              <Badge variant="outline" className="text-xs">
                {recentActivity.length} recent activities
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-100 flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Total Webhooks
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{stats.totalWebhooks}</div>
              <div className="bg-blue-400/20 p-2 rounded-lg">
                <Zap className="h-6 w-6 text-blue-200" />
              </div>
            </div>
            <p className="text-xs text-blue-100 mt-2 flex items-center gap-1">
              <div className={`w-2 h-2 rounded-full ${stats.activeWebhooks > 0 ? 'bg-green-300' : 'bg-gray-300'}`}></div>
              {stats.activeWebhooks} active
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500 to-emerald-600 text-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-100 flex items-center gap-2">
              <Bell className="h-4 w-4" />
              Active Channels
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{stats.activeChannels}</div>
              <div className="bg-green-400/20 p-2 rounded-lg">
                <Bell className="h-6 w-6 text-green-200" />
              </div>
            </div>
            <p className="text-xs text-green-100 mt-2 flex items-center gap-1">
              <div className={`w-2 h-2 rounded-full ${stats.totalChannels > 0 ? 'bg-green-300' : 'bg-gray-300'}`}></div>
              {stats.totalChannels} total
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-violet-600 text-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-purple-100 flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Total Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{stats.totalAlerts}</div>
              <div className="bg-purple-400/20 p-2 rounded-lg">
                <Activity className="h-6 w-6 text-purple-200" />
              </div>
            </div>
            <p className="text-xs text-purple-100 mt-2 flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {stats.recentAlerts} recent
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500 to-amber-600 text-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-orange-100 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Success Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{stats.successRate}%</div>
              <div className="bg-orange-400/20 p-2 rounded-lg">
                <TrendingUp className="h-6 w-6 text-orange-200" />
              </div>
            </div>
            <div className="mt-2">
              <Progress value={stats.successRate} className="h-2 bg-orange-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      {recentActivity.length > 0 && (
        <Card className="shadow-md hover:shadow-lg transition-shadow duration-300">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-lg">
                <Activity className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              Real-time Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/30 hover:bg-muted/50 rounded-lg transition-colors duration-200">
                  <div className="flex items-center gap-3">
                    {getActivityIcon(activity.type)}
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{activity.message}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(activity.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                  <Badge variant="outline" className={`text-xs ${getActivityColor(activity.action)}`}>
                    {activity.action}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}