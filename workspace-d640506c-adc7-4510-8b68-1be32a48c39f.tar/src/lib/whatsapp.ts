interface WhatsAppConfig {
  apiKey: string
  phoneNumberId: string
  businessAccountId: string
  recipientNumber: string
}

interface WhatsAppMessage {
  to: string
  text: string
  type: 'text' | 'template'
  template?: {
    name: string
    language: string
    components?: Array<{
      type: string
      parameters?: Array<{
        type: string
        text?: string
      }>
    }>
  }
}

export class WhatsAppService {
  private config: WhatsAppConfig
  private baseUrl: string

  constructor(config: WhatsAppConfig) {
    this.config = config
    this.baseUrl = 'https://graph.facebook.com/v18.0'
  }

  async sendMessage(message: string): Promise<{ success: boolean; error?: string }> {
    try {
      const whatsappMessage: WhatsAppMessage = {
        to: this.config.recipientNumber,
        text: message,
        type: 'text'
      }

      const response = await fetch(
        `${this.baseUrl}/${this.config.phoneNumberId}/messages`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.config.apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            messaging_product: 'whatsapp',
            to: this.config.recipientNumber,
            text: {
              body: message
            }
          })
        }
      )

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(`WhatsApp API error: ${errorData.error?.message || response.statusText}`)
      }

      const result = await response.json()
      
      if (result.error) {
        throw new Error(`WhatsApp API error: ${result.error.message}`)
      }

      return { success: true }
    } catch (error) {
      console.error('WhatsApp send error:', error)
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }
    }
  }

  async sendTemplateMessage(
    templateName: string, 
    language: string = 'en_US',
    parameters?: Record<string, string>
  ): Promise<{ success: boolean; error?: string }> {
    try {
      const components = parameters ? [{
        type: 'body',
        parameters: Object.entries(parameters).map(([_, value]) => ({
          type: 'text',
          text: value
        }))
      }] : undefined

      const response = await fetch(
        `${this.baseUrl}/${this.config.phoneNumberId}/messages`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.config.apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            messaging_product: 'whatsapp',
            to: this.config.recipientNumber,
            type: 'template',
            template: {
              name: templateName,
              language: {
                code: language
              },
              components
            }
          })
        }
      )

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(`WhatsApp API error: ${errorData.error?.message || response.statusText}`)
      }

      const result = await response.json()
      
      if (result.error) {
        throw new Error(`WhatsApp API error: ${result.error.message}`)
      }

      return { success: true }
    } catch (error) {
      console.error('WhatsApp template send error:', error)
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }
    }
  }

  async verifyConfiguration(): Promise<{ success: boolean; error?: string }> {
    try {
      // Test with a simple verification message
      const testMessage = '🔔 TradingView Alert System Test - Configuration Verified'
      const result = await this.sendMessage(testMessage)
      
      return result
    } catch (error) {
      console.error('WhatsApp verification error:', error)
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }
    }
  }

  // Helper method to format alert messages for WhatsApp
  formatAlertMessage(alertData: {
    webhookName: string
    message: string
    timestamp: string
    severity?: 'low' | 'medium' | 'high' | 'critical'
  }): string {
    const { webhookName, message, timestamp, severity = 'medium' } = alertData
    
    const severityEmojis = {
      low: '🟢',
      medium: '🟡',
      high: '🟠',
      critical: '🔴'
    }

    const formattedTime = new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })

    return `${severityEmojis[severity]} *TradingView Alert*\n\n` +
           `*Source:* ${webhookName}\n` +
           `*Time:* ${formattedTime}\n\n` +
           `${message}\n\n` +
           `📱 Sent via WhatsApp Alert System`
  }

  // Helper method to send trading view alerts
  async sendTradingViewAlert(alertData: {
    webhookName: string
    message: string
    timestamp: string
    severity?: 'low' | 'medium' | 'high' | 'critical'
  }): Promise<{ success: boolean; error?: string }> {
    const formattedMessage = this.formatAlertMessage(alertData)
    return await this.sendMessage(formattedMessage)
  }
}

// Factory function to create WhatsApp service from channel config
export function createWhatsAppService(channelConfig: string): WhatsAppService {
  try {
    const config = JSON.parse(channelConfig) as WhatsAppConfig
    
    // Validate required fields
    if (!config.apiKey || !config.phoneNumberId || !config.businessAccountId || !config.recipientNumber) {
      throw new Error('Missing required WhatsApp configuration fields')
    }

    return new WhatsAppService(config)
  } catch (error) {
    throw new Error(`Invalid WhatsApp configuration: ${error instanceof Error ? error.message : 'Unknown error'}`)
  }
}